MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 946
AudioContainer CONTINUE
PlaySound 1426, SE1, 14, 8, 0, 115, 0, 0, 0
PlaySound 1426, SE2, 14, 10, -200, 100, 0, 0, 0
PlaySound 1445, SE2, 14, 12, 400, 110, 0, 0, 0
PlaySound 1452, SE1, 14, 16, 0, 115, 0, 0, 0
PlaySound 1452, SE2, 14, 32, 100, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 11, 0, 3, 3, 9
Emit 946, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 946, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 946, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 946, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 946, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 946, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 946, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 946, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 946, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 946, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 946, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 12
ChangeSpriteColor ATTACKER, 0, 10, 0, 31, 18, 6
ScaleSprite ATTACKER, ROUNDTRIP, -819, 1229, 5, 0, 1
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 8
Wait 16
ScaleSprite ATTACKER, ROUNDTRIP, -819, 1229, 5, 0, 1
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 8
Wait 18
ChangeSpriteColor ATTACKER, 10, 0, 0, 31, 18, 6
ChangeBackgroundColor 4, 11, 0, 0, 3, 3, 9
Wait 10
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
