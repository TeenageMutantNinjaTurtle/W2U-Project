import { createKit, deg, fadeInOut, grow, hold, paint, setCurves, spin, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, glow, intro, outro, ring, snd, sparks, squash, tint, USER, WHITE, type Pal } from "../tools/phrases";

// Power Shift (move 829) - from the Bulbapedia stills (reference/sheet.png).
//   1. Two orbs appear beside the user: a fiery orange one scored with
//      slashes (its attack) and a cool cyan one with hexagons floating off it
//      (its defence).
//   2. They cross over, changing sides.
//   3. They settle into one pale sphere round the user, both colours in it.
// Stays on the user; the stat swap is the engine's. The hexagon is drawn
// (generated/texture-hexagon.png).

const SPA = 1009;
const kit = await createKit({ workDir: import.meta.dirname, slug: "power-shift", moveId: 829, spaId: SPA, donors: [228, 465, 411, 298, 560] });

const CAMERA_IN = 10;
const SHOW = 18;
const CROSS = 12;
const SETTLE = 30;

const ORANGE: Rgb = [1.0, 0.6, 0.15];
const PALE_ORANGE: Rgb = [1.0, 0.88, 0.6];
const CYAN: Rgb = [0.35, 0.9, 1.0];
const PALE_CYAN: Rgb = [0.8, 0.97, 1.0];
const SIDE = 1.9;
const HEIGHT = 1.2;

// --- a hexagon outline: a white mask to be tinted ---
const hexTex = await kit.drawn("hexagon", 16, 16, "a5i3", (x, y) => {
  const dx = Math.abs(x + 0.5 - 8), dy = Math.abs(y + 0.5 - 8);
  const d = Math.max(dx * 0.866 + dy * 0.5, dy); // hexagonal distance
  if (d > 7) return undefined;
  return [255, 255, 255, d > 5.2 ? 255 : 110];
});

// An orb that shows on one side, then flies across to the other.
function orb(name: string, side: 1 | -1, colours: [Rgb, Rgb, Rgb]): string[] {
  const names: string[] = [];
  const at: Vec3 = [side * SIDE, HEIGHT, 0.6];
  for (const [layer, tex, scale, level, cols] of [["Core", kit.tex(T.softDisc), 0.7, 1, [colours[1], WHITE, colours[0]]], ["Glow", kit.tex(T.fuzzyGlow), 1.25, 0.8, colours]] as const) {
    const show = kit.parked(tex, at, scale, SHOW + 1);
    setCurves(show, grow(0.2, 0.4, 1.05), { start: 0, mid: level, end: level, curveIn: 0.3, curveOut: 1 });
    paint(show, cols[0] as Rgb, cols[1] as Rgb, cols[2] as Rgb);
    kit.add(`${name}${layer}Show`, show);
    const cross = kit.parked(tex, at, scale, CROSS + 1);
    cross.startDelayFrames = SHOW;
    cross.axis = [-side, 0, 0];
    cross.initVelAxisAmplifier = (2 * SIDE) / CROSS;
    // A lift, so the two pass over and under each other.
    cross.behaviors = [{ type: "gravity", magnitude: [0, side * 0.02, 0] }];
    setCurves(cross, hold(1.05), hold(level));
    paint(cross, cols[0] as Rgb, cols[1] as Rgb, cols[2] as Rgb);
    kit.add(`${name}${layer}Cross`, cross);
    names.push(`${name}${layer}Show`, `${name}${layer}Cross`);
  }
  return names;
}
const attack = orb("attack", -1, [ORANGE, PALE_ORANGE, [1.0, 0.4, 0.05]]);
const defence = orb("defence", 1, [CYAN, PALE_CYAN, [0.15, 0.6, 1.0]]);

// The attack orb's slashes and the defence orb's hexagons.
const slashes = [35, -35].map((angle, i) => {
  const r = kit.parked(kit.tex(T.streak), [-SIDE, HEIGHT, 0.7], 0.9, SHOW - 4);
  r.startDelayFrames = 4 + i * 2;
  r.aspectRatio = 0.2;
  r.initAngle = deg(90 + angle);
  setCurves(r, grow(0.2, 0.25, 1), fadeInOut(1, 0.1, 0.8));
  paint(r, WHITE, WHITE, PALE_ORANGE);
  kit.add(`slash${i}`, r);
  return `slash${i}`;
});
const SETTLED = SHOW + CROSS;
const user = [
  ...slashes,
  ...sparks(kit, "hexagons", { pos: [SIDE, HEIGHT, 0.7], at: 4, radius: 0.9, speed: 0.02, count: 1, bursts: (SHOW - 4) / 3, gap: 3, life: 12, scale: 0.3, pal: [PALE_CYAN, WHITE, CYAN], shape: "ball", tex: hexTex, twinkle: false }),
  ...attack, ...defence,
  // --- 3. one sphere ---
  ...sparks(kit, "mixedHex", { pos: [0, 0.6, 0.6], at: SETTLED + 2, radius: 1.8, speed: 0.02, count: 1, bursts: 7, gap: 3, life: 12, scale: 0.3, pal: [PALE_CYAN, PALE_ORANGE, WHITE], shape: "ball", tex: hexTex, twinkle: false }),
  ...ring(kit, "sphereRim", { pos: USER, at: SETTLED, life: SETTLE, scale: 2.4, pal: [PALE_ORANGE, WHITE, ORANGE], tex: kit.tex(T.ring), to: 1.04, level: 0.85 }),
  ...glow(kit, "sphere", { pos: USER, at: SETTLED, life: SETTLE, scale: 2.35, pal: [PALE_CYAN, WHITE, CYAN], tex: kit.tex(T.softDisc), level: 0.5, scaleCurve: grow(0.3, 0.25, 1.04) }),
  ...glow(kit, "meet", { pos: [0, HEIGHT, 0.6], at: SHOW + CROSS / 2 - 2, life: 8, scale: 1.3, pal: [WHITE, WHITE, PALE_CYAN], tex: kit.tex(T.spiky), spin: 0.15, level: 1 }),
];
setCurves(kit.resources[kit.idx("sphereRim")]!, grow(0.3, 0.25, 1.04), fadeInOut(0.85, 0.15, 0.8));

const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1510, 0, { vol: 105 }),
  snd(1510, 4, { ch: "SE2", pitch: 300, vol: 100 }),
  snd(1455, SHOW, { ch: "SE2", vol: 115 }),
  snd(1452, SETTLED, { vol: 110 }),
  snd(1784, SETTLED + 6, { ch: "SE2", pitch: 200, vol: 100 }),
)}
${emits(kit, user, "ATTACKER")}
Wait ${SETTLED}
${tint("ATTACKER", 0, 8, 4, [28, 30, 31])}
${squash("ATTACKER", -819, 819, 5)}
Wait ${SETTLE - 10}
${tint("ATTACKER", 8, 0, 6, [28, 30, 31])}
Wait 10
${outro({ unfreeze: "NONE" })}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 240, 129, 381, 163],
  references: ["reference/Power_Shift_LA.png", "reference/Power_Shift_IX.png", "reference/Power_Shift_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("attackCoreShow")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("defenceCoreCross")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("sphere")}, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  orbs f${CAMERA_IN}, cross f${CAMERA_IN + SHOW}-${CAMERA_IN + SETTLED}, sphere until f${CAMERA_IN + SETTLED + SETTLE}`);
