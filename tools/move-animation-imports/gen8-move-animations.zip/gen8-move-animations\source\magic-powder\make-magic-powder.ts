import { aimed, createKit, fadeInOut, grow, setCurves, spin, T, twinkle, type Rgb } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FRONT, glow, intro, outro, pan, puffs, ring, snd, sparks, squash, tint, WHITE, type Pal } from "../tools/phrases";

// Magic Powder (move 750) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user flicks a cloud of glittering powder at the foe: tiny cyan,
//      pink and white specks with four-point sparkles in it.
//   2. It settles over the foe.
//   3. The foe turns blue-violet (it becomes Psychic-type) inside a sweeping
//      blue swirl, sparkles popping round it.

const SPA = 948;
const kit = await createKit({ workDir: import.meta.dirname, slug: "magic-powder", moveId: 750, spaId: SPA, donors: [228, 465, 321, 298, 407] });

const CAMERA_IN = 10;
const FLICK = 10;
const TRAVEL = 14; // the powder drifts across
const SETTLE = 22;
const CHANGE = 30;

const CYAN: Rgb = [0.45, 0.95, 1.0];
const PINK: Rgb = [1.0, 0.55, 0.9];
const VIOLET: Rgb = [0.55, 0.4, 1.0];
const BLUE: Rgb = [0.25, 0.45, 1.0];
const PALE_BLUE: Rgb = [0.7, 0.85, 1.0];
const GLITTER: Pal = [CYAN, WHITE, PINK];

// --- 1. the flick and the drifting cloud ---
const user = [
  ...sparks(kit, "flick", { pos: FRONT, at: FLICK - 4, radius: 0.5, speed: 0.12, count: 3, bursts: 4, gap: 2, life: 10, scale: 0.11, pal: GLITTER }),
  ...glow(kit, "glint", { pos: FRONT, at: FLICK - 4, life: 9, scale: 0.7, pal: [WHITE, WHITE, CYAN], tex: kit.tex(T.star4Big), spin: 0.1, scaleCurve: twinkle(1.3), alpha: twinkle(1) }),
];
function cloud(name: string, tex: number, scale: number, count: number, gap: number): void {
  const r = kit.spray([333, 1], tex, FRONT, { radius: 0.9, speed: 0.02, count, bursts: 5, gap, life: TRAVEL + 2, scale, shape: "ball" });
  r.startDelayFrames = FLICK;
  aimed(r, 16 / TRAVEL, TRAVEL + 2);
  r.airResistance = 1.0;
  r.variance.lifeTime = 0;
  setCurves(r, undefined, twinkle());
  kit.prism(r, GLITTER);
  kit.add(name, r);
}
cloud("powder", kit.tex(T.dot), 0.12, 4, 2);
cloud("powderSparkles", kit.tex(T.sparkle4), 0.32, 1, 3);

// --- 2. settling over the foe, then 3. the change ---
const foe = [
  ...sparks(kit, "settling", { pos: [0, 1.0, 0.8], radius: 1.5, speed: 0.02, count: 4, bursts: 8, gap: 3, life: 16, scale: 0.12, pal: GLITTER, fall: 0.006, shape: "ball" }),
  ...sparks(kit, "twinkles", { pos: [0, 0.6, 0.9], radius: 1.6, speed: 0, count: 1, bursts: 8, gap: 4, life: 9, scale: 0.36, pal: [WHITE, CYAN, PINK], shape: "ball", tex: kit.tex(T.sparkle4) }),
  ...puffs(kit, "haze", { pos: FOE, radius: 0.9, count: 1, bursts: 5, gap: 4, life: 16, scale: 1.1, pal: [VIOLET, PINK, BLUE], level: 0.4 }),
  // The change: a blue swirl sweeping round the foe.
  ...ring(kit, "swirl", { pos: [0, -0.6, 0.6], at: SETTLE, life: 20, scale: 2.6, pal: [BLUE, PALE_BLUE, VIOLET], tex: kit.tex(T.swirlRings), spin: 0.14, aspect: 2.4, to: 1.25, level: 0.9 }),
  ...ring(kit, "swirl2", { pos: [0, 0.4, 0.6], at: SETTLE + 4, life: 18, scale: 2.0, pal: [PALE_BLUE, WHITE, BLUE], tex: kit.tex(T.swirlRings), spin: -0.12, aspect: 2.4, to: 1.25, level: 0.75 }),
  ...glow(kit, "blueGlow", { pos: FOE, at: SETTLE, life: CHANGE, scale: 2.8, pal: [BLUE, VIOLET, PALE_BLUE], level: 0.6 }),
  ...glow(kit, "flashStar", { pos: [-0.9, 0.2, 1.0], at: SETTLE + 3, life: 10, scale: 0.9, pal: [WHITE, WHITE, PALE_BLUE], tex: kit.tex(T.star4Big), spin: 0.08, scaleCurve: twinkle(1.3), alpha: twinkle(1) }),
  ...sparks(kit, "changed", { pos: FOE, at: SETTLE + 2, radius: 1.2, speed: 0.1, count: 3, bursts: 4, gap: 4, life: 12, scale: 0.13, pal: [PALE_BLUE, WHITE, PINK], fall: -0.004 }),
];

const landAt = FLICK + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1474, 0, { vol: 80 }),
  snd(1718, FLICK - 2, { ch: "SE2", pitch: 300, vol: 115 }),
  `SwitchAudioSide SE2, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0`,
  snd(1463, landAt, { side: "D", pitch: 300, vol: 100 }),
  snd(1784, landAt + SETTLE, { ch: "SE2", side: "D", vol: 110 }),
  snd(1509, landAt + SETTLE + 4, { side: "D", pitch: 600, vol: 90 }),
)}
${arena(0, 7, 8, [3, 5, 14])}
${emits(kit, user, "ATTACKER")}
${emits(kit, ["powder", "powderSparkles"], "ATTACKER", "DEFENDER")}
Wait ${FLICK - 4}
${squash("ATTACKER", 819, -819, 4)}
Wait 4
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
Wait ${SETTLE}
ToggleFreezeSprite DEFENDER, START
${tint("DEFENDER", 0, 12, 6, [10, 9, 31])}
${squash("DEFENDER", -819, 819, 5)}
Wait ${CHANGE - 10}
${tint("DEFENDER", 12, 0, 8, [10, 9, 31])}
${arena(7, 0, 8, [3, 5, 14])}
Wait 10
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 153, 129, 236],
  references: ["reference/Magic_Powder_VIII.png", "reference/Magic_Powder_VIII_2.png", "reference/Magic_Powder_IX.png", "reference/Magic_Powder_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("powder")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("swirl")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  flick f${CAMERA_IN + FLICK - 4}, powder lands f${CAMERA_IN + landAt}, change f${CAMERA_IN + landAt + SETTLE}`);
