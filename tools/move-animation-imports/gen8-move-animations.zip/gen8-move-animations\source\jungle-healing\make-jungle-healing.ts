import { createKit, fadeInOut, fadeOut, grow, hold, setCurves, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, circleEmits, emits, glow, intro, outro, ring, risers, snd, sparks, squash, tint, USER, USER_FLOOR, vortex, WHITE, type Pal } from "../tools/phrases";

// Jungle Healing (move 816) - from the Bulbapedia stills (reference/sheet.png).
//   1. The scene floods with soft green; sparkles drift and leaves turn in
//      the air round the user as it gathers itself.
//   2. The healing: ribbons of green and cyan light start close round the
//      user and widen slowly, turn by turn, as green light blooms over it.
// Stays on the user; the healing and status cure are the engine's.
// No whirl in the wind-up, and a whirl that opens out slowly once the healing
// starts, are Logan's direction (2026-10-03).
// The ribbons are Hurricane's tornado in green; the leaves are Razor Leaf's.

const SPA = 996;
const kit = await createKit({ workDir: import.meta.dirname, slug: "jungle-healing", moveId: 816, spaId: SPA, donors: [711, 242, 228, 465, 411, 298, 407] });

const CAMERA_IN = 10;
const WHIRL = 30;
const BLOOM = 46;

const GREEN: Rgb = [0.35, 0.95, 0.5];
const TEAL: Rgb = [0.3, 0.9, 0.85];
const PALE: Rgb = [0.88, 1.0, 0.9];
const DEEP: Rgb = [0.15, 0.7, 0.35];
const HEAL: Pal = [GREEN, PALE, TEAL];
const TOTAL = WHIRL + BLOOM;

// The whirl opens out in stages: each few swooshes are born wider than the
// last (a swoosh's width is fixed when it is born), and all of them turn slowly.
const STAGES = [0.8, 1.15, 1.5, 1.85]; // how wide each stage is
const STAGE_GAP = 7;
const ribbons = STAGES.flatMap((widen, i) => vortex(kit, `ribbons${i}`, { at: WHIRL - 2 + i * STAGE_GAP, frames: STAGE_GAP, pal: [TEAL, PALE, GREEN], widen, life: 16, pace: 0.6 }));
const user = [
  ...sparks(kit, "leaves", { pos: [0, 0.6, 0.4], at: 4, radius: 2.0, speed: 0.04, count: 1, bursts: (TOTAL - 20) / 4, gap: 4, life: 18, scale: 0.28, pal: [WHITE, [0.8, 1.0, 0.7], [1.0, 1.0, 0.7]], fall: 0.006, tex: kit.tex(242, 1), twinkle: false, spin: 0.2, shape: "ball" }),
  ...sparks(kit, "glints", { pos: [0, 0.8, 0.4], at: 6, radius: 2.2, speed: 0, count: 1, bursts: (TOTAL - 20) / 4, gap: 4, life: 9, scale: 0.36, pal: [WHITE, PALE, TEAL], shape: "ball", tex: kit.tex(T.sparkle4) }),
  ...risers(kit, "light", { pos: USER_FLOOR, at: WHIRL - 8, frames: BLOOM - 10, radius: 1.6, speed: 0.3, scale: 1.0, life: 10, every: 3, pal: [GREEN, WHITE, TEAL], streak: true }),
  ...risers(kit, "motes", { pos: USER_FLOOR, at: 4, frames: TOTAL - 20, radius: 1.8, speed: 0.13, scale: 0.16, life: 16, every: 3, pal: [PALE, WHITE, GREEN] }),
  ...ring(kit, "pulse", { pos: USER, at: WHIRL, scale: 2.0, pal: [PALE, WHITE, GREEN], to: 2.4, life: 14 }),
  ...glow(kit, "bloom", { pos: USER, at: WHIRL - 4, life: BLOOM + 4, scale: 4.0, pal: [GREEN, PALE, DEEP], level: 0.75, scaleCurve: grow(0.3, 0.3, 1.2) }),
  ...glow(kit, "aura", { pos: USER, life: TOTAL, scale: 2.8, pal: [GREEN, TEAL, PALE], level: 0.55 }),
];

const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1425, 0, { pitch: 300, vol: 100 }),
  snd(1718, 4, { ch: "SE2", pitch: 300, vol: 95 }),
  snd(1427, WHIRL - 2, { vol: 120 }),
  snd(1784, WHIRL + 10, { ch: "SE2", pitch: 200, vol: 100 }),
)}
${arena(0, 8, 10, [6, 22, 10])}
${tint("ATTACKER", 0, 6, 8, [14, 31, 18])}
${circleEmits(kit, ribbons, "ATTACKER")}
${emits(kit, user, "ATTACKER")}
Wait ${WHIRL}
${tint("ATTACKER", 6, 12, 4, [20, 31, 22])}
${squash("ATTACKER", -819, 819, 5)}
Wait ${BLOOM - 12}
${tint("ATTACKER", 12, 0, 8, [20, 31, 22])}
${arena(8, 0, 10, [6, 22, 10])}
Wait 12
${outro({ unfreeze: "NONE" })}`;

await kit.finish({
  script,
  donorMoveIds: [542, 75, 63, 605, 240, 129, 236],
  references: ["reference/Jungle_Healing_IX.png", "reference/Jungle_Healing_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `EmitCircle ${SPA}, ${kit.idx("ribbons0Inner")}, ATTACKER_LEFT`, `EmitCircle ${SPA}, ${kit.idx("ribbons3Outer")}, ATTACKER_LEFT`, `Emit ${SPA}, ${kit.idx("bloom")}, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  wind-up f${CAMERA_IN}, whirl opens f${CAMERA_IN + WHIRL - 2}-${CAMERA_IN + WHIRL - 2 + STAGES.length * STAGE_GAP}, bloom f${CAMERA_IN + WHIRL - 4}-${CAMERA_IN + TOTAL}`);
