MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 990
AudioContainer CONTINUE
PlaySound 1463, SE1, 14, 0, -400, 110, 0, 0, 0
PlaySound 1445, SE2, 14, 4, -800, 85, 0, 0, 0
PlaySound 1463, SE1, 16, 32, -600, 110, 0, 0, 0
PlaySound 1727, SE2, 16, 40, 600, 90, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 6, 0, 22, 22, 6
Emit 990, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 990, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 990, 2, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 990, 3, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 5, 0, 1
Wait 18
ChangeSpriteColor ATTACKER, 6, 0, 0, 22, 22, 6
Wait 4
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
Emit 990, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 990, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 990, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 990, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 9, 0, 22, 23, 6
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 11
Wait 24
ChangeSpriteColor DEFENDER, 9, 0, 0, 22, 23, 6
Wait 12
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
