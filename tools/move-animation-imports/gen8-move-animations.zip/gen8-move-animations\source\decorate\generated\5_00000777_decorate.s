MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 957
AudioContainer CONTINUE
PlaySound 1474, SE1, 14, 0, 0, 85, 0, 0, 0
PlaySound 1784, SE2, 14, 4, 0, 105, 0, 0, 0
PlaySound 1509, SE1, 14, 12, 500, 85, 0, 0, 0
PlaySound 1784, SE2, 16, 38, 200, 110, 0, 0, 0
PlaySound 1427, SE1, 16, 48, 300, 105, 0, 0, 0
PlaySound 1452, SE2, 16, 60, 300, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 957, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 957, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 957, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 957, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 957, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 5, 0, 1
Wait 28
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
Emit 957, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 957, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 957, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 957, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 957, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 957, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 957, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 957, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 10
ChangeSpriteColor DEFENDER, 0, 9, 0, 31, 18, 26
Wait 12
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 5, 0, 1
Wait 14
ChangeSpriteColor DEFENDER, 9, 0, 0, 31, 18, 26
Wait 8
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
