LoadSPA 954
AudioContainer CONTINUE
PlaySound 1510, SE1, 14, 0, 0, 110, 0, 0, 0
PlaySound 1510, SE2, 16, 2, 200, 105, 0, 0, 0
PlaySound 1455, SE2, FLAT, 24, 0, 115, 0, 0, 0
PlaySound 1452, SE1, 14, 38, 0, 110, 0, 0, 0
PlaySound 1452, SE2, 16, 40, 100, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 9, 0, 2, 4, 10
Emit 954, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 954, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 954, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 954, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 954, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 954, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 954, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 954, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 954, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 954, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 954, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 954, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 954, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 954, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 954, 7, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 954, 15, DEFENDER, ATTACKER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 38
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 4, 0, 1
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 4, 0, 1
Wait 16
ChangeBackgroundColor 4, 9, 0, 0, 2, 4, 10
Wait 8
LetCMDsFinish PARTICLE
LetCMDsFinish ALL
TerminateMoveScript
