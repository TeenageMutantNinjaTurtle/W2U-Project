MoveCamera INTERPOLATION, ATTACKER, 8, 0, 8
LetCMDsFinish CAMERA
LoadSPA 983
AudioContainer CONTINUE
PlaySound 1718, SE1, 14, 0, 500, 105, 0, 0, 0
PlaySound 1425, SE2, 14, 8, 600, 120, 0, 0, 0
PlaySound 1423, SE1, 16, 14, 0, 127, 0, 0, 0
PlaySound 1415, SE2, 16, 15, 0, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 0, 14, 31, 16
Emit 983, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 983, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 983, 0, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 983, 1, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 983, 2, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, 819, -1229, 6, 0, 1
Wait 8
ToggleSpriteVisibility ATTACKER, 3
MoveCamera INTERPOLATION, DEFENDER, 6, 0, 8
Wait 6
Emit 983, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 983, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 983, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 983, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 983, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 983, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 24, 31, 20
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 24, 31, 20
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 22
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 0, 0, 0, 14, 31, 16
ToggleSpriteVisibility ATTACKER, 4
MoveCamera INTERPOLATION, INIT, 10, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
