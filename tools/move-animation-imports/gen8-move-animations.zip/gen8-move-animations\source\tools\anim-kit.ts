// Shared toolkit for the Gen 9 move-animation generators.
//
// A generator creates a Kit for its move, pulls textures and resource
// "shells" from retail donor SPAs in ../donor-pool, builds its resources with
// the helpers below, registers them by name, writes its move script with
// kit.emit(...), and calls kit.finish(...). That writes the SPA, the script
// and moveanim.json, then re-parses the SPA and runs the checks every move
// needs. Move-specific checks run on the returned re-parsed resources.
import assert from "node:assert/strict";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { crc32, deflateSync } from "node:zlib";
import {
  parseSpaArchive,
  serializeSpaArchive,
  type SpaArchive,
  type SpaResource,
  type SpaTexture,
} from "../../Pokeweb-Serverless/src/pokeweb/nitroSpa";
import { replaceSpaTextureRgba } from "../../Pokeweb-Serverless/src/pokeweb/spaTransform";

export { assert };
export type Rgb = [number, number, number];
export type Vec3 = [number, number, number];
export interface Curve3 { start: number; mid: number; end: number; curveIn: number; curveOut: number }

const POOL = path.join(import.meta.dirname, "../donor-pool");

// --- texture catalogue (donor SPA, texture index) ------------------------------
// All white A5I3 masks unless noted, so a resource colour paints them.
export const T = {
  softDisc: [298, 0], // Swift: soft-edged disc
  sparkle4: [298, 1], // Swift: four-point sparkle
  ring: [298, 2], // Swift: ring
  star5: [298, 3], // Swift: hard five-point star
  softStar: [298, 4], // Swift: soft star
  hoop: [560, 1], // Lucky Chant: clean thick ring
  fuzzyGlow: [465, 1], // Dazzling Gleam: soft glow
  spikeRing: [465, 2], // Dazzling Gleam: sun ring
  shard: [465, 3], // Dazzling Gleam: tapered shard
  sunburst: [228, 1], // Hyper Beam: radial sunburst
  swirlRings: [228, 3], // Hyper Beam: swirl rings
  puff: [321, 5], // Explosion: puffy cloud
  spike: [321, 6], // Explosion: tapered spike / cone
  dot: [333, 0], // Slash: glow dot
  hitStar: [333, 1], // Slash: hit star
  streak: [333, 2], // Slash: slash streak (vertical line)
  hairStreak: [411, 0], // Rain Dance: hair-thin streak
  star4Big: [407, 1], // Moonlight: four-point star
  crescent: [606, 3], // Psycho Cut: crescent
  clumps: [606, 2], // Psycho Cut: clumpy puff cluster
  rippleRings: [606, 0], // Psycho Cut: concentric rings
  bladeArc: [606, 4], // Psycho Cut: wide blade arc
  web: [340, 1], // Spider Web: web (4-colour palette)
  thinRings: [770, 2], // Sticky Web: thin concentric rings
  thread: [249, 1], // String Shot: thread streak
  coil: [249, 0], // String Shot: stacked coil loops
  spiky: [579, 2], // Night Slash: spiky flash
} as const satisfies Record<string, readonly [number, number]>;

// --- resource shells (donor SPA, resource index) -------------------------------
export const S = {
  held: [606, 0], // Psycho Cut: held disc with scale/alpha/colour curves (parked layers)
  sphereSpray: [333, 1], // Slash: particles thrown off a sphere
  beam: [228, 0], // Hyper Beam: directional stream fired along an aimed axis
  dirSparks: [228, 3], // Hyper Beam: directional sparks off a sphere
  converge: [321, 5], // Explosion: particles drawn inward (convergence)
} as const satisfies Record<string, readonly [number, number]>;

const ALWAYS = [606, 333, 227];

// --- free helpers ------------------------------------------------------------

export function retexture(resource: SpaResource, textureIndex: number): void {
  resource.textureIndex = textureIndex;
  if (resource.texAnim) resource.texAnim.textures = resource.texAnim.textures.map(() => textureIndex);
  delete resource.childResource;
}

export function setCurves(resource: SpaResource, scale: Curve3 | undefined, alpha: Curve3 | undefined): void {
  if (scale) {
    assert.ok(resource.scaleAnim, "Shell has no scale curve");
    Object.assign(resource.scaleAnim, scale, { loop: false });
  }
  if (alpha) {
    assert.ok(resource.alphaAnim, "Shell has no alpha curve");
    Object.assign(resource.alphaAnim, alpha, { loop: false });
  }
  // loopFrames also paces looping texture animations; leave those alone.
  if (!resource.texAnim?.loop) resource.loopFrames = 1;
}

export function paint(resource: SpaResource, base: Rgb, start: Rgb = base, end: Rgb = base, peak = 0.3): void {
  resource.color = [...base];
  if (!resource.colorAnim) return; // shells without a colour curve just take the base colour
  Object.assign(resource.colorAnim, { start: [...start], end: [...end], curveIn: 0, curvePeak: peak, curveOut: 1, interpolate: true, loop: false, randomStartColor: false });
}

/** Colour cycling a -> b -> c every `frames` (shimmer). */
export function shimmer(resource: SpaResource, [a, b, c]: [Rgb, Rgb, Rgb], frames: number): void {
  assert.ok(resource.colorAnim, "Shell has no colour curve");
  resource.color = [...b];
  Object.assign(resource.colorAnim, { start: [...a], end: [...c], curveIn: 0, curvePeak: 0.5, curveOut: 1, interpolate: true, loop: true, randomStartColor: false });
  resource.loopFrames = frames;
}

export function spin(resource: SpaResource, min: number, max = min, startAngle = 0, randomStart = false): void {
  resource.hasRotation = min !== 0 || max !== 0;
  resource.minRotation = min;
  resource.maxRotation = max;
  resource.randomInitAngle = randomStart;
  resource.initAngle = startAngle;
}

/** Fired along an axis the VM aims at the destination (Emit ..., ATTACKER, DEFENDER). */
export function aimed(resource: SpaResource, speed: number, life: number, dive = 0): void {
  const n = Math.hypot(1, dive);
  resource.axis = [1 / n, -dive / n, 0];
  resource.initVelAxisAmplifier = speed;
  resource.particleLifeFrames = life;
  resource.followEmitter = false;
}

export const deg = (d: number) => (d * Math.PI) / 180;
export const lighten = (rgb: Rgb, t: number): Rgb => rgb.map((c) => c + (1 - c) * t) as Rgb;
export const darken = (rgb: Rgb, t: number): Rgb => rgb.map((c) => c * (1 - t)) as Rgb;

// Common curve shapes.
export const twinkle = (peak = 1): Curve3 => ({ start: 0, mid: peak, end: 0, curveIn: 0.35, curveOut: 0.55 });
export const fadeOut = (level = 1, from = 0.55): Curve3 => ({ start: level, mid: level, end: 0, curveIn: 0, curveOut: from });
export const fadeInOut = (level = 1, inFrac = 0.2, outFrac = 0.6): Curve3 => ({ start: 0, mid: level, end: 0, curveIn: inFrac, curveOut: outFrac });
export const hold = (level = 1): Curve3 => ({ start: level, mid: level, end: level, curveIn: 0, curveOut: 1 });
/** Grow from `from` to 1 over the first `inFrac`, then on to `end`. */
export const grow = (from: number, inFrac: number, end = 1, outFrac = 1): Curve3 => ({ start: from, mid: 1, end, curveIn: inFrac, curveOut: outFrac });

/** Minimal PNG writer for previewing drawn textures. */
export async function savePng(file: string, width: number, height: number, rgba: Uint8ClampedArray): Promise<void> {
  const chunk = (type: string, data: Buffer) => {
    const head = Buffer.alloc(8);
    head.writeUInt32BE(data.length, 0);
    head.write(type, 4, "ascii");
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(crc32(Buffer.concat([Buffer.from(type, "ascii"), data])) >>> 0, 0);
    return Buffer.concat([head, data, crc]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr.set([8, 6, 0, 0, 0], 8);
  const raw = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y++) Buffer.from(rgba.buffer, rgba.byteOffset + y * width * 4, width * 4).copy(raw, y * (width * 4 + 1) + 1);
  await writeFile(file, Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk("IHDR", ihdr), chunk("IDAT", deflateSync(raw)), chunk("IEND", Buffer.alloc(0))]));
}

export const close = (got: readonly number[], want: readonly number[], tol = 0.04) => got.every((v, i) => Math.abs(v - want[i]!) <= tol);
export const show = (v: readonly number[]) => `[${v.map((c) => c.toFixed(2)).join(",")}]`;

// --- the kit -----------------------------------------------------------------

export interface KitOptions {
  workDir: string;
  slug: string;
  moveId: number;
  spaId: number;
  donors: number[]; // donor SPA ids beyond the always-loaded shells
}

export interface FinishOptions {
  script: string;
  expectText: string[];
  donorMoveIds: number[];
  references?: string[];
  backgrounds?: number[];
}

export async function createKit(options: KitOptions): Promise<Kit> {
  const archives = new Map<number, SpaArchive>();
  for (const id of new Set([...ALWAYS, ...options.donors, ...Object.values(T).map(([s]) => s), ...Object.values(S).map(([s]) => s)])) {
    try {
      archives.set(id, parseSpaArchive(new Uint8Array(await readFile(path.join(POOL, `spa_${id}.spa`)))));
    } catch (error) {
      if (options.donors.includes(id) || ALWAYS.includes(id)) throw new Error(`Donor SPA ${id} is not in the pool (${POOL}): ${error}`);
    }
  }
  return new Kit(options, archives);
}

export class Kit {
  readonly textures: SpaTexture[] = [];
  private readonly textureKeys = new Map<string, number>();
  private readonly named = new Map<string, number>();
  readonly resources: SpaResource[] = [];
  readonly usedSpas = new Set<number>();
  private readonly auroraColor;

  constructor(readonly options: KitOptions, private readonly archives: Map<number, SpaArchive>) {
    const aurora = this.spa(227).resources[0]!.colorAnim!;
    assert.ok(aurora.randomStartColor && !aurora.interpolate, "Aurora Beam no longer steps a random colour");
    this.auroraColor = aurora;
  }

  spa(id: number): SpaArchive {
    const archive = this.archives.get(id);
    assert.ok(archive, `Donor SPA ${id} not loaded; add it to the kit's donors`);
    return archive;
  }

  /** Texture `index` of donor `spaId` in this move's table (added once). */
  tex(spaId: number, index: number): number;
  tex(ref: readonly [number, number]): number;
  tex(a: number | readonly [number, number], b?: number): number {
    const [spaId, index] = typeof a === "number" ? [a, b!] : a;
    const key = `${spaId}:${index}`;
    const existing = this.textureKeys.get(key);
    if (existing !== undefined) return existing;
    const texture = this.spa(spaId).textures[index];
    assert.ok(texture, `Donor SPA ${spaId} has no texture ${index}`);
    assert.equal(texture.useSharedTexture, false, `Texture ${key} is shared`);
    const clone = structuredClone(texture);
    clone.index = this.textures.length;
    this.textures.push(clone);
    this.textureKeys.set(key, clone.index);
    this.usedSpas.add(spaId);
    return clone.index;
  }

  /**
   * A texture drawn here, pixel by pixel. `pixel` returns [r, g, b, a] (0-255)
   * or undefined for transparent. "a3i5" keeps up to 32 colours with soft
   * alpha (tint multiplies it, so paint such resources white); "a5i3" is a
   * white mask. A preview PNG is written next to the generator.
   */
  async drawn(name: string, width: number, height: number, format: "a3i5" | "a5i3" | "direct", pixel: (x: number, y: number) => readonly number[] | undefined): Promise<number> {
    const rgba = new Uint8ClampedArray(width * height * 4);
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const p = pixel(x, y);
        if (p) rgba.set([p[0]!, p[1]!, p[2]!, p[3] ?? 255], (y * width + x) * 4);
      }
    }
    const scratch: SpaArchive = { resourceCount: 0, textureCount: 1, resources: [], textures: [structuredClone(this.spa(298).textures[0]!)], warnings: [], rawHeader: this.spa(606).rawHeader?.slice() };
    replaceSpaTextureRgba(scratch, 0, { width, height, rgba }, format);
    const texture = scratch.textures[0]!;
    texture.index = this.textures.length;
    this.textures.push(texture);
    this.textureKeys.set(`drawn:${name}`, texture.index);
    await mkdir(path.join(this.options.workDir, "generated"), { recursive: true });
    await savePng(path.join(this.options.workDir, "generated", `texture-${name}.png`), width, height, rgba);
    return texture.index;
  }

  /** A clone of a donor resource, child removed. */
  shell(spaId: number, index: number): SpaResource;
  shell(ref: readonly [number, number]): SpaResource;
  shell(a: number | readonly [number, number], b?: number): SpaResource {
    const [spaId, index] = typeof a === "number" ? [a, b!] : a;
    const resource = this.spa(spaId).resources[index];
    assert.ok(resource, `Donor SPA ${spaId} has no resource ${index}`);
    this.usedSpas.add(spaId);
    const clone = structuredClone(resource);
    delete clone.childResource;
    return clone;
  }

  /** One parked billboard: no emission shape, no motion, a single quad. */
  parked(textureIndex: number, pos: Vec3, scale: number, life: number): SpaResource {
    const resource = this.shell(S.held);
    retexture(resource, textureIndex);
    Object.assign(resource, {
      emissionType: 0, emissionAxis: 0, radius: 0, length: 0, axis: [0, 1, 0],
      initVelAxisAmplifier: 0, initVelPosAmplifier: 0, airResistance: 1.0,
      followEmitter: false, behaviors: [], emitterBasePos: [...pos],
      baseScale: scale, aspectRatio: 1, particleLifeFrames: life, drawType: 0,
      emitterLifeFrames: 1, emissionCount: 1, emissionIntervalFrames: 1, startDelayFrames: 0,
    });
    spin(resource, 0);
    return resource;
  }

  /**
   * Particles from a shape round `pos`: on a sphere's surface (default), filling
   * a ball (`ball`), or on a screen-facing circle (`circle`). `speed` is the
   * outward velocity; `bursts` emissions `gap` frames apart.
   */
  spray(shell: readonly [number, number] | SpaResource, textureIndex: number, pos: Vec3, opts: { radius: number; speed: number; count: number; bursts?: number; gap?: number; life: number; scale: number; shape?: "sphere" | "ball" | "circle" | "point"; directional?: boolean }): SpaResource {
    const resource = Array.isArray(shell) ? this.shell(shell as readonly [number, number]) : structuredClone(shell as SpaResource);
    retexture(resource, textureIndex);
    const emissionType = { sphere: 1, ball: 4, circle: 2, point: 0 }[opts.shape ?? "sphere"];
    Object.assign(resource, {
      emissionType, emissionAxis: 0, radius: opts.radius, emitterBasePos: [...pos], axis: [0, 1, 0],
      initVelAxisAmplifier: 0, initVelPosAmplifier: opts.speed, followEmitter: false,
      emissionCount: opts.count, emitterLifeFrames: Math.max(1, ((opts.bursts ?? 1) - 1) * (opts.gap ?? 1) + 1),
      emissionIntervalFrames: opts.gap ?? 1, particleLifeFrames: opts.life, baseScale: opts.scale, startDelayFrames: 0,
    });
    if (opts.directional !== undefined) resource.drawType = opts.directional ? 1 : 0;
    // The usual spray shell (333/1) is stored turned 91 degrees, so a drawn
    // texture sprayed from it lay on its side (Decorate's strawberries). Start
    // every camera-facing spray upright; spin() can turn it afterwards.
    if (!opts.directional) resource.initAngle = 0;
    // Hyper Beam's spark shell (228/3) is anchored at one end (offsetPos 2),
    // offset a further quad-length (polygonY 1) and stretched up to 4.8x along
    // its motion (directionalBillboardScale 3.84). Fine for its tiny sparks; at
    // the scales used here it threw each streak 10-20 units from its particle,
    // to the edges of the screen. Centre every sprayed quad on its particle.
    Object.assign(resource, { offsetPos: 0, polygonX: 0, polygonY: 0, directionalBillboardScale: 0, scaleAnimDir: 0 });
    return resource;
  }

  /** Each particle takes one of three colours at random and keeps it (Aurora Beam's curve). */
  prism(resource: SpaResource, [a, b, c]: [Rgb, Rgb, Rgb]): void {
    assert.ok(resource.colorAnim, "Shell has no colour curve");
    resource.color = [...b];
    Object.assign(resource.colorAnim, structuredClone(this.auroraColor), { start: [...a], end: [...c] });
  }

  add(name: string, resource: SpaResource): number {
    assert.ok(!this.named.has(name), `Resource ${name} added twice`);
    const index = this.resources.length;
    resource.index = index;
    this.resources.push(resource);
    this.named.set(name, index);
    return index;
  }

  idx(name: string): number {
    const index = this.named.get(name);
    assert.ok(index !== undefined, `No resource named ${name}`);
    return index;
  }

  /** `Emit` line for a named resource. */
  emit(name: string, target: "ATTACKER" | "DEFENDER", toward = "NONE", y = "2px"): string {
    return `Emit ${this.options.spaId}, ${this.idx(name)}, ${target}, ${toward}, ${y}, 0, 0, 1x, 1x, 1x, 1x`;
  }

  get scriptPath(): string {
    return path.join(this.options.workDir, "generated", `5_${String(this.options.moveId).padStart(8, "0")}_${this.options.slug.replace(/-/g, "_")}.s`);
  }

  async finish(finish: FinishOptions): Promise<{ built: (name: string) => SpaResource; reparsed: SpaArchive }> {
    const { workDir, slug, moveId, spaId } = this.options;
    const outDir = path.join(workDir, "generated");
    await mkdir(outDir, { recursive: true });
    assert.ok(this.resources.length > 0, "No resources");
    for (const [index, resource] of this.resources.entries()) {
      assert.ok(resource.textureIndex < this.textures.length, `Resource ${index} texture out of range`);
      assert.equal(resource.childResource, undefined, `Resource ${index} kept a donor child`);
      assert.ok(resource.particleLifeFrames >= 1 && resource.emitterLifeFrames >= 1, `Resource ${index} has a zero life`);
    }
    const archive: SpaArchive = { resourceCount: this.resources.length, textureCount: this.textures.length, resources: this.resources, textures: this.textures, warnings: [], rawHeader: this.spa(606).rawHeader?.slice() };
    const bytes = serializeSpaArchive(archive);
    const spaPath = path.join(outDir, `6_${String(spaId).padStart(8, "0")}.bin`);
    await writeFile(spaPath, bytes);

    const reparsed = parseSpaArchive(bytes);
    assert.equal(reparsed.resources.length, this.resources.length, "Resource count changed on round-trip");
    assert.equal(reparsed.textures.length, this.textures.length, "Texture count changed on round-trip");
    assert.equal(reparsed.warnings.length, 0, `Round-trip warnings: ${reparsed.warnings.join("; ")}`);
    for (const [index, resource] of reparsed.resources.entries()) {
      const want = this.resources[index]!;
      assert.equal(resource.textureIndex, want.textureIndex, `Resource ${index} texture index drifted`);
      assert.ok(close(resource.emitterBasePos, want.emitterBasePos), `Resource ${index} base position drifted`);
      assert.ok(close(resource.color, want.color), `Resource ${index} colour drifted: ${show(resource.color)} vs ${show(want.color)}`);
    }

    // Every Emit in the script must name a resource that exists.
    for (const match of finish.script.matchAll(new RegExp(`Emit\\w* ${spaId}, (\\d+),`, "g"))) {
      assert.ok(Number(match[1]) < this.resources.length, `Script emits missing resource ${match[1]}`);
    }
    assert.ok(finish.script.includes(`LoadSPA ${spaId}`), "Script never loads its SPA");
    for (const line of finish.expectText) assert.ok(finish.script.includes(line), `Script lacks expected line: ${line}`);

    await writeFile(this.scriptPath, finish.script, "utf8");
    const manifest = {
      version: 1,
      moveId,
      slug,
      donorMoveIds: finish.donorMoveIds,
      reservedSpaIds: [spaId],
      generator: `make-${slug}.ts`,
      reference: finish.references ?? [],
      script: path.relative(workDir, this.scriptPath).replace(/\\/g, "/"),
      animation: `generated/5_${String(moveId).padStart(8, "0")}.bin`,
      spas: [path.relative(workDir, spaPath).replace(/\\/g, "/")],
      expect: {
        loadSpas: [spaId],
        backgrounds: finish.backgrounds ?? [],
        forbidSpas: [...this.usedSpas].sort((x, y) => x - y),
        text: finish.expectText,
        maxLoadedSpas: 1,
      },
    };
    await writeFile(path.join(workDir, "moveanim.json"), `${JSON.stringify(manifest, null, 2)}\n`);

    console.log(`Wrote ${spaPath} (${bytes.length} bytes, ${this.resources.length} resources, ${this.textures.length} textures)`);
    console.log(`  resources: ${[...this.named.entries()].map(([n, i]) => `${i}:${n}`).join(" ")}`);
    console.log(`Wrote ${this.scriptPath}`);
    return { built: (name: string) => reparsed.resources[this.idx(name)]!, reparsed };
  }
}
