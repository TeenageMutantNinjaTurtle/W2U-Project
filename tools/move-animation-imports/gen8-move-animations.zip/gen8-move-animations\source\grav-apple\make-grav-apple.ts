import { createKit, fadeOut, hold, paint, setCurves, spin, T, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, FOE, glow, hit, impact, intro, outro, pan, quake, snd, sparks, squash, streaks, tint, WHITE, type Pal } from "../tools/phrases";

// Grav Apple (move 788) - from the Bulbapedia stills (reference/sheet.png).
//   1. An apple hangs high in the air and gleams.
//   2. It drops straight down onto the foe.
//   3. It smashes: chunks of red skin and pale flesh fly, yellow stars pop
//      round the foe on an orange burst.
// The apple and its chunks are drawn (generated/texture-apple.png, -chunk.png).

const SPA = 968;
const kit = await createKit({ workDir: import.meta.dirname, slug: "grav-apple", moveId: 788, spaId: SPA, donors: [228, 465, 579, 411, 298, 407] });

const CAMERA_IN = 10;
const CALL = 10;
const PAN = 10;
const HANG = 16; // the apple hangs and gleams
const DROP = 4;
const AFTER = 28;

const YELLOW: Rgb = [1.0, 0.92, 0.25];
const ORANGE: Rgb = [1.0, 0.6, 0.15];
const PALE: Rgb = [1.0, 0.97, 0.75];
const HEIGHT = 2.5; // as high as the camera on the foe shows
const HIGH: Vec3 = [FOE[0], FOE[1] + HEIGHT, FOE[2] + 0.2];

// --- the drawn apple: red, a paler cheek, a stalk and a leaf ---
const appleTex = await kit.drawn("apple", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5, py = y + 0.5;
  // Two overlapping lobes with a dip at the top.
  const lobe = Math.min(Math.hypot(px - 11.5, py - 19) / 9.5, Math.hypot(px - 20.5, py - 19) / 9.5);
  const waist = ((px - 16) / 11) ** 2 + ((py - 21) / 9) ** 2;
  if (py < 8 && Math.abs(px - 16 - (8 - py) * 0.4) < 1) return [96, 60, 30]; // stalk
  if (((px - 21.5) / 4.5) ** 2 + ((py - 6.5) / 2.3) ** 2 <= 1) return [70, 180, 70]; // leaf
  if (lobe > 1 && waist > 1) return undefined;
  if (lobe > 0.88 && waist > 0.85) return [140, 12, 24];
  const light = Math.max(0, 1 - Math.hypot(px - 11, py - 15) / 9);
  const cheek = Math.max(0, 1 - Math.hypot(px - 19, py - 24) / 7);
  return [Math.round(225 + 30 * light), Math.round(35 + 120 * light + 110 * cheek), Math.round(40 + 70 * light + 10 * cheek)];
});
// --- a chunk: a wedge of pale flesh with a strip of red skin ---
const chunkTex = await kit.drawn("chunk", 16, 16, "a3i5", (x, y) => {
  const px = x + 0.5 - 8, py = y + 0.5 - 8;
  if (Math.abs(px) + Math.abs(py) * 0.8 > 7) return undefined;
  if (py < -2.5 + px * 0.3) return [215, 30, 40];
  if (Math.abs(px) + Math.abs(py) * 0.8 > 5.8) return [225, 205, 150];
  return [255, 246, 205];
});

const hang = kit.parked(appleTex, HIGH, 0.9, HANG + 1);
setCurves(hang, { start: 0.4, mid: 1.05, end: 1, curveIn: 0.25, curveOut: 0.6 }, { start: 0, mid: 1, end: 1, curveIn: 0.2, curveOut: 1 });
paint(hang, WHITE);
kit.add("appleHang", hang);
const fall = kit.parked(appleTex, HIGH, 0.9, DROP + 1);
fall.startDelayFrames = HANG;
fall.axis = [0, -1, 0];
fall.initVelAxisAmplifier = (HEIGHT - 0.6) / DROP;
spin(fall, 0.25);
setCurves(fall, hold(1), hold(1));
paint(fall, WHITE);
kit.add("appleFall", fall);

const LAND = HANG + DROP;
const HEAD: Vec3 = [0, 0.9, 1.0];
const foe = [
  "appleHang", "appleFall",
  ...glow(kit, "gleam", { pos: [HIGH[0] + 0.3, HIGH[1] + 0.4, HIGH[2] + 0.1], at: 4, life: 10, scale: 0.9, pal: [WHITE, WHITE, PALE], tex: kit.tex(T.star4Big), spin: 0.1, scaleCurve: twinkle(1.3), alpha: twinkle(1) }),
  ...streaks(kit, "dropLines", { pos: [0, 2.8, 0.9], at: HANG, radius: 0.5, speed: 0, count: 2, bursts: 3, gap: 1, life: 5, scale: 1.1, pal: [WHITE, PALE, WHITE], flat: true, lift: -0.9 }),
  // --- the smash ---
  ...sparks(kit, "stars", { pos: HEAD, at: LAND, radius: 0.7, speed: 0.22, count: 6, life: 16, scale: 0.42, pal: [YELLOW, PALE, [1.0, 0.8, 0.15]], tex: kit.tex(T.star5), twinkle: false, spin: 0.15, shape: "circle" }),
  ...sparks(kit, "chunks", { pos: HEAD, at: LAND, radius: 0.5, speed: 0.26, count: 8, life: 18, scale: 0.3, pal: [WHITE, WHITE, WHITE], fall: 0.026, tex: chunkTex, twinkle: false, spin: 0.25 }),
  ...impact(kit, "smash", { pos: HEAD, at: LAND, pal: [ORANGE, PALE, YELLOW], size: 1.3, rays: 8, flecks: 0 }),
  ...sparks(kit, "juice", { pos: HEAD, at: LAND, radius: 0.5, speed: 0.3, count: 8, life: 14, scale: 0.13, pal: [YELLOW, PALE, ORANGE], fall: 0.014, twinkle: false, shape: "circle" }),
];
const chunks = kit.resources[kit.idx("chunks")]!;
chunks.axis = [0, 1, 0];
chunks.initVelAxisAmplifier = 0.28;
setCurves(chunks, hold(1), fadeOut(1, 0.8));
setCurves(kit.resources[kit.idx("stars")]!, { start: 0.5, mid: 1.1, end: 0.8, curveIn: 0.2, curveOut: 0.7 }, fadeOut(1, 0.7));

const landAt = CALL + PAN + LAND;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1509, CALL + PAN + 4, { side: "D", pitch: 700, vol: 95 }),
  snd(1407, CALL + PAN + HANG, { ch: "SE2", side: "D", pitch: -300, vol: 115 }),
  snd(1705, landAt, { side: "D", pitch: 100, vol: 127 }),
  snd(1423, landAt, { ch: "SE2", side: "D", pitch: 300, vol: 115 }),
)}
${tint("ATTACKER", 0, 6, 3, [31, 14, 12])}
${squash("ATTACKER", -819, 819, 4)}
Wait ${CALL}
${tint("ATTACKER", 6, 0, 3, [31, 14, 12])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
Wait ${LAND}
${hit({ rgb: [31, 28, 16], power: 2 })}
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1638, 6, 0, 1
${quake("0.5x", 4)}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 236],
  references: ["reference/Grav_Apple_VIII.png", "reference/Grav_Apple_VIII_2.png", "reference/Grav_Apple_IX.png", "reference/Grav_Apple_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("appleFall")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("chunks")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  apple hangs f${CAMERA_IN + CALL + PAN}, drops f${CAMERA_IN + CALL + PAN + HANG}, lands f${CAMERA_IN + landAt}`);
