MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 996
AudioContainer CONTINUE
PlaySound 1425, SE1, 14, 0, 300, 100, 0, 0, 0
PlaySound 1718, SE2, 14, 4, 300, 95, 0, 0, 0
PlaySound 1427, SE1, 14, 28, 0, 120, 0, 0, 0
PlaySound 1784, SE2, 14, 40, 200, 100, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 0, 6, 22, 10
ChangeSpriteColor ATTACKER, 0, 6, 0, 14, 31, 18
EmitCircle 996, 0, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 996, 1, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 996, 2, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 996, 3, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 996, 4, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 996, 5, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 996, 6, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 996, 7, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
Emit 996, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 996, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 996, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 996, 11, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 996, 12, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 996, 13, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 996, 14, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 30
ChangeSpriteColor ATTACKER, 6, 12, 0, 20, 31, 22
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 5, 0, 1
Wait 34
ChangeSpriteColor ATTACKER, 12, 0, 0, 20, 31, 22
ChangeBackgroundColor 4, 8, 0, 0, 6, 22, 10
Wait 12
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
