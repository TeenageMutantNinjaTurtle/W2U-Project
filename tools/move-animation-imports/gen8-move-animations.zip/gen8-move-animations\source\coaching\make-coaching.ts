import { createKit, deg, fadeInOut, grow, paint, setCurves, spin, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, FOE, FOE_FLOOR, glow, intro, notes, outro, pan, ring, risers, snd, sparks, squash, tint, WHITE, type Pal } from "../tools/phrases";

// Coaching (move 811) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user shouts through a red megaphone inside a golden ring, orange
//      notes flying off it.
//   2. Its ally is wrapped in a golden dome with rings of light turning
//      round it and red motes rising.
// The megaphone is drawn (generated/texture-megaphone.png); the notes are
// Sing's. The move targets an ally, so in a single battle it fails before
// animating.

const SPA = 991;
const kit = await createKit({ workDir: import.meta.dirname, slug: "coaching", moveId: 811, spaId: SPA, donors: [212, 228, 465, 411, 298, 560] });

const CAMERA_IN = 10;
const SHOUTS = 3;
const SHOUT_GAP = 9;
const SHOUTING = SHOUTS * SHOUT_GAP + 4;
const PAN = 10;
const BOOST = 40;

const GOLD: Rgb = [1.0, 0.85, 0.3];
const PALE: Rgb = [1.0, 0.97, 0.75];
const ORANGE: Rgb = [1.0, 0.55, 0.15];
const RED: Rgb = [1.0, 0.25, 0.2];
const HORN: Vec3 = [0.9, 0.9, 0.5];

// --- the drawn megaphone: a red cone with a pale bell rim and a grip ---
const hornTex = await kit.drawn("megaphone", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5, py = y + 0.5;
  // Cone: narrow at the left (mouthpiece), flaring to the right.
  const t = (px - 4) / 22; // 0..1 along the cone
  if (t >= 0 && t <= 1) {
    const half = 2.2 + 8.5 * t;
    const dy = Math.abs(py - 14);
    if (dy <= half) {
      if (t > 0.9) return [250, 235, 215]; // bell rim
      if (dy > half - 1.2) return [150, 20, 25];
      const light = Math.max(0, 1 - Math.abs(py - 11) / 7);
      return [Math.round(210 + 40 * light), Math.round(35 + 60 * light), Math.round(40 + 40 * light)];
    }
  }
  if (px >= 1.5 && px < 4 && Math.abs(py - 14) <= 2.8) return [240, 230, 215]; // mouthpiece
  if (px >= 9 && px <= 13 && py > 17 && py <= 27) return px < 10 || px > 12 || py > 26 ? [120, 20, 25] : [205, 45, 45]; // grip
  return undefined;
});

const horn = kit.parked(hornTex, HORN, 0.95, SHOUT_GAP + 1);
Object.assign(horn, { emitterLifeFrames: SHOUTS * SHOUT_GAP + 1, emissionIntervalFrames: SHOUT_GAP });
spin(horn, 0, 0, deg(18)); // tipped up toward the ally
setCurves(horn, { start: 1.25, mid: 0.95, end: 1.0, curveIn: 0.3, curveOut: 0.7 }, { start: 1, mid: 1, end: 1, curveIn: 0, curveOut: 1 });
paint(horn, WHITE);
kit.add("horn", horn);

const BELL: Vec3 = [HORN[0] + 0.8, HORN[1] + 0.3, HORN[2] + 0.1];
const user = [
  "horn",
  ...ring(kit, "hornRing", { pos: HORN, life: SHOUTING, scale: 1.5, pal: [GOLD, PALE, ORANGE], tex: kit.tex(T.ring), to: 1.05, level: 0.9 }),
  ...Array.from({ length: SHOUTS }, (_, i) => ring(kit, `shout${i}`, { pos: BELL, at: i * SHOUT_GAP + 1, scale: 0.8, pal: [PALE, WHITE, GOLD], to: 2.4, life: 11, level: 0.8 })).flat(),
  ...notes(kit, "hornNotes", { pos: BELL, frames: SHOUTING - 6, every: 5, life: 14, scale: 0.36, radius: 0.5, rise: 0.09, pal: [ORANGE, RED, GOLD] }),
];
setCurves(kit.resources[kit.idx("hornRing")]!, grow(0.5, 0.15, 1.05), fadeInOut(0.9, 0.1, 0.85));

// --- 2. on the ally ---
const ally = [
  ...ring(kit, "orbitA", { pos: FOE, at: 4, life: BOOST - 8, scale: 1.3, pal: [PALE, WHITE, GOLD], tex: kit.tex(T.ring), aspect: 2.3, to: 1.1, level: 0.9 }),
  ...ring(kit, "orbitB", { pos: [0, 0.9, 0.8], at: 10, life: BOOST - 16, scale: 1.0, pal: [GOLD, PALE, ORANGE], tex: kit.tex(T.ring), aspect: 2.3, to: 1.1, level: 0.8 }),
  ...risers(kit, "redMotes", { pos: FOE_FLOOR, at: 4, frames: BOOST - 16, radius: 1.5, speed: 0.2, scale: 0.16, life: 14, every: 2, pal: [RED, ORANGE, PALE] }),
  ...risers(kit, "lightUp", { pos: FOE_FLOOR, at: 6, frames: BOOST - 20, radius: 1.3, speed: 0.3, scale: 0.9, life: 9, every: 3, pal: [PALE, WHITE, GOLD], streak: true }),
  ...glow(kit, "dome", { pos: FOE, life: BOOST, scale: 2.7, pal: [GOLD, PALE, ORANGE], tex: kit.tex(T.softDisc), level: 0.5, scaleCurve: grow(0.4, 0.2, 1.02) }),
  ...ring(kit, "domeRim", { pos: FOE, life: BOOST, scale: 2.65, pal: [PALE, WHITE, GOLD], tex: kit.tex(T.ring), to: 1.02, level: 0.7 }),
];
setCurves(kit.resources[kit.idx("domeRim")]!, grow(0.4, 0.2, 1.02), fadeInOut(0.7, 0.15, 0.85));

const shouts = Array.from({ length: SHOUTS }, () => `${squash("ATTACKER", 819, -819, 3)}\nWait ${SHOUT_GAP}`).join("\n");
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  ...Array.from({ length: SHOUTS }, (_, i) => snd(1869, i * SHOUT_GAP, { ch: i % 2 ? "SE2" : "SE1", pitch: 1200 + i * 200, vol: 100 })),
  snd(1523, 2, { ch: "SE2", pitch: 400, vol: 95 }),
  snd(1452, SHOUTING + PAN + 6, { side: "D", vol: 115 }),
  snd(1452, SHOUTING + PAN + 22, { ch: "SE2", side: "D", pitch: 100, vol: 115 }),
)}
${emits(kit, user, "ATTACKER")}
${shouts}
Wait 4
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, ally, "DEFENDER")}
Wait 6
${tint("DEFENDER", 0, 9, 5, [31, 27, 10])}
${squash("DEFENDER", -819, 1229, 5)}
Wait 16
${squash("DEFENDER", -819, 1229, 5)}
Wait ${BOOST - 22 - 8}
${tint("DEFENDER", 9, 0, 6, [31, 27, 10])}
Wait 8
${outro({ unfreeze: "NONE" })}`;

await kit.finish({
  script,
  donorMoveIds: [47, 63, 605, 240, 129, 381],
  references: ["reference/Coaching_VIII.png", "reference/Coaching_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("horn")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("dome")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  shouts f${CAMERA_IN}-${CAMERA_IN + SHOUTING}, ally f${CAMERA_IN + SHOUTING + PAN}-${CAMERA_IN + SHOUTING + PAN + BOOST}`);
