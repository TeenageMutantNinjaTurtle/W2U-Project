import { createKit, fadeOut, hold, paint, setCurves, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, FOE, hit, impact, intro, outro, pan, puffs, snd, sparks, squash, streaks, tint, USER_FLOOR, WHITE, type Pal } from "../tools/phrases";

// Skitter Smack (move 806) - from the Bulbapedia stills (reference/sheet.png).
//   1. The light drops and the user turns to a black silhouette, then
//      skitters off out of sight.
//   2. It comes at the foe from behind: a black blur, then a smack that
//      bursts mint green, white and yellow with white speed lines.
// The user is hidden while it skitters (ToggleSpriteVisibility 3/4).

const SPA = 986;
const kit = await createKit({ workDir: import.meta.dirname, slug: "skitter-smack", moveId: 806, spaId: SPA, donors: [228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 10;
const DARKEN = 14;
const SKITTER = 10;
const PAN = 8;
const LUNGE = 5; // the blur crosses behind the foe
const AFTER = 24;

const MINT: Rgb = [0.45, 1.0, 0.7];
const PALE: Rgb = [0.92, 1.0, 0.92];
const YELLOW: Rgb = [1.0, 0.92, 0.3];
const BLACK: Rgb = [0, 0, 0];
const PAL: Pal = [MINT, PALE, YELLOW];
const DUST: Pal = [[0.5, 0.5, 0.52], [0.7, 0.7, 0.72], [0.32, 0.32, 0.35]];

const user = [
  ...puffs(kit, "wisps", { pos: [0, 0.2, 0.3], radius: 1.6, count: 1, bursts: DARKEN / 3, gap: 3, life: 12, scale: 0.9, pal: DUST, speed: 0.08, level: 0.5 }),
  // Scuttling off: puffs of dust zigzagging away.
  ...Array.from({ length: 3 }, (_, i) => puffs(kit, `scuttle${i}`, { pos: [i % 2 ? 1.2 : -1.0, USER_FLOOR[1] + 0.2, 0.3 - i * 0.5], at: DARKEN + i * 3, radius: 0.3, count: 2, life: 10, scale: 0.6, pal: DUST, speed: 0.08, level: 0.8 })).flat(),
  ...streaks(kit, "scuttleLines", { pos: [0, -0.8, 0.3], at: DARKEN, radius: 1.2, speed: 0.4, count: 2, bursts: 3, gap: 3, life: 6, scale: 0.7, pal: [[0.8, 0.8, 0.82], WHITE, [0.6, 0.6, 0.65]], flat: true }),
];

// The blur: a black shape crossing behind the foe from its far side.
const BEHIND: Vec3 = [3.4, 0.4, -0.2];
const blur = kit.parked(kit.tex(T.softDisc), BEHIND, 1.2, LUNGE + 1);
blur.aspectRatio = 1.7;
blur.axis = [-1, 0, 0];
blur.initVelAxisAmplifier = (BEHIND[0] - 0.4) / LUNGE;
setCurves(blur, hold(1), { start: 0, mid: 0.95, end: 0.95, curveIn: 0.3, curveOut: 1 });
paint(blur, BLACK);
kit.add("blur", blur);
const foe = [
  ...impact(kit, "smack", { at: LUNGE, pal: PAL, size: 1.4, rays: 0, flecks: 0 }),
  ...streaks(kit, "jags", { at: LUNGE, radius: 0.5, speed: 0.42, count: 8, life: 11, scale: 0.95, pal: [MINT, YELLOW, PALE], tex: kit.tex(T.shard) }),
  ...streaks(kit, "speedLines", { at: LUNGE, radius: 0.8, speed: 0.6, count: 9, life: 8, scale: 1.0, pal: [WHITE, PALE, WHITE] }),
  ...sparks(kit, "flecks", { at: LUNGE + 2, radius: 0.9, speed: 0.2, count: 6, life: 12, scale: 0.14, pal: [MINT, WHITE, YELLOW], shape: "circle", twinkle: false }),
  "blur",
];

const smackAt = DARKEN + SKITTER + PAN + LUNGE;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1470, 0, { pitch: -300, vol: 80 }),
  snd(1407, DARKEN, { ch: "SE2", pitch: 700, vol: 105 }),
  snd(1407, DARKEN + 4, { pitch: 900, vol: 100 }),
  snd(1425, DARKEN + SKITTER + PAN, { ch: "SE2", side: "D", pitch: 600, vol: 115 }),
  snd(1423, smackAt, { side: "D", vol: 127 }),
  snd(1475, smackAt, { ch: "SE2", side: "D", pitch: 300, vol: 115 }),
)}
${arena(0, 10, 8, [2, 2, 5])}
${tint("ATTACKER", 0, 16, DARKEN - 4, [1, 1, 2])}
${emits(kit, user, "ATTACKER")}
Wait ${DARKEN}
${squash("ATTACKER", 819, -819, 3)}
Wait 3
ToggleSpriteVisibility ATTACKER, 3
Wait ${SKITTER - 3}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
Wait ${LUNGE}
${arena(10, 0, 3, [2, 2, 5])}
${hit({ rgb: [26, 31, 24], power: 2 })}
Wait ${AFTER}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
${tint("ATTACKER", 16, 0, 0, [1, 1, 2])}
ToggleSpriteVisibility ATTACKER, 4
${pan("INIT", 12)}
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 153, 129],
  references: ["reference/Skitter_Smack_VIII.png", "reference/Skitter_Smack_VIII_2.png", "reference/Skitter_Smack_IX.png", "reference/Skitter_Smack_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, "ToggleSpriteVisibility ATTACKER, 3", "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("blur")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("jags")}, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 4", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  darkens f${CAMERA_IN}, skitters f${CAMERA_IN + DARKEN}, smack f${CAMERA_IN + smackAt}`);
