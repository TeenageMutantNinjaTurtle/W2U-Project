import { createKit, fadeInOut, fadeOut, grow, paint, setCurves, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, FOE, glow, hit, impact, intro, outro, pan, ring, shake, snd, sparks, squash, streaks, tint, USER, WHITE, type Pal } from "../tools/phrases";

// Expanding Force (move 797) - from the Bulbapedia stills (reference/sheet.png).
//   1. A translucent pink sphere swells round the user, small white rings
//      drifting in it and two bright cyan cores with rings round them.
//   2. Round the foe a tall box of light stands up - four white edges and a
//      violet haze - and the force bursts inside it in jagged pink, cyan and
//      yellow.
// The box's wall is a drawn plain panel (generated/texture-panel.png).

const SPA = 977;
const kit = await createKit({ workDir: import.meta.dirname, slug: "expanding-force", moveId: 797, spaId: SPA, donors: [228, 465, 579, 411, 298, 560] });

const CAMERA_IN = 10;
const SWELL = 28;
const PAN = 10;
const BOX = 8; // the box stands before the burst
const AFTER = 30;

const PINK: Rgb = [1.0, 0.6, 0.85];
const PALE: Rgb = [1.0, 0.9, 0.97];
const HOT: Rgb = [1.0, 0.3, 0.75];
const CYAN: Rgb = [0.4, 0.95, 1.0];
const VIOLET: Rgb = [0.65, 0.45, 1.0];
const YELLOW: Rgb = [1.0, 0.92, 0.3];

// --- a plain panel: a white mask that fades toward its top edge ---
const panelTex = await kit.drawn("panel", 16, 32, "a5i3", (_x, y) => [255, 255, 255, Math.round(60 + 170 * (y / 31))]);

// --- 1. the sphere ---
const core = (name: string, pos: Vec3, at: number): string[] => [
  ...glow(kit, `${name}Core`, { pos, at, life: SWELL - at, scale: 0.42, pal: [CYAN, WHITE, CYAN], tex: kit.tex(T.softDisc), level: 1 }),
  ...ring(kit, `${name}Ring`, { pos, at: at + 2, life: SWELL - at - 2, scale: 0.9, pal: [PALE, WHITE, VIOLET], tex: kit.tex(T.thinRings), to: 1.15, level: 0.8 }),
];
const user = [
  ...core("left", [-0.7, 0.5, 0.9], 6), ...core("right", [0.8, 0.3, 0.9], 9),
  ...sparks(kit, "bubbles", { pos: [0, 0.4, 0.7], radius: 2.0, speed: 0.03, count: 1, bursts: SWELL / 3, gap: 3, life: 14, scale: 0.24, pal: [WHITE, PALE, PINK], shape: "ball", tex: kit.tex(T.ring) }),
  ...ring(kit, "rim", { pos: USER, life: SWELL + 4, scale: 2.5, pal: [PALE, WHITE, PINK], tex: kit.tex(T.ring), to: 1.25, level: 0.75 }),
  ...glow(kit, "sphere", { pos: USER, life: SWELL + 4, scale: 2.5, pal: [PINK, PALE, HOT], tex: kit.tex(T.softDisc), level: 0.5, scaleCurve: grow(0.35, 0.3, 1.25) }),
  ...ring(kit, "release", { pos: USER, at: SWELL, scale: 2.6, pal: [PINK, WHITE, HOT], to: 2.0, life: 9 }),
];
setCurves(kit.resources[kit.idx("rim")]!, grow(0.35, 0.3, 1.25), fadeInOut(0.75, 0.15, 0.85));

// --- 2. the box of force ---
const HALF = 1.5, TOP = 1.6;
function edge(name: string, x: number, z: number, at: number): string {
  const r = kit.parked(kit.tex(T.streak), [x, TOP - 1.2, FOE[2] + z], 3.3, BOX + 16);
  r.startDelayFrames = at;
  r.aspectRatio = 0.1;
  setCurves(r, grow(0.2, 0.2, 1.02), fadeInOut(1, 0.1, 0.8));
  paint(r, WHITE, WHITE, PALE);
  kit.add(name, r);
  return name;
}
const wall = kit.parked(panelTex, [0, TOP - 1.4, FOE[2] - 0.2], 3.0, BOX + 16);
wall.aspectRatio = HALF / 3.0;
setCurves(wall, grow(0.3, 0.2, 1.02), fadeInOut(0.5, 0.15, 0.8));
paint(wall, VIOLET, PINK, VIOLET);
kit.add("wall", wall);
const foe = [
  edge("edgeFL", -HALF, 0.5, 0), edge("edgeFR", HALF, 0.5, 1), edge("edgeBL", -HALF + 0.5, -0.4, 2), edge("edgeBR", HALF + 0.5, -0.4, 3),
  ...impact(kit, "burst", { at: BOX, pal: [PINK, PALE, HOT], size: 1.25, rays: 0, flecks: 0 }),
  ...streaks(kit, "jagsPink", { at: BOX, radius: 0.5, speed: 0.36, count: 7, life: 11, scale: 0.9, pal: [HOT, PINK, VIOLET], tex: kit.tex(T.shard) }),
  ...streaks(kit, "jagsBright", { at: BOX + 1, radius: 0.5, speed: 0.3, count: 7, life: 11, scale: 0.8, pal: [CYAN, YELLOW, WHITE], tex: kit.tex(T.shard) }),
  ...streaks(kit, "risingLines", { pos: [0, -1.2, 0.8], at: 2, radius: HALF, speed: 0, count: 2, bursts: 7, gap: 3, life: 8, scale: 1.0, pal: [WHITE, PALE, PINK], flat: true, lift: 0.4 }),
  ...sparks(kit, "ringlets", { at: BOX + 2, radius: 1.0, speed: 0.16, count: 5, life: 14, scale: 0.26, pal: [WHITE, PALE, YELLOW], shape: "circle", tex: kit.tex(T.ring), twinkle: false }),
  "wall",
];

const burstAt = SWELL + PAN + BOX;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1474, 0, { vol: 85 }),
  snd(1434, 6, { ch: "SE2", pitch: 400, vol: 100 }),
  snd(1505, SWELL, { vol: 115 }),
  snd(1510, SWELL + PAN, { ch: "SE2", side: "D", pitch: 300, vol: 110 }),
  snd(1475, burstAt, { side: "D", pitch: 200, vol: 125 }),
  snd(1455, burstAt + 1, { ch: "SE2", side: "D", vol: 115 }),
)}
${tint("ATTACKER", 0, 7, 6, [31, 20, 28])}
${emits(kit, user, "ATTACKER")}
${shake("ATTACKER", 819, SWELL / 2 - 4)}
Wait ${SWELL}
${squash("ATTACKER", -819, 819, 4)}
${tint("ATTACKER", 7, 0, 4, [31, 20, 28])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
Wait ${BOX}
${hit({ rgb: [31, 22, 29], power: 3, freeze: false })}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 381, 564],
  references: ["reference/Expanding_Force_VIII.png", "reference/Expanding_Force_VIII_2.png", "reference/Expanding_Force_IX.png", "reference/Expanding_Force_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("sphere")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("edgeFL")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("jagsPink")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  sphere f${CAMERA_IN}-${CAMERA_IN + SWELL}, box f${CAMERA_IN + SWELL + PAN}, burst f${CAMERA_IN + burstAt}`);
