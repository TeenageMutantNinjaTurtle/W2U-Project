MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 961
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, 0, 105, 0, 0, 0
PlaySound 1495, SE2, 14, 6, 300, 80, 0, 0, 0
PlaySound 1376, SE1, 14, 36, 0, 0, 0, 0, 0
PlaySound 1651, SE2, 14, 36, -300, 127, 0, 0, 0
PlaySound 2010, SE2, 16, 44, 0, 127, 0, 0, 0
PlaySound 1423, SE1, 16, 44, 200, 120, 0, 0, 0
PlaySound 1475, SE1, 16, 49, -400, 127, 0, 0, 0
PlaySound 1413, SE2, 16, 51, -200, 127, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 13, 0, 1, 2, 8
ChangeSpriteColor ATTACKER, 0, 10, 0, 12, 22, 31
Emit 961, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 961, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 961, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 961, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 961, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 961, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 961, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 11
Wait 30
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 6, 0, 1
Wait 6
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 4px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 961, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 961, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 961, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 961, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 961, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 961, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 961, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 961, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 961, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 961, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 12, 12, 0, 24, 30, 31
Wait 5
ChangeBackgroundColor 4, 15, 15, 0, 31, 31, 22
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 31, 20
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 31, 20
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 15, 13, 1, 1, 2, 8
ChangeSpriteColor ATTACKER, 10, 0, 0, 12, 22, 31
Wait 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 8
ChangeBackgroundColor 4, 13, 0, 0, 1, 2, 8
Wait 20
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
