MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 973
AudioContainer CONTINUE
PlaySound 1470, SE1, 14, 2, -300, 80, 0, 0, 0
PlaySound 1509, SE2, 14, 16, 700, 95, 0, 0, 0
PlaySound 1407, SE1, 14, 22, 300, 120, 0, 0, 0
PlaySound 1514, SE1, 16, 29, -200, 127, 0, 0, 0
PlaySound 1514, SE2, 16, 32, 100, 127, 0, 0, 0
PlaySound 1475, SE1, 16, 32, -200, 120, 0, 0, 0
AudioContainer SUSPEND
ScaleSprite ATTACKER, ROUNDTRIP, 819, -1638, 14, 0, 1
Emit 973, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 18
ChangeSpriteColor ATTACKER, 0, 9, 0, 31, 6, 10
Wait 4
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 4px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, 7, 0, 8
Wait 7
ChangeBackgroundColor 4, 0, 10, 0, 14, 4, 18
Emit 973, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 973, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 973, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 973, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 973, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 973, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 973, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 973, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 973, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 973, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
Wait 3
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 16, 20
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 16, 20
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeSpriteColor ATTACKER, 9, 0, 0, 31, 6, 10
Wait 16
ChangeBackgroundColor 4, 10, 0, 0, 14, 4, 18
Wait 10
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
