import { createKit, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FOE_FLOOR, glow, hit, impact, intro, outro, pan, puffs, ring, risers, shake, snd, sparks, streaks, tint, USER, USER_FLOOR, WHITE, type Pal } from "../tools/phrases";

// Bitter Malice (move 841) - from the Bulbapedia stills (reference/sheet.png).
//   1. Malice boils off the user: black wisps and violet-blue tendrils of it
//      writhing round its body, the light going out of the arena.
//   2. A black pool opens under the foe, rimmed in violet.
//   3. The malice rises out of it: black shapes and blue-violet tendrils
//      climbing over the foe, a cold blue light at the heart of it, flecks
//      of black thrown off.
// The Attack drop (the frostbite of Legends: Arceus) is the engine's.

const SPA = 1021;
const kit = await createKit({ workDir: import.meta.dirname, slug: "bitter-malice", moveId: 841, spaId: SPA, donors: [228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 10;
const BOIL = 24;
const PAN = 10;
const POOL = 8; // the pool opens before the malice rises
const RISE = 30;
const AFTER = 14;

const INK: Rgb = [0.03, 0.02, 0.06];
const NIGHT: Rgb = [0.12, 0.06, 0.25];
const VIOLET: Rgb = [0.5, 0.25, 1.0];
const BLUE: Rgb = [0.3, 0.4, 1.0];
const PALE: Rgb = [0.8, 0.8, 1.0];
const SHADE: Pal = [INK, NIGHT, INK];

// --- 1. it boils off the user ---
const user = [
  ...streaks(kit, "tendrils", { pos: USER, radius: 1.0, speed: 0.2, count: 3, bursts: BOIL / 4, gap: 4, life: 10, scale: 1.0, pal: [VIOLET, BLUE, NIGHT], lift: 0.12 }),
  ...puffs(kit, "wisps", { pos: USER, radius: 1.3, count: 2, bursts: BOIL / 4, gap: 4, life: 14, scale: 0.9, pal: SHADE, speed: 0.06, rise: 0.04, level: 0.9, tex: kit.tex(T.clumps) }),
  ...sparks(kit, "glare", { pos: [0.2, 0.9, -0.2], at: 6, radius: 0, speed: 0, count: 1, bursts: 2, gap: 9, life: 7, scale: 0.6, pal: [[1.0, 0.4, 0.7], WHITE, VIOLET], shape: "ball", tex: kit.tex(T.sparkle4) }),
  ...ring(kit, "userPool", { pos: USER_FLOOR, life: BOIL + 2, scale: 0.85, pal: [VIOLET, BLUE, NIGHT], to: 1.2, aspect: 2.6, level: 0.8 }),
  ...glow(kit, "pall", { pos: USER, life: BOIL + 4, scale: 3.0, pal: [NIGHT, INK, VIOLET], level: 0.85 }),
];

// --- 2./3. the pool, and what rises from it ---
const foe = [
  ...sparks(kit, "flecks", { at: POOL, radius: 0.8, speed: 0.2, count: 3, bursts: 4, gap: 6, life: 14, scale: 0.22, pal: SHADE, fall: 0.01, tex: kit.tex(T.clumps), twinkle: false, spin: 0.2 }),
  ...risers(kit, "blueTendrils", { pos: FOE_FLOOR, at: POOL, frames: RISE - 6, radius: 1.3, speed: 0.34, scale: 1.1, life: 10, every: 2, pal: [BLUE, PALE, VIOLET], streak: true }),
  ...puffs(kit, "shapes", { pos: [0, -0.8, 0.8], at: POOL, radius: 1.7, count: 2, bursts: RISE / 4, gap: 4, life: 14, scale: 0.85, pal: SHADE, speed: 0.05, rise: 0.1, level: 0.8, tex: kit.tex(T.clumps), to: 1.4 }),
  ...impact(kit, "pulse", { at: POOL + 14, pal: [BLUE, PALE, VIOLET], size: 1.4, rays: 6, flecks: 0, spiky: false }),
  ...glow(kit, "coldHeart", { pos: FOE, at: POOL, life: RISE, scale: 2.2, pal: [BLUE, PALE, VIOLET], level: 0.85 }),
  ...ring(kit, "poolRim", { pos: FOE_FLOOR, life: POOL + RISE, scale: 0.9, pal: [VIOLET, BLUE, NIGHT], to: 1.25, aspect: 2.6, level: 0.9 }),
  ...glow(kit, "pool", { pos: FOE_FLOOR, life: POOL + RISE, scale: 1.1, pal: [INK, INK, NIGHT], tex: kit.tex(T.softDisc), aspect: 2.6, level: 0.95 }),
  ...glow(kit, "gloom", { pos: FOE, at: POOL, life: RISE, scale: 3.4, pal: [NIGHT, INK, VIOLET], level: 0.45 }),
];

const poolAt = BOIL + PAN;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1434, 0, { pitch: -300, vol: 115 }),
  snd(1815, 6, { ch: "SE2", pitch: -200, vol: 105 }),
  snd(1815, poolAt, { side: "D", pitch: -500, vol: 115 }),
  snd(1434, poolAt + POOL, { ch: "SE2", side: "D", pitch: -500, vol: 120 }),
  snd(1420, poolAt + POOL + 1, { side: "D", pitch: -300, vol: 115 }),
  snd(1475, poolAt + POOL + 14, { side: "D", pitch: -500, vol: 125 }),
)}
${arena(0, 11, 10, [3, 1, 8])}
${tint("ATTACKER", 0, 10, 8, [6, 3, 14])}
${emits(kit, user, "ATTACKER")}
${shake("ATTACKER", 819, BOIL / 2 - 4)}
Wait ${BOIL}
${tint("ATTACKER", 10, 0, 6, [6, 3, 14])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
Wait ${POOL + 1}
${hit({ rgb: [16, 12, 31], power: 1 })}
${shake("DEFENDER", 819, 5)}
Wait ${14 - 1 - 2}
${hit({ rgb: [14, 14, 31], power: 3, freeze: false })}
Wait ${RISE - 14 - 6 - 8}
${arena(11, 0, 10, [3, 1, 8])}
Wait ${8 + AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [247, 399, 63, 605, 400, 240, 153, 129],
  references: ["reference/Bitter_Malice_LA.png", "reference/Bitter_Malice_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("wisps")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("pool")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("blueTendrils")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  boil f${CAMERA_IN}, pool f${CAMERA_IN + poolAt}, rises f${CAMERA_IN + poolAt + POOL}, pulse f${CAMERA_IN + poolAt + POOL + 14}`);
