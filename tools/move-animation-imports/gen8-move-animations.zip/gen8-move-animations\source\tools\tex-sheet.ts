// usage (from Pokeweb-Serverless/): npx vite-node ../work/tools/tex-sheet.ts -- <out.png> <spaId>...
// Renders every texture of the given donor-pool SPAs in one row per SPA, left
// to right by texture index, each fitted into a 96px cell on a checkerboard.
// Prints each resource's texture / shape so a shell can be picked.
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { PNG } from "../../Pokeweb-Serverless/node_modules/pngjs/lib/png.js";
import { parseSpaArchive } from "../../Pokeweb-Serverless/src/pokeweb/nitroSpa";

const [out, ...ids] = process.argv.slice(2).filter((a) => a !== "--");
const CELL = 96, GAP = 4;
const archives = await Promise.all(ids.map(async (id) => parseSpaArchive(new Uint8Array(await readFile(path.join(import.meta.dirname, `../donor-pool/spa_${id}.spa`))))));
const cols = Math.max(...archives.map((a) => a.textures.length));
const png = new PNG({ width: cols * (CELL + GAP), height: archives.length * (CELL + GAP) });
png.data.fill(20);
archives.forEach((a, row) => {
  a.textures.forEach((t, col) => {
    const s = Math.min(CELL / t.width, CELL / t.height);
    const w = Math.round(t.width * s), h = Math.round(t.height * s);
    for (let y = 0; y < CELL; y++) for (let x = 0; x < CELL; x++) {
      const di = ((row * (CELL + GAP) + y) * png.width + col * (CELL + GAP) + x) * 4;
      const bg = (Math.floor(x / 12) + Math.floor(y / 12)) % 2 === 0 ? 60 : 90;
      let rgb = [bg, bg, bg];
      if (x < w && y < h) {
        const si = (Math.min(t.height - 1, Math.floor(y / s)) * t.width + Math.min(t.width - 1, Math.floor(x / s))) * 4;
        const al = t.rgba[si + 3]! / 255;
        rgb = [0, 1, 2].map((k) => Math.round(t.rgba[si + k]! * al + bg * (1 - al)));
      }
      png.data.set([rgb[0]!, rgb[1]!, rgb[2]!, 255], di);
    }
  });
  console.log(`SPA ${ids[row]}: ${a.textures.map((t, i) => `${i}:${t.width}x${t.height}`).join(" ")}`);
  for (const r of a.resources) {
    console.log(`  res ${r.index}: tex ${r.textureIndex}${r.texAnim ? ` anim[${r.texAnim.textures.slice(0, r.texAnim.textureCount).join(",")}]${r.texAnim.loop ? " loop" : ""}` : ""} emit ${r.emissionType}/${r.emissionCount}x every ${r.emissionIntervalFrames} for ${r.emitterLifeFrames} life ${r.particleLifeFrames} scale ${r.baseScale.toFixed(2)} r ${r.radius.toFixed(2)} vel ${r.initVelPosAmplifier.toFixed(2)}/${r.initVelAxisAmplifier.toFixed(2)} draw ${r.drawType}${r.followEmitter ? " follow" : ""}${r.childResource ? " +child" : ""} beh[${(r.behaviors ?? []).map((b: any) => b.type).join(",")}]`);
  }
});
await writeFile(out!, PNG.sync.write(png));
