import { createKit, deg, fadeOut, hold, paint, setCurves, spin, T, type Rgb } from "../tools/anim-kit";
import { audio, emits, FOE_FLOOR, glow, hit, impact, intro, lunge, outro, pan, puffs, quake, shake, snd, sparks, squash, streaks, tint, WHITE, type Pal } from "../tools/phrases";

// Stone Axe (move 830) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user swings its axe: a golden crescent sweeps across the front of
//      the foe from right to left, striking sparks as it passes.
//   2. The ground rumbles.
//   3. Pointed splinters of stone push up out of the ground under the foe,
//      chips flying.
// The right-to-left cut, the rumble and the spikes under the foe are Logan's
// direction (2026-10-03). The splinters are drawn
// (generated/texture-splinter.png); the cut is Psycho Cut's crescent; the
// chips are Crunch's debris. Leaving the stones on the field is the engine's.

const SPA = 1010;
const kit = await createKit({ workDir: import.meta.dirname, slug: "stone-axe", moveId: 830, spaId: SPA, donors: [413, 228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const WINDUP = 10;
const PAN = 7;
const SWEEP = 7; // the cut crossing the foe
const RUMBLE = 12;
const SPLINTERS = SWEEP + RUMBLE; // they come up once the ground has shaken
const STAND = 24;
const AFTER = 10;

const GOLD: Rgb = [1.0, 0.85, 0.25];
const PALE: Rgb = [1.0, 0.97, 0.75];
const ORANGE: Rgb = [1.0, 0.6, 0.15];
const ROCK: Pal = [[0.72, 0.66, 0.6], [0.9, 0.86, 0.8], [0.5, 0.45, 0.42]];

// --- a splinter of stone: a tall pointed shard, lit on one face ---
const splinterTex = await kit.drawn("splinter", 16, 32, "a3i5", (x, y) => {
  const px = x + 0.5 - 8, py = y + 0.5;
  const half = 0.5 + 6.5 * Math.min(1, py / 26);
  if (Math.abs(px - (30 - py) * 0.06) > half || py > 31.5) return undefined;
  if (Math.abs(px - (30 - py) * 0.06) > half - 1) return [70, 62, 58];
  const lit = px < 0.5;
  const grain = 0.9 + 0.1 * Math.sin(py * 0.9 + px * 0.5);
  const v = (lit ? 190 : 120) * grain;
  return [Math.round(v), Math.round(v * 0.93), Math.round(v * 0.86)];
});

// The cut: Psycho Cut's crescent, its curved edge leading, crossing in front
// of the foe from its right to its left; two fainter ones trail it.
const CUT_FROM = 2.4;
const CRESCENT_SITS = 0.9; // the crescent is drawn in the left of its texture, this far from the middle at these sizes
function cut(name: string, at: number, scale: number, level: number, colours: [Rgb, Rgb, Rgb]): string {
  const r = kit.parked(kit.tex(T.crescent), [CUT_FROM + CRESCENT_SITS, 0.3, 1.0], scale, SWEEP + 2);
  r.startDelayFrames = at;
  Object.assign(r, { axis: [-1, 0, 0], initVelAxisAmplifier: (2 * CUT_FROM) / SWEEP, airResistance: 1.0 });
  setCurves(r, hold(1), { start: level * 0.6, mid: level, end: 0, curveIn: 0.15, curveOut: 0.7 });
  paint(r, colours[0], colours[1], colours[2]);
  kit.add(name, r);
  return name;
}
const STRIKE = Math.floor(SWEEP / 2); // the cut reaches the foe halfway across
const stones: string[] = [];
for (const [i, [x, tilt, scale]] of ([[-1.25, 14, 0.6], [-0.4, 5, 0.78], [0.45, -7, 0.7], [1.25, -16, 0.55]] as const).entries()) {
  // Under the foe: their feet sit just below the ground line, in front of its own.
  const r = kit.parked(splinterTex, [x, FOE_FLOOR[1] + scale * 0.6, 1.0], scale, STAND - i);
  r.startDelayFrames = SPLINTERS + i;
  r.aspectRatio = 0.5;
  spin(r, 0, 0, deg(tilt));
  setCurves(r, { start: 0.15, mid: 1.08, end: 1, curveIn: 0.2, curveOut: 0.6 }, { start: 1, mid: 1, end: 0, curveIn: 0, curveOut: 0.8 });
  paint(r, WHITE);
  kit.add(`stone${i}`, r);
  stones.push(`stone${i}`);
}
const foe = [
  cut("cut", 0, 1.6, 1, [PALE, WHITE, GOLD]),
  cut("cutGlow", 0, 1.9, 0.9, [GOLD, PALE, ORANGE]),
  cut("cutTrail1", 1, 1.8, 0.5, [GOLD, PALE, ORANGE]),
  cut("cutTrail2", 2, 1.7, 0.3, [ORANGE, GOLD, ORANGE]),
  ...impact(kit, "strike", { at: STRIKE, pal: [GOLD, PALE, ORANGE], size: 1.3, rays: 8, flecks: 0 }),
  ...sparks(kit, "sparks", { at: STRIKE, radius: 0.6, speed: 0.34, count: 9, life: 13, scale: 0.13, pal: [GOLD, WHITE, ORANGE], fall: 0.012, twinkle: false, shape: "circle" }),
  // The rumble: dust and pebbles jumping off the ground.
  ...puffs(kit, "rumbleDust", { pos: FOE_FLOOR, at: SWEEP, radius: 1.8, count: 2, bursts: RUMBLE / 4, gap: 4, life: 10, scale: 0.45, pal: ROCK, speed: 0.04, rise: 0.02, level: 0.6 }),
  ...sparks(kit, "pebbles", { pos: FOE_FLOOR, at: SWEEP, radius: 1.8, speed: 0.06, count: 2, bursts: RUMBLE / 4, gap: 4, life: 8, scale: 0.12, pal: ROCK, fall: 0.03, tex: kit.tex(413, 2), twinkle: false }),
  ...stones,
  ...sparks(kit, "chips", { pos: FOE_FLOOR, at: SPLINTERS, radius: 1.6, speed: 0.22, count: 7, life: 18, scale: 0.24, pal: ROCK, fall: 0.026, tex: kit.tex(413, 2), twinkle: false, spin: 0.2 }),
  ...streaks(kit, "groundLines", { pos: [0, -1.1, 0.8], at: SPLINTERS, radius: 1.4, speed: 0.3, count: 6, life: 7, scale: 0.6, pal: [PALE, WHITE, GOLD], flat: true, lift: 0.2 }),
];
Object.assign(kit.resources[kit.idx("chips")]!, { axis: [0, 1, 0], initVelAxisAmplifier: 0.32 });
setCurves(kit.resources[kit.idx("chips")]!, hold(1), fadeOut(1, 0.8));
const user = glow(kit, "ready", { life: WINDUP + 4, scale: 2.2, pal: [GOLD, ORANGE, PALE], level: 0.5 });

const cutAt = WINDUP + PAN;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1407, WINDUP - 2, { pitch: -200, vol: 115 }),
  snd(1514, cutAt, { side: "D", pitch: -300, vol: 127 }),
  snd(1435, cutAt + STRIKE, { ch: "SE2", side: "D", pitch: 200, vol: 110 }),
  snd(1884, cutAt + SWEEP, { side: "D", pitch: -600, vol: 100 }),
  snd(1417, cutAt + SPLINTERS, { ch: "SE2", side: "D", vol: 115 }),
  snd(1884, cutAt + SPLINTERS + 1, { side: "D", vol: 115 }),
)}
${tint("ATTACKER", 0, 7, 3, [31, 27, 10])}
${emits(kit, user, "ATTACKER")}
${squash("ATTACKER", -819, 819, 4)}
Wait ${WINDUP}
${lunge("ATTACKER", 4)}
${tint("ATTACKER", 7, 0, 4, [31, 27, 10])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
Wait ${STRIKE}
${hit({ rgb: [31, 29, 16], power: 2 })}
Wait ${SWEEP - STRIKE - 4}
${quake("0.5x", RUMBLE / 2)}
${shake("DEFENDER", 410, RUMBLE / 2)}
Wait ${RUMBLE}
${quake("0.5x", 3)}
Wait ${STAND + AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [242, 427, 63, 605, 400, 240, 129],
  references: ["reference/Stone_Axe_LA.png", "reference/Stone_Axe_IX.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("cut")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("stone0")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  cut f${CAMERA_IN + cutAt}-${CAMERA_IN + cutAt + SWEEP}, rumble until f${CAMERA_IN + cutAt + SPLINTERS}, splinters f${CAMERA_IN + cutAt + SPLINTERS}-${CAMERA_IN + cutAt + SPLINTERS + STAND}`);
