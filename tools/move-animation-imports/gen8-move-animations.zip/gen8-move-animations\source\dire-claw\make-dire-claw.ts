import { createKit, T, type Rgb } from "../tools/anim-kit";
import { audio, emits, FOE, glow, hit, impact, intro, lunge, outro, pan, puffs, slash, snd, sparks, squash, streaks, tint, WHITE, type Pal } from "../tools/phrases";

// Dire Claw (move 827) - from the Bulbapedia stills (reference/sheet.png:
// Legends: Arceus, then Scarlet/Violet).
//   1. The user rakes the foe: three parallel claw strokes, white edged in
//      teal, with violet streaks flying off them.
//   2. The wound bursts in a blot of green venom, bubbling.

const SPA = 1007;
const kit = await createKit({ workDir: import.meta.dirname, slug: "dire-claw", moveId: 827, spaId: SPA, donors: [228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 10;
const WINDUP = 9;
const PAN = 7;
const VENOM = 5; // the blot follows the rake
const AFTER = 24;

const TEAL: Rgb = [0.5, 1.0, 0.9];
const PALE: Rgb = [0.92, 1.0, 0.97];
const VIOLET: Rgb = [0.6, 0.25, 1.0];
const DEEP: Rgb = [0.35, 0.1, 0.75];
const GREEN: Rgb = [0.3, 0.9, 0.5];
const VENOM_PAL: Pal = [GREEN, [0.75, 1.0, 0.8], [0.15, 0.7, 0.4]];

const OFFSETS = [-0.55, 0, 0.55];
const foe = [
  ...OFFSETS.flatMap((d, i) => [
    ...slash(kit, `claw${i}`, { pos: [d * 0.8, 0.3 - d * 0.6, 1.0], at: i, angle: 52, scale: 3.0, pal: [PALE, WHITE, TEAL], life: 8, aspect: 0.16 }),
    ...slash(kit, `clawEdge${i}`, { pos: [d * 0.8, 0.3 - d * 0.6, 0.95], at: i, angle: 52, scale: 3.2, pal: [TEAL, PALE, [0.2, 0.8, 0.7]], life: 9, aspect: 0.34 }),
  ]),
  ...streaks(kit, "violetStreaks", { at: 1, radius: 0.5, speed: 0.5, count: 9, life: 9, scale: 1.0, pal: [VIOLET, [0.85, 0.65, 1.0], DEEP] }),
  ...sparks(kit, "shreds", { at: 1, radius: 0.6, speed: 0.28, count: 6, life: 12, scale: 0.14, pal: [VIOLET, DEEP, [0.85, 0.65, 1.0]], fall: 0.012, twinkle: false }),
  // The venom.
  ...impact(kit, "wound", { at: VENOM, pal: [PALE, WHITE, GREEN], size: 1.0, rays: 0, flecks: 0, spiky: false }),
  ...puffs(kit, "venom", { pos: FOE, at: VENOM, radius: 0.6, count: 3, bursts: 2, gap: 3, life: 14, scale: 0.9, pal: VENOM_PAL, speed: 0.1, level: 0.95, tex: kit.tex(T.clumps), to: 1.5 }),
  ...sparks(kit, "bubbles", { at: VENOM + 1, radius: 0.9, speed: 0.12, count: 5, life: 14, scale: 0.22, pal: [[0.75, 1.0, 0.85], WHITE, GREEN], tex: kit.tex(T.ring), fall: -0.006, twinkle: false }),
];
const user = glow(kit, "ready", { life: WINDUP + 4, scale: 2.2, pal: [VIOLET, TEAL, DEEP], level: 0.5 });

const rakeAt = WINDUP + PAN;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1407, WINDUP - 2, { pitch: 300, vol: 115 }),
  snd(1514, rakeAt, { side: "D", pitch: 200, vol: 127 }),
  snd(1514, rakeAt + 2, { ch: "SE2", side: "D", pitch: 500, vol: 115 }),
  snd(1727, rakeAt + VENOM, { side: "D", pitch: 400, vol: 115 }),
)}
${tint("ATTACKER", 0, 7, 3, [20, 10, 31])}
${emits(kit, user, "ATTACKER")}
${squash("ATTACKER", -819, 819, 4)}
Wait ${WINDUP}
${lunge("ATTACKER", 4)}
${tint("ATTACKER", 7, 0, 4, [20, 10, 31])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
Wait 2
${hit({ rgb: [22, 31, 26], power: 2 })}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [163, 63, 605, 400, 240, 153, 129, 427],
  references: ["reference/Dire_Claw_LA.png", "reference/Dire_Claw_IX.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("claw0")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("venom")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  rake f${CAMERA_IN + rakeAt}, venom f${CAMERA_IN + rakeAt + VENOM}`);
