import { aimed, createKit, fadeOut, grow, hold, paint, setCurves, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FOE_FLOOR, glow, hit, impact, intro, lunge, outro, pan, puffs, quake, remapAnim, ring, shot, snd, sparks, squash, streaks, tint, WHITE, type Pal } from "../tools/phrases";

// Pyro Ball (move 780) - from the Bulbapedia stills (reference/sheet.png).
//   1. A small ball of fire forms at the user's foot.
//   2. The user juggles it: three kicks send it up and it drops back each
//      time, a little bigger for every kick.
//   3. The fourth kick launches it: a yellow ring flashes and the fireball
//      streaks across with flames trailing behind it.
//   4. It explodes on the foe in a massive burst of fire: a blinding blast,
//      a second one behind it, balls of fire thrown out all round, red arcs
//      and smoke, the arena flushed red.
// The juggling and the bigger explosion are Logan's direction (2026-10-03).
// The fireball and the fire puffs are Fire Blast's (SPA 295).

const SPA = 960;
const kit = await createKit({ workDir: import.meta.dirname, slug: "pyro-ball", moveId: 780, spaId: SPA, donors: [295, 228, 465, 579, 411, 298, 560] });

const CAMERA_IN = 12;
const FORM = 10; // the ball forms
const JUGGLES = 3;
const BOUNCE = 10; // one kick up and back down
const HEIGHT = 1.6; // how high each kick sends it
const BUILD = FORM + JUGGLES * BOUNCE;
const HOLD = 0;
const TRAVEL = 8;
const AFTER = 30;

const ORANGE: Rgb = [1.0, 0.6, 0.15];
const YELLOW: Rgb = [1.0, 0.9, 0.35];
const PALE: Rgb = [1.0, 0.97, 0.75];
const RED: Rgb = [1.0, 0.25, 0.12];
const PAL: Pal = [YELLOW, PALE, ORANGE];
const FOOT: Vec3 = [0.5, -0.5, -0.6];

// Fire Blast's churning fireball.
function fireball(pos: Vec3, scale: number, at: number, life: number): ReturnType<typeof kit.shell> {
  const r = remapAnim(kit, kit.shell(295, 0), 295);
  Object.assign(r, { emitterBasePos: [...pos], baseScale: scale, startDelayFrames: at, particleLifeFrames: life, radius: 0 });
  return r;
}

// --- 1. the ball forms at the user's foot ---
const forming = fireball(FOOT, 0.5, 0, FORM);
if (forming.scaleAnim) Object.assign(forming.scaleAnim, { start: 0.15, mid: 0.8, end: 1, curveIn: 0.6, curveOut: 0.9, loop: false });
kit.add("forming", forming);
// --- 2. three kicks: up it goes and back it comes, bigger each time ---
const juggled: string[] = [];
for (let i = 0; i < JUGGLES; i++) {
  const r = fireball(FOOT, 0.55 + i * 0.16, FORM + i * BOUNCE, BOUNCE);
  // Thrown straight up, pulled back to the foot in BOUNCE frames.
  Object.assign(r, { axis: [0, 1, 0], initVelAxisAmplifier: (4 * HEIGHT) / BOUNCE, initVelPosAmplifier: 0, airResistance: 1.0, followEmitter: false, behaviors: [{ type: "gravity", magnitude: [0, (-8 * HEIGHT) / (BOUNCE * BOUNCE), 0] }] });
  if (r.scaleAnim) Object.assign(r.scaleAnim, { start: 1, mid: 1.08, end: 1, curveIn: 0.5, curveOut: 0.5, loop: false });
  kit.add(`juggle${i}`, r);
  juggled.push(`juggle${i}`);
}
const user = [
  "forming",
  ...juggled,
  // A flash at the foot for each kick.
  ...Array.from({ length: JUGGLES }, (_, i) => glow(kit, `tap${i}`, { pos: FOOT, at: FORM + i * BOUNCE, life: 5, scale: 0.8, pal: [PALE, WHITE, YELLOW], tex: kit.tex(T.hitStar), spin: 0.2, level: 1, scaleCurve: grow(0.5, 0.3, 1.2), alpha: fadeOut(1, 0.4) })).flat(),
  ...sparks(kit, "embers", { pos: FOOT, radius: 0.5, speed: 0.12, count: 2, bursts: JUGGLES + 1, gap: BOUNCE, life: 10, scale: 0.13, pal: [YELLOW, PALE, ORANGE], fall: 0.008, twinkle: false }),
  ...glow(kit, "heat", { pos: FOOT, life: BUILD, scale: 1.3, pal: [ORANGE, RED, YELLOW], level: 0.5 }),
  // --- 3. the launch ---
  ...ring(kit, "kickRing", { pos: FOOT, at: BUILD + HOLD, scale: 1.4, pal: [YELLOW, PALE, ORANGE], tex: kit.tex(T.hoop), to: 2.3, life: 9 }),
  ...glow(kit, "kickFlash", { pos: FOOT, at: BUILD + HOLD, life: 7, scale: 1.6, pal: [PALE, WHITE, YELLOW], tex: kit.tex(T.spiky), spin: 0.2, level: 1, scaleCurve: grow(0.5, 0.3, 1.3), alpha: fadeOut(1, 0.4) }),
];
const ball = fireball(FOOT, 1.25, BUILD + HOLD, TRAVEL + 1);
aimed(ball, 16 / TRAVEL, TRAVEL + 1);
ball.airResistance = 1.0;
if (ball.scaleAnim) Object.assign(ball.scaleAnim, { start: 1, mid: 1, end: 1.1, curveIn: 0, curveOut: 1, loop: false });
kit.add("ball", ball);
// Flames strung out behind it.
shot(kit, "trail", kit.tex(295, 4), { from: FOOT, at: BUILD + HOLD + 1, travel: TRAVEL, scale: 0.85, pal: [WHITE, WHITE, WHITE], count: 4, gap: 1, scaleCurve: grow(1, 0.1, 0.5), alpha: fadeOut(0.9, 0.3) });

// --- 4. the explosion ---
const blast = fireball(FOE, 3.0, 0, 18);
if (blast.scaleAnim) Object.assign(blast.scaleAnim, { start: 0.4, mid: 1, end: 1.25, curveIn: 0.25, curveOut: 0.8, loop: false });
kit.add("blast", blast);
const blast2 = fireball([0.3, 0.7, 0.8], 2.0, 6, 14);
if (blast2.scaleAnim) Object.assign(blast2.scaleAnim, { start: 0.5, mid: 1, end: 1.2, curveIn: 0.3, curveOut: 0.8, loop: false });
kit.add("blast2", blast2);
const foe = [
  ...impact(kit, "boom", { pal: PAL, size: 2.1, rays: 10, flecks: 0 }),
  // Balls of fire thrown out all round.
  ...sparks(kit, "fireballs", { radius: 0.6, speed: 0.36, count: 6, life: 13, scale: 0.6, pal: [WHITE, WHITE, WHITE], shape: "circle", tex: kit.tex(295, 4), twinkle: false, spin: 0.2 }),
  "blast2",
  "blast",
  ...ring(kit, "redArc", { at: 1, scale: 2.0, pal: [RED, ORANGE, RED], tex: kit.tex(T.ring), to: 2.3, life: 12 }),
  ...ring(kit, "redArc2", { at: 6, scale: 1.6, pal: [ORANGE, YELLOW, RED], tex: kit.tex(T.ring), to: 2.5, life: 12 }),
  ...streaks(kit, "tongues", { radius: 0.6, speed: 0.46, count: 8, life: 11, scale: 1.0, pal: [ORANGE, YELLOW, RED], tex: kit.tex(T.spike) }),
  ...sparks(kit, "cinders", { at: 4, radius: 1.2, speed: 0.2, count: 3, bursts: 3, gap: 4, life: 14, scale: 0.14, pal: [YELLOW, PALE, ORANGE], fall: 0.01 }),
  ...puffs(kit, "smoke", { pos: FOE_FLOOR, at: 8, radius: 1.6, count: 3, life: 16, scale: 1.0, pal: [[0.28, 0.18, 0.14], [0.5, 0.36, 0.26], [0.12, 0.08, 0.06]], speed: 0.14, rise: 0.03, level: 0.7 }),
];
setCurves(kit.resources[kit.idx("tongues")]!, grow(1.2, 0.3, 0.6), fadeOut());
setCurves(kit.resources[kit.idx("fireballs")]!, grow(0.8, 0.3, 1.3), fadeOut(1, 0.5));

const kickAt = BUILD + HOLD;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1426, 0, { pitch: 400, vol: 95 }),
  ...Array.from({ length: JUGGLES }, (_, i) => snd(1423, FORM + i * BOUNCE, { ch: "SE2", pitch: 500 + i * 150, vol: 100 })),
  snd(1376, kickAt, { ch: "SE2", vol: 0 }),
  snd(1425, kickAt, { vol: 127 }),
  snd(1423, kickAt, { ch: "SE2", pitch: 300, vol: 115 }),
  `SwitchAudioSide SE1, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0`,
  snd(1475, kickAt + TRAVEL, { side: "D", pitch: -300, vol: 127 }),
  snd(1475, kickAt + TRAVEL + 8, { ch: "SE2", side: "D", pitch: -500, vol: 120 }),
  snd(1426, kickAt + TRAVEL + 10, { side: "D", vol: 110 }),
)}
${tint("ATTACKER", 0, 8, 6, [31, 18, 6])}
${emits(kit, user, "ATTACKER")}
${emits(kit, ["ball", "trail"], "ATTACKER", "DEFENDER")}
Wait ${FORM}
${Array.from({ length: JUGGLES }, () => [squash("ATTACKER", 410, -410, 2), `Wait ${BOUNCE}`].join(String.fromCharCode(10))).join(String.fromCharCode(10))}
${lunge("ATTACKER", 3)}
${tint("ATTACKER", 8, 0, 4, [31, 18, 6])}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${arena(0, 13, 0, [31, 26, 18])}
${hit({ rgb: [31, 28, 16], power: 3 })}
${arena(13, 9, 3, [28, 8, 6])}
Wait 8
${quake("2458", 8)}
Wait 10
${quake("1x", 6)}
${arena(9, 0, 10, [28, 8, 6])}
Wait ${AFTER - 18}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [126, 63, 605, 400, 240, 129, 381],
  references: ["reference/Pyro_Ball_VIII.png", "reference/Pyro_Ball_VIII_2.png", "reference/Pyro_Ball_IX.png", "reference/Pyro_Ball_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("juggle0")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("juggle2")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("ball")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("blast")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  forms f${CAMERA_IN}, juggled f${CAMERA_IN + FORM}-${CAMERA_IN + BUILD}, launched f${CAMERA_IN + kickAt}, blast f${CAMERA_IN + kickAt + TRAVEL}`);
