import { createKit, fadeInOut, fadeOut, grow, setCurves, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, beam, emits, FOE, FRONT, glow, hit, impact, intro, lunge, outro, pan, quake, ring, shake, snd, sparks, streaks, tint, USER, WHITE, type Pal } from "../tools/phrases";

// Dragon Energy (move 820) - from the Bulbapedia stills (reference/sheet.png).
//   1. The light turns a dark purple. Spheres of purple energy with hot red
//      cores swell in the air all round the user.
//   2. They rush in and it lets the lot go at once: a torrent of dark purple
//      and deep red energy.
//   3. The foe vanishes in a deep red blast.
// Dark purple and deep red (rather than the pink of the stills) are Logan's
// direction (2026-10-03).

const SPA = 1000;
const kit = await createKit({ workDir: import.meta.dirname, slug: "dragon-energy", moveId: 820, spaId: SPA, donors: [228, 465, 579, 411, 298] });

const CAMERA_IN = 12;
const SWELL = 30;
const RUSH = 8; // the spheres rush in
const TRAVEL = 8;
const POUR = 20;
const AFTER = 26;

const PURPLE: Rgb = [0.28, 0.04, 0.5]; // the body of it: a dark purple
const EMBER: Rgb = [0.8, 0.14, 0.24]; // its highlights: a glowing red
const RED: Rgb = [0.52, 0.0, 0.06]; // its depths: a deep red
const HOT: Rgb = [0.95, 0.48, 0.52]; // the hottest points, in place of white
const PAL: Pal = [PURPLE, EMBER, RED];

// The spheres: a pink shell and a white core, spawned together round the user.
function spheres(name: string, tex: number, scale: number, colours: Pal, level: number, twinkling: boolean): string {
  const r = kit.spray([333, 1], tex, [0, 0.6, 0.3], { radius: 2.4, speed: 0, count: 1, bursts: 7, gap: 3, life: SWELL - 6, scale, shape: "ball" });
  r.variance.lifeTime = 0;
  // They hang, swelling, then rush in to the user as the charge peaks.
  r.behaviors = [{ type: "convergence", target: [0, 0, 0], force: 0.012 }];
  setCurves(r, grow(0.2, 0.4, 1.15), fadeInOut(level, 0.2, twinkling ? 0.9 : 0.85));
  kit.prism(r, colours);
  kit.add(name, r);
  return name;
}
const user = [
  spheres("cores", kit.tex(T.softDisc), 0.26, [HOT, EMBER, HOT], 1, true),
  spheres("shells", kit.tex(T.fuzzyGlow), 0.95, PAL, 0.8, false),
  ...glow(kit, "aura", { pos: USER, life: SWELL + RUSH, scale: 3.0, pal: [PURPLE, RED, EMBER], level: 0.6 }),
  ...streaks(kit, "rush", { pos: FRONT, at: SWELL, radius: 2.4, speed: -0.3, count: 4, bursts: 3, gap: 2, life: 7, scale: 0.8, pal: [EMBER, HOT, PURPLE] }),
  ...glow(kit, "core", { pos: FRONT, at: SWELL - 2, life: RUSH + POUR + 8, scale: 1.6, pal: [EMBER, HOT, PURPLE], tex: kit.tex(T.spiky), spin: 0.2, level: 1, scaleCurve: grow(0.3, 0.2, 1.1), alpha: fadeInOut(1, 0.1, 0.85) }),
  ...ring(kit, "release", { pos: FRONT, at: SWELL + RUSH, life: 10, scale: 1.6, pal: [EMBER, HOT, PURPLE], to: 2.4 }),
];
const shots = beam(kit, "torrent", { at: SWELL + RUSH, pour: POUR, travel: TRAVEL, width: 1.9, pal: [PURPLE, EMBER, RED], core: HOT, tex: kit.tex(T.softDisc) });

const foe = [
  ...impact(kit, "blast", { pal: PAL, size: 1.9, rays: 10, flecks: 0 }),
  ...glow(kit, "whiteout", { pos: FOE, life: POUR + 4, scale: 4.0, pal: [EMBER, HOT, PURPLE], level: 1, scaleCurve: grow(0.4, 0.15, 1.15), alpha: fadeInOut(1, 0.05, 0.7) }),
  ...ring(kit, "shock", { at: 2, scale: 2.3, pal: [EMBER, HOT, PURPLE], to: 2.4, life: 13 }),
  ...impact(kit, "blast2", { at: 10, pal: [RED, HOT, PURPLE], size: 1.5, rays: 8, flecks: 0, spiky: false }),
  ...sparks(kit, "motes", { at: POUR - 6, radius: 1.6, speed: 0.1, count: 3, bursts: 4, gap: 4, life: 14, scale: 0.18, pal: [PURPLE, HOT, RED], fall: -0.006, tex: kit.tex(T.softDisc) }),
];

const fireAt = SWELL + RUSH;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1497, 0, { pitch: -200, vol: 110 }),
  snd(1474, 6, { ch: "SE2", pitch: -300, vol: 90 }),
  snd(1505, SWELL, { ch: "SE2", vol: 110 }),
  snd(1975, fireAt, { vol: 127 }),
  snd(1424, fireAt, { ch: "SE2", pitch: -500, vol: 125 }),
  `SwitchAudioSide SE2, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0`,
  snd(1475, fireAt + TRAVEL, { side: "D", pitch: -400, vol: 127 }),
  snd(1420, fireAt + TRAVEL + 10, { ch: "SE2", side: "D", vol: 127 }),
)}
${arena(0, 12, 8, [6, 1, 10])}
${tint("ATTACKER", 0, 9, 8, [16, 3, 22])}
${emits(kit, user, "ATTACKER")}
${emits(kit, shots, "ATTACKER", "DEFENDER")}
${shake("ATTACKER", 819, SWELL / 2 - 4)}
Wait ${SWELL}
${tint("ATTACKER", 9, 14, 3, [26, 6, 10])}
${shake("ATTACKER", 1229, RUSH / 2)}
Wait ${RUSH}
${lunge("ATTACKER", -2)}
${shake("ATTACKER", 1229, POUR / 2)}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${arena(12, 15, 0, [24, 4, 8])}
${hit({ rgb: [28, 6, 10], power: 3, stop: 7 })}
${arena(15, 12, 4, [6, 1, 10])}
Wait 10
${quake("2458", 8)}
Wait ${POUR - 7 - 10}
${tint("ATTACKER", 14, 0, 5, [26, 6, 10])}
${arena(12, 0, 10, [6, 1, 10])}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129],
  references: ["reference/SwShCT_Prerelease_Dragon_Energy_2.png", "reference/Dragon_Energy_IX.png", "reference/Dragon_Energy_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("shells")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("torrentJet")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("blastFlash")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  spheres f${CAMERA_IN}, fires f${CAMERA_IN + fireAt}, lands f${CAMERA_IN + fireAt + TRAVEL}`);
