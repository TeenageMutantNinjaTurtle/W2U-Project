import { createKit, fadeOut, grow, hold, paint, setCurves, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FOE_FLOOR, glow, hit, impact, intro, outro, pan, quake, ring, risers, shake, snd, sparks, streaks, tint, USER, USER_FLOOR, WHITE, type Pal } from "../tools/phrases";

// Astral Barrage (move 825) - from the Bulbapedia stills (reference/sheet.png)
// and the two Sword/Shield screenshots and description Logan sent on
// 2026-10-03, in place of my first version.
//   1. A black and purple pit opens in the ground round the user.
//   2. For about two seconds small purple spirit balls leap up out of the pit
//      and fall back, turning round the user as they go.
//   3. Then the balls rise into the air together and are gone.
//   4. Shadow rains down on the foe - streaks and spirit balls falling out of
//      the sky - and it ends in a massive purple explosion: rings of magenta
//      light spreading overhead, spires of magenta bursting up out of the
//      ground.
// The spirit ball is drawn (generated/texture-spirit.png). The leaping and
// the turning are the engine's "gravity" and "spin" behaviours; the pit sits
// behind the user in depth so the user stands in it.

const SPA = 1005;
const kit = await createKit({ workDir: import.meta.dirname, slug: "astral-barrage", moveId: 825, spaId: SPA, donors: [228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 12;
const OPEN = 8; // the pit opens
const LEAPING = 52; // the balls leap (with OPEN, about two seconds)
const ASCEND = 10; // they rise out of sight
const PAN = 10;
const RAIN = 18;
const AFTER = 32;
const SUMMON = OPEN + LEAPING;

const VIOLET: Rgb = [0.6, 0.3, 1.0];
const PALE: Rgb = [0.88, 0.78, 1.0];
const MAGENTA: Rgb = [1.0, 0.25, 0.85];
const DEEP: Rgb = [0.16, 0.04, 0.34];
const INK: Rgb = [0.02, 0, 0.05];
const PAL: Pal = [VIOLET, PALE, MAGENTA];

// --- a spirit ball: a round purple body, paler at its heart, with a dark rim
// and a short tail curling down from it ---
const spiritTex = await kit.drawn("spirit", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5 - 16, py = y + 0.5;
  const head = Math.hypot(px, py - 11) - 8.5;
  const t = (py - 11) / 19;
  const tail = t >= 0 && t <= 1 ? Math.abs(px - 5 * t * Math.sin(t * Math.PI * 0.9)) - 8.5 * Math.pow(1 - t, 1.3) : 99;
  const d = Math.min(head, tail);
  if (d > 0) return undefined;
  if (d > -1.5) return [60, 14, 130, 255];
  const heart = Math.max(0, 1 - Math.hypot(px + 2, py - 9) / 8);
  return [Math.round(120 + 90 * heart), Math.round(40 + 90 * heart), Math.round(215 + 40 * heart), 255];
});

// --- 1. the pit: behind the user in depth (on the user's side, negative z is
// away from the camera), so the user's sprite covers it and stands in it ---
const PIT: Vec3 = [0, USER_FLOOR[1] - 0.1, -0.7];
const pit = [
  ...ring(kit, "pitRim", { pos: PIT, life: SUMMON + ASCEND + 4, scale: 1.05, pal: [VIOLET, MAGENTA, DEEP], to: 1.05, aspect: 2.6, level: 0.9 }),
  ...glow(kit, "pitGlow", { pos: PIT, life: SUMMON + ASCEND + 4, scale: 1.25, pal: [DEEP, VIOLET, INK], aspect: 2.6, level: 0.8 }),
  ...glow(kit, "pit", { pos: PIT, life: SUMMON + ASCEND + 4, scale: 0.95, pal: [INK, INK, DEEP], tex: kit.tex(T.softDisc), aspect: 2.6, level: 1 }),
];
for (const n of ["pitRim", "pitGlow", "pit"]) setCurves(kit.resources[kit.idx(n)]!, { start: 0.1, mid: 1, end: 0.3, curveIn: OPEN / (SUMMON + ASCEND + 4), curveOut: 0.92 }, { start: 0.6, mid: n === "pit" ? 1 : 0.9, end: 0, curveIn: 0.06, curveOut: 0.92 });

// --- 2. the spirit balls leap: thrown up from anywhere on a ring on the
// ground, pulled back down, and turned round the user all the while ---
const LEAP = 14; // frames one ball is in the air
const LEAP_HEIGHT = 1.5;
const ROUND = (2 * Math.PI) / 22; // how far round the user a ball goes each frame
const leapers = kit.spray([333, 1], spiritTex, USER_FLOOR, { radius: 1.7, speed: 0, count: 2, bursts: Math.floor((LEAPING - LEAP) / 3) + 1, gap: 3, life: LEAP, scale: 0.34, shape: "circle" });
Object.assign(leapers, { startDelayFrames: OPEN, emissionAxis: 1, axis: [0, 1, 0], initVelAxisAmplifier: (4 * LEAP_HEIGHT) / LEAP, airResistance: 1.0 });
leapers.variance.lifeTime = 0;
leapers.behaviors = [{ type: "gravity", magnitude: [0, (-8 * LEAP_HEIGHT) / (LEAP * LEAP), 0] }, { type: "spin", axis: 1, angle: ROUND }];
setCurves(leapers, { start: 0.5, mid: 1, end: 0.7, curveIn: 0.3, curveOut: 0.8 }, { start: 0.6, mid: 1, end: 0.5, curveIn: 0.15, curveOut: 0.85 });
paint(leapers, WHITE);
kit.add("leapers", leapers);

// --- 3. they rise: six on an even ring, still turning, straight up and away ---
const risen = kit.parked(spiritTex, USER_FLOOR, 0.38, ASCEND);
Object.assign(risen, { startDelayFrames: SUMMON, emissionType: 3, emissionAxis: 1, emissionCount: 6, radius: 1.7, axis: [0, 1, 0], initVelAxisAmplifier: 0.62, airResistance: 1.0 });
risen.behaviors = [{ type: "spin", axis: 1, angle: ROUND }];
setCurves(risen, hold(1), { start: 1, mid: 1, end: 0, curveIn: 0, curveOut: 0.8 });
paint(risen, WHITE);
kit.add("risen", risen);

const user = [
  "leapers",
  "risen",
  ...risers(kit, "riseTrails", { pos: USER_FLOOR, at: SUMMON, frames: ASCEND - 2, radius: 1.7, speed: 0.6, scale: 1.2, life: 7, every: 1, count: 2, pal: [VIOLET, PALE, DEEP], streak: true }),
  ...sparks(kit, "pitMotes", { pos: [0, -0.8, 0.3], at: OPEN, radius: 1.8, speed: 0.04, count: 1, bursts: LEAPING / 4, gap: 4, life: 12, scale: 0.13, pal: [PALE, WHITE, VIOLET], fall: -0.012, shape: "circle" }),
  ...pit,
  ...glow(kit, "aura", { pos: USER, life: SUMMON + ASCEND, scale: 2.8, pal: [VIOLET, DEEP, PALE], level: 0.4 }),
];

// --- 4. on the foe: the rain of shadow, then the explosion ---
const SKY: Vec3 = [0, 4.6, 0.85];
const foe = [
  // The explosion.
  ...impact(kit, "burst", { at: RAIN, pal: PAL, size: 2.1, rays: 9, flecks: 0 }),
  ...streaks(kit, "spires", { pos: [0, -1.1, 0.8], at: RAIN, radius: 0.9, speed: 0.2, count: 8, life: 12, scale: 1.5, pal: [MAGENTA, VIOLET, PALE], tex: kit.tex(T.spike), flat: true, lift: 0.5 }),
  ...ring(kit, "haloLow", { pos: [0, 1.0, 0.8], at: RAIN, life: 16, scale: 0.9, pal: [MAGENTA, PALE, VIOLET], tex: kit.tex(T.ring), aspect: 2.6, to: 2.4, level: 0.95 }),
  ...ring(kit, "haloMid", { pos: [0, 1.6, 0.8], at: RAIN + 3, life: 16, scale: 0.75, pal: [PALE, WHITE, MAGENTA], tex: kit.tex(T.ring), aspect: 2.6, to: 2.6, level: 0.9 }),
  ...ring(kit, "haloHigh", { pos: [0, 2.2, 0.8], at: RAIN + 6, life: 16, scale: 0.6, pal: [VIOLET, PALE, MAGENTA], tex: kit.tex(T.ring), aspect: 2.6, to: 2.8, level: 0.85 }),
  ...glow(kit, "dome", { pos: FOE, at: RAIN, life: 18, scale: 3.6, pal: [VIOLET, MAGENTA, DEEP], tex: kit.tex(T.softDisc), level: 0.75, scaleCurve: grow(0.4, 0.25, 1.15), alpha: fadeOut(0.75, 0.5) }),
  // The rain.
  ...risers(kit, "rainBalls", { pos: SKY, frames: RAIN - 4, radius: 1.3, speed: -0.6, scale: 0.36, life: 9, every: 3, pal: [WHITE, WHITE, WHITE], tex: spiritTex }),
  ...risers(kit, "rain", { pos: SKY, frames: RAIN - 2, radius: 1.5, speed: -0.72, scale: 1.4, life: 8, every: 1, count: 2, pal: [VIOLET, MAGENTA, DEEP], streak: true }),
  ...sparks(kit, "splashes", { pos: [0, -0.2, 0.9], at: 7, radius: 1.2, speed: 0.16, count: 2, bursts: (RAIN - 6) / 3, gap: 3, life: 9, scale: 0.15, pal: [PALE, WHITE, MAGENTA], shape: "circle" }),
  ...glow(kit, "floor", { pos: FOE_FLOOR, life: RAIN + 22, scale: 1.0, pal: [VIOLET, DEEP, MAGENTA], tex: kit.tex(T.softDisc), aspect: 2.6, level: 0.8 }),
];
setCurves(kit.resources[kit.idx("spires")]!, grow(1.2, 0.3, 0.7), fadeOut(1, 0.5));

const rainAt = SUMMON + ASCEND + PAN;
const boomAt = rainAt + RAIN;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1434, 0, { pitch: -800, vol: 115 }),
  snd(1815, OPEN, { ch: "SE2", pitch: -300, vol: 100 }),
  snd(1815, OPEN + 22, { ch: "SE2", pitch: 0, vol: 95 }),
  snd(1815, OPEN + 40, { ch: "SE2", pitch: 200, vol: 95 }),
  snd(1407, SUMMON, { pitch: 500, vol: 115 }),
  snd(1425, rainAt, { side: "D", pitch: -500, vol: 115 }),
  ...Array.from({ length: 3 }, (_, i) => snd(1420, rainAt + 7 + i * 4, { ch: i % 2 ? "SE1" : "SE2", side: "D", pitch: -200, vol: 112 })),
  snd(1475, boomAt, { side: "D", pitch: -500, vol: 127 }),
  snd(1815, boomAt, { ch: "SE2", side: "D", pitch: 300, vol: 122 }),
  snd(1475, boomAt + 8, { side: "D", pitch: -700, vol: 115 }),
)}
${arena(0, 13, 10, [3, 0, 8])}
${tint("ATTACKER", 0, 8, 8, [18, 8, 31])}
${emits(kit, user, "ATTACKER")}
${shake("ATTACKER", 819, 6)}
Wait ${SUMMON}
${tint("ATTACKER", 8, 0, 6, [18, 8, 31])}
Wait ${ASCEND}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
Wait 7
ToggleFreezeSprite DEFENDER, START
${tint("DEFENDER", 0, 9, 4, [20, 10, 31])}
${shake("DEFENDER", 1229, (RAIN - 7) / 2)}
Wait ${RAIN - 7}
${tint("DEFENDER", 9, 0, 0, [20, 10, 31])}
${arena(13, 15, 0, [24, 6, 28])}
${hit({ rgb: [28, 18, 31], power: 3, freeze: false })}
${arena(15, 13, 3, [3, 0, 8])}
Wait 8
${quake("2458", 8)}
Wait 10
${quake("1x", 6)}
Wait ${AFTER - 18 - 10}
${arena(13, 0, 10, [3, 0, 8])}
Wait 10
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 153, 129, 247],
  references: ["reference/Astral_Barrage_VIII.png", "reference/Astral_Barrage_VIII_2.png", "reference/Astral_Barrage_IX.png", "reference/Astral_Barrage_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("pit")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("leapers")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("risen")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("rain")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("spires")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  pit f${CAMERA_IN}, balls leap f${CAMERA_IN + OPEN}-${CAMERA_IN + SUMMON}, rise f${CAMERA_IN + SUMMON}, rain f${CAMERA_IN + rainAt}, explosion f${CAMERA_IN + boomAt}`);
