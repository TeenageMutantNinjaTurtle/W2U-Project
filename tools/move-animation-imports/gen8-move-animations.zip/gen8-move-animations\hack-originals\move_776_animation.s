MoveCamera INTERPOLATION, ATTACKER, 16, 0, 8
LetCMDsFinish ALL
AudioContainer CONTINUE
PlaySound 1407, SE2, 14, 30, 0, 120, 0, 0, 0
PlaySound 1376, SE2, 14, 80, 0, 0, 0, 0, 0
AdjustSound SE2, 0, 0, -1000, 2500, 0, 70, 0, 0
AdjustSound SE2, 0, 1, 120, 0, 50, 30, 0, 0
AudioContainer SUSPEND
ToggleSpriteVisibility ATTACKER, 3
LoadSPA 817
Emit 817, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 10
Emit 817, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 6
AdjustCamera INTERPOLATION_RELATIVE, 0, 0, 0, 0, 5px, 0, 16, 0, 8
LetCMDsFinish ALL
MoveCamera INTERPOLATION, DEFENDER, 16, 0, 8
AudioContainer CONTINUE
PlaySound 1421, SE1, 16, 0, -400, 110, 0, 0, 0
PlaySound 1424, SE2, 16, 15, 0, 120, 0, 0, 0
PlaySound 1475, SE1, 16, 15, 0, 100, 0, 0, 0
AudioContainer SUSPEND
Emit 817, 2, DEFENDER, NONE, 1px, 0, 0, 1x, 1x, 1x, 1x
Wait 10
LoadSPA 659
Emit 659, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 659, 1, DEFENDER, NONE, 1px, 0, 0, 1x, 1x, 1x, 1x
Emit 659, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 20, 0, 1
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 4
ShakeScreen VERTICAL, 2458, 0, 1, 0, 6
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, STOP
ToggleSpriteVisibility ATTACKER, 4
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
