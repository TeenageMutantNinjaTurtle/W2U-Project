import { createKit, deg, fadeInOut, fadeOut, grow, paint, setCurves, spin, T, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, FOE, gather, glow, hit, impact, intro, lunge, outro, pan, quake, ring, shake, slash, snd, sparks, streaks, tint, WHITE, type Pal } from "../tools/phrases";

// Behemoth Blade (move 781) - from the Bulbapedia stills (reference/sheet.png).
//   1. The arena goes dark; the user glows blue and a great blade of blue-white
//      light forms above it, blue motes hanging in the air.
//   2. It cuts across: a long, bright blue-white slash.
//   3. The cut erupts in an enormous white-yellow blast, streaks flying.

const SPA = 961;
const kit = await createKit({ workDir: import.meta.dirname, slug: "behemoth-blade", moveId: 781, spaId: SPA, donors: [228, 465, 579, 411, 298, 407] });

const CAMERA_IN = 12;
const FORM = 30; // the blade forms
const HOLD = 6;
const PAN = 8;
const CUT = 5; // the slash hangs before the blast
const AFTER = 30;

const BLUE: Rgb = [0.3, 0.6, 1.0];
const CYAN: Rgb = [0.55, 0.9, 1.0];
const PALE: Rgb = [0.88, 0.97, 1.0];
const YELLOW: Rgb = [1.0, 0.92, 0.35];
const PALE_YELLOW: Rgb = [1.0, 0.98, 0.78];
const BLUES: Pal = [CYAN, PALE, BLUE];
const BLADE: Vec3 = [0.6, 2.2, 0.3];

// --- 1. the blade of light, standing over the user ---
function bladeLayer(name: string, scale: number, aspect: number, colours: [Rgb, Rgb, Rgb], level: number): string {
  const r = kit.parked(kit.tex(T.streak), BLADE, scale, FORM + HOLD);
  r.aspectRatio = aspect;
  spin(r, 0, 0, deg(-32)); // leaning toward the foe
  setCurves(r, { start: 0.1, mid: 1, end: 1.05, curveIn: 0.45, curveOut: 0.9 }, fadeInOut(level, 0.15, 0.92));
  paint(r, colours[0], colours[1], colours[2]);
  r.startDelayFrames = 6;
  kit.add(name, r);
  return name;
}
const user = [
  bladeLayer("bladeCore", 3.4, 0.16, [WHITE, WHITE, PALE], 1),
  bladeLayer("bladeGlow", 3.6, 0.42, [CYAN, PALE, BLUE], 0.75),
  ...glow(kit, "hilt", { pos: [0.1, 0.9, 0.35], at: 8, life: FORM + HOLD - 6, scale: 1.0, pal: [WHITE, WHITE, CYAN], tex: kit.tex(T.star4Big), spin: 0.06, scaleCurve: twinkle(1.2), alpha: fadeInOut(1, 0.2, 0.8) }),
  ...gather(kit, "draw", { pos: [0.1, 0.9, 0.3], frames: FORM - 6, pal: BLUES, radius: 2.8, scale: 2.2 }),
  ...sparks(kit, "motes", { pos: [0, 1.0, 0.3], radius: 3.0, speed: 0.01, count: 1, bursts: FORM / 3, gap: 3, life: 16, scale: 0.16, pal: [CYAN, WHITE, BLUE], shape: "ball" }),
  ...glow(kit, "aura", { pos: [0, 0.3, 0.2], life: FORM + HOLD, scale: 2.8, pal: [BLUE, CYAN, PALE], level: 0.6 }),
];

// --- 2. the cut, then 3. the blast ---
const foe = [
  ...slash(kit, "cut", { angle: -32, scale: 5.0, pal: [PALE, WHITE, CYAN], life: CUT + 6, aspect: 0.22 }),
  ...slash(kit, "cutGlow", { angle: -32, scale: 5.2, pal: [CYAN, PALE, BLUE], life: CUT + 8, aspect: 0.5 }),
  ...sparks(kit, "cutSparks", { radius: 1.4, speed: 0.2, count: 6, life: 10, scale: 0.14, pal: [PALE, WHITE, CYAN], shape: "circle" }),
  ...impact(kit, "blast", { at: CUT, pal: [YELLOW, PALE_YELLOW, [1.0, 0.75, 0.2]], size: 1.9, rays: 11, flecks: 0 }),
  ...glow(kit, "whiteout", { pos: FOE, at: CUT, life: 14, scale: 4.0, pal: [PALE_YELLOW, WHITE, YELLOW], level: 1, scaleCurve: grow(0.4, 0.2, 1.2), alpha: fadeOut(1, 0.45) }),
  ...ring(kit, "shock", { at: CUT + 1, scale: 2.2, pal: [PALE_YELLOW, WHITE, YELLOW], to: 2.4, life: 13 }),
  ...streaks(kit, "flying", { at: CUT + 2, radius: 1.2, speed: 0.55, count: 5, bursts: 3, gap: 3, life: 9, scale: 0.9, pal: [YELLOW, WHITE, PALE_YELLOW] }),
  ...sparks(kit, "embers", { at: CUT + 6, radius: 1.5, speed: 0.12, count: 3, bursts: 4, gap: 4, life: 14, scale: 0.14, pal: [YELLOW, WHITE, CYAN], fall: -0.006 }),
];

const cutAt = FORM + HOLD + PAN;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1497, 0, { vol: 105 }),
  snd(1495, 6, { ch: "SE2", pitch: 300, vol: 80 }),
  snd(1376, FORM + HOLD, { vol: 0 }),
  snd(1651, FORM + HOLD, { ch: "SE2", pitch: -300, vol: 127 }),
  snd(2010, cutAt, { ch: "SE2", side: "D", vol: 127 }),
  snd(1423, cutAt, { side: "D", pitch: 200, vol: 120 }),
  snd(1475, cutAt + CUT, { side: "D", pitch: -400, vol: 127 }),
  snd(1413, cutAt + CUT + 2, { ch: "SE2", side: "D", pitch: -200, vol: 127 }),
)}
${arena(0, 13, 8, [1, 2, 8])}
${tint("ATTACKER", 0, 10, 6, [12, 22, 31])}
${emits(kit, user, "ATTACKER")}
${shake("ATTACKER", 819, FORM / 2 - 4)}
Wait ${FORM}
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, ${HOLD}, 0, 1
Wait ${HOLD}
${lunge("ATTACKER", 4)}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
${tint("DEFENDER", 0, 12, 0, [24, 30, 31])}
Wait ${CUT}
${arena(13, 15, 0, [31, 31, 22])}
${hit({ rgb: [31, 31, 20], power: 3, freeze: false })}
${arena(15, 13, 4, [1, 2, 8])}
${tint("ATTACKER", 10, 0, 4, [12, 22, 31])}
Wait 10
${quake("1x", 8)}
${arena(13, 0, 10, [1, 2, 8])}
Wait ${AFTER - 10}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 236],
  references: ["reference/Behemoth_Blade_VIII.png", "reference/Behemoth_Blade_VIII_2.png", "reference/Behemoth_Blade_IX.png", "reference/Behemoth_Blade_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("bladeCore")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("cut")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("blastFlash")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  blade forms f${CAMERA_IN}, cut f${CAMERA_IN + cutAt}, blast f${CAMERA_IN + cutAt + CUT}`);
