MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 989
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -600, 110, 0, 0, 0
PlaySound 1815, SE1, 16, 26, -500, 115, 0, 0, 0
PlaySound 1510, SE2, 16, 34, -200, 100, 0, 0, 0
PlaySound 1815, SE1, 16, 49, 300, 100, 0, 0, 0
PlaySound 1407, SE2, 16, 64, 300, 115, 0, 0, 0
PlaySound 1475, SE1, 16, 70, -300, 127, 0, 0, 0
PlaySound 1815, SE2, 16, 70, 500, 120, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 0, 6, 2, 12
ChangeSpriteColor ATTACKER, 0, 10, 0, 10, 2, 16
Emit 989, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 989, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 989, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 6
Wait 16
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
Emit 989, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 989, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 989, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 989, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 989, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 989, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 989, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 989, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 989, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 989, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 989, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 989, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 8
ShakeSprite DEFENDER, 2, 410, 0, 2, 0, 10
Wait 36
ChangeBackgroundColor 4, 13, 13, 0, 31, 14, 28
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 16, 29
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 16, 29
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 13, 10, 0, 6, 2, 12
ChangeSpriteColor ATTACKER, 10, 0, 0, 10, 2, 16
Wait 16
ChangeBackgroundColor 4, 10, 0, 0, 6, 2, 12
Wait 10
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
