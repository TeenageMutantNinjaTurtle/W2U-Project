MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 974
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, 0, 110, 0, 0, 0
PlaySound 1480, SE2, 14, 0, 200, 95, 0, 0, 0
PlaySound 1376, SE1, 14, 42, 0, 0, 0, 0, 0
PlaySound 1688, SE2, 14, 42, 400, 127, 0, 0, 0
PlaySound 1514, SE1, 16, 47, 300, 120, 0, 0, 0
PlaySound 1784, SE2, 16, 50, 300, 95, 0, 0, 0
PlaySound 1475, SE1, 16, 63, -500, 127, 0, 0, 0
PlaySound 1413, SE2, 16, 63, -400, 127, 0, 0, 0
PlaySound 1475, SE1, 16, 73, -700, 120, 0, 0, 0
PlaySound 1426, SE2, 16, 69, 0, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 0, 3, 3, 9
ChangeSpriteColor ATTACKER, 0, 13, 0, 31, 27, 6
Emit 974, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 6, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 7, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 8, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 12
Wait 24
ChangeSpriteColor ATTACKER, 13, 16, 2, 31, 30, 16
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 6
Wait 12
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 6, 0, 1
Wait 6
ToggleSpriteVisibility ATTACKER, 3
MoveCamera INTERPOLATION, DEFENDER, 7, 0, 8
Wait 5
Emit 974, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 8, 8, 0, 31, 30, 16
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 3
Wait 2
ChangeSpriteColor DEFENDER, 8, 0, 0, 31, 30, 16
Wait 14
Emit 974, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 974, 20, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeBackgroundColor 4, 15, 15, 0, 31, 30, 20
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 30, 16
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 7
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 30, 16
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 15, 10, 0, 3, 3, 9
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 14
Wait 10
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 8
ChangeBackgroundColor 4, 10, 0, 0, 3, 3, 9
Wait 18
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 0, 0, 0, 31, 30, 16
ToggleSpriteVisibility ATTACKER, 4
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
