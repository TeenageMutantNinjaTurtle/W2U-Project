MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 960
AudioContainer CONTINUE
PlaySound 1426, SE1, 14, 0, 400, 95, 0, 0, 0
PlaySound 1423, SE2, 14, 10, 500, 100, 0, 0, 0
PlaySound 1423, SE2, 14, 20, 650, 100, 0, 0, 0
PlaySound 1423, SE2, 14, 30, 800, 100, 0, 0, 0
PlaySound 1376, SE2, 14, 40, 0, 0, 0, 0, 0
PlaySound 1425, SE1, 14, 40, 0, 127, 0, 0, 0
PlaySound 1423, SE2, 14, 40, 300, 115, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 8, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 48, -300, 127, 0, 0, 0
PlaySound 1475, SE2, 16, 56, -500, 120, 0, 0, 0
PlaySound 1426, SE1, 16, 58, 0, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 0, 31, 18, 6
Emit 960, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 11, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 12, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 10
ScaleSprite ATTACKER, ROUNDTRIP, 410, -410, 2, 0, 1
Wait 10
ScaleSprite ATTACKER, ROUNDTRIP, 410, -410, 2, 0, 1
Wait 10
ScaleSprite ATTACKER, ROUNDTRIP, 410, -410, 2, 0, 1
Wait 10
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 8, 0, 0, 31, 18, 6
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 960, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 20, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 21, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 22, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 960, 23, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeBackgroundColor 4, 13, 13, 0, 31, 26, 18
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 28, 16
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 28, 16
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 13, 9, 0, 28, 8, 6
Wait 8
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ChangeBackgroundColor 4, 9, 0, 0, 28, 8, 6
Wait 12
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
