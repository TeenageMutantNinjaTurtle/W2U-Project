MoveCamera INTERPOLATION, ATTACKER, 16, 0, 12
LetCMDsFinish ALL
PlaySound 1708, SE1, 14, 0, 0, 115, 0, 0, 0
PlaySound 1475, SE2, 14, 17, 0, 120, 0, 0, 0
AudioContainer SUSPEND
PlaySound 1418, PSG, 14, 20, 0, 115, 0, 0, 0
PlaySound 1376, PSG, 14, 150, 0, 0, 0, 0, 0
AdjustSound PSG, 0, 1, 115, 0, 120, 30, 0, 0
ToggleFreezeSprite ATTACKER, START
ShakeSprite ATTACKER, 2, 0, 0.5px, 2, 1, 1
ScaleSprite ATTACKER, ROUNDTRIP_LONG, -1229, 1229, 2, 1, 1
LoadSPA 514
Emit 514, 1, ATTACKER, NONE, 0, 0, 0, 1x, 1x, 1x, 1x
Emit 514, 8, ATTACKER, NONE, 0, 0, 0, 1x, 1x, 1x, 1x
Wait 12
ShakeScreen VERTICAL, 819, 1x, 1, 1, 14
Wait 20
MoveCamera INTERPOLATION, DEFENDER, 16, 0, 12
AudioContainer CONTINUE
PlaySound 1416, SE1, 16, 0, 500, 115, 0, 0, 0
PlaySound 1376, SE1, 16, 100, 0, 0, 0, 0, 0
AdjustSound SE1, 0, 1, 115, 0, 70, 30, 0, 0
PlaySound 1420, SE2, 16, 85, 0, 115, 0, 0, 0
PlaySound 1420, SE2, 16, 95, 0, 115, 0, 0, 0
PlaySound 1420, SE2, 16, 110, 0, 115, 0, 0, 0
PlaySound 1420, SE2, 16, 123, 0, 115, 0, 0, 0
AudioContainer SUSPEND
ToggleFreezeSprite DEFENDER, START
Emit 514, 4, DEFENDER, NONE, 0, 0, 0, 1x, 1x, 1x, 1x
Emit 514, 7, DEFENDER, NONE, 0, 0, 0, 1x, 1x, 1x, 1x
Emit 514, 2, DEFENDER, NONE, 0, 0, 0, 1x, 1x, 1x, 1x
Emit 514, 5, DEFENDER, NONE, 0, 0, 0, 1x, 1x, 1x, 1x
Emit 514, 3, DEFENDER, NONE, 0, 0, 0, 1x, 1x, 1x, 1x
Emit 514, 6, DEFENDER, NONE, 0, 0, 0, 1x, 1x, 1x, 1x
Wait 80
Emit 514, 0, DEFENDER, NONE, 1px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite DEFENDER, 2, 1229, 0, 1, 2, 6
Wait 40
MoveCamera INTERPOLATION, INIT, 16, 0, 12
ToggleFreezeSprite ATTACKER, STOP
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
