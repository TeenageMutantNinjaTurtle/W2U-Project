// Shared builder for the four Forces of Nature storms (Springtide, Bleakwind,
// Wildbolt, Sandsear). They share one shape in the games: the user whips up
// wind in its own colour, then a tall tornado of that colour spins up over
// the foe, laced with whatever the storm carries (hearts, sleet, lightning,
// burning sand), and bursts.
// The tornado is Hurricane's (SPA 711), recoloured and widened.
import { createKit, type Kit, type Rgb } from "./anim-kit";
import { arena, audio, circleEmits, emits, FOE, glow, hit, impact, intro, outro, pan, quake, risers, shake, snd, sparks, streaks, tint, USER, vortex, WHITE, FOE_FLOOR, type Pal } from "./phrases";

export interface StormSpec {
  workDir: string;
  slug: string;
  moveId: number;
  spaId: number;
  /** [main, light, deep] */
  pal: Pal;
  /** a second colour laced through the wind */
  accent: Rgb;
  /** 5-bit colours */
  userTint: [number, number, number];
  arenaTint: [number, number, number];
  donors?: number[];
  donorMoveIds?: number[];
  references: string[];
  /** what the storm carries: extra resources on the user and on the foe (`at` 0 = the tornado starting) */
  carries: (kit: Kit, t: { GATHER: number; STORM: number }) => { user?: string[]; foe?: string[] } | Promise<{ user?: string[]; foe?: string[] }>;
  /** extra PlaySound lines; `stormAt` is the frame the tornado starts */
  sounds?: (stormAt: number) => string[];
  describe: string;
}

export async function buildStorm(spec: StormSpec): Promise<void> {
  const kit = await createKit({ workDir: spec.workDir, slug: spec.slug, moveId: spec.moveId, spaId: spec.spaId, donors: [711, 228, 465, 579, 411, 298, ...(spec.donors ?? [])] });
  const [MAIN, LIGHT, DEEP] = spec.pal;

  // --- timing (30 fps) ---
  const CAMERA_IN = 10;
  const GATHER = 24;
  const PAN = 10;
  const STORM = 40;
  const BURST = STORM - 8; // the last gust
  const AFTER = 14;

  const extras = await spec.carries(kit, { GATHER, STORM });

  // --- 1. the user whips up the wind ---
  const userWind = vortex(kit, "userWind", { frames: GATHER - 4, pal: [MAIN, LIGHT, spec.accent], widen: 1.2 });
  const user = [
    ...(extras.user ?? []),
    ...streaks(kit, "gusts", { pos: USER, radius: 2.2, speed: 0.4, count: 3, bursts: GATHER / 4, gap: 4, life: 7, scale: 0.9, pal: [LIGHT, WHITE, MAIN], flat: true }),
    ...glow(kit, "aura", { pos: USER, life: GATHER + 4, scale: 2.8, pal: [MAIN, DEEP, LIGHT], level: 0.6 }),
  ];

  // --- 2. the tornado ---
  const tornado = vortex(kit, "tornado", { frames: STORM - 8, pal: [MAIN, LIGHT, DEEP], widen: 1.7, life: 22 });
  const lace = vortex(kit, "lace", { at: 4, frames: STORM - 14, pal: [spec.accent, WHITE, spec.accent], widen: 1.25 });
  const foe = [
    ...(extras.foe ?? []),
    ...risers(kit, "updraft", { pos: FOE_FLOOR, frames: STORM - 10, radius: 1.3, speed: 0.4, scale: 1.2, life: 9, every: 3, pal: [LIGHT, WHITE, MAIN], streak: true }),
    ...impact(kit, "gustHit", { at: 2, pal: [MAIN, LIGHT, DEEP], size: 1.2, rays: 0, flecks: 0, spiky: false }),
    ...impact(kit, "burst", { at: BURST, pal: [LIGHT, WHITE, MAIN], size: 1.6, rays: 9, flecks: 0 }),
    ...sparks(kit, "debris", { at: 2, radius: 1.6, speed: 0.14, count: 2, bursts: Math.round(STORM / 4) - 2, gap: 4, life: 12, scale: 0.14, pal: [LIGHT, WHITE, spec.accent], fall: -0.012 }),
    ...glow(kit, "eye", { pos: FOE, life: STORM, scale: 3.0, pal: [MAIN, DEEP, LIGHT], level: 0.5 }),
  ];

  const stormAt = GATHER + PAN;
  const script = `${intro(spec.spaId, CAMERA_IN)}
${audio(
    snd(1425, 0, { pitch: 200, vol: 110 }),
    snd(1445, 2, { ch: "SE2", pitch: -200, vol: 100 }),
    snd(1919, stormAt, { side: "D", vol: 115 }),
    snd(1425, stormAt, { ch: "SE2", side: "D", pitch: -300, vol: 120 }),
    snd(1420, stormAt + 2, { ch: "SE2", side: "D", vol: 110 }),
    snd(1420, stormAt + 16, { ch: "SE2", side: "D", pitch: 200, vol: 110 }),
    snd(1475, stormAt + BURST, { ch: "SE2", side: "D", pitch: -200, vol: 125 }),
    ...(spec.sounds?.(stormAt) ?? []),
  )}
${arena(0, 9, 8, spec.arenaTint)}
${tint("ATTACKER", 0, 8, 6, spec.userTint)}
${circleEmits(kit, userWind, "ATTACKER")}
${emits(kit, user, "ATTACKER")}
${shake("ATTACKER", 819, GATHER / 2 - 4)}
Wait ${GATHER}
${tint("ATTACKER", 8, 0, 4, spec.userTint)}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${circleEmits(kit, [...tornado, ...lace], "DEFENDER")}
${emits(kit, foe, "DEFENDER")}
Wait 2
${hit({ rgb: spec.userTint, power: 2 })}
${shake("DEFENDER", 1229, BURST / 2 - 4)}
Wait ${BURST - 2 - 4}
${hit({ rgb: [31, 31, 31], power: 3, freeze: false })}
Wait 8
${quake("1x", 6)}
${arena(9, 0, 8, spec.arenaTint)}
Wait ${STORM - BURST - 8 - 6 + AFTER}
${outro()}`;

  await kit.finish({
    script,
    donorMoveIds: [542, 63, 605, 400, 240, 129, ...(spec.donorMoveIds ?? [])],
    references: spec.references,
    expectText: [`LoadSPA ${spec.spaId}`, `EmitCircle ${spec.spaId}, ${kit.idx("userWindInner")}, ATTACKER_LEFT`, "MoveCamera INTERPOLATION, DEFENDER", `EmitCircle ${spec.spaId}, ${kit.idx("tornadoInner")}, DEFENDER_LEFT`, `Emit ${spec.spaId}, ${kit.idx("burstFlash")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
  });
  console.log(`  ${spec.describe}: wind f${CAMERA_IN}, tornado f${CAMERA_IN + stormAt}-${CAMERA_IN + stormAt + STORM}, last gust f${CAMERA_IN + stormAt + BURST}`);
}
