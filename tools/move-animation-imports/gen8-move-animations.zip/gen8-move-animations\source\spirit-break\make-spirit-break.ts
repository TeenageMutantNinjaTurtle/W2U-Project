import { createKit, fadeInOut, fadeOut, grow, setCurves, T, twinkle, type Rgb } from "../tools/anim-kit";
import { arena, audio, emits, FOE, glow, hit, impact, intro, lunge, outro, pan, ring, shake, snd, sparks, streaks, tint, USER, WHITE, type Pal } from "../tools/phrases";

// Spirit Break (move 789) - from the Bulbapedia stills (reference/sheet.png).
//   1. Dusk falls. A thin pink ring stands round the user as pink energy
//      flares off it in blades, motes drifting.
//   2. It strikes: jagged pink light blasts out from the foe in every
//      direction, white sparkles glinting in it.

const SPA = 969;
const kit = await createKit({ workDir: import.meta.dirname, slug: "spirit-break", moveId: 789, spaId: SPA, donors: [228, 465, 579, 411, 298, 407] });

const CAMERA_IN = 10;
const FLARE = 22;
const PAN = 8;
const AFTER = 28;

const PINK: Rgb = [1.0, 0.5, 0.85];
const PALE: Rgb = [1.0, 0.86, 0.96];
const HOT: Rgb = [1.0, 0.25, 0.7];
const VIOLET: Rgb = [0.7, 0.4, 1.0];
const PAL: Pal = [PINK, PALE, HOT];

const user = [
  ...ring(kit, "halo", { pos: USER, life: FLARE + 4, scale: 2.5, pal: [PALE, WHITE, PINK], tex: kit.tex(T.ring), to: 1.04, level: 0.9 }),
  ...streaks(kit, "blades", { pos: USER, radius: 0.6, speed: 0.16, count: 4, bursts: FLARE / 4, gap: 4, life: 10, scale: 1.1, pal: [PINK, PALE, HOT], tex: kit.tex(T.shard) }),
  ...glow(kit, "aura", { pos: USER, life: FLARE + 4, scale: 2.6, pal: [PINK, HOT, PALE], level: 0.6 }),
  ...sparks(kit, "motes", { pos: [0, 0.6, 0.3], radius: 2.4, speed: 0.02, count: 1, bursts: FLARE / 2, gap: 2, life: 14, scale: 0.17, pal: [PALE, WHITE, PINK], shape: "ball", tex: kit.tex(T.softDisc) }),
];
// The ring holds its size.
setCurves(kit.resources[kit.idx("halo")]!, grow(0.6, 0.2, 1.04), fadeInOut(0.9, 0.15, 0.85));

const foe = [
  ...sparks(kit, "glints", { at: 1, radius: 2.0, speed: 0.06, count: 2, bursts: 4, gap: 3, life: 9, scale: 0.5, pal: [WHITE, PALE, WHITE], shape: "circle", tex: kit.tex(T.star4Big) }),
  ...impact(kit, "break", { pal: PAL, size: 1.6, rays: 10, flecks: 0 }),
  ...streaks(kit, "jags", { radius: 0.6, speed: 0.5, count: 9, life: 11, scale: 1.25, pal: [PINK, HOT, PALE], tex: kit.tex(T.shard) }),
  ...streaks(kit, "jags2", { at: 4, radius: 0.5, speed: 0.4, count: 7, life: 11, scale: 1.0, pal: [HOT, PINK, VIOLET], tex: kit.tex(T.shard) }),
  ...glow(kit, "bloom", { pos: FOE, life: 16, scale: 3.6, pal: [PINK, WHITE, HOT], level: 0.9, scaleCurve: grow(0.4, 0.2, 1.15), alpha: fadeOut(0.9, 0.4) }),
  ...sparks(kit, "after", { at: 8, radius: 1.5, speed: 0.1, count: 3, bursts: 3, gap: 4, life: 14, scale: 0.15, pal: [PALE, WHITE, PINK], fall: -0.006 }),
];
setCurves(kit.resources[kit.idx("glints")]!, twinkle(1.2), twinkle(1));

const hitAt = FLARE + PAN;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1497, 0, { pitch: 500, vol: 95 }),
  snd(1509, 6, { ch: "SE2", pitch: 400, vol: 90 }),
  snd(1376, FLARE, { vol: 0 }),
  snd(1407, FLARE, { ch: "SE2", pitch: 200, vol: 115 }),
  snd(1475, hitAt, { side: "D", pitch: 200, vol: 127 }),
  snd(1423, hitAt, { ch: "SE2", side: "D", pitch: 500, vol: 120 }),
  snd(1509, hitAt + 4, { side: "D", pitch: 900, vol: 95 }),
)}
${arena(0, 10, 8, [8, 4, 16])}
${tint("ATTACKER", 0, 9, 5, [31, 16, 27])}
${emits(kit, user, "ATTACKER")}
${shake("ATTACKER", 819, FLARE / 2 - 2)}
Wait ${FLARE}
${lunge("ATTACKER", 4)}
${tint("ATTACKER", 9, 0, 4, [31, 16, 27])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
${arena(10, 14, 0, [31, 20, 28])}
${hit({ rgb: [31, 22, 29], power: 3 })}
${arena(14, 10, 4, [8, 4, 16])}
Wait ${AFTER - 10}
${arena(10, 0, 8, [8, 4, 16])}
Wait 10
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 236],
  references: ["reference/Spirit_Break_VIII.png", "reference/Spirit_Break_VIII_2.png", "reference/Spirit_Break_IX.png", "reference/Spirit_Break_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("halo")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("jags")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  flare f${CAMERA_IN}, strike f${CAMERA_IN + hitAt}`);
