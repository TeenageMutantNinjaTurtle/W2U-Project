import { assert, createKit, fadeInOut, grow, setCurves, T, twinkle, type Rgb } from "../tools/anim-kit";
import { audio, bolt, emits, FOE, FRONT, glow, hit, introStill, lunge, outro, ring, shot, snd, sparks, streaks, tint, WHITE, type Pal } from "../tools/phrases";

// Dragon Darts (move 751) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user launches a dart (a Dreepy in the games) with a white flash
//      and a violet trail.
//   2. It strikes in a violet dome edged with a white arc, a white four-point
//      flash at the centre and jagged magenta-red shards thrown out.
// Two hits: Gen 5 replays the animation per hit, so the camera stays still
// and one hit is about a second.

const SPA = 949;
const kit = await createKit({ workDir: import.meta.dirname, slug: "dragon-darts", moveId: 751, spaId: SPA, donors: [228, 465, 579, 411, 321, 298, 407, 560] });

const WINDUP = 5;
const TRAVEL = 6;
const AFTER = 18;

const VIOLET: Rgb = [0.62, 0.3, 1.0];
const PALE_VIOLET: Rgb = [0.88, 0.75, 1.0];
const MAGENTA: Rgb = [1.0, 0.2, 0.55];
const CRIMSON: Rgb = [0.85, 0.1, 0.3];
const PAL: Pal = [VIOLET, PALE_VIOLET, MAGENTA];

// --- 1. the dart ---
const user = [
  ...glow(kit, "launch", { pos: FRONT, at: WINDUP, life: 8, scale: 1.0, pal: [WHITE, WHITE, PALE_VIOLET], tex: kit.tex(T.star4Big), spin: 0.1, scaleCurve: twinkle(1.3), alpha: twinkle(1) }),
  ...sparks(kit, "launchSparks", { pos: FRONT, at: WINDUP, radius: 0.3, speed: 0.2, count: 5, life: 9, scale: 0.12, pal: [PALE_VIOLET, WHITE, MAGENTA] }),
];
bolt(kit, "dart", { at: WINDUP, travel: TRAVEL, scale: 1.0, pal: [VIOLET, PALE_VIOLET, MAGENTA], tex: kit.tex(T.spike) });
bolt(kit, "dartCore", { at: WINDUP, travel: TRAVEL, scale: 1.5, pal: [WHITE, WHITE, PALE_VIOLET] });
shot(kit, "dartTrail", kit.tex(T.softDisc), { at: WINDUP, travel: TRAVEL, scale: 0.5, pal: [VIOLET, MAGENTA, VIOLET], count: 3, gap: 1, alpha: fadeInOut(0.8, 0.1, 0.5) });

// --- 2. the strike ---
const foe = [
  ...glow(kit, "dome", { pos: FOE, life: 14, scale: 2.4, pal: [VIOLET, MAGENTA, PALE_VIOLET], level: 0.85, scaleCurve: grow(0.4, 0.25, 1.15) }),
  ...ring(kit, "arc", { scale: 1.5, pal: [PALE_VIOLET, WHITE, VIOLET], tex: kit.tex(T.hoop), to: 1.7, life: 12 }),
  ...glow(kit, "star", { pos: [0, 0.3, 1.0], life: 9, scale: 1.5, pal: [WHITE, WHITE, PALE_VIOLET], tex: kit.tex(T.star4Big), scaleCurve: twinkle(1.2), alpha: twinkle(1) }),
  ...streaks(kit, "shards", { radius: 0.5, speed: 0.4, count: 9, life: 11, scale: 0.7, pal: [MAGENTA, CRIMSON, VIOLET], tex: kit.tex(T.shard) }),
  ...streaks(kit, "rays", { radius: 0.4, speed: 0.5, count: 6, life: 9, scale: 0.9, pal: [WHITE, PALE_VIOLET, WHITE] }),
  ...sparks(kit, "flecks", { radius: 0.5, speed: 0.26, count: 7, life: 13, scale: 0.14, pal: [PALE_VIOLET, WHITE, MAGENTA], shape: "circle", twinkle: false }),
];

const script = `${introStill(SPA)}
${audio(
  snd(1539, WINDUP, { pitch: 200, vol: 115 }),
  snd(1425, WINDUP, { ch: "SE2", pitch: 500, vol: 100 }),
  snd(1423, WINDUP + TRAVEL, { side: "D", vol: 127 }),
  snd(1475, WINDUP + TRAVEL, { ch: "SE2", side: "D", pitch: 200, vol: 115 }),
)}
${tint("ATTACKER", 0, 8, 2, [20, 10, 31])}
${emits(kit, user, "ATTACKER")}
${emits(kit, ["dart", "dartCore", "dartTrail"], "ATTACKER", "DEFENDER")}
Wait ${WINDUP}
${lunge("ATTACKER", 2)}
${tint("ATTACKER", 8, 0, 3, [20, 10, 31])}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [26, 16, 31], power: 2, stop: 3 })}
Wait ${AFTER}
${outro({ camera: false })}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 153, 129, 236, 381],
  references: ["reference/Dragon_Darts_VIII.png", "reference/Dragon_Darts_VIII_2.png", "reference/Dragon_Darts_IX.png", "reference/Dragon_Darts_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("dart")}, ATTACKER, DEFENDER`, `Emit ${SPA}, ${kit.idx("shards")}, DEFENDER`],
});
assert.ok(!script.includes("MoveCamera"), "Multi-hit animation moves the camera");
console.log(`  dart f${WINDUP}, strike f${WINDUP + TRAVEL}, one hit ~${WINDUP + TRAVEL + 3 + AFTER} frames`);
