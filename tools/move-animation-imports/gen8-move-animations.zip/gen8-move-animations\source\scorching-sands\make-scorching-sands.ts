import { aimed, createKit, fadeInOut, grow, setCurves, spin, T, twinkle, type Rgb } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FRONT, glow, hit, intro, outro, pan, puffs, shake, snd, sparks, squash, streaks, tint, USER_FLOOR, WHITE, type Pal } from "../tools/phrases";

// Scorching Sands (move 815) - from the Bulbapedia stills (reference/sheet.png).
//   1. The air turns a hot orange-red. The user throws up burning sand.
//   2. A cloud of it rolls over the foe, embers glowing in it, and it lands
//      in jagged yellow-orange bursts.

const SPA = 995;
const kit = await createKit({ workDir: import.meta.dirname, slug: "scorching-sands", moveId: 815, spaId: SPA, donors: [228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 10;
const KICK = 14;
const TRAVEL = 11;
const SCOUR = 26;
const AFTER = 12;

const SAND: Rgb = [0.85, 0.7, 0.45];
const PALE_SAND: Rgb = [0.95, 0.86, 0.65];
const DARK_SAND: Rgb = [0.65, 0.48, 0.28];
const YELLOW: Rgb = [1.0, 0.85, 0.2];
const ORANGE: Rgb = [1.0, 0.5, 0.12];
const RED: Rgb = [1.0, 0.25, 0.15];
const DUST: Pal = [SAND, PALE_SAND, DARK_SAND];
const EMBER: Pal = [ORANGE, YELLOW, RED];

const user = [
  ...puffs(kit, "kicked", { pos: [0, USER_FLOOR[1] + 0.4, 0.4], radius: 1.3, count: 2, bursts: KICK / 3, gap: 3, life: 14, scale: 0.9, pal: DUST, speed: 0.1, rise: 0.04, level: 0.9 }),
  ...sparks(kit, "userEmbers", { pos: [0, -0.6, 0.4], radius: 1.3, speed: 0.1, count: 2, bursts: KICK / 3, gap: 3, life: 12, scale: 0.13, pal: EMBER, fall: -0.012 }),
];
function rolling(name: string, tex: number, scale: number, count: number, gap: number, colours: Pal, level: number, dots = false): void {
  const r = kit.spray([333, 1], tex, [FRONT[0], -0.2, FRONT[2]], { radius: 1.0, speed: 0.01, count, bursts: 5, gap, life: TRAVEL + 2, scale, shape: "ball" });
  r.startDelayFrames = KICK - 2;
  aimed(r, 16 / TRAVEL, TRAVEL + 2);
  r.airResistance = 1.0;
  r.variance.lifeTime = 0;
  if (!dots) spin(r, -0.06, 0.06, 0, true);
  setCurves(r, dots ? undefined : grow(0.6, 0.3, 1.4), dots ? twinkle() : fadeInOut(level, 0.15, 0.8));
  kit.prism(r, colours);
  kit.add(name, r);
}
rolling("sandCloud", kit.tex(T.puff), 1.0, 2, 2, DUST, 0.9);
rolling("cloudEmbers", kit.tex(T.dot), 0.14, 2, 2, EMBER, 1, true);

const star = (name: string, pos: [number, number, number], at: number) => glow(kit, name, { pos, at, life: 9, scale: 1.3, pal: [YELLOW, PALE_SAND, ORANGE], tex: kit.tex(T.hitStar), spin: 0.12, level: 1, scaleCurve: twinkle(1.25), alpha: twinkle(1) });
const foe = [
  ...star("burstA", [-0.3, 0.5, 1.1], 0), ...star("burstB", [0.5, 0.0, 1.1], 7), ...star("burstC", [-0.1, 0.9, 1.1], 14),
  ...streaks(kit, "jags", { radius: 0.5, speed: 0.34, count: 4, bursts: 3, gap: 7, life: 9, scale: 0.7, pal: [YELLOW, ORANGE, PALE_SAND], tex: kit.tex(T.shard) }),
  ...sparks(kit, "embers", { radius: 1.4, speed: 0.1, count: 2, bursts: SCOUR / 3, gap: 3, life: 12, scale: 0.14, pal: EMBER, fall: -0.012 }),
  ...puffs(kit, "scour", { pos: FOE, radius: 1.3, count: 2, bursts: SCOUR / 4, gap: 4, life: 16, scale: 1.2, pal: DUST, speed: 0.08, level: 0.85, to: 1.5 }),
  ...glow(kit, "heat", { pos: FOE, life: SCOUR + 4, scale: 3.0, pal: [ORANGE, RED, YELLOW], level: 0.5 }),
];

const landAt = KICK - 2 + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1463, KICK - 6, { pitch: -200, vol: 110 }),
  snd(1426, KICK - 4, { ch: "SE2", pitch: 200, vol: 95 }),
  `SwitchAudioSide SE1, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0`,
  snd(1423, landAt, { side: "D", pitch: 200, vol: 120 }),
  snd(1426, landAt, { ch: "SE2", side: "D", vol: 105 }),
  snd(1423, landAt + 7, { side: "D", pitch: 400, vol: 110 }),
  snd(1423, landAt + 14, { side: "D", pitch: 100, vol: 115 }),
)}
${arena(0, 10, 8, [26, 10, 4])}
${tint("ATTACKER", 0, 6, 4, [31, 22, 10])}
${emits(kit, user, "ATTACKER")}
${emits(kit, ["sandCloud", "cloudEmbers"], "ATTACKER", "DEFENDER")}
${squash("ATTACKER", -819, 819, 4)}
Wait ${KICK - 2}
${tint("ATTACKER", 6, 0, 4, [31, 22, 10])}
Wait 2
${pan("DEFENDER", TRAVEL - 2)}
Wait ${TRAVEL - 2}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [31, 24, 10], power: 2 })}
${shake("DEFENDER", 1229, SCOUR / 2 - 4)}
Wait ${SCOUR - 8}
${arena(10, 0, 8, [26, 10, 4])}
Wait ${AFTER + 4}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 153, 129, 163],
  references: ["reference/Scorching_Sands_VIII.png", "reference/Scorching_Sands_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("sandCloud")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("scour")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  kicks f${CAMERA_IN}, cloud f${CAMERA_IN + KICK - 2}, scours f${CAMERA_IN + landAt}`);
