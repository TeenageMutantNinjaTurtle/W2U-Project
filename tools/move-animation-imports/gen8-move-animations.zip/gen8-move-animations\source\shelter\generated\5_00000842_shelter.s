MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1022
AudioContainer CONTINUE
PlaySound 1727, SE1, 14, 0, 600, 95, 0, 0, 0
PlaySound 1418, SE2, 14, 2, 500, 85, 0, 0, 0
PlaySound 1474, SE2, 14, 14, 0, 95, 0, 0, 0
PlaySound 1474, SE2, 14, 24, 200, 95, 0, 0, 0
PlaySound 1452, SE1, 14, 40, 0, 115, 0, 0, 0
PlaySound 1784, SE2, 14, 42, 300, 105, 0, 0, 0
AudioContainer SUSPEND
Emit 1022, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1022, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1022, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1022, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1022, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1022, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1022, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1022, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1022, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor ATTACKER, 0, 8, 1, 22, 26, 31
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 14, 0, 1
Wait 40
ChangeSpriteColor ATTACKER, 8, 14, 0, 31, 31, 31
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 5, 0, 1
Wait 5
ChangeSpriteColor ATTACKER, 14, 0, 0, 31, 31, 31
Wait 13
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
