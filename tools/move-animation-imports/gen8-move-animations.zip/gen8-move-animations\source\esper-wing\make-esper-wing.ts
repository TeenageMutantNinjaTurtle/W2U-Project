import { createKit, deg, fadeOut, grow, paint, setCurves, spin, T, type Rgb } from "../tools/anim-kit";
import { audio, circleEmits, emits, FOE, glow, hit, impact, intro, lunge, outro, pan, shake, snd, sparks, streaks, tint, USER, vortex, WHITE } from "../tools/phrases";

// Esper Wing (move 840) - from the Bulbapedia stills (reference/sheet.png).
//   1. Ribbons of pink and violet psychic light whirl round the user's
//      wings, sparkling.
//   2. It swoops and cuts the foe with each wing in quick succession: a
//      pale-pink crescent down from its top right, then one from its top left.
//   3. The second cut bursts violet-white, slivers of light and sparks flying.
// The ribbons are Hurricane's swooshes (SPA 711) recoloured. The Speed boost
// and the high critical-hit ratio are the engine's.

const SPA = 1020;
const kit = await createKit({ workDir: import.meta.dirname, slug: "esper-wing", moveId: 840, spaId: SPA, donors: [711, 228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const WHIRL = 22;
const PAN = 7;
const AFTER = 26;

const PINK: Rgb = [1.0, 0.5, 0.9];
const PALE: Rgb = [1.0, 0.88, 0.98];
const VIOLET: Rgb = [0.62, 0.35, 1.0];
const DEEP: Rgb = [0.4, 0.15, 0.75];

// --- 1. the ribbons ---
const ribbons = vortex(kit, "ribbons", { frames: WHIRL - 6, pal: [PINK, PALE, VIOLET], widen: 1.3 });
const user = [
  ...sparks(kit, "glints", { pos: USER, radius: 2.0, speed: 0, count: 1, bursts: WHIRL / 3, gap: 3, life: 9, scale: 0.3, pal: [WHITE, PALE, PINK], shape: "sphere", tex: kit.tex(T.sparkle4) }),
  ...streaks(kit, "wingLines", { pos: USER, radius: 1.4, speed: 0.36, count: 3, bursts: WHIRL / 5, gap: 5, life: 8, scale: 0.9, pal: [PALE, WHITE, PINK], flat: true }),
  ...glow(kit, "aura", { pos: USER, life: WHIRL + 4, scale: 2.9, pal: [VIOLET, DEEP, PINK], level: 0.7 }),
];

// --- 2./3. the cuts: one wing down from the foe's top right, then the other
// from its top left, in quick succession ---
// (the blade arc texture is an arch; turned past 90 degrees it hangs like a
// bowl, tilted down toward the side it is travelling to)
const SLASH_GAP = 5;
const SLASHES = [
  { start: [1.0, 1.5], toward: [-1, -1], tilt: 215 }, // from the top right, down to the left
  { start: [-1.0, 1.5], toward: [1, -1], tilt: 145 }, // from the top left, down to the right
] as const;
const foe: string[] = [];
for (const [i, s] of SLASHES.entries()) {
  for (const [layer, scale, colours] of [["", 1.6, [PALE, WHITE, PINK]], ["Glow", 1.9, [PINK, PALE, VIOLET]]] as const) {
    const r = kit.parked(kit.tex(T.bladeArc), [s.start[0], s.start[1], 1.0], scale, 9);
    r.startDelayFrames = i * SLASH_GAP;
    r.aspectRatio = 1.8;
    spin(r, 0, 0, deg(s.tilt));
    // It starts up at the foe's shoulder and sweeps down through it.
    Object.assign(r, { axis: [s.toward[0] * Math.SQRT1_2, s.toward[1] * Math.SQRT1_2, 0], initVelAxisAmplifier: 0.32, airResistance: 0.85 });
    setCurves(r, grow(0.5, 0.3, 1.15), fadeOut(1, 0.45));
    paint(r, colours[0] as Rgb, colours[1] as Rgb, colours[2] as Rgb);
    kit.add(`cut${layer}${i}`, r);
    foe.push(`cut${layer}${i}`);
  }
}
foe.push(
  ...impact(kit, "first", { pos: [0.3, 0.6, 0.9], at: 1, pal: [PINK, WHITE, VIOLET], size: 1.0, rays: 0, flecks: 0 }),
  ...impact(kit, "burst", { at: SLASH_GAP + 1, pal: [PINK, WHITE, VIOLET], size: 1.6, rays: 9, flecks: 0 }),
  ...streaks(kit, "slivers", { at: 1, radius: 0.6, speed: 0.44, count: 4, bursts: 2, gap: SLASH_GAP, life: 10, scale: 1.0, pal: [PALE, WHITE, PINK], tex: kit.tex(T.shard) }),
  ...sparks(kit, "sparkle", { at: SLASH_GAP + 3, radius: 1.3, speed: 0.16, count: 7, life: 14, scale: 0.3, pal: [WHITE, PALE, VIOLET], shape: "circle", tex: kit.tex(T.sparkle4) }),
  ...glow(kit, "after", { pos: FOE, life: SLASH_GAP + 16, scale: 3.0, pal: [VIOLET, DEEP, PINK], level: 0.6 }),
);

const cutAt = WHIRL + PAN;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1510, 0, { pitch: 200, vol: 105 }),
  snd(1425, 2, { ch: "SE2", pitch: 500, vol: 100 }),
  snd(1407, WHIRL - 1, { pitch: 300, vol: 118 }),
  snd(1514, cutAt, { side: "D", pitch: 100, vol: 127 }),
  snd(1514, cutAt + SLASH_GAP, { ch: "SE2", side: "D", pitch: 300, vol: 127 }),
  snd(1455, cutAt + SLASH_GAP + 1, { ch: "SE2", side: "D", pitch: 300, vol: 115 }),
  snd(1475, cutAt + SLASH_GAP + 1, { side: "D", pitch: 200, vol: 120 }),
)}
${tint("ATTACKER", 0, 9, 6, [26, 14, 31])}
${circleEmits(kit, ribbons, "ATTACKER")}
${emits(kit, user, "ATTACKER")}
Wait ${WHIRL}
${lunge("ATTACKER", 6)}
${tint("ATTACKER", 9, 0, 5, [26, 14, 31])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
Wait 1
ToggleFreezeSprite DEFENDER, START
${tint("DEFENDER", 0, 10, 0, [29, 20, 31])}
${shake("DEFENDER", 1229, 3)}
Wait 1
${tint("DEFENDER", 10, 0, 4, [29, 20, 31])}
Wait ${SLASH_GAP - 1}
${hit({ rgb: [29, 20, 31], power: 3, freeze: false })}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [542, 427, 63, 605, 400, 240, 129],
  references: ["reference/Esper_Wing_LA.png", "reference/Esper_Wing_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `EmitCircle ${SPA}, ${kit.idx("ribbonsInner")}, ATTACKER_LEFT`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("cut0")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("cut1")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("burstFlash")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  ribbons f${CAMERA_IN}, cuts f${CAMERA_IN + cutAt} and f${CAMERA_IN + cutAt + SLASH_GAP}`);
