MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 991
AudioContainer CONTINUE
PlaySound 1869, SE1, 14, 0, 1200, 100, 0, 0, 0
PlaySound 1869, SE2, 14, 9, 1400, 100, 0, 0, 0
PlaySound 1869, SE1, 14, 18, 1600, 100, 0, 0, 0
PlaySound 1523, SE2, 14, 2, 400, 95, 0, 0, 0
PlaySound 1452, SE1, 16, 47, 0, 115, 0, 0, 0
PlaySound 1452, SE2, 16, 63, 100, 115, 0, 0, 0
AudioContainer SUSPEND
Emit 991, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 991, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 991, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 991, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 991, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 991, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 991, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 991, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 3, 0, 1
Wait 9
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 3, 0, 1
Wait 9
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 3, 0, 1
Wait 9
Wait 4
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
Emit 991, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 991, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 991, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 991, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 991, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 991, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 6
ChangeSpriteColor DEFENDER, 0, 9, 0, 31, 27, 10
ScaleSprite DEFENDER, ROUNDTRIP, -819, 1229, 5, 0, 1
Wait 16
ScaleSprite DEFENDER, ROUNDTRIP, -819, 1229, 5, 0, 1
Wait 10
ChangeSpriteColor DEFENDER, 9, 0, 0, 31, 27, 10
Wait 8
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
