import { createKit, grow, setCurves, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, beam, emits, FOE, FRONT, gather, glow, hit, impact, intro, lunge, pan, quake, ring, shake, snd, sparks, streaks, tint, USER, WHITE, type Pal } from "../tools/phrases";

// Chloroblast (move 835) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user gathers its own life into a shell of yellow-green light,
//      streaks of it racing in.
//   2. It lets it all go as one enormous beam - white at the heart, yellow
//      and green at the edges - arcs of light thrown off the muzzle.
//   3. The beam tears into the foe: jagged yellow splinters and green
//      streaks flying, leaves torn loose.
//   4. Spent, the user shudders (the HP it pays is the engine's part).
// The leaves are Razor Leaf's (SPA 242).

const SPA = 1015;
const kit = await createKit({ workDir: import.meta.dirname, slug: "chloroblast", moveId: 835, spaId: SPA, donors: [242, 228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 12;
const CHARGE = 28;
const HOLD = 5;
const TRAVEL = 8;
const POUR = 26;
const AFTER = 22;

const LIME: Rgb = [0.75, 1.0, 0.3];
const YELLOW: Rgb = [1.0, 0.95, 0.3];
const PALE: Rgb = [0.97, 1.0, 0.8];
const GREEN: Rgb = [0.2, 0.85, 0.35];
const PAL: Pal = [LIME, PALE, GREEN];

const user = [
  ...gather(kit, "draw", { pos: USER, frames: CHARGE, pal: [LIME, YELLOW, GREEN], radius: 2.8, scale: 2.6, streaks: true }),
  ...ring(kit, "shell", { pos: USER, life: CHARGE + HOLD, scale: 2.2, pal: [LIME, PALE, GREEN], to: 1.05, level: 0.9 }),
  ...sparks(kit, "motes", { pos: USER, radius: 1.8, speed: 0.05, count: 1, bursts: CHARGE / 3, gap: 3, life: 12, scale: 0.16, pal: [YELLOW, WHITE, LIME], fall: -0.012 }),
  ...glow(kit, "glare", { pos: FRONT, at: CHARGE - 6, life: HOLD + POUR + 8, scale: 1.7, pal: [PALE, WHITE, YELLOW], tex: kit.tex(T.spiky), spin: 0.2, level: 1, scaleCurve: grow(1.5, 0.12, 1.05) }),
  // Arcs of light thrown off the muzzle as it fires.
  ...ring(kit, "muzzleA", { pos: FRONT, at: CHARGE + HOLD, life: 10, scale: 1.4, pal: [YELLOW, WHITE, LIME], to: 2.4 }),
  ...ring(kit, "muzzleB", { pos: FRONT, at: CHARGE + HOLD + 9, life: 10, scale: 1.4, pal: [LIME, WHITE, GREEN], to: 2.4 }),
];
const shots = beam(kit, "beam", { at: CHARGE + HOLD, pour: POUR, travel: TRAVEL, width: 1.8, pal: [LIME, PALE, GREEN], tex: kit.tex(T.softDisc) });

const foe = [
  ...impact(kit, "blast", { pal: [YELLOW, PALE, LIME], size: 1.8, rays: 9, flecks: 0 }),
  ...streaks(kit, "splinters", { radius: 0.7, speed: 0.44, count: 4, bursts: 4, gap: 5, life: 10, scale: 1.1, pal: [YELLOW, PALE, YELLOW], tex: kit.tex(T.shard) }),
  ...streaks(kit, "greenLines", { at: 2, radius: 0.9, speed: 0.4, count: 3, bursts: 4, gap: 5, life: 8, scale: 0.9, pal: [GREEN, LIME, PALE] }),
  ...sparks(kit, "leaves", { at: 2, radius: 1.0, speed: 0.22, count: 2, bursts: 4, gap: 5, life: 16, scale: 0.3, pal: [WHITE, WHITE, WHITE], fall: 0.01, tex: kit.tex(242, 1), twinkle: false, spin: 0.25 }),
  ...glow(kit, "wash", { pos: FOE, life: POUR + 4, scale: 3.2, pal: PAL, level: 0.7 }),
];

const fireAt = CHARGE + HOLD;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1497, 0, { vol: 115 }),
  snd(1480, 10, { ch: "SE2", pitch: 300, vol: 105 }),
  snd(1450, fireAt, { pitch: -200, vol: 127 }),
  snd(1962, fireAt, { ch: "SE2", vol: 115 }),
  `SwitchAudioSide SE2, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0`,
  snd(1475, fireAt + TRAVEL, { side: "D", pitch: -200, vol: 127 }),
  snd(1420, fireAt + TRAVEL + 12, { side: "D", pitch: 200, vol: 120 }),
)}
${arena(0, 9, 8, [6, 12, 3])}
${tint("ATTACKER", 0, 10, 8, [26, 31, 10])}
${emits(kit, user, "ATTACKER")}
${emits(kit, shots, "ATTACKER", "DEFENDER")}
${shake("ATTACKER", 819, CHARGE / 2 - 4)}
Wait ${CHARGE + HOLD}
${lunge("ATTACKER", -3)}
${shake("ATTACKER", 1229, POUR / 2)}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${arena(9, 13, 0, [29, 31, 20])}
${hit({ rgb: [29, 31, 16], power: 3 })}
${arena(13, 9, 4, [6, 12, 3])}
Wait 10
${quake("1x", 6)}
Wait ${POUR - 6 - 10}
${tint("ATTACKER", 10, 0, 4, [26, 31, 10])}
${arena(9, 0, 8, [6, 12, 3])}
Wait ${AFTER}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
${pan("INIT", 12)}
Wait 12
${tint("ATTACKER", 0, 8, 2, [31, 31, 31])}
${shake("ATTACKER", 1229, 6)}
Wait 3
${tint("ATTACKER", 8, 0, 6, [31, 31, 31])}
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [75, 76, 63, 605, 400, 240, 153, 129],
  references: ["reference/Chloroblast_LA.png", "reference/Chloroblast_IX.png", "reference/Chloroblast_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("drawIn")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("beamJet")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("splinters")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  charge f${CAMERA_IN}, fire f${CAMERA_IN + fireAt}, lands f${CAMERA_IN + fireAt + TRAVEL}`);
