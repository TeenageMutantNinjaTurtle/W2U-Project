MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1009
AudioContainer CONTINUE
PlaySound 1510, SE1, 14, 0, 0, 105, 0, 0, 0
PlaySound 1510, SE2, 14, 4, 300, 100, 0, 0, 0
PlaySound 1455, SE2, 14, 18, 0, 115, 0, 0, 0
PlaySound 1452, SE1, 14, 30, 0, 110, 0, 0, 0
PlaySound 1784, SE2, 14, 36, 200, 100, 0, 0, 0
AudioContainer SUSPEND
Emit 1009, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1009, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1009, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1009, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1009, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1009, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1009, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1009, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1009, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1009, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1009, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1009, 11, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1009, 12, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1009, 13, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1009, 14, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 30
ChangeSpriteColor ATTACKER, 0, 8, 0, 28, 30, 31
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 5, 0, 1
Wait 20
ChangeSpriteColor ATTACKER, 8, 0, 0, 28, 30, 31
Wait 10
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
