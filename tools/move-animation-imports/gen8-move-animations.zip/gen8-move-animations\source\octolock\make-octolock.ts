import { createKit, deg, paint, setCurves, spin, T, type Rgb } from "../tools/anim-kit";
import { audio, circleEmits, emits, FOE, glow, intro, lunge, outro, pan, quake, shake, snd, sparks, tint, vortex, WHITE, type Pal } from "../tools/phrases";

// Octolock (move 753) - from the Bulbapedia still (reference/sheet.png).
// A thick red tentacle coils round the foe from its feet to above its head
// and holds it, an orange-yellow swirl sweeping round them with yellow motes.
// A status move: the foe is squeezed and held, with no hit flash.
// The coils are Bind's wrap band, recoloured and stacked; the swirl is
// Hurricane's tornado in orange and yellow.

const SPA = 951;
const kit = await createKit({ workDir: import.meta.dirname, slug: "octolock", moveId: 753, spaId: SPA, donors: [186, 711, 228, 465, 298] });

const CAMERA_IN = 10;
const REACH = 10;
const PAN = 8;
const BANDS = 4;
const BAND_GAP = 3; // one coil after another, feet first
const WRAP = BANDS * BAND_GAP + 4;
const SQUEEZES = 3;
const SQUEEZE_GAP = 13;
const HELD = SQUEEZES * SQUEEZE_GAP + 8;

const RED: Rgb = [0.85, 0.12, 0.18];
const DEEP_RED: Rgb = [0.55, 0.05, 0.12];
const ORANGE: Rgb = [1.0, 0.6, 0.1];
const YELLOW: Rgb = [1.0, 0.9, 0.3];
const SWIRL: Pal = [ORANGE, YELLOW, [1.0, 0.4, 0.05]];

// --- the coils: Bind's band, one per turn of the tentacle, drawing tight ---
const bandTex = kit.tex(186, 0);
const coils: string[] = [];
for (let i = 0; i < BANDS; i++) {
  const r = kit.parked(bandTex, [FOE[0], -0.9 + i * 0.72, FOE[2] + 0.15 + i * 0.01], 0.8, WRAP - i * BAND_GAP + HELD);
  r.startDelayFrames = i * BAND_GAP;
  r.aspectRatio = 2.0;
  spin(r, 0, 0, deg(i % 2 ? -9 : 9)); // alternate tilt, so the turns read as one spiral
  // Each turn starts loose and wide, draws tight, then pulses with the squeezes.
  setCurves(r, { start: 1.7, mid: 1.0, end: 0.92, curveIn: 8 / (WRAP + HELD), curveOut: 0.9 }, { start: 0, mid: 1, end: 0, curveIn: 0.06, curveOut: 0.9 });
  paint(r, RED, RED, DEEP_RED, 0.25);
  kit.add(`coil${i}`, r);
  coils.push(`coil${i}`);
}

const foe = [
  ...coils,
  ...sparks(kit, "motes", { pos: [0, 0.2, 0.8], at: WRAP, radius: 2.0, speed: 0.03, count: 2, bursts: SQUEEZES * 2, gap: 6, life: 12, scale: 0.18, pal: [YELLOW, WHITE, ORANGE], shape: "ball", tex: kit.tex(T.softDisc) }),
  ...glow(kit, "grip", { pos: FOE, life: WRAP + HELD, scale: 2.8, pal: [ORANGE, RED, YELLOW], level: 0.4 }),
];
// The swirl: kept close round the foe, lifted off the ground, and turning slowly.
const SWIRL_PACE = 0.6; // of Hurricane's own speed
const SWIRL_LIFT = -0.5; // Hurricane's sits at -1, on the ground
const swirl = vortex(kit, "swirl", { frames: WRAP + HELD - 28, pal: SWIRL, widen: 1.1, life: 17, pace: SWIRL_PACE });

const user = glow(kit, "reach", { life: REACH + 4, scale: 2.2, pal: [RED, ORANGE, YELLOW], level: 0.5 });

const wrapAt = REACH + PAN;
const squeezes = Array.from({ length: SQUEEZES }, (_, i) => [
  "ScaleSprite DEFENDER, ROUNDTRIP, -1229, 410, 5, 0, 1",
  shake("DEFENDER", 819, 3),
  ...(i === SQUEEZES - 1 ? [quake("0.5x", 3, "HORIZON")] : []),
  `Wait ${SQUEEZE_GAP}`,
].join("\n")).join("\n");
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1407, REACH - 2, { pitch: -500, vol: 105 }),
  ...Array.from({ length: BANDS }, (_, i) => snd(1441, wrapAt + i * BAND_GAP, { ch: i % 2 ? "SE2" : "SE1", side: "D", pitch: -300 + i * 80, vol: 110 })),
  ...Array.from({ length: SQUEEZES }, (_, i) => snd(1441, wrapAt + WRAP + i * SQUEEZE_GAP, { ch: i % 2 ? "SE1" : "SE2", side: "D", pitch: -600, vol: 120 })),
)}
${tint("ATTACKER", 0, 8, 4, [28, 6, 8])}
${emits(kit, user, "ATTACKER")}
Wait ${REACH}
${lunge("ATTACKER", 3)}
${tint("ATTACKER", 8, 0, 4, [28, 6, 8])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${circleEmits(kit, swirl, "DEFENDER", { y: SWIRL_LIFT, frames: 200 })}
${emits(kit, foe, "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
${shake("DEFENDER", 819, WRAP / 2)}
Wait ${WRAP}
${tint("DEFENDER", 0, 8, 4, [31, 10, 6])}
${squeezes}
${tint("DEFENDER", 8, 0, 6, [31, 10, 6])}
Wait 8
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [20, 542, 63, 605, 129],
  references: ["reference/Octolock_VIII.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("coil0")}, DEFENDER`, `EmitCircle ${SPA}, ${kit.idx("swirlInner")}, DEFENDER_LEFT`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  coils wrap f${CAMERA_IN + wrapAt}-${CAMERA_IN + wrapAt + WRAP}, held with ${SQUEEZES} squeezes until f${CAMERA_IN + wrapAt + WRAP + HELD}`);
