import { aimed, createKit, fadeInOut, grow, setCurves, spin, T, type Rgb } from "../tools/anim-kit";
import { audio, emits, FOE, FRONT, glow, intro, outro, pan, puffs, shake, snd, sparks, squash, tint, USER, type Pal } from "../tools/phrases";

// Corrosive Gas (move 810) - from the Bulbapedia stills (reference/sheet.png).
//   1. Thick olive-yellow gas billows up round the user.
//   2. It rolls across and settles over the foe in a sour yellow haze, dark
//      flecks dropping off it as its item is eaten away.
// A status move: the foe shudders in the gas, with no hit flash.

const SPA = 990;
const kit = await createKit({ workDir: import.meta.dirname, slug: "corrosive-gas", moveId: 810, spaId: SPA, donors: [228, 465, 321, 298] });

const CAMERA_IN = 10;
const BILLOW = 22;
const TRAVEL = 14; // the gas rolls across
const SETTLE = 34;

const OLIVE: Rgb = [0.62, 0.62, 0.2];
const PALE_OLIVE: Rgb = [0.82, 0.84, 0.4];
const DARK_OLIVE: Rgb = [0.4, 0.42, 0.1];
const YELLOW: Rgb = [0.95, 0.95, 0.3];
const GAS: Pal = [OLIVE, PALE_OLIVE, DARK_OLIVE];

const user = [
  ...puffs(kit, "billow", { pos: USER, radius: 1.5, count: 2, bursts: BILLOW / 3, gap: 3, life: 16, scale: 1.0, pal: GAS, speed: 0.07, rise: 0.03, level: 0.9, to: 1.5 }),
  ...puffs(kit, "billowLow", { pos: [0, -0.8, 0.5], at: 2, radius: 1.8, count: 1, bursts: BILLOW / 3, gap: 3, life: 16, scale: 0.8, pal: [PALE_OLIVE, YELLOW, OLIVE], speed: 0.08, level: 0.8, to: 1.5 }),
];
// The cloud rolling across.
function rolling(name: string, scale: number, count: number, gap: number, colours: Pal, level: number): void {
  const r = kit.spray([333, 1], kit.tex(T.puff), FRONT, { radius: 0.9, speed: 0.01, count, bursts: 5, gap, life: TRAVEL + 2, scale, shape: "ball" });
  r.startDelayFrames = BILLOW - 4;
  aimed(r, 16 / TRAVEL, TRAVEL + 2);
  r.airResistance = 1.0;
  r.variance.lifeTime = 0;
  spin(r, -0.06, 0.06, 0, true);
  setCurves(r, grow(0.6, 0.3, 1.4), fadeInOut(level, 0.15, 0.8));
  kit.prism(r, colours);
  kit.add(name, r);
}
rolling("cloud", 1.0, 2, 2, GAS, 0.9);
rolling("cloudPale", 0.75, 1, 3, [PALE_OLIVE, YELLOW, OLIVE], 0.75);

const foe = [
  ...sparks(kit, "corroded", { pos: [0, 0.2, 1.0], at: 8, radius: 1.0, speed: 0.04, count: 2, bursts: 7, gap: 3, life: 14, scale: 0.15, pal: [[0.05, 0.05, 0], [0.2, 0.2, 0.05], [0, 0, 0]], fall: 0.016, shape: "ball", twinkle: false }),
  ...puffs(kit, "haze", { pos: FOE, radius: 1.2, count: 2, bursts: SETTLE / 4 - 2, gap: 4, life: 18, scale: 1.1, pal: GAS, speed: 0.05, rise: 0.02, level: 0.85, to: 1.5 }),
  ...puffs(kit, "hazePale", { pos: [0.2, 0.6, 0.7], at: 3, radius: 1.2, count: 1, bursts: SETTLE / 4 - 2, gap: 4, life: 18, scale: 0.9, pal: [PALE_OLIVE, YELLOW, OLIVE], speed: 0.05, level: 0.7, to: 1.5 }),
  ...glow(kit, "sour", { pos: FOE, life: SETTLE, scale: 2.8, pal: [YELLOW, OLIVE, PALE_OLIVE], level: 0.5 }),
];

const landAt = BILLOW - 4 + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1463, 0, { pitch: -400, vol: 110 }),
  snd(1445, 4, { ch: "SE2", pitch: -800, vol: 85 }),
  snd(1463, landAt, { side: "D", pitch: -600, vol: 110 }),
  snd(1727, landAt + 8, { ch: "SE2", side: "D", pitch: 600, vol: 90 }),
)}
${tint("ATTACKER", 0, 6, 4, [22, 22, 6])}
${emits(kit, user, "ATTACKER")}
${emits(kit, ["cloud", "cloudPale"], "ATTACKER", "DEFENDER")}
${squash("ATTACKER", 819, -819, 5)}
Wait ${BILLOW - 4}
${tint("ATTACKER", 6, 0, 4, [22, 22, 6])}
Wait 4
${pan("DEFENDER", TRAVEL - 4)}
Wait ${TRAVEL - 4}
${emits(kit, foe, "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
${tint("DEFENDER", 0, 9, 8, [22, 23, 6])}
${shake("DEFENDER", 819, SETTLE / 2 - 6)}
Wait ${SETTLE - 10}
${tint("DEFENDER", 9, 0, 8, [22, 23, 6])}
Wait 12
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 153, 129],
  references: ["reference/Corrosive_Gas_VIII.png", "reference/Corrosive_Gas_VIII_2.png", "reference/Corrosive_Gas_IX.png", "reference/Corrosive_Gas_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("billow")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("cloud")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("haze")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  billows f${CAMERA_IN}, rolls f${CAMERA_IN + BILLOW - 4}, settles f${CAMERA_IN + landAt}`);
