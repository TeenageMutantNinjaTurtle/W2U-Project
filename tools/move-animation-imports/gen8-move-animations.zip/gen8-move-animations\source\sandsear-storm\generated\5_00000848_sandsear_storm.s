MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1028
AudioContainer CONTINUE
PlaySound 1425, SE1, 14, 0, 200, 110, 0, 0, 0
PlaySound 1445, SE2, 14, 2, -200, 100, 0, 0, 0
PlaySound 1919, SE1, 16, 34, 0, 115, 0, 0, 0
PlaySound 1425, SE2, 16, 34, -300, 120, 0, 0, 0
PlaySound 1420, SE2, 16, 36, 0, 110, 0, 0, 0
PlaySound 1420, SE2, 16, 50, 200, 110, 0, 0, 0
PlaySound 1475, SE2, 16, 66, -200, 125, 0, 0, 0
PlaySound 1426, SE2, 16, 36, -200, 115, 0, 0, 0
PlaySound 1426, SE2, 16, 54, 100, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 9, 0, 15, 9, 4
ChangeSpriteColor ATTACKER, 0, 8, 0, 30, 22, 12
EmitCircle 1028, 4, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 1028, 5, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
Emit 1028, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1028, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1028, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 8
Wait 24
ChangeSpriteColor ATTACKER, 8, 0, 0, 30, 22, 12
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
EmitCircle 1028, 8, DEFENDER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 1028, 9, DEFENDER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 1028, 10, DEFENDER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 1028, 11, DEFENDER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
Emit 1028, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1028, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1028, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1028, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1028, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1028, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1028, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1028, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1028, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1028, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 2
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 30, 22, 12
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 30, 22, 12
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 12
Wait 26
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 31, 31
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 31, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ChangeBackgroundColor 4, 9, 0, 0, 15, 9, 4
Wait 8
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
