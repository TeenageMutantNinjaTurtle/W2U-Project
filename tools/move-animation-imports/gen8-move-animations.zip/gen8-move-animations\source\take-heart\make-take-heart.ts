import { createKit, paint, setCurves, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, glow, intro, outro, ring, risers, snd, sparks, squash, streaks, tint, USER, USER_FLOOR, WHITE } from "../tools/phrases";

// Take Heart (move 850) - from the Bulbapedia stills (reference/sheet.png).
//   1. Bubbles bloom in front of the user like the petals of a flower - a
//      ring of six round one - shimmering pink and violet.
//   2. They burst together in a white star, rays of pink, cyan and white
//      shooting out, motes of every colour scattering.
//   3. Arcs of pink light close round the user and it takes heart: a soft
//      green light under it, bright motes floating up.
// Stays on the user; the status cure and the Sp. Atk and Sp. Def boosts are
// the engine's.

const SPA = 1030;
const kit = await createKit({ workDir: import.meta.dirname, slug: "take-heart", moveId: 850, spaId: SPA, donors: [228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const BLOOM = 22;
const BURST = 12;
const EMBRACE = 28;

const PINK: Rgb = [1.0, 0.55, 0.9];
const PALE: Rgb = [1.0, 0.9, 0.98];
const VIOLET: Rgb = [0.7, 0.5, 1.0];
const CYAN: Rgb = [0.55, 0.95, 1.0];
const GREEN: Rgb = [0.5, 1.0, 0.6];
const GOLD: Rgb = [1.0, 0.9, 0.45];

// --- 1. the bubbles: one in the middle, six round it ---
const HEART: Vec3 = [0, 0.9, 0.0];
const PETAL = 0.95; // how far the outer six sit from the middle
const spots: Array<{ at: Vec3; delay: number; scale: number }> = [{ at: HEART, delay: 0, scale: 0.8 }];
for (let i = 0; i < 6; i++) {
  const a = (i / 6) * Math.PI * 2 + Math.PI / 6;
  spots.push({ at: [HEART[0] + Math.cos(a) * PETAL, HEART[1] + Math.sin(a) * PETAL, HEART[2]], delay: 3 + i * 2, scale: 0.6 });
}
const bubbles: string[] = [];
for (const [i, s] of spots.entries()) {
  for (const [layer, tex, colours, level] of [
    ["Rim", kit.tex(T.ring), [i % 2 ? PINK : PALE, WHITE, VIOLET], 0.95],
    ["Body", kit.tex(T.softDisc), [i % 2 ? VIOLET : PINK, PALE, CYAN], 0.45],
  ] as const) {
    const r = kit.parked(tex, s.at, s.scale, BLOOM - s.delay + 1);
    r.startDelayFrames = s.delay;
    setCurves(r, { start: 0.15, mid: 1.08, end: 1, curveIn: 0.3, curveOut: 0.7 }, { start: 0, mid: level, end: level, curveIn: 0.2, curveOut: 1 });
    paint(r, colours[0] as Rgb, colours[1] as Rgb, colours[2] as Rgb);
    kit.add(`bubble${i}${layer}`, r);
    bubbles.push(`bubble${i}${layer}`);
  }
}

const embraceAt = BLOOM + BURST;
const user = [
  // --- 2. the burst ---
  ...glow(kit, "star", { pos: HEART, at: BLOOM, life: 9, scale: 1.5, pal: [WHITE, WHITE, PALE], tex: kit.tex(T.spiky), spin: 0.2, level: 1 }),
  ...streaks(kit, "rays", { pos: HEART, at: BLOOM, radius: 0.5, speed: 0.5, count: 9, life: 10, scale: 1.1, pal: [PINK, CYAN, WHITE] }),
  ...sparks(kit, "motes", { pos: HEART, at: BLOOM, radius: 0.6, speed: 0.26, count: 9, life: 16, scale: 0.18, pal: [GOLD, CYAN, PINK], shape: "circle", tex: kit.tex(T.softDisc), twinkle: false }),
  ...ring(kit, "pop", { pos: HEART, at: BLOOM, life: 10, scale: 1.2, pal: [PALE, WHITE, PINK], to: 2.2 }),
  ...bubbles,
  // --- 3. it takes heart ---
  ...ring(kit, "armsA", { pos: USER, at: embraceAt, life: 14, scale: 2.6, pal: [PINK, PALE, VIOLET], to: 0.75, level: 0.9 }),
  ...ring(kit, "armsB", { pos: USER, at: embraceAt + 7, life: 14, scale: 2.6, pal: [PALE, WHITE, PINK], to: 0.75, level: 0.9 }),
  ...risers(kit, "brightMotes", { pos: USER_FLOOR, at: embraceAt, frames: EMBRACE - 8, radius: 1.5, speed: 0.12, scale: 0.18, life: 16, every: 2, pal: [GOLD, CYAN, PINK], tex: kit.tex(T.softDisc) }),
  ...sparks(kit, "glints", { pos: USER, at: embraceAt + 4, radius: 2.0, speed: 0, count: 1, bursts: EMBRACE / 5, gap: 4, life: 9, scale: 0.32, pal: [WHITE, PALE, CYAN], shape: "sphere", tex: kit.tex(T.sparkle4) }),
  ...glow(kit, "greenLight", { pos: USER_FLOOR, at: embraceAt, life: EMBRACE, scale: 1.0, pal: [GREEN, WHITE, CYAN], tex: kit.tex(T.softDisc), aspect: 2.6, level: 0.7 }),
  ...glow(kit, "warmth", { pos: USER, at: embraceAt, life: EMBRACE, scale: 2.8, pal: [PINK, VIOLET, PALE], level: 0.6 }),
];
// The arms close in rather than spread.
for (const n of ["armsA", "armsB"]) setCurves(kit.resources[kit.idx(n)]!, { start: 1, mid: 0.88, end: 0.72, curveIn: 0.4, curveOut: 0.7 }, { start: 0, mid: 0.9, end: 0, curveIn: 0.2, curveOut: 0.75 });

const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1418, 0, { pitch: 700, vol: 90 }),
  snd(1474, 4, { ch: "SE2", pitch: 200, vol: 90 }),
  snd(1474, 12, { ch: "SE2", pitch: 400, vol: 90 }),
  snd(1784, BLOOM, { pitch: 300, vol: 115 }),
  snd(1509, BLOOM + 1, { ch: "SE2", pitch: 500, vol: 100 }),
  snd(1452, embraceAt, { vol: 110 }),
  snd(1427, embraceAt + 4, { ch: "SE2", pitch: 200, vol: 105 }),
)}
${emits(kit, user, "ATTACKER")}
Wait ${BLOOM}
${squash("ATTACKER", 819, -819, 4)}
Wait ${BURST}
${tint("ATTACKER", 0, 10, 8, [31, 22, 30])}
${squash("ATTACKER", -819, 819, 6)}
Wait ${EMBRACE - 12}
${tint("ATTACKER", 10, 0, 10, [31, 22, 30])}
Wait 14
${outro({ unfreeze: "NONE" })}`;

await kit.finish({
  script,
  donorMoveIds: [145, 381, 63, 605, 240, 129],
  references: ["reference/Take_Heart_LA.png", "reference/Take_Heart_IX.png", "reference/Take_Heart_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("bubble0Rim")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("bubble6Body")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("star")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("armsA")}, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  bubbles f${CAMERA_IN}, burst f${CAMERA_IN + BLOOM}, embrace f${CAMERA_IN + embraceAt}-${CAMERA_IN + embraceAt + EMBRACE}`);
