MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 978
AudioContainer CONTINUE
PlaySound 1509, SE1, 14, 0, 400, 100, 0, 0, 0
PlaySound 1435, SE2, 14, 8, -200, 115, 0, 0, 0
PlaySound 1425, SE1, 14, 10, -300, 105, 0, 0, 0
PlaySound 1688, SE2, 14, 26, -200, 120, 0, 0, 0
PlaySound 1884, SE1, 14, 28, 0, 100, 0, 0, 0
PlaySound 1475, SE1, 16, 35, -400, 127, 0, 0, 0
PlaySound 1413, SE2, 16, 35, -300, 127, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 16, 0, 31, 31, 31
Emit 978, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 978, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 978, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 978, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 978, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 978, 1, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 8
ToggleSpriteVisibility ATTACKER, 3
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 6
Wait 18
MoveCamera INTERPOLATION, DEFENDER, 9, 0, 8
Wait 9
Emit 978, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 978, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 978, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 978, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 978, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 978, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 31, 24
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 31, 24
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 8
Wait 20
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 16, 0, 0, 31, 31, 31
ToggleSpriteVisibility ATTACKER, 4
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
