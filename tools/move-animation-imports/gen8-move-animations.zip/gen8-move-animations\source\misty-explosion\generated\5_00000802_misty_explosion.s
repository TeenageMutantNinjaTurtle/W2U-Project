MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 982
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, 400, 105, 0, 0, 0
PlaySound 1458, SE2, 14, 6, 500, 95, 0, 0, 0
PlaySound 1376, SE1, 14, 30, 0, 0, 0, 0, 0
PlaySound 1475, SE1, FLAT, 36, -500, 127, 0, 0, 0
PlaySound 1413, SE2, FLAT, 36, -300, 127, 0, 0, 0
PlaySound 1475, SE1, FLAT, 46, -700, 120, 0, 0, 0
PlaySound 1463, SE2, FLAT, 40, -300, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 12, 0, 31, 22, 28
Emit 982, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 982, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 982, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 982, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, -1229, -1229, 30, 0, 1
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 13
Wait 26
ChangeSpriteColor ATTACKER, 12, 16, 0, 31, 31, 31
Wait 4
MoveCamera INTERPOLATION, INIT, 6, 0, 8
Wait 6
Emit 982, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 982, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 982, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 982, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 982, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 982, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 982, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 982, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 982, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 982, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 982, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeBackgroundColor 4, 14, 14, 0, 31, 24, 29
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 4
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 24, 29
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 24, 29
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 14, 8, 0, 31, 20, 27
Wait 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 8
Wait 8
ChangeBackgroundColor 4, 8, 0, 0, 31, 20, 27
ChangeSpriteColor ATTACKER, 16, 0, 0, 31, 31, 31
Wait 24
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
