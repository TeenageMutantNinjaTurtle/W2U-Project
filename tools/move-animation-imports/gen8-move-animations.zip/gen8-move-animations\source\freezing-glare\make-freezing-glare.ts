import { createKit, fadeInOut, T, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, bolt, emits, FOE, glow, hit, impact, intro, outro, pan, shake, snd, sparks, streaks, tint, USER, WHITE, type Pal } from "../tools/phrases";

// Freezing Glare (move 821) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user's eyes light up: two cold cyan-white stars.
//   2. Twin beams of violet-white light lance out of them.
//   3. They strike in a violet flash, frost glittering off the foe.

const SPA = 1001;
const kit = await createKit({ workDir: import.meta.dirname, slug: "freezing-glare", moveId: 821, spaId: SPA, donors: [228, 465, 579, 411, 298, 407] });

const CAMERA_IN = 10;
const GLARE = 20; // the eyes burn before the beams
const TRAVEL = 7;
const POUR = 18;
const AFTER = 24;

const VIOLET: Rgb = [0.7, 0.45, 1.0];
const PALE: Rgb = [0.93, 0.88, 1.0];
const CYAN: Rgb = [0.45, 0.95, 1.0];
const ICE: Rgb = [0.8, 0.97, 1.0];
const PAL: Pal = [VIOLET, PALE, [0.45, 0.25, 0.9]];
const EYES: Vec3[] = [[-0.25, 1.05, -0.6], [0.55, 0.95, -0.7]];

const user: string[] = [];
const shots: string[] = [];
EYES.forEach((eye, i) => {
  user.push(...glow(kit, `eye${i}`, { pos: [eye[0], eye[1], 0.6], at: i * 2, life: GLARE + POUR, scale: 0.95, pal: [ICE, WHITE, CYAN], tex: kit.tex(T.star4Big), spin: 0.05, level: 1, scaleCurve: { start: 0.3, mid: 1.1, end: 1, curveIn: 0.25, curveOut: 0.6 }, alpha: fadeInOut(1, 0.1, 0.9) }));
  // A thin beam: long streaks fired one behind another, a white core inside a violet sheath.
  bolt(kit, `beam${i}Core`, { from: eye, at: GLARE, travel: TRAVEL, scale: 2.2, pal: [WHITE, WHITE, PALE], count: POUR / 2, gap: 2 });
  bolt(kit, `beam${i}`, { from: eye, at: GLARE, travel: TRAVEL, scale: 2.6, pal: [VIOLET, PALE, [0.5, 0.3, 0.95]], count: POUR / 2, gap: 2, tex: kit.tex(T.streak) });
  shots.push(`beam${i}Core`, `beam${i}`);
});
user.push(
  ...glow(kit, "cold", { pos: USER, life: GLARE + POUR, scale: 2.7, pal: [VIOLET, CYAN, PALE], level: 0.5 }),
  ...sparks(kit, "eyeFrost", { pos: [0.15, 1.0, 0.6], radius: 0.9, speed: 0.06, count: 1, bursts: GLARE / 4, gap: 4, life: 10, scale: 0.26, pal: [WHITE, ICE, CYAN], shape: "ball", tex: kit.tex(T.sparkle4) }),
);

const foe = [
  ...impact(kit, "strike", { pal: PAL, size: 1.4, rays: 8, flecks: 0 }),
  ...streaks(kit, "iceShards", { at: 2, radius: 0.5, speed: 0.34, count: 7, life: 11, scale: 0.7, pal: [ICE, WHITE, CYAN], tex: kit.tex(T.shard) }),
  ...sparks(kit, "frost", { at: 2, radius: 1.3, speed: 0.06, count: 1, bursts: POUR / 3, gap: 3, life: 10, scale: 0.34, pal: [WHITE, ICE, CYAN], shape: "ball", tex: kit.tex(T.sparkle4) }),
  ...glow(kit, "chill", { pos: FOE, life: POUR + 6, scale: 2.9, pal: [VIOLET, CYAN, PALE], level: 0.7 }),
  ...impact(kit, "strike2", { at: 9, pal: [CYAN, WHITE, VIOLET], size: 1.0, rays: 0, flecks: 0, spiky: false }),
];

const landAt = GLARE + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1509, 0, { pitch: 300, vol: 100 }),
  snd(1509, 2, { ch: "SE2", pitch: 500, vol: 95 }),
  snd(1434, GLARE - 6, { pitch: 300, vol: 100 }),
  snd(1962, GLARE, { ch: "SE2", pitch: 600, vol: 105 }),
  `SwitchAudioSide SE2, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0`,
  snd(1475, landAt, { side: "D", pitch: 200, vol: 120 }),
  snd(1376, landAt + POUR, { ch: "SE2", vol: 0 }),
  snd(1420, landAt + 9, { side: "D", pitch: 300, vol: 115 }),
)}
${arena(0, 9, 8, [4, 4, 12])}
${tint("ATTACKER", 0, 6, 6, [22, 18, 31])}
${emits(kit, user, "ATTACKER")}
${emits(kit, shots, "ATTACKER", "DEFENDER")}
Wait ${GLARE}
${shake("ATTACKER", 819, POUR / 2)}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [26, 26, 31], power: 2 })}
${shake("DEFENDER", 1229, POUR / 2 - 4)}
Wait ${POUR - 4}
${tint("ATTACKER", 6, 0, 4, [22, 18, 31])}
${arena(9, 0, 8, [4, 4, 12])}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 236],
  references: ["reference/SwShCT_Prerelease_Freezing_Glare_2.png", "reference/Freezing_Glare_IX.png", "reference/Freezing_Glare_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("eye0")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("beam1")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("frost")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  eyes f${CAMERA_IN}, beams f${CAMERA_IN + GLARE}, land f${CAMERA_IN + landAt}`);
