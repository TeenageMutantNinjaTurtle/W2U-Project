import { createKit, deg, grow, hold, paint, setCurves, spin, T, twinkle, type Rgb } from "../tools/anim-kit";
import { audio, emits, FOE, glow, hit, impact, intro, outro, pan, quake, shake, snd, sparks, tint, WHITE, type Pal } from "../tools/phrases";

// Snap Trap (move 779) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user lies low in the grass; a glint flashes off steel.
//   2. A steel jaw trap - two toothed jaws - springs shut on the foe and
//      holds it.
// The jaws are drawn (generated/texture-trap.png); the lower jaw is the same
// texture turned upside down. Trapping is the engine's part.

const SPA = 959;
const kit = await createKit({ workDir: import.meta.dirname, slug: "snap-trap", moveId: 779, spaId: SPA, donors: [228, 465, 579, 411, 298, 407] });

const CAMERA_IN = 10;
const LURK = 14;
const PAN = 8;
const SET = 10; // the trap lies open under the foe
const SNAP = 3;
const HELD = 30;
const AFTER = 10;

const STEEL: Rgb = [0.8, 0.84, 0.9];
const PALE: Rgb = [0.95, 0.97, 1.0];
const GRASS: Rgb = [0.45, 0.85, 0.3];
const PAL: Pal = [PALE, WHITE, STEEL];

// --- the drawn jaw: a steel arc with a row of triangular teeth along its inner edge ---
const trapTex = await kit.drawn("trap", 64, 32, "a3i5", (x, y) => {
  const u = ((x + 0.5) / 64) * 2 - 1;
  if (Math.abs(u) >= 0.97) return undefined;
  const top = 15 - 12 * Math.sqrt(1 - u * u); // outer edge of the arc
  const bandBottom = top + 7;
  const phase = (u + 1) * 3.5; // seven teeth
  const tri = Math.abs((phase % 1) - 0.5) * 2; // 1 at roots, 0 at tips
  const toothBottom = bandBottom + 10 * (1 - tri);
  const py = y + 0.5;
  if (py < top || py > toothBottom) return undefined;
  if (py - top < 1.2 || toothBottom - py < 1.1) return [70, 76, 92]; // dark edge
  if (py < bandBottom) {
    const light = Math.max(0, 1 - Math.abs(py - top - 2.5) / 4);
    return [Math.round(150 + 90 * light), Math.round(158 + 88 * light), Math.round(175 + 78 * light)];
  }
  return tri > 0.55 ? [215, 220, 232] : [240, 243, 250]; // the teeth, brighter toward the tips
});

const GAPE = 1.5;
const SHUT = 0.35;
const CENTRE = FOE[1] - 0.5; // low on the foe, near the ground
function jaw(side: 1 | -1, y: number, at: number, life: number): ReturnType<typeof kit.parked> {
  const r = kit.parked(trapTex, [FOE[0], CENTRE + side * y, FOE[2] + 0.2], 1.0, life);
  r.aspectRatio = 2;
  r.startDelayFrames = at;
  spin(r, 0, 0, side === 1 ? 0 : deg(180));
  paint(r, WHITE);
  return r;
}
const jaws: string[] = [];
for (const [name, side] of [["upper", 1], ["lower", -1]] as const) {
  const open = jaw(side, GAPE, 0, SET + 1);
  setCurves(open, grow(0.6, 0.4, 1), { start: 0, mid: 1, end: 1, curveIn: 0.3, curveOut: 1 });
  kit.add(`${name}Open`, open);
  const snap = jaw(side, GAPE, SET, SNAP + 1);
  snap.axis = [0, -side, 0];
  snap.initVelAxisAmplifier = (GAPE - SHUT) / SNAP;
  setCurves(snap, hold(1), hold(1));
  kit.add(`${name}Snap`, snap);
  const shut = jaw(side, SHUT, SET + SNAP, HELD);
  setCurves(shut, { start: 1.15, mid: 1, end: 1, curveIn: 0.12, curveOut: 1 }, { start: 1, mid: 1, end: 0, curveIn: 0, curveOut: 0.85 });
  kit.add(`${name}Shut`, shut);
  jaws.push(`${name}Open`, `${name}Snap`, `${name}Shut`);
}

const BITE = SET + SNAP;
const star = (name: string, pos: [number, number, number], at: number) => glow(kit, name, { pos, at, life: 9, scale: 0.9, pal: [WHITE, WHITE, PALE], tex: kit.tex(T.star4Big), spin: 0.1, scaleCurve: twinkle(1.3), alpha: twinkle(1) });
const user = [
  ...star("lurkGlint", [0.5, 0.1, 0.6], LURK - 9),
  ...sparks(kit, "grass", { pos: [0, -1.2, 0.4], radius: 1.2, speed: 0.08, count: 3, bursts: 2, gap: 5, life: 12, scale: 0.13, pal: [GRASS, [0.7, 1.0, 0.45], [0.25, 0.6, 0.2]], fall: 0.01, twinkle: false }),
];
const foe = [
  ...jaws,
  ...star("trapGlint", [0.8, CENTRE + 0.9, 1.1], 2),
  ...impact(kit, "clang", { pos: [0, CENTRE, 0.9], at: BITE, pal: PAL, size: 1.15, rays: 8, flecks: 0, spiky: false }),
  ...sparks(kit, "sparks", { pos: [0, CENTRE, 0.9], at: BITE, radius: 0.9, speed: 0.3, count: 8, life: 14, scale: 0.13, pal: [WHITE, [1.0, 0.95, 0.6], STEEL], fall: 0.012, twinkle: false, shape: "circle" }),
  ...sparks(kit, "heldSparks", { pos: [0, CENTRE, 0.9], at: BITE + 8, radius: 1.3, speed: 0.1, count: 1, bursts: 5, gap: 4, life: 10, scale: 0.12, pal: [WHITE, STEEL, [1.0, 0.95, 0.6]] }),
];

const biteAt = LURK + PAN + BITE;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1509, LURK - 9, { pitch: 800, vol: 95 }),
  snd(1509, LURK + PAN + 2, { ch: "SE2", side: "D", pitch: 600, vol: 90 }),
  snd(1435, biteAt, { side: "D", pitch: 300, vol: 127 }),
  snd(1423, biteAt, { ch: "SE2", side: "D", vol: 120 }),
  snd(1435, biteAt + 12, { side: "D", pitch: -300, vol: 90 }),
)}
${tint("ATTACKER", 0, 6, 4, [14, 26, 10])}
ScaleSprite ATTACKER, ROUNDTRIP, 819, -1229, ${LURK - 2}, 0, 1
${emits(kit, user, "ATTACKER")}
Wait ${LURK}
${tint("ATTACKER", 6, 0, 4, [14, 26, 10])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
Wait ${BITE}
${hit({ rgb: [28, 29, 31], power: 2 })}
ScaleSprite DEFENDER, ROUNDTRIP, 0, -1229, 8, 0, 1
${shake("DEFENDER", 819, HELD / 2 - 4)}
Wait ${HELD - 4}
${quake("0.5x", 3, "HORIZON")}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 236],
  references: ["reference/Snap_Trap_VIII.png", "reference/Snap_Trap_VIII_2.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("upperShut")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("clangFlash")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  lurk f${CAMERA_IN}, trap set f${CAMERA_IN + LURK + PAN}, snap f${CAMERA_IN + biteAt}, held until f${CAMERA_IN + biteAt + HELD}`);
