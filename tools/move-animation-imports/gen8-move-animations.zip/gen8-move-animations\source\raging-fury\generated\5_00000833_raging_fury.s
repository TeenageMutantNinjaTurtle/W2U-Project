MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1013
AudioContainer CONTINUE
PlaySound 1426, SE1, 14, 0, -200, 110, 0, 0, 0
PlaySound 1426, SE2, 14, 9, 0, 115, 0, 0, 0
PlaySound 1426, SE1, 14, 18, 200, 120, 0, 0, 0
PlaySound 1452, SE2, 14, 0, -300, 100, 0, 0, 0
PlaySound 1452, SE1, 14, 9, -300, 100, 0, 0, 0
PlaySound 1452, SE2, 14, 18, -300, 100, 0, 0, 0
PlaySound 1688, SE1, 14, 28, -300, 125, 0, 0, 0
PlaySound 1475, SE1, 16, 34, -400, 127, 0, 0, 0
PlaySound 1413, SE2, 16, 34, 0, 127, 0, 0, 0
PlaySound 1426, SE2, 16, 37, -200, 120, 0, 0, 0
AudioContainer SUSPEND
Emit 1013, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 10, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 11, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 12, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 13, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 14, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeBackgroundColor 4, 0, 3, 0, 20, 6, 3
ChangeSpriteColor ATTACKER, 16, 16, 0, 31, 24, 12
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 2, 0, 1
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 3
Wait 2
ChangeSpriteColor ATTACKER, 16, 6, 0, 31, 14, 4
Wait 7
ChangeBackgroundColor 4, 3, 6, 0, 20, 6, 3
ChangeSpriteColor ATTACKER, 16, 16, 0, 31, 24, 12
ScaleSprite ATTACKER, ROUNDTRIP, 1024, -1024, 2, 0, 1
ShakeSprite ATTACKER, 2, 1434, 0, 2, 1, 3
Wait 2
ChangeSpriteColor ATTACKER, 16, 8, 0, 31, 14, 4
Wait 7
ChangeBackgroundColor 4, 6, 9, 0, 20, 6, 3
ChangeSpriteColor ATTACKER, 16, 16, 0, 31, 24, 12
ScaleSprite ATTACKER, ROUNDTRIP, 1229, -1229, 2, 0, 1
ShakeSprite ATTACKER, 2, 1639, 0, 2, 1, 3
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 3
Wait 2
ChangeSpriteColor ATTACKER, 16, 10, 0, 31, 14, 4
Wait 7
Wait 1
ToggleSpriteVisibility ATTACKER, 3
MoveCamera INTERPOLATION, DEFENDER, 6, 0, 8
Wait 6
Emit 1013, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 20, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 21, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 22, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 23, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1013, 24, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeBackgroundColor 4, 13, 13, 0, 31, 24, 10
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 26, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 26, 12
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 13, 9, 0, 20, 6, 3
Wait 8
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 6
ChangeBackgroundColor 4, 9, 0, 0, 20, 6, 3
Wait 18
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 10, 0, 0, 31, 14, 4
ToggleSpriteVisibility ATTACKER, 4
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
