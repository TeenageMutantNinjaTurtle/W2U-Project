MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1023
AudioContainer CONTINUE
PlaySound 1407, SE1, 14, 6, 200, 115, 0, 0, 0
PlaySound 1423, SE1, 16, 14, -100, 120, 0, 0, 0
PlaySound 1539, SE1, 14, 28, 300, 120, 0, 0, 0
PlaySound 1539, SE2, 14, 33, 400, 120, 0, 0, 0
PlaySound 1539, SE1, 14, 38, 500, 120, 0, 0, 0
PlaySound 1420, SE2, 16, 34, 0, 125, 0, 0, 0
PlaySound 1420, SE2, 16, 39, 150, 125, 0, 0, 0
PlaySound 1475, SE2, 16, 44, 300, 125, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 7, 0, 31, 24, 8
Wait 8
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 6px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, 6, 0, 8
Wait 6
Emit 1023, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1023, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1023, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1023, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 1
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 10, 10, 0, 31, 28, 14
Wait 2
ChangeSpriteColor DEFENDER, 10, 0, 0, 31, 28, 14
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 2, 0, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 6
Wait 7
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -4px, 49152, 0, 4096, 0
Emit 1023, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1023, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 4
Emit 1023, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1023, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1023, 6, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 6
Emit 1023, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1023, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1023, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1023, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1023, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1023, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1023, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1023, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1023, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1023, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1023, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1023, 20, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor DEFENDER, 10, 10, 0, 31, 26, 10
Wait 2
ChangeSpriteColor DEFENDER, 10, 0, 0, 31, 26, 10
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 2, 0, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 6
Wait 3
ChangeSpriteColor DEFENDER, 10, 10, 0, 31, 26, 10
Wait 2
ChangeSpriteColor DEFENDER, 10, 0, 0, 31, 26, 10
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 2, 0, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 6
Wait 3
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 29, 16
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 29, 16
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeSpriteColor ATTACKER, 7, 0, 0, 31, 24, 8
Wait 24
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
