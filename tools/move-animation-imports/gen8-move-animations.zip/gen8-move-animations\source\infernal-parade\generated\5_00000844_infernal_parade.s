MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1024
AudioContainer CONTINUE
PlaySound 1426, SE1, 14, 0, 500, 100, 0, 0, 0
PlaySound 1426, SE2, 14, 6, 650, 100, 0, 0, 0
PlaySound 1426, SE1, 14, 12, 800, 100, 0, 0, 0
PlaySound 1815, SE2, 14, 2, 200, 100, 0, 0, 0
PlaySound 1407, SE2, 14, 26, 300, 110, 0, 0, 0
PlaySound 1407, SE2, 14, 31, 300, 110, 0, 0, 0
PlaySound 1407, SE2, 14, 36, 300, 110, 0, 0, 0
PlaySound 1420, SE1, 16, 33, 300, 122, 0, 0, 0
PlaySound 1420, SE1, 16, 38, 300, 122, 0, 0, 0
PlaySound 1475, SE1, 16, 43, -100, 122, 0, 0, 0
PlaySound 1426, SE2, 16, 44, -200, 120, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 0, 5, 2, 9
ChangeSpriteColor ATTACKER, 0, 8, 0, 24, 8, 26
Emit 1024, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 11, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 12, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 15, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 16, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 3, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 8, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 9, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 13, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 14, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 26
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 8, 0, 0, 24, 8, 26
MoveCamera INTERPOLATION, DEFENDER, 7, 0, 8
Wait 7
Emit 1024, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 20, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 21, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 22, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 23, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 24, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 25, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 26, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 27, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 28, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1024, 29, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 10, 10, 0, 30, 10, 28
Wait 2
ChangeSpriteColor DEFENDER, 10, 0, 0, 30, 10, 28
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 2, 0, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 6
Wait 3
ChangeSpriteColor DEFENDER, 10, 10, 0, 30, 10, 28
Wait 2
ChangeSpriteColor DEFENDER, 10, 0, 0, 30, 10, 28
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 2, 0, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 6
Wait 3
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 16, 28
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 16, 28
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 6
ChangeBackgroundColor 4, 10, 0, 0, 5, 2, 9
Wait 20
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
