import { aimed, createKit, fadeOut, grow, hold, setCurves, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, beam, emits, FOE, FRONT, gather, glow, hit, impact, intro, lunge, outro, pan, puffs, quake, ring, shake, snd, sparks, streaks, tint, WHITE, zaps, type Pal } from "../tools/phrases";

// Steel Beam (move 796) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user tears metal out of itself: grey shards are drawn in to a
//      blue-white glare inside rings of blue light, orange sparks jumping.
//   2. It fires a steel-blue beam with shards of metal flying along it.
//   3. The beam bursts on the foe in a dark, heavy cloud shot through with
//      white, metal flying out of it.
// The metal is Crunch's debris texture; the sparks are Thunder's arcs in orange.

const SPA = 976;
const kit = await createKit({ workDir: import.meta.dirname, slug: "steel-beam", moveId: 796, spaId: SPA, donors: [413, 257, 228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 12;
const CHARGE = 30;
const HOLD = 5;
const TRAVEL = 8;
const POUR = 24;
const AFTER = 26;

const STEEL: Rgb = [0.6, 0.72, 0.95];
const PALE: Rgb = [0.88, 0.94, 1.0];
const DEEP: Rgb = [0.3, 0.4, 0.8];
const ORANGE: Rgb = [1.0, 0.6, 0.15];
const PAL: Pal = [STEEL, PALE, DEEP];
const METAL: Pal = [[0.8, 0.82, 0.88], [0.95, 0.96, 1.0], [0.55, 0.58, 0.68]];
const SMOKE: Pal = [[0.04, 0.05, 0.12], [0.2, 0.22, 0.4], [0, 0, 0.04]];

const user = [
  ...gather(kit, "draw", { pos: FRONT, frames: CHARGE, pal: PAL, radius: 2.8, scale: 1.6 }),
  ...sparks(kit, "metalIn", { pos: FRONT, radius: 2.4, speed: 0, count: 1, bursts: CHARGE / 3, gap: 3, life: 10, scale: 0.26, pal: METAL, tex: kit.tex(413, 2), twinkle: false, spin: 0.2 }),
  ...ring(kit, "haloA", { pos: FRONT, at: 4, life: 14, scale: 2.4, pal: [STEEL, PALE, DEEP], to: 0.5, level: 0.8 }),
  ...ring(kit, "haloB", { pos: FRONT, at: 16, life: 14, scale: 2.4, pal: [PALE, WHITE, STEEL], to: 0.5, level: 0.8 }),
  ...zaps(kit, "orangeSparks", { pos: FRONT, radius: 1.2, count: 1, bursts: CHARGE / 4, gap: 4, life: 6, scale: 0.5, pal: [ORANGE, [1.0, 0.85, 0.5], ORANGE] }),
  ...glow(kit, "glare", { pos: FRONT, at: CHARGE - 6, life: HOLD + POUR + 8, scale: 1.5, pal: [PALE, WHITE, STEEL], tex: kit.tex(T.spiky), spin: 0.2, level: 1, scaleCurve: grow(1.5, 0.12, 1.05) }),
];
// The metal is drawn inward, and the rings close in on the glare.
kit.resources[kit.idx("metalIn")]!.behaviors = [{ type: "convergence", target: [0, 0, 0], force: 0.1 }];
for (const n of ["haloA", "haloB"]) setCurves(kit.resources[kit.idx(n)]!, { start: 1, mid: 0.6, end: 0.25, curveIn: 0.5, curveOut: 0.6 }, { start: 0, mid: 0.8, end: 0, curveIn: 0.2, curveOut: 0.7 });

const shots = [...beam(kit, "beam", { at: CHARGE + HOLD, pour: POUR, travel: TRAVEL, width: 1.5, pal: [STEEL, PALE, DEEP], tex: kit.tex(T.softDisc) })];
// Shards of metal flying along the beam.
const shards = kit.spray([333, 1], kit.tex(413, 2), FRONT, { radius: 0.8, speed: 0.01, count: 1, bursts: POUR / 3, gap: 3, life: TRAVEL + 2, scale: 0.26, shape: "ball" });
shards.startDelayFrames = CHARGE + HOLD;
aimed(shards, 16 / TRAVEL, TRAVEL + 2);
shards.airResistance = 1.0;
shards.variance.lifeTime = 0;
setCurves(shards, hold(1), hold(1));
kit.prism(shards, METAL);
kit.add("shards", shards);
shots.push("shards");

const foe = [
  ...impact(kit, "hit", { pal: PAL, size: 1.6, rays: 9, flecks: 0 }),
  ...sparks(kit, "metalOut", { radius: 0.8, speed: 0.34, count: 4, bursts: 3, gap: 5, life: 16, scale: 0.28, pal: METAL, fall: 0.02, tex: kit.tex(413, 2), twinkle: false, spin: 0.25 }),
  ...streaks(kit, "whiteCuts", { at: 4, radius: 1.0, speed: 0.2, count: 3, bursts: 5, gap: 4, life: 8, scale: 0.7, pal: [WHITE, PALE, WHITE], tex: kit.tex(T.crescent) }),
  // The dark, heavy cloud.
  ...puffs(kit, "cloud", { pos: FOE, at: 3, radius: 1.3, count: 2, bursts: POUR / 4, gap: 4, life: 18, scale: 1.5, pal: SMOKE, speed: 0.1, level: 0.92, tex: kit.tex(T.clumps), to: 1.6 }),
  ...zaps(kit, "afterSparks", { at: 6, radius: 1.6, count: 1, bursts: 5, gap: 4, life: 6, scale: 0.5, pal: [ORANGE, [1.0, 0.85, 0.5], ORANGE] }),
];

const fireAt = CHARGE + HOLD;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1487, 0, { vol: 110 }),
  snd(1435, 8, { ch: "SE2", pitch: -300, vol: 105 }),
  snd(1437, fireAt, { ch: "SE2", pitch: -1000, vol: 127 }),
  snd(1975, fireAt, { pitch: 300, vol: 115 }),
  `SwitchAudioSide SE2, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0`,
  snd(1475, fireAt + TRAVEL, { side: "D", pitch: -300, vol: 127 }),
  snd(1435, fireAt + TRAVEL + 2, { ch: "SE2", side: "D", pitch: -500, vol: 120 }),
  snd(1420, fireAt + TRAVEL + 12, { side: "D", vol: 120 }),
)}
${arena(0, 9, 8, [4, 6, 14])}
${tint("ATTACKER", 0, 8, 6, [20, 24, 31])}
${emits(kit, user, "ATTACKER")}
${emits(kit, shots, "ATTACKER", "DEFENDER")}
${shake("ATTACKER", 819, CHARGE / 2 - 4)}
Wait ${CHARGE + HOLD}
${lunge("ATTACKER", -2)}
${shake("ATTACKER", 1229, POUR / 2)}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${arena(9, 13, 0, [26, 29, 31])}
${hit({ rgb: [26, 29, 31], power: 3 })}
${arena(13, 9, 4, [4, 6, 14])}
Wait 10
${quake("1x", 6)}
Wait ${POUR - 6 - 10}
${tint("ATTACKER", 8, 0, 4, [20, 24, 31])}
${arena(9, 0, 8, [4, 6, 14])}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [242, 87, 63, 605, 400, 240, 153, 129, 427],
  references: ["reference/Steel_Beam_VIII.png", "reference/Steel_Beam_VIII_2.png", "reference/Steel_Beam_IX.png", "reference/Steel_Beam_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("metalIn")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("beamJet")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("cloud")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  charge f${CAMERA_IN}, fire f${CAMERA_IN + fireAt}, lands f${CAMERA_IN + fireAt + TRAVEL}`);
