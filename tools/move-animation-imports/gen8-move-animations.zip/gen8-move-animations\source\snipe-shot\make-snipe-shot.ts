import { createKit, fadeOut, grow, setCurves, T, twinkle, type Rgb } from "../tools/anim-kit";
import { arena, audio, bolt, emits, FOE, FRONT, glow, hit, impact, intro, lunge, outro, pan, ring, shot, snd, sparks, streaks, tint, WHITE, type Pal } from "../tools/phrases";

// Snipe Shot (move 745) - from the Bulbapedia stills (reference/sheet.png).
//   1. Aim: the arena dims; the user points, a glint at its fingertip, water
//      swirling up round it in bright blue-white arcs and droplets.
//   2. Shot: one thin, very fast bolt of water.
//   3. Hit: the foe bursts in blue water - curved splashes thrown outward and
//      droplets hanging in the air.

const SPA = 943;
const kit = await createKit({ workDir: import.meta.dirname, slug: "snipe-shot", moveId: 745, spaId: SPA, donors: [228, 465, 579, 411, 321, 298, 632, 407] });

const CAMERA_IN = 10;
const AIM = 20;
const TRAVEL = 4;
const AFTER = 22;

const BLUE: Rgb = [0.25, 0.6, 1.0];
const CYAN: Rgb = [0.55, 0.88, 1.0];
const PALE: Rgb = [0.86, 0.96, 1.0];
const DEEP: Rgb = [0.12, 0.35, 0.9];
const PAL: Pal = [CYAN, PALE, BLUE];

// --- 1. aim ---
const user = [
  ...streaks(kit, "swirl", { pos: [0, -0.6, 0.2], radius: 1.2, speed: 0.1, count: 2, bursts: AIM / 4, gap: 4, life: 10, scale: 0.45, pal: [CYAN, BLUE, PALE], tex: kit.tex(T.spike), flat: true, lift: 0.22 }),
  ...sparks(kit, "drops", { pos: [0, 0, 0.2], radius: 1.4, speed: 0.04, count: 1, bursts: AIM / 2, gap: 2, life: 10, scale: 0.13, pal: [PALE, WHITE, CYAN], fall: -0.008 }),
  ...glow(kit, "glint", { pos: FRONT, at: AIM - 8, life: 9, scale: 0.9, pal: [WHITE, WHITE, CYAN], tex: kit.tex(T.star4Big), spin: 0.1, scaleCurve: twinkle(1.3), alpha: twinkle(1) }),
  ...ring(kit, "muzzle", { pos: FRONT, at: AIM, life: 7, scale: 0.7, pal: [PALE, WHITE, CYAN], to: 2.0 }),
];
bolt(kit, "bolt", { at: AIM, travel: TRAVEL, scale: 2.2, pal: [WHITE, WHITE, PALE] });
shot(kit, "boltGlow", kit.tex(T.softDisc), { at: AIM, travel: TRAVEL, scale: 0.45, pal: [CYAN, PALE, BLUE], count: 2, gap: 1 });

// --- 3. hit ---
const foe = [
  ...impact(kit, "hit", { pal: PAL, size: 1.0, rays: 0, flecks: 0 }),
  ...streaks(kit, "splash", { radius: 0.5, speed: 0.42, count: 9, life: 11, scale: 0.75, pal: [BLUE, PALE, CYAN], tex: kit.tex(T.spike) }),
  ...streaks(kit, "splash2", { at: 3, radius: 0.4, speed: 0.3, count: 6, life: 10, scale: 0.55, pal: [DEEP, CYAN, BLUE], tex: kit.tex(T.spike) }),
  ...ring(kit, "ripple", { scale: 1.2, pal: [PALE, WHITE, CYAN], tex: kit.tex(632, 2), to: 1.9, life: 10 }),
  ...sparks(kit, "droplets", { radius: 0.6, speed: 0.3, count: 10, life: 18, scale: 0.16, pal: [PALE, WHITE, CYAN], fall: 0.012, twinkle: false }),
];
// The splashes start long and shrink as they fly.
for (const n of ["splash", "splash2"]) setCurves(kit.resources[kit.idx(n)]!, grow(1.1, 0.3, 0.6), fadeOut());
// The flash stays small: a thin shot, not a blast.
kit.resources[kit.idx("hitFlash")]!.baseScale = 1.1;

const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1418, 0, { ch: "PSG", pitch: 600, vol: 95 }),
  snd(1445, 2, { ch: "SE2", pitch: 1200, vol: 90 }),
  snd(1509, AIM - 8, { pitch: 900, vol: 100 }),
  snd(1407, AIM, { pitch: 700, vol: 125 }),
  `SwitchAudioSide SE1, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0`,
  snd(1511, AIM + TRAVEL, { ch: "SE2", side: "D", pitch: 500, vol: 120 }),
  snd(1475, AIM + TRAVEL, { side: "D", vol: 115 }),
)}
${arena(0, 8, 6, [2, 3, 10])}
${tint("ATTACKER", 0, 6, 4, [20, 28, 31])}
${emits(kit, user, "ATTACKER")}
${emits(kit, ["bolt", "boltGlow"], "ATTACKER", "DEFENDER")}
Wait ${AIM}
${lunge("ATTACKER", -1)}
${tint("ATTACKER", 6, 0, 3, [20, 28, 31])}
${pan("DEFENDER", TRAVEL + 2)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [24, 30, 31], power: 2 })}
${arena(8, 0, 8, [2, 3, 10])}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 153, 129, 453, 236],
  references: ["reference/Snipe_Shot_VIII.png", "reference/Snipe_Shot_VIII_2.png", "reference/Snipe_Shot_IX.png", "reference/Snipe_Shot_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("bolt")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("splash")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  aim f${CAMERA_IN}, shot f${CAMERA_IN + AIM}, hit f${CAMERA_IN + AIM + TRAVEL}`);
