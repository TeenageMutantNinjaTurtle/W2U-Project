ChangeBackgroundColor 4, 0, 12, 1, 31, 12, 22
PlaySound 1485, SE1, FLAT, 0, 200, 100, 0, 0, 0
LetCMDsFinish PALFADE_3D
ChangeBackgroundColor 4, 12, 0, 1, 31, 12, 22
LetCMDsFinish PALFADE_3D
ChangeBackgroundColor 4, 0, 12, 1, 31, 12, 22
PlaySound 1485, SE1, FLAT, 0, 200, 100, 0, 0, 0
LetCMDsFinish PALFADE_3D
ChangeBackgroundColor 4, 12, 0, 1, 31, 12, 22
LetCMDsFinish ALL
MoveCamera INTERPOLATION, DEFENDER, 16, 0, 8
AudioContainer CONTINUE
PlaySound 1541, SE2, 16, 0, 0, 127, 0, 0, 0
PlaySound 1420, SE1, 14, 30, 0, 120, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 16, 0, 30, 0, 0
AudioContainer SUSPEND
LoadSPA 565
LoadSPA 204
Emit 204, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 565, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 565, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 565, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 20
ToggleFreezeSprite DEFENDER, START
Emit 204, 1, DEFENDER, C_DOUBLE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 2, 1, 1
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
