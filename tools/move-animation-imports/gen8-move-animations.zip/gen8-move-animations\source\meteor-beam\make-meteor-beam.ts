import { createKit, fadeInOut, fadeOut, grow, hold, setCurves, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, beam, emits, FOE, FRONT, gather, glow, hit, impact, intro, lunge, outro, pan, quake, ring, risers, shake, shot, snd, sparks, streaks, tint, twoPart, USER, WHITE, type Pal } from "../tools/phrases";

// Meteor Beam (move 800) - from the Bulbapedia stills (reference/sheet.png).
// A two-turn move, so the script has two parts (as retail Solar Beam).
//   Charge turn: the arena turns to starry violet space; inside a pink-red
//     ring the user gathers a yellow-orange flare, blue-white sparks jumping
//     off it, stars streaming in and stones lifting off the ground.
//   Attack turn: a beam of yellow-white light with dark hoops strung along
//     it, bursting on the foe in jagged yellow and black.

const SPA = 980;
const kit = await createKit({ workDir: import.meta.dirname, slug: "meteor-beam", moveId: 800, spaId: SPA, donors: [413, 228, 465, 579, 411, 298, 560] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const GATHER = 44; // charge turn
const AIM = 10; // attack turn: the flare brightens
const TRAVEL = 8;
const POUR = 24;
const AFTER = 26;

const PINK: Rgb = [1.0, 0.35, 0.5];
const ORANGE: Rgb = [1.0, 0.6, 0.15];
const YELLOW: Rgb = [1.0, 0.9, 0.35];
const PALE: Rgb = [1.0, 0.98, 0.78];
const BLUE: Rgb = [0.45, 0.75, 1.0];
const BLACK: Rgb = [0, 0, 0];
const ROCK: Pal = [[0.7, 0.64, 0.6], [0.9, 0.86, 0.82], [0.5, 0.45, 0.42]];
const FIRE: Pal = [YELLOW, PALE, ORANGE];

// --- charge turn ---
const charge = [
  ...ring(kit, "halo", { pos: USER, life: GATHER, scale: 2.5, pal: [PINK, [1.0, 0.6, 0.7], [0.9, 0.15, 0.35]], tex: kit.tex(T.hoop), to: 1.04, level: 0.85 }),
  ...gather(kit, "draw", { pos: USER, frames: GATHER - 8, pal: [PALE, WHITE, YELLOW], radius: 3.0, scale: 1.6, streaks: true }),
  ...glow(kit, "flare", { pos: USER, at: 6, life: GATHER - 6, scale: 1.3, pal: [YELLOW, PALE, ORANGE], tex: kit.tex(T.spiky), spin: 0.12, level: 1, scaleCurve: grow(0.3, 0.6, 1.15), alpha: fadeInOut(1, 0.15, 0.85) }),
  ...streaks(kit, "blueSparks", { pos: USER, at: 8, radius: 0.6, speed: 0.22, count: 3, bursts: (GATHER - 16) / 4, gap: 4, life: 8, scale: 0.7, pal: [BLUE, WHITE, [0.3, 0.5, 1.0]], tex: kit.tex(T.shard) }),
  ...sparks(kit, "stars", { pos: [0, 0.8, 0.2], radius: 3.2, speed: 0, count: 1, bursts: GATHER / 3, gap: 3, life: 10, scale: 0.34, pal: [WHITE, [0.8, 0.9, 1.0], [1.0, 0.8, 0.9]], shape: "ball", tex: kit.tex(T.sparkle4) }),
  ...risers(kit, "stones", { at: 6, frames: GATHER - 16, radius: 2.0, speed: 0.09, scale: 0.24, life: 18, every: 4, pal: ROCK, tex: kit.tex(413, 2) }),
];
setCurves(kit.resources[kit.idx("halo")]!, grow(0.5, 0.2, 1.04), fadeInOut(0.85, 0.12, 0.88));

// --- attack turn ---
const aim = [
  ...glow(kit, "muzzleFlare", { pos: FRONT, life: AIM + POUR + 6, scale: 1.5, pal: [PALE, WHITE, YELLOW], tex: kit.tex(T.spiky), spin: 0.2, level: 1, scaleCurve: grow(0.4, 0.2, 1.1), alpha: fadeInOut(1, 0.1, 0.85) }),
  ...ring(kit, "muzzleRing", { pos: FRONT, at: AIM, life: 10, scale: 1.6, pal: [PINK, PALE, [0.9, 0.15, 0.35]], tex: kit.tex(T.hoop), to: 2.2 }),
  ...streaks(kit, "aimSparks", { pos: FRONT, radius: 0.5, speed: 0.22, count: 3, bursts: 3, gap: 3, life: 8, scale: 0.6, pal: [BLUE, WHITE, [0.3, 0.5, 1.0]], tex: kit.tex(T.shard) }),
];
const shots = [...beam(kit, "beam", { at: AIM, pour: POUR, travel: TRAVEL, width: 1.4, pal: [YELLOW, PALE, ORANGE], tex: kit.tex(T.softDisc) })];
// Dark hoops strung along the beam.
shot(kit, "hoops", kit.tex(T.ring), { from: FRONT, at: AIM + 1, travel: TRAVEL, scale: 1.35, pal: [BLACK, BLACK, BLACK], count: 5, gap: 4, aspect: 0.45, scaleCurve: hold(1), alpha: fadeInOut(0.9, 0.1, 0.8) });
shots.unshift("hoops"); // in front of the beam
const foe = [
  ...impact(kit, "strike", { pal: FIRE, size: 1.7, rays: 8, flecks: 0 }),
  ...streaks(kit, "yellowJags", { radius: 0.6, speed: 0.42, count: 6, life: 11, scale: 1.0, pal: [YELLOW, PALE, ORANGE], tex: kit.tex(T.shard) }),
  ...streaks(kit, "blackJags", { at: 1, radius: 0.6, speed: 0.36, count: 6, life: 11, scale: 0.9, pal: [BLACK, [0.15, 0.08, 0], BLACK], tex: kit.tex(T.shard) }),
  ...impact(kit, "strike2", { at: 12, pal: [ORANGE, PALE, PINK], size: 1.3, rays: 8, flecks: 0, spiky: false }),
  ...sparks(kit, "rubble", { at: 2, radius: 0.8, speed: 0.3, count: 5, life: 16, scale: 0.26, pal: ROCK, fall: 0.026, tex: kit.tex(413, 2), twinkle: false, spin: 0.2 }),
  ...glow(kit, "blaze", { pos: FOE, life: POUR + 4, scale: 3.2, pal: [YELLOW, WHITE, ORANGE], level: 0.8 }),
];

const chargeScript = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1497, 0, { vol: 110 }),
  snd(1474, 4, { ch: "SE2", vol: 85 }),
  snd(1509, 16, { ch: "SE2", pitch: 500, vol: 85 }),
  snd(1452, GATHER - 8, { ch: "SE2", pitch: 300, vol: 110 }),
)}
${arena(0, 12, 10, [9, 4, 20])}
${tint("ATTACKER", 0, 8, 10, [31, 26, 14])}
${emits(kit, charge, "ATTACKER")}
${shake("ATTACKER", 819, GATHER / 2 - 6)}
Wait ${GATHER - 10}
${tint("ATTACKER", 8, 0, 8, [31, 26, 14])}
${arena(12, 0, 10, [9, 4, 20])}
Wait 12
${outro({ unfreeze: "NONE" })}`;

const fireScript = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1487, 0, { vol: 105 }),
  snd(1975, AIM, { vol: 127 }),
  snd(1424, AIM, { ch: "SE2", pitch: -300, vol: 120 }),
  `SwitchAudioSide SE2, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0`,
  snd(1475, AIM + TRAVEL, { side: "D", pitch: -300, vol: 127 }),
  snd(1884, AIM + TRAVEL + 2, { ch: "SE2", side: "D", vol: 110 }),
  snd(1420, AIM + TRAVEL + 12, { side: "D", vol: 125 }),
)}
${arena(0, 12, 4, [9, 4, 20])}
${tint("ATTACKER", 0, 10, 4, [31, 28, 14])}
${emits(kit, aim, "ATTACKER")}
${emits(kit, shots, "ATTACKER", "DEFENDER")}
${shake("ATTACKER", 819, AIM / 2)}
Wait ${AIM}
${lunge("ATTACKER", -2)}
${shake("ATTACKER", 1229, POUR / 2)}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${arena(12, 14, 0, [31, 28, 18])}
${hit({ rgb: [31, 29, 16], power: 3 })}
${arena(14, 12, 4, [9, 4, 20])}
Wait 10
${quake("1x", 6)}
Wait ${POUR - 6 - 10}
${tint("ATTACKER", 10, 0, 4, [31, 28, 14])}
${arena(12, 0, 10, [9, 4, 20])}
Wait ${AFTER}
${outro()}`;

const script = twoPart(chargeScript, fireScript);
await kit.finish({
  script,
  donorMoveIds: [242, 63, 605, 400, 240, 129, 381],
  references: ["reference/Meteor_Beam_VIII.png", "reference/Meteor_Beam_VIII_2.png", "reference/Meteor_Beam_IX.png", "reference/Meteor_Beam_IX_2.png"],
  expectText: [".word 2 @ Count", `LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("halo")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("beamJet")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("yellowJags")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  charge turn ~${CAMERA_IN + GATHER + 14} frames; attack turn: fire f${CAMERA_IN + AIM}, lands f${CAMERA_IN + AIM + TRAVEL}`);
