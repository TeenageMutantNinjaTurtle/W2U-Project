import { createKit, deg, paint, spin, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FOE_FLOOR, FRONT, gather, glow, hit, impact, intro, lunge, outro, pan, remapAnim, ring, shake, snd, sparks, tint, WHITE, zaps, type Pal } from "../tools/phrases";

// Thunder Cage (move 819) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user gathers a glare of yellow-white electricity.
//   2. Over the foe a blazing knot of lightning hangs in the air, and bolts
//      pour down from it to the ground on every side: a cage of lightning,
//      crackling round the foe.
// The lightning is Thunder's (the bolt column and the arcs).

const SPA = 999;
const kit = await createKit({ workDir: import.meta.dirname, slug: "thunder-cage", moveId: 819, spaId: SPA, donors: [256, 257, 228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const CHARGE = 20;
const PAN = 10;
const KNOT = 6; // the knot flares before the bars come down
const CAGE = 36;
const AFTER = 10;

const YELLOW: Rgb = [1.0, 0.92, 0.25];
const PALE: Rgb = [1.0, 0.98, 0.72];
const GOLD: Rgb = [1.0, 0.72, 0.15];
const ICE: Rgb = [0.75, 0.95, 1.0];
const PAL: Pal = [YELLOW, PALE, GOLD];
const TOP: Vec3 = [0, 2.5, 0.8];

const user = [
  ...gather(kit, "draw", { pos: FRONT, frames: CHARGE, pal: PAL, radius: 2.4, scale: 1.5 }),
  ...zaps(kit, "crackle", { pos: FRONT, radius: 1.0, count: 1, bursts: CHARGE / 3, gap: 3, life: 6, scale: 0.6, pal: [YELLOW, WHITE, ICE] }),
  ...glow(kit, "glare", { pos: FRONT, at: 4, life: CHARGE, scale: 1.2, pal: [PALE, WHITE, YELLOW], tex: kit.tex(T.spiky), spin: 0.2, level: 1 }),
];

// A bar of the cage: Thunder's bolt column, leaning in to the knot at the top.
function bar(name: string, footX: number, at: number, colour: Rgb): string {
  const tilt = Math.atan2(footX, TOP[1] - FOE_FLOOR[1]); // lean so the top meets the knot
  const r = remapAnim(kit, kit.shell(256, 1), 256);
  Object.assign(r, { emitterBasePos: [footX / 2, (TOP[1] + FOE_FLOOR[1]) / 2, 0.8 - Math.abs(footX) * 0.05], baseScale: 2.3, startDelayFrames: at, particleLifeFrames: 9, emitterLifeFrames: CAGE - 8, emissionIntervalFrames: 8 });
  spin(r, 0, 0, tilt);
  paint(r, colour, WHITE, colour);
  kit.add(name, r);
  return name;
}
const foe = [
  ...glow(kit, "knot", { pos: TOP, life: KNOT + CAGE, scale: 1.2, pal: [PALE, WHITE, YELLOW], tex: kit.tex(T.spiky), spin: 0.2, level: 1 }),
  ...glow(kit, "knotGlow", { pos: TOP, life: KNOT + CAGE, scale: 1.8, pal: [YELLOW, PALE, GOLD], level: 0.8 }),
  bar("barA", -2.2, KNOT, YELLOW), bar("barB", -0.9, KNOT + 2, PALE), bar("barC", 0.9, KNOT + 4, YELLOW), bar("barD", 2.2, KNOT + 6, PALE),
  ...zaps(kit, "arcs", { at: KNOT, radius: 1.6, count: 2, bursts: CAGE / 4, gap: 4, life: 6, scale: 0.8, pal: [YELLOW, WHITE, ICE] }),
  ...impact(kit, "shock", { at: KNOT, pal: PAL, size: 1.3, rays: 0, flecks: 0, spiky: false }),
  ...ring(kit, "floorRing", { pos: FOE_FLOOR, at: KNOT, scale: 1.7, pal: [YELLOW, PALE, GOLD], tex: kit.tex(T.ring), aspect: 2.6, to: 1.4, life: CAGE, level: 0.9 }),
  ...glow(kit, "floorGlow", { pos: FOE_FLOOR, at: KNOT, life: CAGE, scale: 1.8, pal: [YELLOW, GOLD, PALE], aspect: 2.6, level: 0.65 }),
  ...sparks(kit, "sparks", { at: KNOT, radius: 1.5, speed: 0.12, count: 2, bursts: CAGE / 4, gap: 4, life: 10, scale: 0.13, pal: [YELLOW, WHITE, GOLD], fall: 0.01 }),
];

const cageAt = CHARGE + PAN + KNOT;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1483, 0, { ch: "SE2", vol: 100 }),
  snd(1458, 6, { pitch: 300, vol: 105 }),
  snd(1376, CHARGE, { ch: "SE2", vol: 0 }),
  snd(1522, CHARGE, { vol: 120 }),
  snd(1683, cageAt - 2, { ch: "SE2", side: "D", vol: 127 }),
  snd(1475, cageAt, { side: "D", pitch: -200, vol: 125 }),
  snd(1710, cageAt + 10, { ch: "SE2", side: "D", pitch: 200, vol: 110 }),
  snd(1710, cageAt + 22, { side: "D", pitch: 400, vol: 105 }),
)}
${tint("ATTACKER", 0, 9, 5, [31, 30, 12])}
${emits(kit, user, "ATTACKER")}
${shake("ATTACKER", 819, CHARGE / 2 - 2)}
Wait ${CHARGE}
${lunge("ATTACKER", -1)}
${tint("ATTACKER", 9, 0, 4, [31, 30, 12])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
${arena(0, 9, 4, [4, 4, 12])}
Wait ${KNOT}
${hit({ rgb: [31, 31, 14], power: 2 })}
${shake("DEFENDER", 1229, CAGE / 2 - 6)}
Wait ${CAGE - 10}
${arena(9, 0, 8, [4, 4, 12])}
Wait ${AFTER + 6}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [87, 63, 605, 400, 240, 129],
  references: ["reference/SwShCT_Prerelease_Thunder_Cage_2.png", "reference/Thunder_Cage_IX.png", "reference/Thunder_Cage_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("crackle")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("barA")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("barD")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  charge f${CAMERA_IN}, cage f${CAMERA_IN + cageAt}-${CAMERA_IN + cageAt + CAGE}`);
