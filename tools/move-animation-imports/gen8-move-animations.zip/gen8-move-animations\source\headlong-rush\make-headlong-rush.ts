import { aimed, createKit, fadeOut, grow, hold, paint, setCurves, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FOE_FLOOR, glow, hit, impact, intro, pan, puffs, quake, ring, risers, snd, sparks, squash, streaks, tint, USER, USER_FLOOR, WHITE, type Pal } from "../tools/phrases";

// Headlong Rush (move 838) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user braces: an orange glow outlines it, dust kicked up at its
//      feet, lines of force streaming past.
//   2. It hurls itself at the foe as a burning orange mass.
//   3. The ground erupts under the foe: a yellow-orange blast with rays, a
//      column of earth and rock thrown up, dark dust rolling out.
// The user is hidden while it charges (ToggleSpriteVisibility 3/4). The rock
// is Crunch's debris (SPA 413). The Defense drops are the engine's.

const SPA = 1018;
const kit = await createKit({ workDir: import.meta.dirname, slug: "headlong-rush", moveId: 838, spaId: SPA, donors: [413, 228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 10;
const BRACE = 20;
const TRAVEL = 6;
const AFTER = 30;

const ORANGE: Rgb = [1.0, 0.55, 0.1];
const YELLOW: Rgb = [1.0, 0.88, 0.3];
const PALE: Rgb = [1.0, 0.97, 0.75];
const RUST: Rgb = [0.8, 0.3, 0.05];
const EARTH: Pal = [[0.55, 0.38, 0.2], [0.75, 0.58, 0.36], [0.32, 0.2, 0.1]];
const DUST: Pal = [[0.42, 0.3, 0.16], [0.6, 0.45, 0.28], [0.2, 0.13, 0.06]];
const rockTex = kit.tex(413, 2);
const BODY: Vec3 = [0, 0.3, 0.3];

// --- 1. the brace ---
const user = [
  ...ring(kit, "outline", { pos: USER, life: BRACE + 2, scale: 2.1, pal: [ORANGE, YELLOW, RUST], to: 1.08, level: 0.95 }),
  ...streaks(kit, "force", { pos: USER, radius: 2.4, speed: -0.24, count: 3, bursts: BRACE / 4, gap: 4, life: 7, scale: 0.6, pal: [YELLOW, PALE, ORANGE] }),
  ...puffs(kit, "kickedDust", { pos: USER_FLOOR, radius: 1.2, count: 2, bursts: BRACE / 5, gap: 5, life: 13, scale: 0.7, pal: DUST, speed: 0.08, rise: 0.02, level: 0.8 }),
  ...glow(kit, "aura", { pos: USER, life: BRACE + 2, scale: 2.8, pal: [ORANGE, RUST, YELLOW], level: 0.7 }),
];

// --- 2. the rush: a burning mass thrown at the foe ---
const rush: string[] = [];
for (const [name, tex, scale, colours, level] of [
  ["rushCore", kit.tex(T.softDisc), 1.5, [YELLOW, PALE, ORANGE], 0.95],
  ["rushBody", kit.tex(T.fuzzyGlow), 2.8, [ORANGE, YELLOW, RUST], 0.85],
] as const) {
  const r = kit.parked(tex, BODY, scale, TRAVEL + 1);
  r.startDelayFrames = BRACE;
  aimed(r, 16 / TRAVEL, TRAVEL + 1);
  r.airResistance = 1.0;
  setCurves(r, hold(1.05), hold(level));
  paint(r, colours[0] as Rgb, colours[1] as Rgb, colours[2] as Rgb);
  kit.add(name, r);
  rush.push(name);
}
const wake = [
  ...streaks(kit, "wake", { pos: USER, at: BRACE, radius: 1.5, speed: 0.42, count: 4, bursts: 3, gap: 2, life: 7, scale: 1.0, pal: [YELLOW, PALE, ORANGE], flat: true }),
  ...puffs(kit, "wakeDust", { pos: USER_FLOOR, at: BRACE, radius: 1.0, count: 3, life: 12, scale: 0.8, pal: DUST, speed: 0.1, level: 0.8 }),
];

// --- 3. the ground erupts ---
const foe = [
  ...impact(kit, "blast", { pal: [YELLOW, PALE, ORANGE], size: 2.0, rays: 9, flecks: 0 }),
  ...risers(kit, "column", { pos: FOE_FLOOR, frames: 10, radius: 0.9, speed: 0.36, scale: 0.42, life: 14, every: 1, pal: EARTH, tex: rockTex }),
  ...sparks(kit, "rocks", { pos: FOE_FLOOR, radius: 1.0, speed: 0.3, count: 7, life: 20, scale: 0.34, pal: EARTH, fall: 0.026, tex: rockTex, twinkle: false, spin: 0.25 }),
  ...streaks(kit, "rays", { at: 1, radius: 0.8, speed: 0.5, count: 7, life: 9, scale: 1.1, pal: [YELLOW, PALE, ORANGE] }),
  ...ring(kit, "shock", { pos: FOE_FLOOR, at: 1, life: 13, scale: 0.8, pal: [YELLOW, PALE, ORANGE], to: 2.0, aspect: 2.6 }),
  ...puffs(kit, "dust", { pos: FOE_FLOOR, at: 2, radius: 1.6, count: 3, bursts: 3, gap: 4, life: 20, scale: 1.2, pal: DUST, speed: 0.14, rise: 0.02, level: 0.9, tex: kit.tex(T.clumps), to: 1.6 }),
  ...glow(kit, "fire", { pos: FOE, life: 16, scale: 3.6, pal: [ORANGE, YELLOW, RUST], level: 0.8 }),
];
Object.assign(kit.resources[kit.idx("rocks")]!, { axis: [0, 1, 0], initVelAxisAmplifier: 0.36 });
setCurves(kit.resources[kit.idx("rocks")]!, hold(1), fadeOut(1, 0.8));
setCurves(kit.resources[kit.idx("rays")]!, grow(1.2, 0.3, 0.6), fadeOut());

const hitAt = BRACE + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1480, 0, { pitch: -300, vol: 110 }),
  snd(1452, 4, { ch: "SE2", pitch: -200, vol: 105 }),
  snd(1688, BRACE, { pitch: -200, vol: 125 }),
  snd(1475, hitAt, { side: "D", pitch: -400, vol: 127 }),
  snd(1413, hitAt, { ch: "SE2", side: "D", vol: 127 }),
  snd(1884, hitAt + 3, { ch: "SE2", side: "D", pitch: -200, vol: 120 }),
)}
${tint("ATTACKER", 0, 10, 6, [31, 18, 4])}
${emits(kit, user, "ATTACKER")}
${emits(kit, [...rush, ...wake], "ATTACKER", "DEFENDER")}
${squash("ATTACKER", 1229, -1229, BRACE - 4)}
Wait ${BRACE}
ToggleSpriteVisibility ATTACKER, 3
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${arena(0, 12, 0, [31, 26, 12])}
${hit({ rgb: [31, 26, 12], power: 3 })}
${arena(12, 0, 6, [31, 26, 12])}
Wait 8
${quake("2458", 8)}
Wait ${AFTER - 8}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
${tint("ATTACKER", 10, 0, 4, [31, 18, 4])}
ToggleSpriteVisibility ATTACKER, 4
${pan("INIT", 12)}
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [242, 89, 63, 605, 400, 240, 153, 129, 564],
  references: ["reference/Headlong_Rush_LA.png", "reference/Headlong_Rush_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("outline")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("rushBody")}, ATTACKER, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 3", "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("column")}, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 4", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  brace f${CAMERA_IN}, rush f${CAMERA_IN + BRACE}, lands f${CAMERA_IN + hitAt}`);
