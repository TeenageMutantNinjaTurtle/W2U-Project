LoadSPA 998
AudioContainer CONTINUE
PlaySound 1445, SE1, 14, 0, 700, 100, 0, 0, 0
PlaySound 1407, SE2, 14, 4, 500, 115, 0, 0, 0
PlaySound 1511, SE1, 16, 7, 600, 120, 0, 0, 0
PlaySound 1423, SE2, 16, 7, 200, 120, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 6, 0, 16, 26, 31
Emit 998, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 3
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
Wait 3
ChangeSpriteColor ATTACKER, 6, 0, 0, 16, 26, 31
Emit 998, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 998, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 998, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 998, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 998, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 998, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 1
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 24, 30, 31
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 24, 30, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 14
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
