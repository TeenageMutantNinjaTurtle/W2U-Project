import { assert, createKit, T, twinkle, type Rgb } from "../tools/anim-kit";
import { audio, emits, FOE, glow, hit, introStill, lunge, outro, ring, slash, snd, sparks, streaks, tint, USER_FLOOR, WHITE, type Pal } from "../tools/phrases";

// Triple Axel (move 813) - from the Bulbapedia stills (reference/sheet.png).
// The user spins on the ice, glitter scattering from its feet, and its kick
// lands as a long, thin white-blue slash across the foe with ice sparkles.
// Up to three hits: Gen 5 replays the animation per hit, so the camera stays
// still and one hit is under a second.

const SPA = 993;
const kit = await createKit({ workDir: import.meta.dirname, slug: "triple-axel", moveId: 813, spaId: SPA, donors: [228, 465, 579, 411, 298, 407] });

const SPIN = 8;
const AFTER = 14;

const ICE: Rgb = [0.6, 0.9, 1.0];
const PALE: Rgb = [0.9, 0.98, 1.0];
const BLUE: Rgb = [0.35, 0.65, 1.0];
const PAL: Pal = [ICE, PALE, BLUE];

const user = [
  ...ring(kit, "spinRing", { pos: [0, USER_FLOOR[1] + 0.1, 0.3], scale: 1.0, pal: [PALE, WHITE, ICE], tex: kit.tex(T.ring), aspect: 2.6, to: 1.8, life: 9, level: 0.85 }),
  ...sparks(kit, "glitter", { pos: [0, USER_FLOOR[1] + 0.3, 0.4], radius: 1.0, speed: 0.16, count: 6, life: 10, scale: 0.26, pal: [WHITE, PALE, ICE], shape: "circle", tex: kit.tex(T.sparkle4) }),
  // (No streaks round the user as it spins: Logan had the lines that trailed over it at the start removed, 2026-10-03.)
];
const foe = [
  ...slash(kit, "kick", { angle: 62, scale: 4.2, pal: [PALE, WHITE, ICE], life: 8, aspect: 0.14 }),
  ...slash(kit, "kickGlow", { angle: 62, scale: 4.3, pal: [ICE, PALE, BLUE], life: 9, aspect: 0.36 }),
  ...glow(kit, "glint", { pos: [0.1, 0.4, 1.0], at: 1, life: 8, scale: 1.0, pal: [WHITE, WHITE, ICE], tex: kit.tex(T.star4Big), spin: 0.1, scaleCurve: twinkle(1.3), alpha: twinkle(1) }),
  ...streaks(kit, "iceShards", { at: 1, radius: 0.5, speed: 0.34, count: 6, life: 9, scale: 0.6, pal: [ICE, WHITE, BLUE], tex: kit.tex(T.shard) }),
  ...sparks(kit, "frost", { at: 1, radius: 0.7, speed: 0.2, count: 6, life: 12, scale: 0.26, pal: [WHITE, PALE, ICE], shape: "circle", tex: kit.tex(T.sparkle4) }),
  // Ice knocked off by the kick: chunks and chips thrown out, then dropping
  // to the ground (more of it at Logan's request, 2026-10-03).
  ...sparks(kit, "iceChunks", { at: 1, radius: 0.6, speed: 0.24, count: 6, bursts: 2, gap: 3, life: 14, scale: 0.44, pal: [ICE, WHITE, BLUE], fall: 0.03, tex: kit.tex(T.shard), twinkle: false, spin: 0.3, shape: "circle" }),
  ...sparks(kit, "iceChips", { at: 2, radius: 0.8, speed: 0.18, count: 6, bursts: 2, gap: 3, life: 14, scale: 0.19, pal: [WHITE, PALE, ICE], fall: 0.026, twinkle: false }),
];

const script = `${introStill(SPA)}
${audio(
  snd(1425, 0, { pitch: 800, vol: 105 }),
  snd(1514, SPIN, { ch: "SE2", side: "D", pitch: 500, vol: 120 }),
  snd(1509, SPIN + 1, { side: "D", pitch: 900, vol: 95 }),
)}
${tint("ATTACKER", 0, 7, 2, [20, 28, 31])}
${emits(kit, user, "ATTACKER")}
ScaleSprite ATTACKER, ROUNDTRIP, -1638, 0, 3, 0, 1
Wait ${SPIN - 3}
${lunge("ATTACKER", 3)}
Wait 3
${tint("ATTACKER", 7, 0, 3, [20, 28, 31])}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [24, 30, 31], power: 2, stop: 3 })}
Wait ${AFTER}
${outro({ camera: false })}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 236, 163],
  references: ["reference/Triple_Axel_VIII.png", "reference/Triple_Axel_IX.png", "reference/Triple_Axel_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("glitter")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("kick")}, DEFENDER`],
});
assert.ok(!script.includes("MoveCamera"), "Multi-hit animation moves the camera");
console.log(`  spin f0, kick f${SPIN}, one hit ~${SPIN + 3 + AFTER} frames`);
