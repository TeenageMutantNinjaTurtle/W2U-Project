MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1014
AudioContainer CONTINUE
PlaySound 1418, SE1, 14, 0, 0, 115, 0, 0, 0
PlaySound 1511, SE2, 14, 4, -300, 105, 0, 0, 0
PlaySound 1418, SE2, 14, 11, 200, 110, 0, 0, 0
PlaySound 1407, SE1, 14, 22, -200, 122, 0, 0, 0
PlaySound 1511, SE2, 16, 28, -200, 127, 0, 0, 0
PlaySound 1475, SE1, 16, 28, -300, 127, 0, 0, 0
PlaySound 1413, SE2, 16, 30, 0, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 0, 4, 10, 22
ChangeSpriteColor ATTACKER, 0, 10, 0, 12, 24, 31
Emit 1014, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 6, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 7, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 8, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 9, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 8
Wait 22
ToggleSpriteVisibility ATTACKER, 3
MoveCamera INTERPOLATION, DEFENDER, 6, 0, 8
Wait 6
Emit 1014, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1014, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 24, 30, 31
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 24, 30, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 20
ChangeBackgroundColor 4, 8, 0, 0, 4, 10, 22
Wait 8
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 10, 0, 0, 12, 24, 31
ToggleSpriteVisibility ATTACKER, 4
MoveCamera INTERPOLATION, INIT, 12, 0, 8
Wait 12
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 6
LetCMDsFinish ALL
TerminateMoveScript
