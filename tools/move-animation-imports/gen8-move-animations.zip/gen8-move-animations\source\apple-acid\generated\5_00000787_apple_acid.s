MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 967
AudioContainer CONTINUE
PlaySound 1727, SE1, 14, 10, 300, 120, 0, 0, 0
PlaySound 1407, SE2, 14, 10, -300, 105, 0, 0, 0
PlaySound 1727, SE1, 14, 16, 500, 110, 0, 0, 0
PlaySound 1727, SE1, 16, 20, -100, 127, 0, 0, 0
PlaySound 1511, SE2, 16, 20, -400, 110, 0, 0, 0
PlaySound 1727, SE1, 16, 29, -300, 125, 0, 0, 0
PlaySound 1727, SE2, 16, 39, -600, 100, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 7, 0, 31, 26, 6
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 4, 0, 1
Emit 967, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 967, 0, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 967, 1, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 967, 2, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 10
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 2px, 49152, 0, 4096, 0
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 5
ChangeSpriteColor ATTACKER, 7, 0, 0, 31, 26, 6
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
Emit 967, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 967, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 967, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 967, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 967, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 31, 26, 8
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 31, 26, 8
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 5
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 9, 9, 0, 31, 26, 8
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 4
Wait 2
ChangeSpriteColor DEFENDER, 9, 0, 0, 31, 26, 8
Wait 28
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
