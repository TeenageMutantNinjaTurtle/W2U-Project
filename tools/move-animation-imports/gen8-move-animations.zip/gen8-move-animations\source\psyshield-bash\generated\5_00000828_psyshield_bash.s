MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1008
AudioContainer CONTINUE
PlaySound 1474, SE1, 14, 0, 0, 90, 0, 0, 0
PlaySound 1505, SE2, 14, 4, 300, 105, 0, 0, 0
PlaySound 1688, SE1, 14, 18, 400, 120, 0, 0, 0
PlaySound 1475, SE1, 16, 25, -200, 127, 0, 0, 0
PlaySound 1455, SE2, 16, 25, 0, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 0, 22, 26, 31
Emit 1008, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1008, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1008, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1008, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1008, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1008, 1, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1008, 3, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1008, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 14, 0, 1
Wait 18
ToggleSpriteVisibility ATTACKER, 3
MoveCamera INTERPOLATION, DEFENDER, 7, 0, 8
Wait 7
Emit 1008, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1008, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1008, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1008, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1008, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1008, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 26, 28, 31
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 26, 28, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 26
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 8, 0, 0, 22, 26, 31
ToggleSpriteVisibility ATTACKER, 4
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
