MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish ALL
ChangeSpriteColor ATTACKER, 10, 0, 3, 31, 31, 31
LoadSPA 286
Emit 286, 0, ATTACKER, NONE, 1.5px, 0, 0, 1x, 1x, 3277, 1x
Emit 286, 1, ATTACKER, NONE, 1.5px, 0, 0, 1x, 1x, 3277, 1x
AudioContainer CONTINUE
PlaySound 1417, SE1, 14, 0, 0, 120, 0, 0, 0
PlaySound 1376, SE1, 14, 90, 0, 0, 0, 0, 0
AdjustSound SE1, 0, 0, -1000, 3000, 0, 90, 0, 0
PlaySound 1483, SE2, 14, 0, 0, 127, 0, 0, 0
AdjustSound SE2, 0, 0, -1000, 3000, 0, 90, 0, 0
AudioContainer SUSPEND
AudioContainer CONTINUE
PlaySound 1473, SE2, 14, 95, 0, 120, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 2, 0, 8, 2, 0, 0, 0
MoveSprite ATTACKER, ROUNDTRIP, 3, 1px, 1px, 40960, 4096, 12288, 0
Wait 10
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, START
ScaleSprite DEFENDER, ROUNDTRIP, 410, -410, 2, 0, 1
ChangeSpriteColor ATTACKER, 10, 0, 3, 31, 31, 31
LoadSPA 442
EmitOrtho 442, 0, ATTACKER, NONE, 0, 2px, 0, 0.5x, 1x, 0.5x, 1x
LetCMDsFinish ALL
ChangeBackgroundColor 2, 8, 0, 2, 0, 0, 0
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
