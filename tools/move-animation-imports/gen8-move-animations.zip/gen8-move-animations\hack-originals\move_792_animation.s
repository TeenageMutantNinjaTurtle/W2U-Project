MoveCamera INTERPOLATION, ATTACKER, 16, 0, 8
LetCMDsFinish ALL
LoadSPA 352
Emit 352, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 352, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
AudioContainer CONTINUE
PlaySound 1471, SE1, 14, 0, 0, 115, 0, 0, 0
PlaySound 1358, SE2, 14, 20, 0, 80, 0, 0, 0
AudioContainer SUSPEND
LetCMDsFinish ALL
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
