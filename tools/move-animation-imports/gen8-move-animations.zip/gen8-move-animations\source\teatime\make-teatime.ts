import { createKit, deg, fadeInOut, hold, paint, setCurves, spin, T, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, glow, intro, notes, outro, pan, snd, sparks, squash, WHITE, type Pal } from "../tools/phrases";

// Teatime (move 752) - from the Bulbapedia stills (reference/sheet.png).
//   1. A translucent pink teapot and a pink teacup on its saucer appear in
//      the air by the user, the pot tipping to pour, with colourful music
//      notes drifting round.
//   2. A teacup is set in front of each Pokemon and they tuck in (every
//      Pokemon eats its Berry - the engine's part).
// The teapot and teacup are drawn (generated/texture-teapot.png, -cup.png);
// the notes are Sing's.

const SPA = 950;
const kit = await createKit({ workDir: import.meta.dirname, slug: "teatime", moveId: 752, spaId: SPA, donors: [212, 228, 465, 298, 407] });

const CAMERA_IN = 10;
const SERVE = 34; // pot and cup in the air, pouring
const SIP = 28; // a cup at each Pokemon

const PINK: Rgb = [1.0, 0.62, 0.8];
const NOTE_PAL: Pal = [[1.0, 0.85, 0.2], [0.3, 0.9, 1.0], [1.0, 0.35, 0.75]];
const NOTE_PAL_2: Pal = [[0.45, 1.0, 0.45], [1.0, 0.55, 0.2], [0.75, 0.5, 1.0]];

const body = (light: number): number[] => [255, Math.round(150 + 70 * light), Math.round(190 + 50 * light)];
const RIM = [225, 105, 160];

// --- the drawn teapot: round body, spout to the left, handle to the right, knobbed lid ---
const potTex = await kit.drawn("teapot", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5, py = y + 0.5;
  const inBody = ((px - 16) / 9.5) ** 2 + ((py - 19) / 8) ** 2;
  const inLid = ((px - 16) / 6) ** 2 + ((py - 11) / 2.5) ** 2;
  const knob = Math.hypot(px - 16, py - 7.5);
  const handle = Math.hypot(px - 25.5, py - 18);
  // Spout: a band rising to the left from the body.
  const sx = px - 8, sy = py - 17;
  const along = (-sx * 0.8 + -sy * 0.6), across = Math.abs(-sx * 0.6 + sy * 0.8);
  const inSpout = along > -2 && along < 7 && across < 2.2 - along * 0.12;
  let inside = false, edge = false;
  if (inBody <= 1) { inside = true; edge = inBody > 0.78; }
  else if (inLid <= 1 && py < 12) { inside = true; edge = inLid > 0.6; }
  else if (knob <= 2.2) { inside = true; edge = knob > 1.3; }
  else if (handle <= 5.5 && handle >= 3.3 && px > 24) { inside = true; edge = true; }
  else if (inSpout) { inside = true; edge = across > 1.3 - along * 0.1; }
  if (!inside) return undefined;
  if (edge) return RIM;
  const light = Math.max(0, 1 - Math.hypot(px - 12.5, py - 15.5) / 9);
  return body(light);
});

// --- the drawn teacup on its saucer ---
const cupTex = await kit.drawn("cup", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5, py = y + 0.5;
  // Cup: a tapering body, rows 8-22.
  if (py >= 8 && py <= 22) {
    const half = 8.5 - (py - 8) * 0.22;
    const dx = Math.abs(px - 15);
    if (dx <= half) {
      if (py < 10) return dx < half - 1.2 ? [200, 120, 80] : RIM; // tea at the brim
      if (dx > half - 1.3 || py > 21) return RIM;
      return body(Math.max(0, 1 - Math.hypot(px - 11.5, py - 13) / 8));
    }
  }
  const handle = Math.hypot(px - 24.5, py - 14);
  if (handle <= 4 && handle >= 2.2 && px > 23) return RIM;
  // Saucer: a flat ellipse under the cup.
  const saucer = ((px - 15) / 13) ** 2 + ((py - 25) / 2.6) ** 2;
  if (saucer <= 1) return saucer > 0.7 ? RIM : body(0.55);
  return undefined;
});

const piece = (tex: number, pos: Vec3, scale: number, at: number, life: number, angle = 0): ReturnType<typeof kit.parked> => {
  const r = kit.parked(tex, pos, scale, life);
  r.startDelayFrames = at;
  spin(r, 0, 0, deg(angle));
  setCurves(r, { start: 0.3, mid: 1.05, end: 1, curveIn: 0.2, curveOut: 0.5 }, fadeInOut(0.92, 0.12, 0.85));
  paint(r, WHITE);
  return r;
};

// --- 1. served in the air beside the user ---
const POT: Vec3 = [1.3, 2.3, 0.5];
const CUP: Vec3 = [-0.4, 1.0, 0.6];
kit.add("pot", piece(potTex, POT, 1.2, 0, SERVE, 0));
// The pot tips to pour: a second, tilted copy takes over.
const tipped = piece(potTex, POT, 1.2, 10, SERVE - 10, 28);
setCurves(tipped, hold(1), fadeInOut(0.92, 0.08, 0.85));
kit.add("potTipped", tipped);
kit.resources[kit.idx("pot")]!.particleLifeFrames = 11;
setCurves(kit.resources[kit.idx("pot")]!, { start: 0.3, mid: 1.05, end: 1, curveIn: 0.5, curveOut: 0.9 }, { start: 0, mid: 0.92, end: 0.92, curveIn: 0.3, curveOut: 1 });
kit.add("cupAir", piece(cupTex, CUP, 1.0, 4, SERVE - 4));
const served = [
  "pot", "potTipped", "cupAir",
  // The tea pouring from the spout into the cup.
  ...sparks(kit, "pour", { pos: [0.3, 2.1, 0.55], at: 14, radius: 0.1, speed: 0.02, count: 1, bursts: 8, gap: 2, life: 9, scale: 0.16, pal: [PINK, WHITE, [0.9, 0.5, 0.35]], fall: 0.03, twinkle: false, tex: kit.tex(T.softDisc) }),
  ...glow(kit, "steam", { pos: [-0.4, 1.9, 0.6], at: 18, life: 16, scale: 0.7, pal: [WHITE, WHITE, PINK], level: 0.55 }),
  ...notes(kit, "notesA", { pos: [0.3, 1.6, 0.4], frames: SERVE - 6, every: 6, life: 18, scale: 0.42, radius: 2.2, pal: NOTE_PAL }),
  ...sparks(kit, "twinkles", { pos: [0.3, 1.6, 0.5], at: 4, radius: 2.2, speed: 0, count: 1, bursts: 7, gap: 4, life: 9, scale: 0.3, pal: [WHITE, [1, 0.95, 0.6], PINK], shape: "ball", tex: kit.tex(T.sparkle4) }),
];

// --- 2. a cup at each Pokemon ---
const places: Array<["ATTACKER" | "DEFENDER", string]> = [["ATTACKER", "user"], ["DEFENDER", "foe"]];
const setting: Record<string, string[]> = {};
for (const [, who] of places) {
  const at: Vec3 = [who === "user" ? 1.3 : -1.3, -0.6, 0.9];
  kit.add(`${who}Cup`, piece(cupTex, at, 0.7, 0, SIP));
  setting[who] = [
    `${who}Cup`,
    ...glow(kit, `${who}Glint`, { pos: [at[0], at[1] + 0.5, at[2] + 0.1], at: 2, life: 9, scale: 0.6, pal: [WHITE, WHITE, PINK], tex: kit.tex(T.star4Big), scaleCurve: twinkle(1.3), alpha: twinkle(1) }),
    ...notes(kit, `${who}Notes`, { pos: [0, 1.2, 0.5], at: 4, frames: SIP - 12, every: 7, life: 16, scale: 0.36, radius: 1.5, pal: who === "user" ? NOTE_PAL : NOTE_PAL_2 }),
  ];
}

const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1474, 0, { vol: 85 }),
  snd(1523, 4, { ch: "SE2", pitch: 300, vol: 105 }),
  snd(1445, 14, { pitch: 1500, vol: 75 }),
  snd(1784, SERVE, { ch: "SE2", side: "FLAT", vol: 105 }),
  snd(1779, SERVE + 12, { side: "FLAT", pitch: 300, vol: 110 }),
  snd(1509, SERVE + 16, { ch: "SE2", side: "FLAT", pitch: 500, vol: 85 }),
)}
${emits(kit, served, "ATTACKER")}
Wait ${SERVE - 10}
${pan("INIT", 10)}
Wait 10
${emits(kit, setting.user!, "ATTACKER")}
${emits(kit, setting.foe!, "DEFENDER")}
Wait 12
${squash("ATTACKER", 819, -819, 4)}
${squash("DEFENDER", 819, -819, 4)}
Wait 8
${squash("ATTACKER", 819, -819, 4)}
${squash("DEFENDER", 819, -819, 4)}
Wait ${SIP - 20}
${outro({ camera: false, unfreeze: "NONE" })}`;

await kit.finish({
  script,
  donorMoveIds: [47, 63, 605, 129, 236],
  references: ["reference/Teatime_VIII.png", "reference/Teatime_VIII_2.png", "reference/Teatime_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("pot")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("foeCup")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  served f${CAMERA_IN}-${CAMERA_IN + SERVE}, cups at both f${CAMERA_IN + SERVE}-${CAMERA_IN + SERVE + SIP}`);
