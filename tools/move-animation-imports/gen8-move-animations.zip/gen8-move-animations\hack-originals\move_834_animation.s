MoveCamera INTERPOLATION, ATTACKER, 16, 0, 8
AudioContainer CONTINUE
PlaySound 1418, PSG, 14, 0, 0, 120, 0, 0, 0
PlaySound 1376, PSG, 14, 130, 0, 0, 0, 0, 0
AdjustSound PSG, 0, 0, 0, 3000, 0, 60, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 15, 2, 0, 0, 0
LoadSPA 479
Emit 479, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
LetCMDsFinish ALL
AudioContainer CONTINUE
PlaySound 1450, SE1, 14, 0, 0, 100, 0, 0, 0
PlaySound 1376, SE1, 14, 100, 0, 0, 0, 0, 0
PlaySound 1407, SE2, 14, 0, 0, 120, 0, 0, 0
PlaySound 1376, SE2, 14, 100, 0, 0, 0, 0, 0
AdjustSound SE2, 0, 0, -1000, 3000, 0, 50, 0, 0
AdjustSound SE1, 0, 0, -1000, 3000, 0, 50, 0, 0
AdjustSound SE1, 0, 1, 100, 0, 70, 30, 0, 0
AdjustSound SE2, 0, 1, 120, 0, 70, 30, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 16, 0, 40, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 16, 0, 40, 0, 0
AudioContainer SUSPEND
EmitProjectile 479, 0, STRAIGHT, ATTACKER, DEFENDER, 1px, 0, 0, 1x, 1x, 0
EmitProjectile 479, 1, STRAIGHT, ATTACKER, DEFENDER, 1px, 0, 0, 1x, 1x, 0
EmitProjectile 479, 2, STRAIGHT, ATTACKER, DEFENDER, 1px, 0, 0, 1x, 1x, 0
LoadBackground 159
ApplyBackground 2, 0
ChangeBackgroundColor 4, 15, 0, 0, 0, 0, 0
MoveBackground INTERPOLATION_DIRECT, -32, 0, 100, 0, 0
ApplyBackground OFF, 1
ApplyBackground ON, 1
Wait 20
MoveCamera INTERPOLATION, INIT, 16, 0, 8
ToggleSpriteShadow ATTACKER, ON
ToggleSpriteShadow DEFENDER, ON
ToggleFreezeSprite DEFENDER, START
ShakeSprite DEFENDER, 2, -0.5px, 0, 2, 1, 8
LetCMDsFinish ALL
ChangeBackgroundColor 4, 0, 15, 1, 0, 0, 0
LetCMDsFinish ALL
ToggleSpriteShadow ATTACKER, OFF
ToggleSpriteShadow DEFENDER, OFF
ApplyBackground OFF, 0
ApplyBackground ON, 0
ChangeBackgroundColor 4, 12, 0, 1, 0, 0, 0
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
ApplyBackground 2, 1
TerminateMoveScript
