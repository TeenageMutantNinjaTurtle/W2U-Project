MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1016
AudioContainer CONTINUE
PlaySound 1509, SE1, 14, 0, 500, 100, 0, 0, 0
PlaySound 1509, SE2, 14, 6, 300, 100, 0, 0, 0
PlaySound 1509, SE1, 14, 12, 100, 100, 0, 0, 0
PlaySound 1425, SE2, 14, 4, 600, 90, 0, 0, 0
PlaySound 1539, SE2, 14, 26, -500, 118, 0, 0, 0
PlaySound 1539, SE2, 14, 31, -500, 118, 0, 0, 0
PlaySound 1539, SE2, 14, 36, -500, 118, 0, 0, 0
PlaySound 1417, SE1, 16, 33, 200, 125, 0, 0, 0
PlaySound 1417, SE1, 16, 38, 200, 125, 0, 0, 0
PlaySound 1475, SE1, 16, 43, -200, 125, 0, 0, 0
PlaySound 1884, SE2, 16, 44, 300, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 0, 10, 16, 26
ChangeSpriteColor ATTACKER, 0, 8, 0, 20, 27, 31
Emit 1016, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 11, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 2, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 8, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 26
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 8, 0, 0, 20, 27, 31
MoveCamera INTERPOLATION, DEFENDER, 7, 0, 8
Wait 7
Emit 1016, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 20, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 21, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 22, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 23, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1016, 24, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 10, 10, 0, 24, 29, 31
Wait 2
ChangeSpriteColor DEFENDER, 10, 0, 0, 24, 29, 31
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 2, 0, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 6
Wait 3
ChangeSpriteColor DEFENDER, 10, 10, 0, 24, 29, 31
Wait 2
ChangeSpriteColor DEFENDER, 10, 0, 0, 24, 29, 31
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 2, 0, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 6
Wait 3
ChangeSpriteColor DEFENDER, 15, 15, 0, 28, 31, 31
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 28, 31, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 6
ChangeBackgroundColor 4, 8, 0, 0, 10, 16, 26
Wait 20
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
