MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1004
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, 600, 95, 0, 0, 0
PlaySound 1509, SE2, 14, 22, 600, 90, 0, 0, 0
PlaySound 1509, SE2, 14, 28, 720, 90, 0, 0, 0
PlaySound 1509, SE2, 14, 35, 840, 90, 0, 0, 0
PlaySound 1509, SE2, 14, 41, 960, 90, 0, 0, 0
PlaySound 1509, SE2, 14, 44, 900, 100, 0, 0, 0
PlaySound 1376, SE1, 14, 59, 0, 0, 0, 0, 0
PlaySound 1539, SE2, 14, 59, -300, 125, 0, 0, 0
PlaySound 1514, SE1, 16, 63, 500, 120, 0, 0, 0
PlaySound 1435, SE1, 16, 79, 600, 122, 0, 0, 0
PlaySound 1475, SE1, 16, 89, 300, 127, 0, 0, 0
PlaySound 1423, SE2, 16, 89, 600, 120, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 11, 0, 2, 4, 16
ChangeSpriteColor ATTACKER, 0, 8, 0, 20, 28, 31
Emit 1004, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 9, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 10, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 11, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 54
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 5, 0, 1
Wait 5
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 8, 0, 0, 20, 28, 31
MoveCamera INTERPOLATION, DEFENDER, 4, 0, 8
Wait 4
Emit 1004, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 10, 10, 0, 22, 29, 31
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 3
Wait 2
ChangeSpriteColor DEFENDER, 10, 0, 0, 22, 29, 31
ChangeBackgroundColor 4, 11, 15, 1, 0, 1, 6
Wait 14
Emit 1004, 22, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 23, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 24, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 25, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 20, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 21, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 26, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 27, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 28, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1004, 29, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor DEFENDER, 0, 12, 0, 22, 29, 31
ShakeSprite DEFENDER, 2, 410, 0, 2, 1, 5
Wait 10
ChangeSpriteColor DEFENDER, 0, 0, 0, 22, 29, 31
ChangeBackgroundColor 4, 14, 14, 0, 28, 31, 31
ChangeSpriteColor DEFENDER, 15, 15, 0, 28, 31, 31
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 28, 31, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 14, 11, 0, 2, 4, 16
Wait 10
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 2
ChangeBackgroundColor 4, 11, 0, 0, 2, 4, 16
Wait 10
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
