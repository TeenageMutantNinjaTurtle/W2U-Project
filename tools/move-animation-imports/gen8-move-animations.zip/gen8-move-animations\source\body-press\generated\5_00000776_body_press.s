MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 956
AudioContainer CONTINUE
PlaySound 1463, SE1, 14, 0, 0, 105, 0, 0, 0
PlaySound 1407, SE2, 14, 10, 300, 115, 0, 0, 0
PlaySound 1560, SE2, 16, 23, 0, 120, 0, 0, 0
PlaySound 1705, SE1, 16, 28, -400, 127, 0, 0, 0
PlaySound 1413, SE2, 16, 28, -300, 127, 0, 0, 0
PlaySound 1884, SE1, 16, 32, 0, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 956, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 956, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, 1229, -1638, 5, 0, 1
Wait 10
ScaleSprite ATTACKER, ROUNDTRIP, -819, 1638, 2, 0, 1
Wait 3
ToggleSpriteVisibility ATTACKER, 3
Wait 5
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 5
Emit 956, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 956, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 956, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 956, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 956, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 956, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 956, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 956, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 956, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 956, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 5
ChangeBackgroundColor 4, 12, 12, 0, 31, 30, 20
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 30, 18
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 30, 18
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 12, 0, 0, 31, 30, 20
Wait 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 8
Wait 26
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ToggleSpriteVisibility ATTACKER, 4
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
