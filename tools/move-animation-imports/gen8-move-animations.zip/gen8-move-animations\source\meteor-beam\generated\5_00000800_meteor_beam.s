.include "B2W2_MOVSCRCMD.s"
.align 4

.word 2 @ Count
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE

SCRIPT_CHARGE:
MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 980
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, 0, 110, 0, 0, 0
PlaySound 1474, SE2, 14, 4, 0, 85, 0, 0, 0
PlaySound 1509, SE2, 14, 16, 500, 85, 0, 0, 0
PlaySound 1452, SE2, 14, 36, 300, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 12, 0, 9, 4, 20
ChangeSpriteColor ATTACKER, 0, 8, 0, 31, 26, 14
Emit 980, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 16
Wait 34
ChangeSpriteColor ATTACKER, 8, 0, 0, 31, 26, 14
ChangeBackgroundColor 4, 12, 0, 0, 9, 4, 20
Wait 12
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript

SCRIPT_FIRE:
MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 980
AudioContainer CONTINUE
PlaySound 1487, SE1, 14, 0, 0, 105, 0, 0, 0
PlaySound 1975, SE1, 14, 10, 0, 127, 0, 0, 0
PlaySound 1424, SE2, 14, 10, -300, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 8, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 18, -300, 127, 0, 0, 0
PlaySound 1884, SE2, 16, 20, 0, 110, 0, 0, 0
PlaySound 1420, SE1, 16, 30, 0, 125, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 12, 0, 9, 4, 20
ChangeSpriteColor ATTACKER, 0, 10, 0, 31, 28, 14
Emit 980, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 12, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 10, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 11, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 5
Wait 10
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -2px, 49152, 0, 4096, 0
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 12
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 980, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 20, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 980, 21, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeBackgroundColor 4, 14, 14, 0, 31, 28, 18
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 29, 16
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 29, 16
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 14, 12, 1, 9, 4, 20
Wait 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 8
ChangeSpriteColor ATTACKER, 10, 0, 0, 31, 28, 14
ChangeBackgroundColor 4, 12, 0, 0, 9, 4, 20
Wait 26
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
