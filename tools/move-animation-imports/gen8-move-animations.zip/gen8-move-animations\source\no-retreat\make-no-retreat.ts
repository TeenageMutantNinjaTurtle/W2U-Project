import { createKit, paint, setCurves, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, flames, glow, intro, outro, risers, shake, snd, sparks, squash, streaks, tint, WHITE, type Pal } from "../tools/phrases";

// No Retreat (move 748) - from the Bulbapedia stills (reference/sheet.png).
// Night falls; a flaming brazier on crossed legs stands either side of the
// user; a wall of white spray bursts up behind it and it blazes orange.
// Stays on the user; the stat rises and the trapping are the engine's.
// The brazier is drawn (generated/texture-brazier.png); the flames are Fire
// Blast's.

const SPA = 946;
const kit = await createKit({ workDir: import.meta.dirname, slug: "no-retreat", moveId: 748, spaId: SPA, donors: [295, 228, 465, 411, 298] });

const CAMERA_IN = 10;
const LIGHT = 12; // braziers stand, then catch
const BLAZE = 44;

const ORANGE: Rgb = [1.0, 0.6, 0.15];
const YELLOW: Rgb = [1.0, 0.88, 0.35];
const RED: Rgb = [1.0, 0.3, 0.15];
const SPRAY: Rgb = [0.9, 0.95, 1.0];
const FIRE: Pal = [ORANGE, YELLOW, RED];
const TOTAL = LIGHT + BLAZE;

// --- the drawn brazier: a dark bowl on crossed legs ---
const brazierTex = await kit.drawn("brazier", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5, py = y + 0.5;
  const iron = [46, 36, 44], rim = [120, 84, 52], glowing = [200, 96, 36];
  // Bowl: the lower half of an ellipse, rows 4-12.
  if (py >= 4 && py <= 12) {
    const half = 12 * Math.sqrt(Math.max(0, 1 - ((py - 4) / 9) ** 2));
    if (Math.abs(px - 16) <= half) return py < 6 ? (Math.abs(px - 16) < half - 2 ? glowing : rim) : iron;
  }
  // Two legs crossing between the bowl and the ground.
  if (py > 11 && py <= 31) {
    const t = (py - 11) / 20;
    for (const dir of [1, -1]) {
      const cx = 16 + dir * (-7 + 16 * t);
      if (Math.abs(px - cx) <= 1.4) return Math.abs(px - cx) < 0.7 ? rim : iron;
    }
  }
  return undefined;
});

const SIDES: Array<[string, number]> = [["left", -2.7], ["right", 2.7]];
const user: string[] = [];
for (const [name, x] of SIDES) {
  const stand: Vec3 = [x, -0.5, 0.4];
  const r = kit.parked(brazierTex, stand, 1.2, TOTAL);
  setCurves(r, { start: 0.6, mid: 1, end: 1, curveIn: 0.12, curveOut: 1 }, { start: 0, mid: 1, end: 0, curveIn: 0.1, curveOut: 0.88 });
  paint(r, WHITE);
  kit.add(`${name}Brazier`, r);
  user.push(`${name}Brazier`);
  user.push(...flames(kit, `${name}Fire`, { pos: [x, 0.85, 0.45], at: LIGHT - 4, frames: BLAZE - 6, every: 3, life: 10, scale: 0.9, rise: 0.03, radius: 0.2 }));
  user.push(...glow(kit, `${name}Light`, { pos: [x, 0.9, 0.3], at: LIGHT - 4, life: BLAZE, scale: 1.7, pal: [ORANGE, YELLOW, RED], level: 0.55 }));
}
user.push(
  // The wall of white spray bursting up behind the user.
  ...streaks(kit, "spray", { pos: [0, -1.2, -0.8], at: LIGHT, radius: 1.6, speed: 0.1, count: 3, bursts: 8, gap: 3, life: 12, scale: 0.7, pal: [SPRAY, WHITE, SPRAY], flat: true, lift: 0.42 }),
  ...sparks(kit, "foam", { pos: [0, 0.6, -0.8], at: LIGHT + 2, radius: 2.0, speed: 0.12, count: 3, bursts: 8, gap: 3, life: 14, scale: 0.12, pal: [WHITE, SPRAY, WHITE], fall: 0.01, shape: "ball" }),
  // The user blazes.
  ...glow(kit, "aura", { pos: [0, 0.3, 0.2], at: LIGHT, life: BLAZE, scale: 2.8, pal: [ORANGE, RED, YELLOW], level: 0.65 }),
  ...flames(kit, "bodyFire", { pos: [0, 0.2, -0.3], at: LIGHT, frames: BLAZE - 10, every: 3, life: 10, scale: 1.1, rise: 0.05, radius: 1.0 }),
  ...risers(kit, "embers", { at: LIGHT, frames: BLAZE - 12, radius: 1.5, speed: 0.2, scale: 0.13, life: 14, every: 3, pal: FIRE }),
);

const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1426, LIGHT - 4, { vol: 115 }),
  snd(1426, LIGHT - 2, { ch: "SE2", pitch: -200, vol: 100 }),
  snd(1445, LIGHT, { ch: "SE2", pitch: 400, vol: 110 }),
  snd(1452, LIGHT + 4, { vol: 115 }),
  snd(1452, LIGHT + 20, { ch: "SE2", pitch: 100, vol: 115 }),
)}
${arena(0, 11, 8, [3, 3, 9])}
${emits(kit, user, "ATTACKER")}
Wait ${LIGHT}
${tint("ATTACKER", 0, 10, 4, [31, 18, 6])}
${squash("ATTACKER", -819, 1229, 5)}
${shake("ATTACKER", 819, 8)}
Wait 16
${squash("ATTACKER", -819, 1229, 5)}
${shake("ATTACKER", 819, 8)}
Wait ${BLAZE - 16 - 10}
${tint("ATTACKER", 10, 0, 6, [31, 18, 6])}
${arena(11, 0, 10, [3, 3, 9])}
Wait 10
${outro({ unfreeze: "NONE" })}`;

await kit.finish({
  script,
  donorMoveIds: [126, 63, 605, 240, 129],
  references: ["reference/No_Retreat_VIII.png", "reference/No_Retreat_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("leftBrazier")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("spray")}, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  braziers f${CAMERA_IN}, alight f${CAMERA_IN + LIGHT - 4}, blaze f${CAMERA_IN + LIGHT}-${CAMERA_IN + TOTAL}`);
