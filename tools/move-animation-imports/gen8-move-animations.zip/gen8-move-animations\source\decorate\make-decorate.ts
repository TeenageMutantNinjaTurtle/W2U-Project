import { createKit, fadeInOut, grow, hold, paint, setCurves, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, FOE, glow, intro, outro, pan, ring, risers, snd, sparks, squash, tint, USER, WHITE, type Pal } from "../tools/phrases";

// Decorate (move 777) - from the Bulbapedia stills (reference/sheet.png).
//   1. A translucent pink dome forms round the user, strawberries and dollops
//      of whipped cream popping up inside it among sparkles.
//   2. The same dome forms round the target: strawberries and cream float
//      round it, pink light streams up and a pink ring turns at its waist.
// The strawberry and the cream are drawn (generated/texture-strawberry.png,
// -cream.png), and stand upright: they used to lie on their sides, which
// Logan had turned a quarter clockwise on 2026-10-03 (the spray shell was
// stored turned; the kit now starts sprays upright). The Attack and Sp. Atk
// boosts are the engine's.

const SPA = 957;
const kit = await createKit({ workDir: import.meta.dirname, slug: "decorate", moveId: 777, spaId: SPA, donors: [228, 465, 411, 298, 560, 407] });

const CAMERA_IN = 10;
const WHIP = 28; // on the user
const PAN = 10;
const DECORATE = 44; // on the target

const PINK: Rgb = [1.0, 0.6, 0.85];
const PALE_PINK: Rgb = [1.0, 0.88, 0.95];
const HOT_PINK: Rgb = [1.0, 0.35, 0.7];
const PINKS: Pal = [PINK, PALE_PINK, HOT_PINK];

// --- the drawn strawberry: red, seeded, with a green cap ---
const berryTex = await kit.drawn("strawberry", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5, py = y + 0.5;
  // A heart-ish drop: wide shoulders at the top, a point at the bottom.
  const t = (py - 8) / 21; // 0 at the shoulders, 1 at the tip
  if (t >= 0 && t <= 1) {
    const half = 10.5 * Math.sqrt(Math.max(0, 1 - t ** 1.7)) * (0.72 + 0.28 * Math.min(1, t * 6 + 0.35));
    const dx = Math.abs(px - 16);
    if (dx <= half) {
      if (dx > half - 1.4 || t > 0.94) return [150, 10, 30];
      const seed = (Math.floor(px / 4) + Math.floor(py / 4)) % 2 === 0 && Math.hypot((px % 4) - 2, (py % 4) - 2) < 0.9;
      if (seed) return [40, 10, 20];
      const light = Math.max(0, 1 - Math.hypot(px - 12, py - 13) / 9);
      return [235 + 20 * light, 40 + 70 * light, 70 + 60 * light].map((c) => Math.round(c));
    }
  }
  // The cap: three green leaves over the shoulders.
  if (py >= 4 && py < 10 && Math.abs(px - 16) < 9 - Math.abs(py - 6) * 0.6 && (Math.abs(((px - 7) % 6) - 3) > 0.8 || py > 6)) return py < 5.2 ? [30, 110, 50] : [70, 185, 85];
  return undefined;
});

// --- the drawn dollop of whipped cream: a pale swirl coming to a peak ---
const creamTex = await kit.drawn("cream", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5, py = y + 0.5;
  // Three stacked, narrowing tiers and a curled tip.
  const tiers: Array<[number, number, number]> = [[24, 12, 5.5], [17, 9, 5], [11, 5.5, 4.5]]; // centre y, half-width, half-height
  for (let i = tiers.length - 1; i >= 0; i--) {
    const [cy, hw, hh] = tiers[i]!;
    const d = ((px - 16 - (i === 2 ? 1.5 : 0)) / hw) ** 2 + ((py - cy) / hh) ** 2;
    if (d <= 1) {
      if (d > 0.72) return [232, 150, 195];
      const light = Math.max(0, 1 - Math.hypot(px - 12, py - cy + 1.5) / 7);
      return [255, Math.round(222 + 30 * light), Math.round(236 + 18 * light)];
    }
  }
  if (Math.hypot(px - 19, py - 5) < 2.2) return [255, 235, 244];
  return undefined;
});

function sweets(p: string, pos: Vec3, at: number, frames: number, radius: number): string[] {
  const names: string[] = [];
  for (const [n, tex, scale, gap] of [["Berries", berryTex, 0.42, 5], ["Creams", creamTex, 0.46, 6]] as const) {
    const r = kit.spray([333, 1], tex, pos, { radius, speed: 0.015, count: 1, bursts: Math.round(frames / gap), gap, life: 20, scale, shape: "sphere" });
    r.startDelayFrames = at + (n === "Creams" ? 2 : 0);
    r.variance.lifeTime = 0;
    r.axis = [0, 1, 0];
    r.initVelAxisAmplifier = 0.03;
    setCurves(r, { start: 0.2, mid: 1.1, end: 1, curveIn: 0.2, curveOut: 0.5 }, fadeInOut(1, 0.1, 0.8));
    paint(r, WHITE);
    kit.add(p + n, r);
    names.push(p + n);
  }
  return names;
}
function dome(p: string, pos: Vec3, life: number, scale: number): string[] {
  const names = [
    ...glow(kit, `${p}Dome`, { pos, life, scale, pal: [PINK, PALE_PINK, HOT_PINK], tex: kit.tex(T.softDisc), level: 0.42, scaleCurve: grow(0.4, 0.2, 1.02) }),
    ...ring(kit, `${p}Rim`, { pos, life, scale: scale * 0.98, pal: [PALE_PINK, WHITE, PINK], tex: kit.tex(T.ring), to: 1.02, level: 0.7 }),
  ];
  setCurves(kit.resources[kit.idx(`${p}Rim`)]!, grow(0.4, 0.2, 1.02), fadeInOut(0.7, 0.15, 0.85));
  return names;
}
const twinkles = (name: string, pos: Vec3, at: number, bursts: number) => sparks(kit, name, { pos, at, radius: 1.8, speed: 0, count: 1, bursts, gap: 4, life: 9, scale: 0.38, pal: [WHITE, [0.7, 1.0, 0.9], [1.0, 0.95, 0.6]], shape: "ball", tex: kit.tex(T.sparkle4) });

// --- 1. on the user ---
const user = [
  ...dome("user", USER, WHIP + 2, 2.5),
  ...sweets("user", [0, 0.4, 0.5], 4, WHIP - 12, 1.9),
  ...twinkles("userTwinkles", [0, 0.4, 0.6], 2, 6),
];

// --- 2. on the target ---
const foe = [
  ...dome("foe", FOE, DECORATE, 2.7),
  ...sweets("foe", [0, 0.4, 1.0], 3, DECORATE - 18, 2.1),
  ...twinkles("foeTwinkles", [0, 0.5, 1.1], 2, 9),
  ...risers(kit, "streams", { pos: [0, -1.4, 0.8], at: 8, frames: DECORATE - 20, radius: 1.5, speed: 0.3, scale: 0.9, life: 10, every: 2, pal: [PALE_PINK, WHITE, PINK], streak: true }),
  ...ring(kit, "waist", { pos: [0, -0.2, 0.9], at: 10, life: DECORATE - 14, scale: 1.2, pal: [HOT_PINK, PALE_PINK, PINK], tex: kit.tex(T.hoop), aspect: 2.4, to: 1.3, level: 0.85 }),
  ...ring(kit, "waist2", { pos: [0, -0.2, 0.9], at: 22, life: 14, scale: 1.2, pal: [PINK, WHITE, HOT_PINK], tex: kit.tex(T.hoop), aspect: 2.4, to: 1.7, level: 0.8 }),
];
setCurves(kit.resources[kit.idx("waist")]!, hold(1.1), fadeInOut(0.85, 0.15, 0.8));

const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1474, 0, { vol: 85 }),
  snd(1784, 4, { ch: "SE2", vol: 105 }),
  snd(1509, 12, { pitch: 500, vol: 85 }),
  snd(1784, WHIP + PAN, { ch: "SE2", side: "D", pitch: 200, vol: 110 }),
  snd(1427, WHIP + PAN + 10, { side: "D", pitch: 300, vol: 105 }),
  snd(1452, WHIP + PAN + 22, { ch: "SE2", side: "D", pitch: 300, vol: 110 }),
)}
${emits(kit, user, "ATTACKER")}
${squash("ATTACKER", 819, -819, 5)}
Wait ${WHIP}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
Wait 10
${tint("DEFENDER", 0, 9, 5, [31, 18, 26])}
Wait 12
${squash("DEFENDER", -1229, 1229, 5)}
Wait ${DECORATE - 22 - 8}
${tint("DEFENDER", 9, 0, 6, [31, 18, 26])}
Wait 8
${outro({ unfreeze: "NONE" })}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 240, 129, 381, 236],
  references: ["reference/Decorate_VIII.png", "reference/Decorate_VIII_2.png", "reference/Decorate_IX.png", "reference/Decorate_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("userDome")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("foeBerries")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  user f${CAMERA_IN}-${CAMERA_IN + WHIP}, target f${CAMERA_IN + WHIP + PAN}-${CAMERA_IN + WHIP + PAN + DECORATE}`);
