import { createKit, fadeInOut, fadeOut, grow, setCurves, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, emits, FOE, gather, glow, hit, impact, intro, outro, pan, puffs, quake, ring, risers, shake, snd, sparks, tint, USER, USER_FLOOR, WHITE, zaps, type Pal } from "../tools/phrases";

// Misty Explosion (move 802) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user draws itself in round a small pink-red core, cyan sparks
//      jumping off it.
//   2. It goes up: a vast dome of pink mist swells out over the field,
//      ringed in cyan, light streaming up through it, pink and white mist
//      rolling out along the ground.
// The user faints afterwards (the engine's part).
// The sparks are Thunder's arcs in cyan.

const SPA = 982;
const kit = await createKit({ workDir: import.meta.dirname, slug: "misty-explosion", moveId: 802, spaId: SPA, donors: [257, 228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 12;
const DRAW_IN = 26;
const HOLD = 4;
const PULL_BACK = 6; // camera back to the wide shot as it goes up
const DOME = 40;
const AFTER = 14;

const PINK: Rgb = [1.0, 0.6, 0.88];
const PALE: Rgb = [1.0, 0.9, 0.97];
const HOT: Rgb = [1.0, 0.3, 0.6];
const CYAN: Rgb = [0.4, 0.95, 1.0];
const MIST: Pal = [PINK, WHITE, PALE];

const user = [
  ...gather(kit, "draw", { pos: USER, frames: DRAW_IN, pal: [PINK, PALE, HOT], radius: 2.8, scale: 1.2 }),
  ...glow(kit, "core", { pos: USER, at: 4, life: DRAW_IN + HOLD, scale: 0.9, pal: [HOT, PALE, [0.9, 0.15, 0.4]], tex: kit.tex(T.softDisc), level: 1, scaleCurve: grow(0.3, 0.7, 1.2) }),
  ...zaps(kit, "cyanSparks", { pos: USER, radius: 1.2, count: 1, bursts: DRAW_IN / 3, gap: 3, life: 6, scale: 0.55, pal: [CYAN, WHITE, CYAN] }),
];

const BOOM = 0; // emitted as it goes up
const blast = [
  ...glow(kit, "whiteout", { pos: USER, at: BOOM, life: 12, scale: 5.0, pal: [PALE, WHITE, PINK], level: 1, scaleCurve: grow(0.3, 0.3, 1.3), alpha: fadeOut(1, 0.4) }),
  ...ring(kit, "cyanRingLow", { pos: [0, -0.6, 0.3], at: BOOM + 3, life: DOME - 6, scale: 2.2, pal: [CYAN, WHITE, CYAN], tex: kit.tex(T.ring), aspect: 2.6, to: 1.9, level: 0.9 }),
  ...ring(kit, "cyanRingHigh", { pos: [0, 1.6, 0.3], at: BOOM + 6, life: DOME - 10, scale: 1.7, pal: [CYAN, WHITE, CYAN], tex: kit.tex(T.ring), aspect: 2.6, to: 1.9, level: 0.8 }),
  ...risers(kit, "pillars", { pos: USER_FLOOR, at: BOOM + 2, frames: DOME - 16, radius: 3.4, speed: 0.4, scale: 1.3, life: 9, every: 2, count: 2, pal: [WHITE, PALE, CYAN], streak: true }),
  ...puffs(kit, "mist", { pos: [0, -1.0, 0.4], at: BOOM + 2, radius: 3.6, count: 3, bursts: 6, gap: 4, life: 18, scale: 1.4, pal: MIST, speed: 0.16, level: 0.85, to: 1.7 }),
  ...puffs(kit, "mistCyan", { pos: [0, -1.0, 0.4], at: BOOM + 4, radius: 3.6, count: 1, bursts: 6, gap: 4, life: 18, scale: 1.2, pal: [[0.75, 0.97, 1.0], WHITE, CYAN], speed: 0.16, level: 0.7, to: 1.7 }),
  ...glow(kit, "dome", { pos: [0, 0.4, 0.2], at: BOOM, life: DOME, scale: 5.6, pal: [PINK, PALE, HOT], tex: kit.tex(T.softDisc), level: 0.8, scaleCurve: grow(0.15, 0.25, 1.15), alpha: fadeInOut(0.8, 0.08, 0.7) }),
];
const foe = [
  ...impact(kit, "caught", { at: 4, pal: [PINK, PALE, HOT], size: 1.6, rays: 9, flecks: 0 }),
  ...sparks(kit, "foeMist", { at: 6, radius: 1.6, speed: 0.1, count: 3, bursts: 4, gap: 4, life: 14, scale: 0.16, pal: [PALE, WHITE, CYAN], fall: -0.006 }),
];

const boomAt = DRAW_IN + HOLD;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1497, 0, { pitch: 400, vol: 105 }),
  snd(1458, 6, { ch: "SE2", pitch: 500, vol: 95 }),
  snd(1376, boomAt, { vol: 0 }),
  snd(1475, boomAt + PULL_BACK, { side: "FLAT", pitch: -500, vol: 127 }),
  snd(1413, boomAt + PULL_BACK, { ch: "SE2", side: "FLAT", pitch: -300, vol: 127 }),
  snd(1475, boomAt + PULL_BACK + 10, { side: "FLAT", pitch: -700, vol: 120 }),
  snd(1463, boomAt + PULL_BACK + 4, { ch: "SE2", side: "FLAT", pitch: -300, vol: 110 }),
)}
${tint("ATTACKER", 0, 12, 10, [31, 22, 28])}
${emits(kit, user, "ATTACKER")}
ScaleSprite ATTACKER, ROUNDTRIP, -1229, -1229, ${DRAW_IN + HOLD}, 0, 1
${shake("ATTACKER", 819, DRAW_IN / 2)}
Wait ${DRAW_IN}
${tint("ATTACKER", 12, 16, HOLD, [31, 31, 31])}
Wait ${HOLD}
${pan("INIT", PULL_BACK)}
Wait ${PULL_BACK}
${emits(kit, blast, "ATTACKER")}
${emits(kit, foe, "DEFENDER")}
${arena(0, 14, 0, [31, 24, 29])}
${quake("2458", 8)}
Wait 4
${hit({ rgb: [31, 24, 29], power: 3 })}
${arena(14, 8, 6, [31, 20, 27])}
Wait 12
${quake("1x", 8)}
Wait ${DOME - 4 - 6 - 12 - 10}
${arena(8, 0, 10, [31, 20, 27])}
${tint("ATTACKER", 16, 0, 8, [31, 31, 31])}
Wait ${10 + AFTER}
${outro({ camera: false })}`;

await kit.finish({
  script,
  donorMoveIds: [87, 63, 605, 400, 240, 153, 129],
  references: ["reference/Misty_Explosion_VIII.png", "reference/Misty_Explosion_VIII_2.png", "reference/Misty_Explosion_IX.png", "reference/Misty_Explosion_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("core")}, ATTACKER`, "MoveCamera INTERPOLATION, INIT", `Emit ${SPA}, ${kit.idx("dome")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("caughtFlash")}, DEFENDER`],
});
console.log(`  draws in f${CAMERA_IN}, goes up f${CAMERA_IN + boomAt + PULL_BACK}, dome until f${CAMERA_IN + boomAt + PULL_BACK + DOME}`);
