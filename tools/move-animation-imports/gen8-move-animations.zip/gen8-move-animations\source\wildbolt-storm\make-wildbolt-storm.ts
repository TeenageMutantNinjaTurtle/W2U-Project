import { type Rgb } from "../tools/anim-kit";
import { snd, sparks, WHITE, zaps } from "../tools/phrases";
import { buildStorm } from "../tools/storm";

// Wildbolt Storm (move 847) - from the Bulbapedia stills (reference/sheet.png).
// The user whips up a dark, charged wind; over the foe it spins into a tall
// storm-grey tornado laced with yellow, lightning cracking through it and
// sparks thrown off.
// Built by ../tools/storm.ts (shared with the other three storms). The
// lightning is Thunder's arcs (SPA 257).

const STORM_GREY: Rgb = [0.62, 0.6, 0.76];
const PALE: Rgb = [0.88, 0.86, 0.96];
const SLATE: Rgb = [0.34, 0.32, 0.5];
const YELLOW: Rgb = [1.0, 0.92, 0.3];
const PALE_YELLOW: Rgb = [1.0, 0.98, 0.7];

await buildStorm({
  workDir: import.meta.dirname,
  slug: "wildbolt-storm",
  moveId: 847,
  spaId: 1027,
  pal: [STORM_GREY, PALE, SLATE],
  accent: YELLOW,
  userTint: [31, 29, 12],
  arenaTint: [5, 5, 11],
  donors: [257],
  donorMoveIds: [87],
  references: ["reference/Wildbolt_Storm_LA.png", "reference/Wildbolt_Storm_IX.png"],
  describe: "wildbolt storm",
  sounds: (stormAt) => [
    snd(1522, 6, { ch: "SE2", pitch: 300, vol: 100 }),
    snd(1458, stormAt + 4, { ch: "SE2", side: "D", vol: 120 }),
    snd(1522, stormAt + 14, { ch: "SE2", side: "D", pitch: -200, vol: 120 }),
    snd(1458, stormAt + 24, { ch: "SE2", side: "D", pitch: 200, vol: 120 }),
  ],
  carries: (kit, { GATHER, STORM }) => ({
    user: [
      ...zaps(kit, "userBolts", { pos: [0, 0.6, 0.4], radius: 1.6, count: 1, bursts: GATHER / 6, gap: 6, life: 6, scale: 0.7, pal: [YELLOW, PALE_YELLOW, YELLOW] }),
    ],
    foe: [
      // Lightning cracking through the tornado, and the sparks it throws.
      ...zaps(kit, "bolts", { pos: [0, 0.7, 1.0], at: 3, radius: 1.7, count: 1, bursts: STORM / 4 - 1, gap: 4, life: 6, scale: 1.0, pal: [YELLOW, PALE_YELLOW, YELLOW] }),
      ...sparks(kit, "yellowSparks", { pos: [0, 0.4, 1.0], at: 3, radius: 1.2, speed: 0.22, count: 2, bursts: STORM / 4 - 2, gap: 4, life: 10, scale: 0.13, pal: [YELLOW, WHITE, PALE_YELLOW], fall: 0.01, twinkle: false }),
    ],
  }),
});
