MoveCamera INTERPOLATION, DEFENDER, 12, 0, 8
LetCMDsFinish ALL
AudioContainer CONTINUE
PlaySound 1411, SE1, 16, 20, 0, 120, 0, 0, 0
PlaySound 1376, SE1, 16, 75, 0, 0, 0, 0, 0
PlaySound 1420, SE1, 16, 60, 0, 120, 0, 0, 0
PlaySound 1424, SE2, 16, 60, 0, 100, 0, 0, 0
PlaySound 1454, SE2, 16, 65, -400, 120, 0, 0, 0
AudioContainer SUSPEND
LoadSPA 822
Emit 822, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 822, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 822, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 10
ShakeSprite DEFENDER, 2, 1px, 0, 3, 1, 3
Wait 40
LoadSPA 205
Emit 205, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 205, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ScaleSprite DEFENDER, ROUNDTRIP, -819, 819, 2, 0, 2
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
