import { createKit, deg, fadeInOut, grow, hold, paint, setCurves, spin, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, FOE, glow, hit, impact, intro, lunge, outro, pan, quake, shake, snd, sparks, squash, tint, WHITE, type Pal } from "../tools/phrases";

// Jaw Lock (move 746) - from the Bulbapedia stills (reference/sheet.png).
//   1. Sword/Shield: a pair of glowing golden jaws with a silver zigzag of
//      teeth clamps shut on the foe and stays locked, sparks flying.
//   2. Scarlet/Violet: the bite bursts in jagged yellow, orange and red.
// The jaws are drawn (generated/texture-jaw.png); the lower jaw is the same
// texture turned upside down.

const SPA = 944;
const kit = await createKit({ workDir: import.meta.dirname, slug: "jaw-lock", moveId: 746, spaId: SPA, donors: [228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const WINDUP = 8;
const PAN = 8;
const OPEN = 10; // jaws hang open over the foe
const SNAP = 3;
const LOCK = 24; // clamped shut
const AFTER = 14;

const GOLD: Rgb = [1.0, 0.8, 0.2];
const PALE_GOLD: Rgb = [1.0, 0.95, 0.6];
const ORANGE: Rgb = [1.0, 0.5, 0.1];
const RED: Rgb = [0.95, 0.2, 0.25];
const PAL: Pal = [GOLD, PALE_GOLD, ORANGE];

// --- the drawn jaw: a glowing golden dome with a zigzag of silver teeth along its lower edge ---
const jawTex = await kit.drawn("jaw", 64, 32, "a3i5", (x, y) => {
  const u = ((x + 0.5) / 64) * 2 - 1;
  if (Math.abs(u) >= 1) return undefined;
  const top = 25 - 23 * Math.sqrt(1 - u * u);
  const phase = (u + 1) * 2.5; // five teeth
  const tri = Math.abs((phase % 1) - 0.5) * 2; // 1 at tooth roots, 0 at tips
  const bottom = 30 - 7 * tri;
  if (y + 0.5 < top || y + 0.5 > bottom) return undefined;
  if (bottom - (y + 0.5) < 2.2) return [238, 240, 245]; // silver tooth edge
  if (y + 0.5 - top < 1.3) return [235, 130, 20]; // warm rim
  const depth = (y + 0.5 - top) / Math.max(1, bottom - top); // 0 at the dome, 1 at the teeth
  const side = Math.abs(u);
  const light = Math.max(0, 1 - 0.55 * side - 0.35 * Math.abs(depth - 0.55));
  // Soft vertical ribs, as on the in-game jaws.
  const rib = 0.92 + 0.08 * Math.cos(u * Math.PI * 5);
  return [255, Math.round((135 + 85 * light) * rib), Math.round(15 + 75 * light * light)];
});

const GAPE = 1.7; // how far each jaw hangs from the bite line when open
const SHUT = 0.55;
function jaw(side: 1 | -1, y: number, at: number, life: number): ReturnType<typeof kit.parked> {
  const r = kit.parked(jawTex, [FOE[0], FOE[1] + side * y, FOE[2] + 0.2], 1.05, life);
  r.aspectRatio = 2;
  r.startDelayFrames = at;
  spin(r, 0, 0, side === 1 ? 0 : deg(180));
  paint(r, WHITE);
  return r;
}
for (const [name, side] of [["upper", 1], ["lower", -1]] as const) {
  // Hanging open, easing in.
  const open = jaw(side, GAPE, 0, OPEN + 1);
  setCurves(open, grow(0.7, 0.4, 1.05), { start: 0, mid: 1, end: 1, curveIn: 0.3, curveOut: 1 });
  kit.add(`${name}Open`, open);
  // The snap: flying to the bite line.
  const snap = jaw(side, GAPE, OPEN, SNAP + 1);
  snap.axis = [0, -side, 0];
  snap.initVelAxisAmplifier = (GAPE - SHUT) / SNAP;
  setCurves(snap, hold(1.05), hold(1));
  kit.add(`${name}Snap`, snap);
  // Locked shut, trembling a little larger on the bite.
  const shut = jaw(side, SHUT, OPEN + SNAP, LOCK);
  setCurves(shut, { start: 1.2, mid: 1.05, end: 1.05, curveIn: 0.15, curveOut: 1 }, { start: 1, mid: 1, end: 0, curveIn: 0, curveOut: 0.85 });
  kit.add(`${name}Shut`, shut);
}
const jaws = ["upper", "lower"].flatMap((n) => [`${n}Open`, `${n}Snap`, `${n}Shut`]);

const BITE = OPEN + SNAP;
const foe = [
  ...glow(kit, "aura", { pos: FOE, life: BITE + LOCK, scale: 3.0, pal: [GOLD, ORANGE, PALE_GOLD], level: 0.55 }),
  ...impact(kit, "bite", { at: BITE, pal: [GOLD, PALE_GOLD, RED], size: 1.25, rays: 9, flecks: 0 }),
  ...impact(kit, "burst", { at: BITE + 3, pal: [ORANGE, PALE_GOLD, RED], size: 0.9, rays: 6, flecks: 0, flash: false }),
  ...sparks(kit, "sparks", { at: BITE, radius: 0.8, speed: 0.3, count: 8, life: 16, scale: 0.14, pal: [GOLD, WHITE, ORANGE], fall: 0.01, twinkle: false }),
  ...sparks(kit, "lockSparks", { at: BITE + 6, radius: 1.3, speed: 0.12, count: 2, bursts: 5, gap: 3, life: 12, scale: 0.12, pal: [PALE_GOLD, WHITE, RED], fall: 0.008 }),
];

const user = glow(kit, "ready", { life: WINDUP + 4, scale: 2.2, pal: PAL, level: 0.6 });

const biteAt = WINDUP + PAN + BITE;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1407, 0, { pitch: -300, vol: 105 }),
  snd(1514, biteAt - SNAP, { side: "D", pitch: -500, vol: 115 }),
  snd(1475, biteAt, { ch: "SE2", side: "D", pitch: -200, vol: 125 }),
  snd(1423, biteAt + 1, { side: "D", pitch: 300, vol: 115 }),
  snd(1420, biteAt + 10, { ch: "SE2", side: "D", pitch: -300, vol: 100 }),
)}
${tint("ATTACKER", 0, 8, 3, [31, 26, 8])}
${emits(kit, user, "ATTACKER")}
${squash("ATTACKER", -819, 819, 4)}
Wait ${WINDUP}
${lunge("ATTACKER", 3)}
${tint("ATTACKER", 8, 0, 4, [31, 26, 8])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, [...jaws, ...foe], "DEFENDER")}
Wait ${BITE}
${hit({ rgb: [31, 28, 12], power: 2 })}
ScaleSprite DEFENDER, ROUNDTRIP, 0, -1229, 8, 0, 1
${shake("DEFENDER", 819, LOCK / 2 - 4)}
Wait ${LOCK - 4}
${quake("0.5x", 3, "HORIZON")}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129],
  references: ["reference/Jaw_Lock_VIII.png", "reference/Jaw_Lock_IX.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("upperShut")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("biteFlash")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  jaws open f${CAMERA_IN + WINDUP + PAN}, bite f${CAMERA_IN + biteAt}, locked until f${CAMERA_IN + biteAt + LOCK}`);
