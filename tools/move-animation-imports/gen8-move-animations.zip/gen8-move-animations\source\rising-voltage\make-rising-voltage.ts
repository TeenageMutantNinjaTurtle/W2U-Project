import { createKit, fadeOut, hold, paint, setCurves, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, bolt, emits, FOE, FOE_FLOOR, glow, hit, impact, intro, outro, pan, remapAnim, ring, shake, snd, sparks, squash, streaks, tint, USER_FLOOR, WHITE, zaps, type Pal } from "../tools/phrases";

// Rising Voltage (move 804) - from the Bulbapedia stills (reference/sheet.png).
//   1. Electricity crackles at the user's feet and runs off along the ground.
//   2. Round the foe the ground lights up and electricity flares up out of
//      it in a cone, widening as it climbs.
//   3. Small bolts of lightning slam down on the foe one after another
//      through the cone, the last the hardest.
// The cone of ground electricity and the small bolts (in place of a single
// pillar, which looked like my other electric moves) are Logan's direction,
// 2026-10-03. The lightning is Thunder's (the bolt column and the arcs).

const SPA = 984;
const kit = await createKit({ workDir: import.meta.dirname, slug: "rising-voltage", moveId: 804, spaId: SPA, donors: [256, 257, 413, 228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const CHARGE = 18;
const RUN = 8; // the current runs along the ground
const RISE = 6; // the cone is up before the first bolt
const BOLTS = 4;
const BOLT_GAP = 5;
const CONE = RISE + BOLTS * BOLT_GAP + 2; // how long the ground keeps flaring
const AFTER = 26;

const YELLOW: Rgb = [1.0, 0.92, 0.25];
const PALE: Rgb = [1.0, 0.98, 0.72];
const GOLD: Rgb = [1.0, 0.72, 0.15];
const ICE: Rgb = [0.75, 0.95, 1.0];
const PAL: Pal = [YELLOW, PALE, GOLD];
const ROCK: Pal = [[0.7, 0.62, 0.5], [0.9, 0.84, 0.72], [0.5, 0.44, 0.34]];

// Thunder's upright bolt column.
function column(pos: Vec3, life: number, scale: number, at: number, colour: Rgb): ReturnType<typeof kit.shell> {
  const r = remapAnim(kit, kit.shell(256, 1), 256);
  Object.assign(r, { emitterBasePos: [...pos], particleLifeFrames: life, baseScale: scale, startDelayFrames: at });
  paint(r, colour, WHITE, colour);
  return r;
}

const user = [
  ...zaps(kit, "feet", { pos: [0, USER_FLOOR[1] + 0.3, 0.4], radius: 1.3, count: 2, bursts: CHARGE / 3, gap: 3, life: 6, scale: 0.6, pal: [YELLOW, WHITE, ICE], shape: "circle" }),
  ...sparks(kit, "feetSparks", { pos: [0, USER_FLOOR[1] + 0.3, 0.4], radius: 1.0, speed: 0.14, count: 2, bursts: CHARGE / 3, gap: 3, life: 9, scale: 0.12, pal: [YELLOW, WHITE, GOLD], fall: -0.008 }),
  ...glow(kit, "floorGlow", { pos: [0, USER_FLOOR[1], 0.3], life: CHARGE + RUN, scale: 1.3, pal: [YELLOW, GOLD, PALE], aspect: 2.6, level: 0.6 }),
];
// The current running along the ground to the foe.
bolt(kit, "current", { from: [0.2, -1.3, -0.6], at: CHARGE, travel: RUN, scale: 1.1, pal: [PALE, WHITE, YELLOW], count: 3, gap: 2 });
bolt(kit, "currentGlow", { from: [0.2, -1.3, -0.6], at: CHARGE, travel: RUN, scale: 0.8, pal: [YELLOW, PALE, GOLD], count: 3, gap: 2, tex: kit.tex(T.spike) });

// --- 3. the small bolts: each comes down at its own spot on the foe ---
const STRIKES: Vec3[] = [[-0.7, 1.2, 0.85], [0.6, 1.0, 0.85], [-0.2, 1.4, 0.85], [0.2, 1.3, 0.85]];
const boltNames: string[] = [];
for (const [i, at] of STRIKES.entries()) {
  const last = i === BOLTS - 1;
  kit.add(`bolt${i}`, column(at, last ? 8 : 6, last ? 2.3 : 1.5, RISE + i * BOLT_GAP, i % 2 ? PALE : YELLOW));
  boltNames.push(`bolt${i}`);
}
const foe = [
  ...boltNames,
  ...STRIKES.flatMap((at, i) => impact(kit, `strike${i}`, { pos: [at[0], 0.1 + (i % 2) * 0.3, 0.9], at: RISE + i * BOLT_GAP + 1, pal: PAL, size: i === BOLTS - 1 ? 1.6 : 0.9, rays: i === BOLTS - 1 ? 8 : 0, flecks: 0, spiky: i === BOLTS - 1 })),
  // --- 2. the cone: electricity leaving a ring on the ground round the foe,
  // climbing and spreading as it goes ---
  ...streaks(kit, "coneLines", { pos: FOE_FLOOR, radius: 1.0, speed: 0.2, count: 3, bursts: CONE / 2, gap: 2, life: 9, scale: 1.0, pal: [YELLOW, WHITE, ICE], flat: true, lift: 0.46 }),
  ...zaps(kit, "coneArcs", { pos: FOE_FLOOR, radius: 1.1, speed: 0.16, count: 2, bursts: CONE / 3, gap: 3, life: 8, scale: 0.75, pal: [YELLOW, WHITE, ICE], shape: "circle" }),
  ...sparks(kit, "coneSparks", { pos: FOE_FLOOR, radius: 1.1, speed: 0.14, count: 2, bursts: CONE / 3, gap: 3, life: 12, scale: 0.13, pal: [YELLOW, WHITE, GOLD], twinkle: false, shape: "circle" }),
  ...ring(kit, "groundRing", { pos: FOE_FLOOR, scale: 0.75, pal: [YELLOW, PALE, GOLD], tex: kit.tex(T.ring), aspect: 2.6, to: 1.5, life: CONE, level: 0.95 }),
  ...glow(kit, "groundGlow", { pos: FOE_FLOOR, life: CONE + 4, scale: 1.0, pal: [YELLOW, GOLD, PALE], tex: kit.tex(T.softDisc), aspect: 2.6, level: 0.8 }),
];
// The arcs and sparks ride the cone too: flat on the ground ring, thrown upward.
for (const n of ["coneArcs", "coneSparks"]) Object.assign(kit.resources[kit.idx(n)]!, { emissionAxis: 1, axis: [0, 1, 0], initVelAxisAmplifier: n === "coneArcs" ? 0.3 : 0.36 });

const coneAt = CHARGE + RUN;
const firstBolt = coneAt + RISE;
const burstAt = firstBolt + (BOLTS - 1) * BOLT_GAP;
// Each of the first bolts is a flash and a jolt; the last is the heavy hit.
const jolts = Array.from({ length: BOLTS - 1 }, (_, i) => [
  ...(i === 0 ? ["ToggleFreezeSprite DEFENDER, START"] : []),
  tint("DEFENDER", 0, 10, 0, [31, 31, 14]),
  shake("DEFENDER", 1229, 2),
  "Wait 1",
  tint("DEFENDER", 10, 0, 4, [31, 31, 14]),
  `Wait ${BOLT_GAP - 1}`,
].join("\n")).join("\n");
const script =`${intro(SPA, CAMERA_IN)}
${audio(
  snd(1483, 0, { ch: "SE2", vol: 100 }),
  snd(1458, 4, { pitch: 200, vol: 105 }),
  snd(1376, CHARGE, { ch: "SE2", vol: 0 }),
  snd(1522, CHARGE, { pitch: 300, vol: 115 }),
  snd(1483, coneAt, { side: "D", pitch: 200, vol: 110 }),
  ...Array.from({ length: BOLTS - 1 }, (_, i) => snd(1458, firstBolt + i * BOLT_GAP, { ch: i % 2 ? "SE1" : "SE2", side: "D", pitch: 300 + i * 150, vol: 118 })),
  snd(1683, burstAt - 1, { ch: "SE2", side: "FLAT", vol: 127 }),
  snd(1475, burstAt, { side: "D", pitch: -300, vol: 127 }),
  snd(1710, burstAt + 8, { ch: "SE2", side: "D", pitch: 300, vol: 105 }),
)}
${tint("ATTACKER", 0, 9, 5, [31, 30, 12])}
${emits(kit, user, "ATTACKER")}
${emits(kit, ["current", "currentGlow"], "ATTACKER", "DEFENDER")}
${shake("ATTACKER", 819, CHARGE / 2 - 2)}
Wait ${CHARGE}
${squash("ATTACKER", 819, -819, 3)}
${tint("ATTACKER", 9, 0, 4, [31, 30, 12])}
${pan("DEFENDER", RUN)}
Wait ${RUN}
${emits(kit, foe, "DEFENDER")}
Wait ${RISE}
${jolts}
${arena(0, 10, 0, [31, 31, 20])}
${hit({ rgb: [31, 31, 14], power: 3, freeze: false })}
${arena(10, 0, 4, [31, 31, 20])}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [87, 242, 63, 605, 400, 240, 129],
  references: ["reference/Rising_Voltage_VIII.png", "reference/Rising_Voltage_VIII_2.png", "reference/Rising_Voltage_IX.png", "reference/Rising_Voltage_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("feet")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("current")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("coneLines")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("bolt0")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("bolt3")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  charge f${CAMERA_IN}, current f${CAMERA_IN + CHARGE}, cone f${CAMERA_IN + coneAt}, bolts f${CAMERA_IN + firstBolt} then every ${BOLT_GAP}, last f${CAMERA_IN + burstAt}`);
