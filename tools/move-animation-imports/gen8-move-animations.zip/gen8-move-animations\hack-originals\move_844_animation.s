MoveCamera INTERPOLATION, ATTACKER, 16, 0, 12
PlaySound 1849, SE1, 14, 0, -100, 127, 0, 0, 0
PlaySound 1867, SE2, 14, 0, 0, 70, 5, 0, 0
AdjustSound SE1, 0, 1, 127, 0, 60, 80, 0, 0
AdjustSound SE2, 0, 1, 70, 0, 50, 70, 0, 0
ToggleFreezeSprite ATTACKER, START
LoadSPA 459
Emit 459, 0, ATTACKER, NONE, 0, 0, 0, 1x, 1x, 1x, 1x
Emit 459, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, 0, 0.5x, 16, 1, 1
ChangeBackgroundColor 4, 0, 12, 1, 0, 0, 0
AudioContainer CONTINUE
PlaySound 1419, PSG, 16, 45, 0, 50, 0, 0, 0
PlaySound 1535, SE1, 16, 45, 0, 127, 0, 0, 0
AudioContainer SUSPEND
ToggleFreezeSprite DEFENDER, START
MoveCamera INTERPOLATION, INIT, 32, 0, 12
LoadSPA 431
EmitProjectile 431, 0, STRAIGHT, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 0
Wait 20
MoveCamera INTERPOLATION, DEFENDER, 16, 0, 8
ToggleFreezeSprite DEFENDER, START
Wait 20
Emit 431, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
LoadSPA 418
Emit 418, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 16, 0, 12, 0, 12
ShakeSprite DEFENDER, 2, 1229, 0, 1, 2, 3
Wait 20
ChangeSpriteColor DEFENDER, 16, 0, 1, 12, 0, 12
ChangeBackgroundColor 4, 12, 0, 1, 0, 0, 0
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, STOP
ToggleFreezeSprite ATTACKER, STOP
LetCMDsFinish ALL
TerminateMoveScript
