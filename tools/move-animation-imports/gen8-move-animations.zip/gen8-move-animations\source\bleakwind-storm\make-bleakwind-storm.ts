import { T, type Rgb } from "../tools/anim-kit";
import { snd, sparks, WHITE } from "../tools/phrases";
import { buildStorm } from "../tools/storm";

// Bleakwind Storm (move 846) - from the Bulbapedia stills (reference/sheet.png).
// The user whips up a bitter grey wind; over the foe it spins into a tall
// silver-white tornado laced with cold violet, shards of ice and sleet
// carried in it, frost flashing where it bites.
// Built by ../tools/storm.ts (shared with the other three storms).

const SILVER: Rgb = [0.82, 0.86, 0.92];
const SLATE: Rgb = [0.5, 0.55, 0.68];
const COLD: Rgb = [0.72, 0.75, 1.0];
const ICE: Rgb = [0.65, 0.88, 1.0];
const PALE: Rgb = [0.92, 0.96, 1.0];

await buildStorm({
  workDir: import.meta.dirname,
  slug: "bleakwind-storm",
  moveId: 846,
  spaId: 1026,
  pal: [SILVER, WHITE, SLATE],
  accent: COLD,
  userTint: [24, 26, 31],
  arenaTint: [8, 9, 15],
  references: ["reference/Bleakwind_Storm_LA.png", "reference/Bleakwind_Storm_IX.png"],
  describe: "bleakwind storm",
  sounds: (stormAt) => [
    snd(1509, stormAt + 6, { ch: "SE2", side: "D", pitch: 600, vol: 95 }),
    snd(1509, stormAt + 20, { ch: "SE2", side: "D", pitch: 800, vol: 95 }),
  ],
  carries: (kit, { GATHER, STORM }) => ({
    user: [
      ...sparks(kit, "userSleet", { pos: [0, 0.8, 0.5], radius: 1.8, speed: 0.1, count: 2, bursts: GATHER / 4, gap: 4, life: 10, scale: 0.12, pal: [WHITE, PALE, ICE], fall: 0.006, twinkle: false }),
    ],
    foe: [
      // Shards of ice flung round in the wind.
      ...sparks(kit, "iceShards", { pos: [0, 0.6, 1.0], at: 2, radius: 1.8, speed: 0.1, count: 1, bursts: STORM / 4 - 2, gap: 4, life: 14, scale: 0.34, pal: [ICE, WHITE, COLD], fall: -0.012, tex: kit.tex(T.shard), twinkle: false, spin: 0.3 }),
      ...sparks(kit, "frostFlash", { pos: [0, 0.6, 1.0], at: 4, radius: 1.8, speed: 0, count: 1, bursts: STORM / 4 - 2, gap: 4, life: 8, scale: 0.4, pal: [WHITE, COLD, PALE], shape: "ball", tex: kit.tex(T.sparkle4) }),
    ],
  }),
});
