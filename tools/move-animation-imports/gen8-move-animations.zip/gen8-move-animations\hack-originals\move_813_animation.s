AudioContainer CONTINUE
PlaySound 1539, SE1, 14, 0, 0, 115, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 16, 0, 20, 0, 0
AudioContainer SUSPEND
AudioContainer CONTINUE
PlaySound 1539, SE2, 14, 25, 0, 115, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 16, 20, 20, 0, 0
AudioContainer SUSPEND
AudioContainer CONTINUE
PlaySound 1539, SE1, 14, 50, 0, 115, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 16, 45, 20, 0, 0
AudioContainer SUSPEND
AudioContainer CONTINUE
PlaySound 1488, SE2, 16, 50, 400, 115, 0, 0, 0
AudioContainer SUSPEND
LoadSPA 507
Emit 507, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 507, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 507, 2, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 12
ToggleFreezeSprite DEFENDER, START
ShakeSprite DEFENDER, 2, 1229, 0, 1, 2, 3
Emit 507, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 507, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 507, 2, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 12
ShakeSprite DEFENDER, 2, 1229, 0, 1, 2, 3
Emit 507, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 507, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 507, 2, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 20
ShakeSprite DEFENDER, 2, 1229, 0, 1, 2, 3
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, STOP
TerminateMoveScript
