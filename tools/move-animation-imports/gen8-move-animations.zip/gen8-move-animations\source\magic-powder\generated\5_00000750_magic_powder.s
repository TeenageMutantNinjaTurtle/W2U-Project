MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 948
AudioContainer CONTINUE
PlaySound 1474, SE1, 14, 0, 0, 80, 0, 0, 0
PlaySound 1718, SE2, 14, 8, 300, 115, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 14, 0, 50, 0, 0
PlaySound 1463, SE1, 16, 24, 300, 100, 0, 0, 0
PlaySound 1784, SE2, 16, 46, 0, 110, 0, 0, 0
PlaySound 1509, SE1, 16, 50, 600, 90, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 7, 0, 3, 5, 14
Emit 948, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 948, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 948, 2, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 948, 3, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 6
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 4, 0, 1
Wait 4
MoveCamera INTERPOLATION, DEFENDER, 14, 0, 8
Wait 14
Emit 948, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 948, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 948, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 948, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 948, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 948, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 948, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 948, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 22
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 10, 9, 31
ScaleSprite DEFENDER, ROUNDTRIP, -819, 819, 5, 0, 1
Wait 20
ChangeSpriteColor DEFENDER, 12, 0, 0, 10, 9, 31
ChangeBackgroundColor 4, 7, 0, 0, 3, 5, 14
Wait 10
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
