.include "B2W2_MOVSCRCMD.s"
.align 4

.word 5 @ Count
.word SCRIPT_V0
.word SCRIPT_V0
.word SCRIPT_V0
.word SCRIPT_V0
.word SCRIPT_V0
.word SCRIPT_V0
.word SCRIPT_V0
.word SCRIPT_V0
.word SCRIPT_V0
.word SCRIPT_V0
.word SCRIPT_V0
.word SCRIPT_V0
.word SCRIPT_V0
.word SCRIPT_V0
.word SCRIPT_V1
.word SCRIPT_V1
.word SCRIPT_V1
.word SCRIPT_V1
.word SCRIPT_V1
.word SCRIPT_V1
.word SCRIPT_V1
.word SCRIPT_V1
.word SCRIPT_V1
.word SCRIPT_V1
.word SCRIPT_V1
.word SCRIPT_V1
.word SCRIPT_V1
.word SCRIPT_V1
.word SCRIPT_V2
.word SCRIPT_V2
.word SCRIPT_V2
.word SCRIPT_V2
.word SCRIPT_V2
.word SCRIPT_V2
.word SCRIPT_V2
.word SCRIPT_V2
.word SCRIPT_V2
.word SCRIPT_V2
.word SCRIPT_V2
.word SCRIPT_V2
.word SCRIPT_V2
.word SCRIPT_V2
.word SCRIPT_V3
.word SCRIPT_V3
.word SCRIPT_V3
.word SCRIPT_V3
.word SCRIPT_V3
.word SCRIPT_V3
.word SCRIPT_V3
.word SCRIPT_V3
.word SCRIPT_V3
.word SCRIPT_V3
.word SCRIPT_V3
.word SCRIPT_V3
.word SCRIPT_V3
.word SCRIPT_V3
.word SCRIPT_V4
.word SCRIPT_V4
.word SCRIPT_V4
.word SCRIPT_V4
.word SCRIPT_V4
.word SCRIPT_V4
.word SCRIPT_V4
.word SCRIPT_V4
.word SCRIPT_V4
.word SCRIPT_V4
.word SCRIPT_V4
.word SCRIPT_V4
.word SCRIPT_V4
.word SCRIPT_V4

SCRIPT_V0:
MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 985
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, 300, 100, 0, 0, 0
PlaySound 1474, SE2, 14, 4, 0, 85, 0, 0, 0
PlaySound 1376, SE1, 14, 24, 0, 0, 0, 0, 0
PlaySound 1510, SE2, 14, 24, 300, 110, 0, 0, 0
PlaySound 1407, SE1, 14, 24, -200, 110, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 8, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 32, -100, 122, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 0, 31, 28, 16
Emit 985, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 8
Wait 24
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -1px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 985, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 31, 28, 16
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 31, 28, 16
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ChangeSpriteColor ATTACKER, 8, 0, 0, 31, 28, 16
Wait 24
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript

SCRIPT_V1:
MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 985
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, 600, 100, 0, 0, 0
PlaySound 1474, SE2, 14, 4, 300, 85, 0, 0, 0
PlaySound 1376, SE1, 14, 24, 0, 0, 0, 0, 0
PlaySound 1510, SE2, 14, 24, 600, 110, 0, 0, 0
PlaySound 1407, SE1, 14, 24, -200, 110, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 8, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 32, 200, 122, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 0, 31, 31, 6
Emit 985, 14, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 15, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 16, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 17, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 19, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 18, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 8
Wait 24
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -1px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 985, 20, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 21, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 22, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 23, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 24, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 25, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 26, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 27, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 31, 31, 6
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 31, 31, 6
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ChangeSpriteColor ATTACKER, 8, 0, 0, 31, 31, 6
Wait 24
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript

SCRIPT_V2:
MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 985
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, 200, 100, 0, 0, 0
PlaySound 1474, SE2, 14, 4, -100, 85, 0, 0, 0
PlaySound 1376, SE1, 14, 24, 0, 0, 0, 0, 0
PlaySound 1510, SE2, 14, 24, 200, 110, 0, 0, 0
PlaySound 1407, SE1, 14, 24, -200, 110, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 8, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 32, -200, 122, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 0, 12, 31, 12
Emit 985, 28, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 29, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 30, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 31, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 33, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 32, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 8
Wait 24
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -1px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 985, 34, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 35, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 36, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 37, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 38, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 39, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 40, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 41, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 12, 31, 12
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 12, 31, 12
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ChangeSpriteColor ATTACKER, 8, 0, 0, 12, 31, 12
Wait 24
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript

SCRIPT_V3:
MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 985
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, 500, 100, 0, 0, 0
PlaySound 1474, SE2, 14, 4, 200, 85, 0, 0, 0
PlaySound 1376, SE1, 14, 24, 0, 0, 0, 0, 0
PlaySound 1510, SE2, 14, 24, 500, 110, 0, 0, 0
PlaySound 1407, SE1, 14, 24, -200, 110, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 8, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 32, 100, 122, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 0, 31, 18, 27
Emit 985, 42, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 43, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 44, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 45, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 47, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 46, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 8
Wait 24
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -1px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 985, 48, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 49, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 50, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 51, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 52, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 53, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 54, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 55, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 31, 18, 27
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 31, 18, 27
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ChangeSpriteColor ATTACKER, 8, 0, 0, 31, 18, 27
Wait 24
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript

SCRIPT_V4:
MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 985
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, 100, 100, 0, 0, 0
PlaySound 1474, SE2, 14, 4, -200, 85, 0, 0, 0
PlaySound 1376, SE1, 14, 24, 0, 0, 0, 0, 0
PlaySound 1510, SE2, 14, 24, 100, 110, 0, 0, 0
PlaySound 1407, SE1, 14, 24, -200, 110, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 8, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 32, -300, 122, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 0, 21, 10, 31
Emit 985, 56, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 57, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 58, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 59, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 61, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 60, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 8
Wait 24
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -1px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 985, 62, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 63, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 64, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 65, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 66, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 67, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 68, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 985, 69, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 21, 10, 31
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 21, 10, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ChangeSpriteColor ATTACKER, 8, 0, 0, 21, 10, 31
Wait 24
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
