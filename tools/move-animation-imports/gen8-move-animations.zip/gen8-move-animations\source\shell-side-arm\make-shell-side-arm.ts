import { createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FOE_FLOOR, FRONT, glow, hit, impact, intro, lunge, outro, pan, ring, shot, snd, sparks, streaks, tint, WHITE, type Pal } from "../tools/phrases";

// Shell Side Arm (move 801) - from the Bulbapedia stills (reference/sheet.png:
// the special version on the top row, the physical one on the bottom).
//   1. The shell arm fires in a magenta burst.
//   2. A dark violet ball of poison flies across, dripping.
//   3. It goes off under the foe: a column of violet poison shoots up out of
//      a ring of magenta spikes, dark chunks flying.
// One animation serves both the special and the physical version (scripts
// cannot tell which the engine picked).

const SPA = 981;
const kit = await createKit({ workDir: import.meta.dirname, slug: "shell-side-arm", moveId: 801, spaId: SPA, donors: [413, 228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 10;
const AIM = 12;
const TRAVEL = 9;
const AFTER = 28;

const MAGENTA: Rgb = [1.0, 0.25, 0.85];
const PINK: Rgb = [1.0, 0.65, 0.95];
const VIOLET: Rgb = [0.6, 0.2, 0.9];
const DEEP: Rgb = [0.22, 0.05, 0.4];
const PAL: Pal = [MAGENTA, PINK, VIOLET];
const CHUNK: Pal = [[0.18, 0.06, 0.28], [0.4, 0.2, 0.55], [0.06, 0.02, 0.1]];

const user = [
  ...glow(kit, "muzzle", { pos: FRONT, at: AIM, life: 9, scale: 1.6, pal: [MAGENTA, PINK, VIOLET], tex: kit.tex(T.spiky), spin: 0.15, level: 1, scaleCurve: grow(0.5, 0.3, 1.35), alpha: fadeOut(1, 0.4) }),
  ...streaks(kit, "muzzleShards", { pos: FRONT, at: AIM, radius: 0.4, speed: 0.36, count: 7, life: 9, scale: 0.7, pal: [MAGENTA, PINK, VIOLET], tex: kit.tex(T.shard) }),
  ...glow(kit, "loading", { pos: FRONT, life: AIM + 2, scale: 1.1, pal: [VIOLET, MAGENTA, DEEP], level: 0.8, scaleCurve: grow(0.3, 0.8, 1.1) }),
];
// The ball: a dark core inside a magenta glow, with drips falling from it.
shot(kit, "ballCore", kit.tex(T.softDisc), { at: AIM, travel: TRAVEL, scale: 0.6, pal: [DEEP, VIOLET, DEEP] });
shot(kit, "ballGlow", kit.tex(T.fuzzyGlow), { at: AIM, travel: TRAVEL, scale: 1.3, pal: [MAGENTA, PINK, VIOLET], alpha: hold(0.85) });
shot(kit, "drips", kit.tex(T.softDisc), { from: [0.3, 0.2, -1.0], at: AIM + 1, travel: TRAVEL + 4, scale: 0.26, pal: [VIOLET, MAGENTA, DEEP], count: 4, gap: 2, dive: 0.12, alpha: fadeOut(0.9, 0.6) });

// --- 3. the eruption ---
const column = kit.parked(kit.tex(T.streak), [0, 1.6, 0.8], 3.6, 16);
column.aspectRatio = 0.42;
setCurves(column, { start: 0.2, mid: 1.05, end: 1.1, curveIn: 0.2, curveOut: 0.8 }, fadeInOut(0.95, 0.1, 0.6));
paint(column, VIOLET, MAGENTA, DEEP);
kit.add("column", column);
const columnCore = kit.parked(kit.tex(T.streak), [0, 1.6, 0.85], 3.4, 14);
columnCore.aspectRatio = 0.16;
setCurves(columnCore, { start: 0.2, mid: 1.05, end: 1.1, curveIn: 0.2, curveOut: 0.8 }, fadeInOut(0.95, 0.1, 0.55));
paint(columnCore, PINK, WHITE, MAGENTA);
kit.add("columnCore", columnCore);
const foe = [
  ...sparks(kit, "chunks", { pos: FOE_FLOOR, at: 1, radius: 0.9, speed: 0.3, count: 8, life: 20, scale: 0.34, pal: CHUNK, fall: 0.028, tex: kit.tex(413, 2), twinkle: false, spin: 0.2 }),
  "columnCore", "column",
  ...streaks(kit, "spikes", { pos: [0, -1.1, 0.8], radius: 0.6, speed: 0.55, count: 8, life: 10, scale: 0.9, pal: [MAGENTA, PINK, VIOLET], tex: kit.tex(T.spike), flat: true }),
  ...impact(kit, "burst", { pal: PAL, size: 1.35, rays: 8, flecks: 0 }),
  ...ring(kit, "pool", { pos: FOE_FLOOR, scale: 1.4, pal: [VIOLET, MAGENTA, DEEP], aspect: 2.6, to: 1.9, life: 16 }),
  ...sparks(kit, "spatter", { at: 2, radius: 0.8, speed: 0.26, count: 6, life: 14, scale: 0.16, pal: [MAGENTA, PINK, VIOLET], fall: 0.014, twinkle: false, tex: kit.tex(T.softDisc) }),
];
Object.assign(kit.resources[kit.idx("chunks")]!, { axis: [0, 1, 0], initVelAxisAmplifier: 0.34 });
setCurves(kit.resources[kit.idx("chunks")]!, hold(1), fadeOut(1, 0.8));
setCurves(kit.resources[kit.idx("spikes")]!, grow(1.2, 0.3, 0.6), fadeOut());

const landAt = AIM + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1487, 0, { pitch: 300, vol: 100 }),
  snd(1727, AIM, { vol: 120 }),
  snd(1407, AIM, { ch: "SE2", pitch: -300, vol: 115 }),
  `SwitchAudioSide SE2, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0`,
  snd(1475, landAt, { side: "D", pitch: -200, vol: 127 }),
  snd(1727, landAt, { ch: "SE2", side: "D", pitch: -400, vol: 120 }),
  snd(1884, landAt + 3, { side: "D", vol: 100 }),
)}
${arena(0, 8, 6, [14, 4, 18])}
${tint("ATTACKER", 0, 8, 4, [26, 10, 31])}
${emits(kit, user, "ATTACKER")}
${emits(kit, ["ballCore", "ballGlow", "drips"], "ATTACKER", "DEFENDER")}
Wait ${AIM}
${lunge("ATTACKER", -2)}
${tint("ATTACKER", 8, 0, 4, [26, 10, 31])}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [28, 14, 31], power: 3 })}
Wait ${AFTER - 8}
${arena(8, 0, 8, [14, 4, 18])}
Wait 8
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [242, 63, 605, 400, 240, 153, 129, 163],
  references: ["reference/Shell_Side_Arm_VIII.png", "reference/Shell_Side_Arm_VIII_2.png", "reference/Shell_Side_Arm_VIII_Physical.png", "reference/Shell_Side_Arm_VIII_Physical_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("ballCore")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("column")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  fires f${CAMERA_IN + AIM}, erupts f${CAMERA_IN + landAt}`);
