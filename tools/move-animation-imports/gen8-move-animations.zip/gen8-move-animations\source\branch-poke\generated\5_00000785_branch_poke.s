LoadSPA 965
AudioContainer CONTINUE
PlaySound 1407, SE1, 14, 4, 600, 100, 0, 0, 0
PlaySound 1539, SE2, 16, 6, 300, 110, 0, 0, 0
PlaySound 1423, SE1, 16, 10, 400, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 6, 0, 14, 28, 10
Wait 4
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 2px, 49152, 0, 4096, 0
Wait 2
Emit 965, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 965, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 965, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 965, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 965, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor ATTACKER, 6, 0, 0, 14, 28, 10
Wait 4
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 10, 10, 0, 31, 31, 18
Wait 2
ChangeSpriteColor DEFENDER, 10, 0, 0, 31, 31, 18
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 2, 0, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 6
Wait 16
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
