import { createKit, deg, fadeInOut, fadeOut, grow, paint, setCurves, spin, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, bolt, emits, FOE, glow, hit, impact, intro, lunge, outro, pan, shot, snd, sparks, streaks, tint, USER, WHITE } from "../tools/phrases";

// Triple Arrows (move 843) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user closes in and kicks: a golden arc across the foe.
//   2. It springs back and looses three arrows one after another, white
//      rings spiralling in their wake.
//   3. Each arrow bursts on the foe in a jagged star of yellow and orange,
//      red splinters flying; the third hardest.
// The arrow is drawn (generated/texture-arrow.png). The Defense drop, flinch
// chance and critical-hit boost are the engine's.

const SPA = 1023;
const kit = await createKit({ workDir: import.meta.dirname, slug: "triple-arrows", moveId: 843, spaId: SPA, donors: [228, 465, 579, 411, 321, 298, 560] });

const CAMERA_IN = 10;
const WINDUP = 8;
const PAN = 6;
const DRAW = 14; // from the kick to the first arrow leaving
const ARROWS = 3;
const ARROW_GAP = 5;
const TRAVEL = 6;
const AFTER = 24;

const GOLD: Rgb = [1.0, 0.85, 0.25];
const PALE: Rgb = [1.0, 0.97, 0.78];
const ORANGE: Rgb = [1.0, 0.55, 0.1];
const RED: Rgb = [0.95, 0.25, 0.1];

// --- an arrow, point up: a pale head, a wooden shaft, orange-red fletching ---
const arrowTex = await kit.drawn("arrow", 16, 32, "a3i5", (x, y) => {
  const px = Math.abs(x + 0.5 - 8), py = y + 0.5;
  if (py < 9) {
    const half = py * 0.5;
    if (px > half) return undefined;
    return px > half - 1 ? [255, 170, 60, 255] : [255, 246, 205, 255];
  }
  if (py >= 21) {
    const half = 1.4 + (py - 21) * 0.42;
    if (px > half) return undefined;
    if (px < 1.3) return [250, 225, 170, 255];
    return px > half - 1 ? [200, 50, 20, 255] : [255, 120, 45, 255];
  }
  return px < 1.3 ? [245, 210, 150, 255] : undefined;
});

// --- 1. the kick: an arc brought down across the foe ---
// (the blade arc texture is an arch; turned 35 degrees clockwise its curve
// bulges up and away from the user, as a blow struck from the user's side -
// the foe's front - does. It starts above the foe and drops through it.
// Logan's direction, 2026-10-03: downward, then turned half round from my
// first try, which read as a blow from behind.)
const kick: string[] = [];
for (const [name, scale, colours] of [["kick", 1.9, [PALE, WHITE, GOLD]], ["kickGlow", 2.3, [GOLD, PALE, ORANGE]]] as const) {
  const r = kit.parked(kit.tex(T.bladeArc), [0.1, 1.1, 1.0], scale, 9);
  r.aspectRatio = 1.7;
  spin(r, 0, 0, deg(-35));
  Object.assign(r, { axis: [0, -1, 0], initVelAxisAmplifier: 0.28, airResistance: 0.85 });
  setCurves(r, grow(0.4, 0.3, 1.2), fadeOut(1, 0.45));
  paint(r, colours[0] as Rgb, colours[1] as Rgb, colours[2] as Rgb);
  kit.add(name, r);
  kick.push(name);
}
kick.push(...impact(kit, "kickHit", { at: 1, pal: [GOLD, PALE, ORANGE], size: 1.0, rays: 0, flecks: 0 }));

// --- 2. the arrows ---
const FROM: Vec3 = [0.3, 0.9, -0.8];
const arrows = bolt(kit, "arrows", { from: FROM, travel: TRAVEL, scale: 1.5, pal: [WHITE, WHITE, WHITE], tex: arrowTex, count: ARROWS, gap: ARROW_GAP, dive: 0.04 });
arrows.aspectRatio = 0.45;
bolt(kit, "arrowLight", { from: FROM, travel: TRAVEL, scale: 2.2, pal: [GOLD, PALE, ORANGE], count: ARROWS, gap: ARROW_GAP, dive: 0.04 });
shot(kit, "spirals", kit.tex(T.thinRings), { from: FROM, at: 1, travel: TRAVEL, scale: 0.55, pal: [WHITE, WHITE, PALE], spin: 0.5, count: ARROWS * 2, gap: ARROW_GAP / 2, dive: 0.04, alpha: fadeInOut(0.9, 0.1, 0.5) });
const loosed = ["arrows", "arrowLight", "spirals"];
const user = [
  ...sparks(kit, "feathers", { pos: USER, radius: 1.0, speed: 0.14, count: 4, life: 14, scale: 0.2, pal: [ORANGE, PALE, RED], fall: 0.008, tex: kit.tex(T.shard), twinkle: false, spin: 0.2 }),
  ...glow(kit, "draw", { pos: FROM, life: (ARROWS - 1) * ARROW_GAP + 8, scale: 1.3, pal: [GOLD, ORANGE, PALE], level: 0.8 }),
];

// --- 3. the bursts ---
const foe: string[] = [];
for (let i = 0; i < ARROWS; i++) {
  const last = i === ARROWS - 1;
  const where: Vec3 = [[-0.4, 0.6, 0.9], [0.4, 0.0, 0.9], [0, 0.3, 0.9]][i] as Vec3;
  foe.push(...impact(kit, `burst${i}`, { pos: where, at: i * ARROW_GAP, pal: [GOLD, PALE, ORANGE], size: last ? 1.7 : 1.1, rays: last ? 9 : 5, flecks: 0 }));
}
foe.push(
  ...streaks(kit, "splinters", { radius: 0.5, speed: 0.42, count: 4, bursts: ARROWS, gap: ARROW_GAP, life: 9, scale: 1.0, pal: [ORANGE, GOLD, RED], tex: kit.tex(T.shard) }),
  ...sparks(kit, "embers", { at: (ARROWS - 1) * ARROW_GAP, radius: 0.8, speed: 0.26, count: 7, life: 14, scale: 0.14, pal: [GOLD, PALE, ORANGE], fall: 0.012, twinkle: false }),
  ...glow(kit, "heat", { pos: FOE, life: ARROWS * ARROW_GAP + 10, scale: 2.8, pal: [ORANGE, RED, GOLD], level: 0.5 }),
);

const kickAt = WINDUP + PAN;
const looseAt = kickAt + DRAW;
const landAt = looseAt + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1407, WINDUP - 2, { pitch: 200, vol: 115 }),
  snd(1423, kickAt, { side: "D", pitch: -100, vol: 120 }),
  ...Array.from({ length: ARROWS }, (_, i) => snd(1539, looseAt + i * ARROW_GAP, { ch: i % 2 ? "SE2" : "SE1", pitch: 300 + i * 100, vol: 120 })),
  ...Array.from({ length: ARROWS }, (_, i) => snd(i === ARROWS - 1 ? 1475 : 1420, landAt + i * ARROW_GAP, { ch: "SE2", side: "D", pitch: i * 150, vol: 125 })),
)}
${tint("ATTACKER", 0, 7, 4, [31, 24, 8])}
Wait ${WINDUP}
${lunge("ATTACKER", 6)}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, kick, "DEFENDER")}
Wait 1
${hit({ rgb: [31, 28, 14], power: 1 })}
Wait ${DRAW - 1 - 2 - 4}
${lunge("ATTACKER", -4)}
${emits(kit, user, "ATTACKER")}
Wait 4
${emits(kit, loosed, "ATTACKER", "DEFENDER")}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [31, 26, 10], power: 1, stop: 2, freeze: false })}
Wait ${ARROW_GAP - 2}
${hit({ rgb: [31, 26, 10], power: 1, stop: 2, freeze: false })}
Wait ${ARROW_GAP - 2}
${hit({ rgb: [31, 29, 16], power: 3, freeze: false })}
${tint("ATTACKER", 7, 0, 6, [31, 24, 8])}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [42, 398, 427, 63, 605, 400, 240, 153, 129, 381],
  references: ["reference/Triple_Arrows_LA.png", "reference/Triple_Arrows_IX.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("kick")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("arrows")}, ATTACKER, DEFENDER`, `Emit ${SPA}, ${kit.idx("burst2Flash")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  kick f${CAMERA_IN + kickAt}, arrows loosed f${CAMERA_IN + looseAt}, land f${CAMERA_IN + landAt} / +${ARROW_GAP} / +${2 * ARROW_GAP}`);
