import { aimed, createKit, fadeOut, grow, hold, paint, setCurves, spin, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, FOE, FOE_FLOOR, glow, hit, impact, intro, outro, pan, puffs, quake, snd, sparks, streaks, tint, USER_FLOOR, WHITE, type Pal } from "../tools/phrases";

// Steel Roller (move 798) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user flashes white and becomes a great steel wheel, spinning on
//      the spot with sparks spraying off the ground.
//   2. It rolls over the ground at the foe, throwing up dust and stones.
//   3. It flattens the foe in a white-gold blast, rock flying.
// The wheel is drawn (generated/texture-wheel.png). The user is hidden while
// it is the wheel (ToggleSpriteVisibility 3/4). Clearing terrain is the
// engine's part.

const SPA = 978;
const kit = await createKit({ workDir: import.meta.dirname, slug: "steel-roller", moveId: 798, spaId: SPA, donors: [413, 228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 10;
const FLASH = 8;
const SPIN_UP = 18;
const TRAVEL = 9;
const AFTER = 30;

const YELLOW: Rgb = [1.0, 0.9, 0.4];
const PALE: Rgb = [1.0, 0.98, 0.82];
const DUST: Rgb = [0.72, 0.62, 0.45];
const PALE_DUST: Rgb = [0.88, 0.8, 0.66];
const ROCK: Pal = [[0.75, 0.68, 0.55], [0.92, 0.88, 0.78], [0.55, 0.48, 0.38]];
const WHEEL: Vec3 = [0, 0.2, 0.3];

// --- the drawn wheel: a fat steel ring, lit from the upper left, with spin streaks ---
const wheelTex = await kit.drawn("wheel", 32, 32, "a3i5", (x, y) => {
  const dx = x + 0.5 - 16, dy = y + 0.5 - 16;
  const r = Math.hypot(dx, dy);
  const R = 10, t = 5.5;
  const d = Math.abs(r - R);
  if (d > t) return r < 3.6 ? [60, 64, 80] : undefined; // a dark hub in the bore
  const radial = (r - R) / t;
  const nz = Math.sqrt(Math.max(0, 1 - radial * radial));
  const light = Math.max(0, (-0.55 * dx - 0.55 * dy) / (r || 1) * radial + 0.75 * nz);
  // Streaks round the rim, so the turning shows.
  const streak = 0.85 + 0.15 * Math.sin(Math.atan2(dy, dx) * 7 + r * 0.6);
  if (d > t - 1) return [78, 84, 104];
  const v = (120 + 135 * light) * streak;
  return [Math.round(v * 0.94), Math.round(v * 0.97), Math.round(Math.min(255, v * 1.05))];
});

function wheel(at: number, life: number, rate: number): ReturnType<typeof kit.parked> {
  const r = kit.parked(wheelTex, WHEEL, 2.0, life);
  r.startDelayFrames = at;
  spin(r, rate);
  paint(r, WHITE);
  return r;
}
const spinning = wheel(FLASH, SPIN_UP + 1, 0.35);
setCurves(spinning, { start: 0.5, mid: 1.05, end: 1, curveIn: 0.2, curveOut: 0.6 }, hold(1));
kit.add("wheelSpin", spinning);
const rolling = wheel(FLASH + SPIN_UP, TRAVEL + 1, 0.55);
aimed(rolling, 16 / TRAVEL, TRAVEL + 1);
rolling.airResistance = 1.0;
setCurves(rolling, hold(1), hold(1));
kit.add("wheelRoll", rolling);

const user = [
  ...glow(kit, "change", { pos: WHEEL, life: FLASH + 6, scale: 2.4, pal: [WHITE, WHITE, PALE], tex: kit.tex(T.sunburst), spin: 0.06, level: 1, scaleCurve: grow(0.4, 0.4, 1.4), alpha: fadeOut(1, 0.5) }),
  "wheelSpin",
  ...streaks(kit, "groundSparks", { pos: [0, USER_FLOOR[1] + 0.2, 0.4], at: FLASH + 2, radius: 0.5, speed: 0.4, count: 2, bursts: (SPIN_UP - 2) / 2, gap: 2, life: 7, scale: 0.55, pal: [YELLOW, WHITE, [1.0, 0.7, 0.25]], flat: true, lift: 0.1 }),
  ...puffs(kit, "spinDust", { pos: USER_FLOOR, at: FLASH + 2, radius: 1.2, count: 1, bursts: SPIN_UP / 3, gap: 3, life: 12, scale: 0.8, pal: [DUST, PALE_DUST, DUST], speed: 0.1 }),
  ...sparks(kit, "kicked", { pos: USER_FLOOR, at: FLASH + SPIN_UP, radius: 0.8, speed: 0.22, count: 5, life: 16, scale: 0.26, pal: ROCK, fall: 0.026, tex: kit.tex(413, 2), twinkle: false, spin: 0.2 }),
];
Object.assign(kit.resources[kit.idx("kicked")]!, { axis: [0, 1, 0], initVelAxisAmplifier: 0.26 });

const foe = [
  ...impact(kit, "crush", { pal: [YELLOW, PALE, [1.0, 0.75, 0.2]], size: 1.7, rays: 10, flecks: 0 }),
  ...glow(kit, "whiteout", { pos: FOE, life: 12, scale: 3.6, pal: [PALE, WHITE, YELLOW], level: 1, scaleCurve: grow(0.4, 0.2, 1.2), alpha: fadeOut(1, 0.45) }),
  ...sparks(kit, "rocks", { pos: FOE_FLOOR, radius: 0.9, speed: 0.34, count: 8, life: 20, scale: 0.32, pal: ROCK, fall: 0.03, tex: kit.tex(413, 2), twinkle: false, spin: 0.2 }),
  ...puffs(kit, "dust", { pos: FOE_FLOOR, at: 1, radius: 1.6, count: 3, bursts: 4, gap: 3, life: 18, scale: 1.3, pal: [DUST, PALE_DUST, [0.5, 0.42, 0.3]], speed: 0.14, rise: 0.03, to: 1.7 }),
];
Object.assign(kit.resources[kit.idx("rocks")]!, { axis: [0, 1, 0], initVelAxisAmplifier: 0.3 });
setCurves(kit.resources[kit.idx("rocks")]!, hold(1), fadeOut(1, 0.8));

const rollAt = FLASH + SPIN_UP;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1509, 0, { pitch: 400, vol: 100 }),
  snd(1435, FLASH, { ch: "SE2", pitch: -200, vol: 115 }),
  snd(1425, FLASH + 2, { pitch: -300, vol: 105 }),
  snd(1688, rollAt, { ch: "SE2", pitch: -200, vol: 120 }),
  snd(1884, rollAt + 2, { vol: 100 }),
  snd(1475, rollAt + TRAVEL, { side: "D", pitch: -400, vol: 127 }),
  snd(1413, rollAt + TRAVEL, { ch: "SE2", side: "D", pitch: -300, vol: 127 }),
)}
${tint("ATTACKER", 0, 16, FLASH - 2, [31, 31, 31])}
${emits(kit, user, "ATTACKER")}
${emits(kit, ["wheelRoll"], "ATTACKER", "DEFENDER")}
Wait ${FLASH}
ToggleSpriteVisibility ATTACKER, 3
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, ${Math.round(SPIN_UP / 3)}
Wait ${SPIN_UP}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [31, 31, 24], power: 3 })}
Wait 10
${quake("1x", 8)}
Wait ${AFTER - 10}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
${tint("ATTACKER", 16, 0, 4, [31, 31, 31])}
ToggleSpriteVisibility ATTACKER, 4
${pan("INIT", 12)}
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [242, 63, 605, 400, 240, 153, 129],
  references: ["reference/Steel_Roller_VIII.png", "reference/Steel_Roller_VIII_2.png", "reference/Steel_Roller_IX.png", "reference/Steel_Roller_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("wheelSpin")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("wheelRoll")}, ATTACKER, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 3", "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("rocks")}, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 4", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  flash f${CAMERA_IN}, wheel f${CAMERA_IN + FLASH}, rolls f${CAMERA_IN + rollAt}, lands f${CAMERA_IN + rollAt + TRAVEL}`);
