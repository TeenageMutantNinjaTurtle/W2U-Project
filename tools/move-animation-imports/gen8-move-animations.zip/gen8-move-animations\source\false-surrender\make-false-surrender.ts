import { createKit, deg, fadeOut, grow, paint, setCurves, T, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, FOE, glow, hit, impact, intro, lunge, outro, pan, snd, sparks, streaks, tint, WHITE, type Pal } from "../tools/phrases";

// False Surrender (move 793) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user bows low, as if giving in...
//   2. ...then whips forward: a huge red X is slashed across the foe, edged
//      in black, with magenta and black shards bursting out and the arena
//      flushed violet.

const SPA = 973;
const kit = await createKit({ workDir: import.meta.dirname, slug: "false-surrender", moveId: 793, spaId: SPA, donors: [228, 465, 579, 411, 298, 407] });

const CAMERA_IN = 10;
const BOW = 22; // head down, held
const PAN = 7;
const SECOND = 3; // the second stroke of the X
const AFTER = 26;

const RED: Rgb = [1.0, 0.1, 0.15];
const HOT: Rgb = [1.0, 0.45, 0.4];
const MAGENTA: Rgb = [1.0, 0.2, 0.7];
const BLACK: Rgb = [0, 0, 0];
const PAL: Pal = [RED, HOT, MAGENTA];
const X_AT: Vec3 = [FOE[0], FOE[1] + 0.1, FOE[2] + 0.2];

function stroke(name: string, angle: number, at: number, scale: number, aspect: number, colour: Rgb, life: number): string {
  const r = kit.parked(kit.tex(T.streak), X_AT, scale, life);
  r.startDelayFrames = at;
  r.aspectRatio = aspect;
  r.initAngle = deg(90 + angle);
  setCurves(r, grow(0.15, 0.18, 1.05), fadeOut(1, 0.55));
  paint(r, colour, colour === BLACK ? BLACK : HOT, colour);
  kit.add(name, r);
  return name;
}

const user = [
  ...glow(kit, "glint", { pos: [0.6, 0.9, 0.5], at: BOW - 6, life: 8, scale: 0.8, pal: [WHITE, WHITE, HOT], tex: kit.tex(T.star4Big), spin: 0.1, scaleCurve: twinkle(1.3), alpha: twinkle(1) }),
];
const foe = [
  // Red strokes first, so they draw over their black edges.
  stroke("redA", 42, 0, 4.0, 0.34, RED, 14), stroke("redB", -42, SECOND, 4.0, 0.34, RED, 14),
  stroke("blackA", 42, 0, 4.3, 0.55, BLACK, 15), stroke("blackB", -42, SECOND, 4.3, 0.55, BLACK, 15),
  ...impact(kit, "burst", { at: SECOND, pal: PAL, size: 1.5, rays: 8, flecks: 0 }),
  ...streaks(kit, "magentaJags", { at: SECOND, radius: 0.6, speed: 0.45, count: 8, life: 11, scale: 1.0, pal: [MAGENTA, RED, HOT], tex: kit.tex(T.shard) }),
  ...streaks(kit, "blackJags", { at: SECOND + 1, radius: 0.6, speed: 0.4, count: 7, life: 11, scale: 0.9, pal: [BLACK, [0.2, 0, 0.1], BLACK], tex: kit.tex(T.shard) }),
  ...sparks(kit, "embers", { at: SECOND + 4, radius: 1.3, speed: 0.14, count: 3, bursts: 3, gap: 4, life: 12, scale: 0.14, pal: [RED, HOT, MAGENTA], fall: 0.008 }),
];

const strikeAt = BOW + PAN;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1470, 2, { pitch: -300, vol: 80 }),
  snd(1509, BOW - 6, { ch: "SE2", pitch: 700, vol: 95 }),
  snd(1407, BOW, { pitch: 300, vol: 120 }),
  snd(1514, strikeAt, { side: "D", pitch: -200, vol: 127 }),
  snd(1514, strikeAt + SECOND, { ch: "SE2", side: "D", pitch: 100, vol: 127 }),
  snd(1475, strikeAt + SECOND, { side: "D", pitch: -200, vol: 120 }),
)}
ScaleSprite ATTACKER, ROUNDTRIP, 819, -1638, ${BOW - 8}, 0, 1
${emits(kit, user, "ATTACKER")}
Wait ${BOW - 4}
${tint("ATTACKER", 0, 9, 2, [31, 6, 10])}
Wait 4
${lunge("ATTACKER", 4)}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${arena(0, 10, 2, [14, 4, 18])}
${emits(kit, foe, "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
Wait ${SECOND}
${hit({ rgb: [31, 16, 20], power: 3, freeze: false })}
${tint("ATTACKER", 9, 0, 4, [31, 6, 10])}
Wait ${AFTER - 10}
${arena(10, 0, 8, [14, 4, 18])}
Wait 10
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 236, 163],
  references: ["reference/False_Surrender_VIII.png", "reference/False_Surrender_IX.png", "reference/False_Surrender_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("redA")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("blackB")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  bow f${CAMERA_IN}-${CAMERA_IN + BOW}, X f${CAMERA_IN + strikeAt}, hit f${CAMERA_IN + strikeAt + SECOND}`);
