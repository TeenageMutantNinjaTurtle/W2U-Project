MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 947
AudioContainer CONTINUE
PlaySound 1727, SE1, 14, 10, 0, 120, 0, 0, 0
PlaySound 1480, SE2, 14, 10, -400, 100, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 9, 0, 50, 0, 0
PlaySound 1727, SE1, 16, 19, -300, 125, 0, 0, 0
PlaySound 1727, SE2, 16, 25, -500, 115, 0, 0, 0
PlaySound 1727, SE1, 16, 31, -200, 105, 0, 0, 0
AudioContainer SUSPEND
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 4, 0, 1
Emit 947, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 947, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 947, 0, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 947, 1, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 10
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -1px, 49152, 0, 4096, 0
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 8
MoveCamera INTERPOLATION, DEFENDER, 9, 0, 8
Wait 9
Emit 947, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 947, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 947, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 947, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 947, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 3, 3, 4
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 12
Wait 19
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 4, 0, 1
Wait 3
ChangeSpriteColor DEFENDER, 12, 0, 0, 3, 3, 4
Wait 18
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
