MoveCamera INTERPOLATION, ZOOM_OUT_PERS, 24, 0, 0
LetCMDsFinish ALL
AudioContainer CONTINUE
PlaySound 1560, SE1, 14, 0, 0, 127, 0, 0, 0
PlaySound 1475, SE1, 14, 10, -500, 100, 0, 0, 0
PlaySound 1652, SE2, 14, 30, 0, 127, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 16, 31, 15, 0, 0
AudioContainer SUSPEND
MoveSprite ATTACKER, ROUNDTRIP_LONG, 2, 0, 2px, 65536, 0, 4096, 0
LetCMDsFinish ALL
MoveCamera INTERPOLATION, DEFENDER, 16, 0, 8
LetCMDsFinish ALL
LoadSPA 659
Emit 659, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 659, 1, DEFENDER, NONE, 1px, 0, 0, 1x, 1x, 1x, 1x
Emit 659, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeScreen VERTICAL, 1229, 0, 2, 0, 8
AudioContainer CONTINUE
PlaySound 1413, SE1, 16, 0, 0, 127, 0, 0, 0
PlaySound 1884, SE2, 16, 0, 0, 127, 0, 0, 0
AudioContainer SUSPEND
ToggleFreezeSprite DEFENDER, START
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 4, 1, 1
MoveSprite DEFENDER, ROUNDTRIP_LONG, 2, 0, 1px, 65536, 0, 4096, 0
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
