MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 951
AudioContainer CONTINUE
PlaySound 1407, SE1, 14, 8, -500, 105, 0, 0, 0
PlaySound 1441, SE1, 16, 18, -300, 110, 0, 0, 0
PlaySound 1441, SE2, 16, 21, -220, 110, 0, 0, 0
PlaySound 1441, SE1, 16, 24, -140, 110, 0, 0, 0
PlaySound 1441, SE2, 16, 27, -60, 110, 0, 0, 0
PlaySound 1441, SE2, 16, 34, -600, 120, 0, 0, 0
PlaySound 1441, SE1, 16, 47, -600, 120, 0, 0, 0
PlaySound 1441, SE2, 16, 60, -600, 120, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 0, 28, 6, 8
Emit 951, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 10
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 8, 0, 0, 28, 6, 8
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
EmitCircle 951, 6, DEFENDER_LEFT, 0.5px, 0.5px, -0.5px, 200, 0, 1, 0
EmitCircle 951, 7, DEFENDER_LEFT, 0.5px, 0.5px, -0.5px, 200, 0, 1, 0
Emit 951, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 951, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 951, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 951, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 951, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 951, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 8
Wait 16
ChangeSpriteColor DEFENDER, 0, 8, 0, 31, 10, 6
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 410, 5, 0, 1
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 3
Wait 13
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 410, 5, 0, 1
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 3
Wait 13
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 410, 5, 0, 1
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 3
ShakeScreen HORIZON, 0.5x, 0, 2, 0, 3
Wait 13
ChangeSpriteColor DEFENDER, 8, 0, 0, 31, 10, 6
Wait 8
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
