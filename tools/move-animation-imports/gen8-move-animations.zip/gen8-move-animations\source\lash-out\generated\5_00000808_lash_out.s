MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 988
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, -400, 95, 0, 0, 0
PlaySound 1869, SE2, 14, 4, -1500, 80, 0, 0, 0
PlaySound 1376, SE1, 14, 24, 0, 0, 0, 0, 0
PlaySound 1425, SE1, 16, 32, -300, 110, 0, 0, 0
PlaySound 1514, SE2, 16, 34, -200, 105, 0, 0, 0
PlaySound 1514, SE2, 16, 42, 0, 105, 0, 0, 0
PlaySound 1407, SE1, 16, 56, -500, 120, 0, 0, 0
PlaySound 1705, SE1, 16, 60, -200, 127, 0, 0, 0
PlaySound 1475, SE2, 16, 60, -400, 125, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 12, 0, 12, 1, 2
ChangeSpriteColor ATTACKER, 0, 9, 0, 22, 10, 31
Emit 988, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 988, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 988, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 10
Wait 24
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 4px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 9, 0, 0, 22, 10, 31
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 988, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 988, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 988, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 988, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 988, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 988, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 988, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 988, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 988, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 988, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 988, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 988, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 988, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 12
Wait 28
ChangeBackgroundColor 4, 15, 15, 0, 20, 2, 3
ChangeSpriteColor DEFENDER, 15, 15, 0, 6, 2, 3
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 6, 2, 3
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 15, 12, 0, 12, 1, 2
Wait 8
ShakeScreen VERTICAL, 2458, 0, 2, 0, 6
Wait 8
ChangeBackgroundColor 4, 12, 0, 0, 12, 1, 2
Wait 10
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
