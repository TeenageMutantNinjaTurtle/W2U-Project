import { createKit, fadeOut, grow, setCurves, T, type Rgb } from "../tools/anim-kit";
import { audio, bolt, emits, FOE, glow, hit, impact, intro, lunge, outro, pan, puffs, snd, sparks, squash, streaks, tint, USER, WHITE, type Pal } from "../tools/phrases";

// Barb Barrage (move 839) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user bristles: purple barbs stand out all round it, beads of
//      magenta venom on them.
//   2. It looses a volley of barbs at the foe.
//   3. They burst on it: magenta spikes jutting out every way, then a
//      splatter of bright magenta venom, drops flying.
// The poison chance and the doubled power on a poisoned foe are the engine's.

const SPA = 1019;
const kit = await createKit({ workDir: import.meta.dirname, slug: "barb-barrage", moveId: 839, spaId: SPA, donors: [228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 10;
const BRISTLE = 18;
const BARBS = 6;
const BARB_GAP = 2;
const TRAVEL = 6;
const AFTER = 24;
const VOLLEY = (BARBS - 1) * BARB_GAP;

const PURPLE: Rgb = [0.5, 0.2, 0.75];
const MAGENTA: Rgb = [1.0, 0.2, 0.85];
const PINK: Rgb = [1.0, 0.65, 0.95];
const DARK: Rgb = [0.25, 0.08, 0.4];
const VENOM: Pal = [MAGENTA, PINK, PURPLE];

// --- 1. the bristle ---
const user = [
  ...streaks(kit, "quills", { pos: USER, radius: 1.1, speed: 0.16, count: 6, bursts: 3, gap: 5, life: 9, scale: 1.0, pal: [PURPLE, PINK, DARK], tex: kit.tex(T.spike) }),
  ...sparks(kit, "beads", { pos: USER, at: 3, radius: 1.5, speed: 0.03, count: 2, bursts: 4, gap: 4, life: 10, scale: 0.2, pal: [MAGENTA, PINK, MAGENTA], shape: "ball", tex: kit.tex(T.softDisc), twinkle: false }),
  ...glow(kit, "menace", { pos: USER, life: BRISTLE + 4, scale: 2.7, pal: [PURPLE, DARK, MAGENTA], level: 0.7 }),
];

// --- 2. the volley ---
bolt(kit, "barbs", { at: BRISTLE, travel: TRAVEL, scale: 1.3, pal: [PURPLE, PINK, DARK], tex: kit.tex(T.spike), count: BARBS, gap: BARB_GAP, spread: 0.9 });
bolt(kit, "barbTrails", { at: BRISTLE, travel: TRAVEL, scale: 1.6, pal: [MAGENTA, PINK, PURPLE], count: BARBS, gap: BARB_GAP, spread: 0.9 });

// --- 3. they burst ---
const foe = [
  ...impact(kit, "stick", { pal: [MAGENTA, PINK, PURPLE], size: 1.2, rays: 0, flecks: 0 }),
  ...streaks(kit, "spikes", { radius: 0.5, speed: 0.3, count: 5, bursts: 3, gap: 4, life: 9, scale: 1.2, pal: [MAGENTA, PINK, PURPLE], tex: kit.tex(T.spike) }),
  // The splatter.
  ...impact(kit, "splat", { at: VOLLEY, pal: [MAGENTA, WHITE, PURPLE], size: 1.6, rays: 7, flecks: 0 }),
  ...puffs(kit, "venom", { pos: FOE, at: VOLLEY, radius: 0.9, count: 4, life: 16, scale: 1.1, pal: VENOM, speed: 0.12, level: 0.95, tex: kit.tex(T.clumps), to: 1.5 }),
  ...sparks(kit, "drops", { at: VOLLEY, radius: 0.6, speed: 0.3, count: 8, life: 18, scale: 0.2, pal: [MAGENTA, PINK, MAGENTA], fall: 0.018, tex: kit.tex(T.softDisc), twinkle: false }),
  ...glow(kit, "taint", { pos: FOE, life: VOLLEY + 16, scale: 3.0, pal: [PURPLE, DARK, MAGENTA], level: 0.6 }),
];
setCurves(kit.resources[kit.idx("spikes")]!, grow(1.1, 0.3, 0.6), fadeOut());

const hitAt = BRISTLE + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1434, 0, { pitch: 300, vol: 105 }),
  snd(1727, 4, { ch: "SE2", pitch: 300, vol: 95 }),
  ...Array.from({ length: 3 }, (_, i) => snd(1539, BRISTLE + i * 4, { ch: i % 2 ? "SE2" : "SE1", pitch: 200 + i * 100, vol: 118 })),
  ...Array.from({ length: 3 }, (_, i) => snd(1423, hitAt + i * 4, { ch: "SE2", side: "D", pitch: 300, vol: 118 })),
  snd(1727, hitAt + VOLLEY, { side: "D", vol: 125 }),
  snd(1475, hitAt + VOLLEY, { ch: "SE2", side: "D", pitch: 200, vol: 120 }),
)}
${tint("ATTACKER", 0, 9, 6, [18, 6, 26])}
${emits(kit, user, "ATTACKER")}
${emits(kit, ["barbs", "barbTrails"], "ATTACKER", "DEFENDER")}
${squash("ATTACKER", 1229, 819, BRISTLE - 4)}
Wait ${BRISTLE}
${lunge("ATTACKER", 3)}
${tint("ATTACKER", 9, 0, 4, [18, 6, 26])}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [28, 10, 28], power: 1, stop: 2 })}
Wait ${VOLLEY / 2 - 2}
${hit({ rgb: [28, 10, 28], power: 1, stop: 2, freeze: false })}
Wait ${VOLLEY / 2 - 2}
${hit({ rgb: [31, 14, 30], power: 3, freeze: false })}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [42, 398, 63, 605, 400, 240, 153, 129],
  references: ["reference/Barb_Barrage_LA.png", "reference/Barb_Barrage_IX.png", "reference/Barb_Barrage_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("quills")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("barbs")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("venom")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  bristle f${CAMERA_IN}, volley f${CAMERA_IN + BRISTLE}, lands f${CAMERA_IN + hitAt}, splatter f${CAMERA_IN + hitAt + VOLLEY}`);
