MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 955
AudioContainer CONTINUE
PlaySound 1435, SE1, 14, 0, 200, 115, 0, 0, 0
PlaySound 1435, SE2, 14, 9, 350, 115, 0, 0, 0
PlaySound 1435, SE1, 14, 18, 500, 115, 0, 0, 0
PlaySound 1869, SE2, 14, 2, 400, 70, 0, 0, 0
PlaySound 1425, SE1, 14, 27, 0, 115, 0, 0, 0
PlaySound 1452, SE2, 14, 33, -300, 115, 0, 0, 0
AudioContainer SUSPEND
Emit 955, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 955, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 955, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 955, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 955, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 955, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 955, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 955, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 955, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 955, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 955, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 955, 11, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 3, 0, 1
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 3
Wait 9
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 3, 0, 1
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 3
Wait 9
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 3, 0, 1
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 3
Wait 9
ChangeBackgroundColor 4, 0, 8, 0, 10, 4, 22
ChangeSpriteColor ATTACKER, 0, 10, 0, 22, 12, 31
ScaleSprite ATTACKER, ROUNDTRIP, -1229, 1229, 5, 0, 1
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 10
Wait 26
ChangeSpriteColor ATTACKER, 10, 0, 0, 22, 12, 31
ChangeBackgroundColor 4, 8, 0, 0, 10, 4, 22
Wait 10
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
