import { createKit, fadeOut, grow, setCurves, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, emits, glow, intro, outro, ring, risers, shake, snd, sparks, squash, streaks, tint, USER, USER_FLOOR, WHITE, type Pal } from "../tools/phrases";

// Clangorous Soul (move 775) - from the Bulbapedia stills (reference/sheet.png).
//   1. Scarlet/Violet: the user clangs its scales - white sound rings ripple
//      off it with pink, cyan and yellow motes.
//   2. Sword/Shield: a violet pool of light spreads under it and a ring of
//      violet-white spikes bursts up all round it.
// Stays on the user; the stat rises and HP cost are the engine's.

const SPA = 955;
const kit = await createKit({ workDir: import.meta.dirname, slug: "clangorous-soul", moveId: 775, spaId: SPA, donors: [228, 465, 411, 321, 298, 560] });

const CAMERA_IN = 10;
const CLANGS = 3;
const CLANG_GAP = 9;
const CLANG = CLANGS * CLANG_GAP;
const SOUL = 36;

const VIOLET: Rgb = [0.65, 0.35, 1.0];
const PALE_VIOLET: Rgb = [0.9, 0.8, 1.0];
const DEEP: Rgb = [0.4, 0.15, 0.8];
const PAL: Pal = [VIOLET, PALE_VIOLET, DEEP];
const MOTES: Pal = [[1.0, 0.5, 0.85], [0.4, 0.95, 1.0], [1.0, 0.9, 0.35]];
const HEAD: [number, number, number] = [0.2, 1.0, 0.3];

const user = [
  // --- 1. the clanging scales ---
  ...Array.from({ length: CLANGS }, (_, i) => ring(kit, `clang${i}`, { pos: HEAD, at: i * CLANG_GAP, scale: 0.9, pal: [WHITE, WHITE, [1.0, 0.92, 0.7]], tex: kit.tex(T.ring), to: 2.4, life: 12 })).flat(),
  ...Array.from({ length: CLANGS }, (_, i) => ring(kit, `clangInner${i}`, { pos: HEAD, at: i * CLANG_GAP + 2, scale: 0.6, pal: [[1.0, 0.92, 0.7], WHITE, [1.0, 0.8, 0.4]], tex: kit.tex(T.hoop), to: 2.0, life: 10, level: 0.8 })).flat(),
  ...sparks(kit, "scaleMotes", { pos: HEAD, radius: 0.6, speed: 0.2, count: 4, bursts: CLANGS, gap: CLANG_GAP, life: 14, scale: 0.2, pal: MOTES, tex: kit.tex(T.softDisc) }),
  // --- 2. the soul: a violet pool and a ring of spikes bursting up ---
  ...glow(kit, "pool", { pos: [0, -1.5, 0.2], at: CLANG - 4, life: SOUL + 4, scale: 1.4, pal: [VIOLET, DEEP, PALE_VIOLET], aspect: 2.6, level: 0.85 }),
  ...ring(kit, "poolRing", { pos: [0, -1.5, 0.25], at: CLANG - 2, life: SOUL, scale: 1.25, pal: [PALE_VIOLET, WHITE, VIOLET], tex: kit.tex(T.ring), aspect: 2.6, to: 1.15, level: 0.9 }),
  ...streaks(kit, "spikes", { pos: [0, -1.3, 0.2], at: CLANG, radius: 2.6, speed: 0.02, count: 5, bursts: 7, gap: 4, life: 10, scale: 0.9, pal: [VIOLET, PALE_VIOLET, WHITE], tex: kit.tex(T.spike), flat: true, lift: 0.2 }),
  ...glow(kit, "aura", { pos: USER, at: CLANG, life: SOUL, scale: 2.9, pal: [VIOLET, DEEP, PALE_VIOLET], level: 0.6 }),
  ...risers(kit, "soulMotes", { pos: USER_FLOOR, at: CLANG + 2, frames: SOUL - 14, radius: 1.4, speed: 0.2, scale: 0.15, life: 14, every: 3, pal: [PALE_VIOLET, WHITE, VIOLET] }),
];
// The spikes shoot up tall and thin out.
setCurves(kit.resources[kit.idx("spikes")]!, grow(0.6, 0.3, 1.2), fadeOut(1, 0.5));

const clangs = Array.from({ length: CLANGS }, () => `${squash("ATTACKER", 819, -819, 3)}\n${shake("ATTACKER", 1229, 3)}\nWait ${CLANG_GAP}`).join("\n");
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  ...Array.from({ length: CLANGS }, (_, i) => snd(1435, i * CLANG_GAP, { ch: i % 2 ? "SE2" : "SE1", pitch: 200 + i * 150, vol: 115 })),
  snd(1869, 2, { ch: "SE2", pitch: 400, vol: 70 }),
  snd(1425, CLANG, { vol: 115 }),
  snd(1452, CLANG + 6, { ch: "SE2", pitch: -300, vol: 115 }),
)}
${emits(kit, user, "ATTACKER")}
${clangs}
${arena(0, 8, 4, [10, 4, 22])}
${tint("ATTACKER", 0, 10, 4, [22, 12, 31])}
${squash("ATTACKER", -1229, 1229, 5)}
${shake("ATTACKER", 819, 10)}
Wait ${SOUL - 10}
${tint("ATTACKER", 10, 0, 6, [22, 12, 31])}
${arena(8, 0, 8, [10, 4, 22])}
Wait 10
${outro({ unfreeze: "NONE" })}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 240, 153, 129, 381],
  references: ["reference/Clangorous_Soul_VIII.png", "reference/Clangorous_Soul_IX.png", "reference/Clangorous_Soul_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("clang0")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("spikes")}, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  clangs f${CAMERA_IN}-${CAMERA_IN + CLANG}, soul f${CAMERA_IN + CLANG}-${CAMERA_IN + CLANG + SOUL}`);
