// Reusable effect "phrases" for the move generators, built on anim-kit.
//
// Each resource phrase adds one or more named resources to the kit and returns
// their names, so a script can emit them in one go with emits(). `at` is the
// delay in frames after the Emit command, which lets a script emit a whole
// side's effects at one point and have them play in sequence.
//
// Coordinates are offsets from the Emit anchor (ATTACKER or DEFENDER at "2px",
// mid-body): +x right, +y up, +z toward the camera. A Pokemon is about 4 units
// tall; the two stand about 16 apart. A quad's scale is its half-extent.
import { aimed, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, T, type Curve3, type Kit, type Rgb, type Vec3 } from "./anim-kit";

export const FOE: Vec3 = [0, 0.3, 0.8];
export const USER: Vec3 = [0, 0.3, 0.2];
export const FRONT: Vec3 = [0.3, 0.6, -1.0]; // just ahead of the user, toward the foe
export const FOE_FLOOR: Vec3 = [0, -1.5, 0.8];
export const USER_FLOOR: Vec3 = [0, -1.5, 0.2];
export const WHITE: Rgb = [1, 1, 1];
export const BLACK: Rgb = [0.05, 0.04, 0.06];
/** [main, light, deep] */
export type Pal = [Rgb, Rgb, Rgb];
type Res = ReturnType<Kit["parked"]>;

/** Streaks keep their size, tapering a little at each end (the 228/3 shell's own curve flickers between 1.6x and 0.5x). */
const STEADY: Curve3 = { start: 0.7, mid: 1, end: 0.75, curveIn: 0.2, curveOut: 0.7 };
const delay = <R extends Res>(r: R, at: number): R => { r.startDelayFrames = at; return r; };
export const up = (pos: Vec3, dy: number): Vec3 => [pos[0], pos[1] + dy, pos[2]];
export const off = (pos: Vec3, dx: number, dy = 0, dz = 0): Vec3 => [pos[0] + dx, pos[1] + dy, pos[2] + dz];

// --- resources -----------------------------------------------------------------

/** The standard hit burst: sunburst, spiky flash, rays spreading from the point, flecks. */
export function impact(kit: Kit, p: string, o: { pos?: Vec3; at?: number; pal: Pal; size?: number; rays?: number; flecks?: number; spiky?: boolean; flash?: boolean }): string[] {
  const pos = o.pos ?? FOE, at = o.at ?? 0, size = o.size ?? 1, names: string[] = [];
  const add = (n: string, r: Res) => { kit.add(p + n, delay(r, at)); names.push(p + n); };
  if (o.flash ?? true) {
    const flash = kit.parked(kit.tex(T.sunburst), pos, 1.6 * size, 12);
    spin(flash, 0.05);
    setCurves(flash, grow(0.4, 0.2, 1.8), fadeOut(1, 0.35));
    paint(flash, o.pal[1], WHITE, o.pal[0]);
    add("Flash", flash);
  }
  if (o.spiky ?? true) {
    const spiky = kit.parked(kit.tex(T.spiky), pos, 1.25 * size, 10);
    spin(spiky, 0.12);
    setCurves(spiky, grow(0.4, 0.25, 1.3), fadeOut(1, 0.4));
    paint(spiky, o.pal[0], WHITE, o.pal[2]);
    add("Spiky", spiky);
  }
  if ((o.rays ?? 8) > 0) {
    const rays = kit.spray([228, 3], kit.tex(T.hairStreak), pos, { radius: 0.4 * size, speed: 0.4 * size, count: o.rays ?? 8, life: 10, scale: 1.1 * size, shape: "circle", directional: true });
    setCurves(rays, STEADY, fadeOut(1, 0.45));
    kit.prism(rays, [o.pal[0], WHITE, o.pal[1]]);
    add("Rays", rays);
  }
  if ((o.flecks ?? 8) > 0) {
    const flecks = kit.spray([333, 1], kit.tex(T.dot), pos, { radius: 0.5 * size, speed: 0.28 * size, count: o.flecks ?? 8, life: 14, scale: 0.15, shape: "circle" });
    flecks.variance.lifeTime = 0;
    flecks.airResistance = 0.93;
    setCurves(flecks, undefined, fadeOut(1, 0.6));
    kit.prism(flecks, o.pal);
    add("Flecks", flecks);
  }
  return names;
}

/** A soft glow (or any single parked texture) that fades in, holds and fades out. */
export function glow(kit: Kit, name: string, o: { pos?: Vec3; at?: number; life: number; scale: number; pal: Pal; level?: number; tex?: number; spin?: number; aspect?: number; angle?: number; scaleCurve?: Curve3; alpha?: Curve3 }): string[] {
  const r = kit.parked(o.tex ?? kit.tex(T.fuzzyGlow), o.pos ?? USER, o.scale, o.life);
  if (o.spin !== undefined || o.angle !== undefined) spin(r, o.spin ?? 0, o.spin ?? 0, o.angle ?? 0);
  if (o.aspect !== undefined) r.aspectRatio = o.aspect;
  setCurves(r, o.scaleCurve ?? grow(0.6, 0.3, 1.1), o.alpha ?? fadeInOut(o.level ?? 0.8, 0.2, 0.7));
  paint(r, o.pal[0], o.pal[1], o.pal[2]);
  kit.add(name, delay(r, o.at ?? 0));
  return [name];
}

/** A ring (or any texture) that swells outward and fades: shockwaves, pulses. */
export function ring(kit: Kit, name: string, o: { pos?: Vec3; at?: number; life?: number; scale: number; pal: Pal; tex?: number; to?: number; spin?: number; aspect?: number; level?: number }): string[] {
  const r = kit.parked(o.tex ?? kit.tex(T.ring), o.pos ?? FOE, o.scale, o.life ?? 12);
  if (o.spin) spin(r, o.spin);
  if (o.aspect !== undefined) r.aspectRatio = o.aspect;
  setCurves(r, grow(0.3, 0.35, o.to ?? 1.6), fadeInOut(o.level ?? 0.95, 0.08, 0.5));
  paint(r, o.pal[0], o.pal[1], o.pal[2]);
  kit.add(name, delay(r, o.at ?? 0));
  return [name];
}

/** Energy drawn in to a point: converging motes plus a glow that builds. */
export function gather(kit: Kit, p: string, o: { pos?: Vec3; at?: number; frames: number; pal: Pal; radius?: number; scale?: number; streaks?: boolean }): string[] {
  const pos = o.pos ?? USER, at = o.at ?? 0, radius = o.radius ?? 2.6;
  const motes = o.streaks
    ? kit.spray([228, 3], kit.tex(T.hairStreak), pos, { radius, speed: 0, count: 2, bursts: Math.round(o.frames / 2), gap: 2, life: 8, scale: 0.6, shape: "circle", directional: true })
    : kit.spray([333, 1], kit.tex(T.dot), pos, { radius, speed: 0, count: 1, bursts: Math.round(o.frames / 2), gap: 2, life: 10, scale: 0.14, shape: "sphere" });
  motes.variance.lifeTime = 0;
  if (o.streaks) {
    // A directional quad points along its velocity, and convergence moves a
    // particle without giving it one (the streaks stood upright). Fly them
    // inward instead: a negative outward speed, timed to reach the centre.
    motes.initVelPosAmplifier = -radius / 9; // most of the way in over its 8-frame life
    motes.airResistance = 1.0;
  } else {
    motes.behaviors = [{ type: "convergence", target: [0, 0, 0], force: radius / 24 }];
  }
  setCurves(motes, o.streaks ? STEADY : undefined, o.streaks ? fadeInOut(0.9, 0.2, 0.7) : twinkle());
  kit.prism(motes, [o.pal[0], WHITE, o.pal[1]]);
  kit.add(`${p}In`, delay(motes, at));
  const g = kit.parked(kit.tex(T.fuzzyGlow), pos, o.scale ?? 2.4, o.frames + 4);
  setCurves(g, { start: 0.3, mid: 0.7, end: 1.15, curveIn: 0.5, curveOut: 0.6 }, { start: 0, mid: 0.5, end: 0.95, curveIn: 0.4, curveOut: 0.8 });
  paint(g, o.pal[0], o.pal[2], o.pal[1]);
  kit.add(`${p}Glow`, delay(g, at));
  return [`${p}In`, `${p}Glow`];
}

/** Hyper Beam's stream as a two-layer beam. Emit toward DEFENDER. Reaches the foe `travel` frames after it starts. */
export function beam(kit: Kit, p: string, o: { from?: Vec3; at?: number; pour: number; travel?: number; width?: number; pal: Pal; core?: Rgb; tex?: number; dive?: number }): string[] {
  const travel = o.travel ?? 9;
  const layer = (scale: number, every: number, base: Rgb, start: Rgb, end: Rgb) => {
    const r = kit.shell(228, 0);
    r.textureIndex = o.tex ?? kit.tex(T.sunburst);
    aimed(r, 16 / travel, travel + 1, o.dive ?? 0);
    Object.assign(r, { emitterBasePos: [...(o.from ?? FRONT)], baseScale: scale, emitterLifeFrames: o.pour, emissionIntervalFrames: every, airResistance: 1.0 });
    setCurves(r, { start: 0.8, mid: 1.0, end: 1.2, curveIn: 0.5, curveOut: 0.5 }, hold(1));
    paint(r, base, start, end, 0.4);
    return delay(r, o.at ?? 0);
  };
  const width = o.width ?? 1.2;
  kit.add(`${p}Jet`, layer(width, 1, o.pal[0], o.pal[1], o.pal[2]));
  kit.add(`${p}Core`, layer(width * 0.48, 2, o.core ?? WHITE, WHITE, o.pal[1]));
  return [`${p}Jet`, `${p}Core`];
}

/** One quad thrown from the user to the foe. Emit toward DEFENDER. It is gone as it arrives, `travel` frames later. */
export function shot(kit: Kit, name: string, tex: number, o: { from?: Vec3; at?: number; travel: number; scale: number; pal: Pal; spin?: number; angle?: number; aspect?: number; dive?: number; scaleCurve?: Curve3; alpha?: Curve3; count?: number; gap?: number; lateral?: number }): Res {
  const from = o.from ?? FRONT;
  const r = kit.parked(tex, from, o.scale, o.travel + 1);
  aimed(r, 16 / o.travel, o.travel + 1, o.dive ?? 0);
  r.airResistance = 1.0;
  if (o.spin !== undefined || o.angle !== undefined) spin(r, o.spin ?? 0, o.spin ?? 0, o.angle ?? 0);
  if (o.aspect !== undefined) r.aspectRatio = o.aspect;
  if (o.count && o.count > 1) Object.assign(r, { emitterLifeFrames: (o.count - 1) * (o.gap ?? 3) + 1, emissionIntervalFrames: o.gap ?? 3 });
  // The engine aims an emitter forward only; a sideways pull closes a lateral offset over the flight.
  if (o.lateral) r.behaviors = [{ type: "gravity", magnitude: [(-2 * o.lateral) / (o.travel * o.travel), 0, 0] }];
  setCurves(r, o.scaleCurve ?? hold(1), o.alpha ?? hold(1));
  paint(r, o.pal[0], o.pal[1], o.pal[2]);
  kit.add(name, delay(r, o.at ?? 0));
  return r;
}

/** A streak that flies from the user to the foe pointing along its path (darts, needles, thin bolts). Emit toward DEFENDER. */
export function bolt(kit: Kit, name: string, o: { from?: Vec3; at?: number; travel: number; scale: number; pal: Pal; tex?: number; count?: number; gap?: number; spread?: number; dive?: number }): Res {
  const r = kit.spray([228, 3], o.tex ?? kit.tex(T.hairStreak), o.from ?? FRONT, { radius: o.spread ?? 0, speed: 0, count: 1, bursts: o.count ?? 1, gap: o.gap ?? 3, life: o.travel + 1, scale: o.scale, shape: o.spread ? "circle" : "point", directional: true });
  aimed(r, 16 / o.travel, o.travel + 1, o.dive ?? 0);
  r.airResistance = 1.0;
  if (r.variance) Object.assign(r.variance, { lifeTime: 0, baseScale: 0 });
  setCurves(r, hold(1), hold(1));
  paint(r, o.pal[0], o.pal[1], o.pal[2]);
  kit.add(name, delay(r, o.at ?? 0));
  return r;
}

/** Soft cloud puffs (Explosion's): smoke, steam, dust, gas, mist. `rise` drifts them upward. */
export function puffs(kit: Kit, name: string, o: { pos?: Vec3; at?: number; radius?: number; count?: number; bursts?: number; gap?: number; life?: number; scale: number; pal: Pal; speed?: number; rise?: number; level?: number; tex?: number; to?: number }): string[] {
  const r = kit.spray([333, 1], o.tex ?? kit.tex(T.puff), o.pos ?? FOE, { radius: o.radius ?? 0.8, speed: o.speed ?? 0.05, count: o.count ?? 2, bursts: o.bursts ?? 1, gap: o.gap ?? 3, life: o.life ?? 14, scale: o.scale, shape: "ball" });
  r.variance.lifeTime = 0;
  if (o.rise) { r.axis = [0, 1, 0]; r.initVelAxisAmplifier = o.rise; }
  spin(r, -0.06, 0.06, 0, true);
  setCurves(r, grow(0.5, 0.3, o.to ?? 1.5), fadeInOut(o.level ?? 0.85, 0.15, 0.5));
  paint(r, o.pal[0], o.pal[1], o.pal[2]);
  kit.add(name, delay(r, o.at ?? 0));
  return [name];
}

/** Small glowing particles thrown outward (sparks, droplets, embers, sparkles). `fall` pulls them down, negative lifts them. */
export function sparks(kit: Kit, name: string, o: { pos?: Vec3; at?: number; radius?: number; speed?: number; count?: number; bursts?: number; gap?: number; life?: number; scale?: number; pal: Pal; fall?: number; shape?: "sphere" | "ball" | "circle"; tex?: number; twinkle?: boolean; spin?: number }): string[] {
  const r = kit.spray([333, 1], o.tex ?? kit.tex(T.dot), o.pos ?? FOE, { radius: o.radius ?? 0.5, speed: o.speed ?? 0.2, count: o.count ?? 4, bursts: o.bursts ?? 1, gap: o.gap ?? 3, life: o.life ?? 12, scale: o.scale ?? 0.14, shape: o.shape ?? "sphere" });
  r.variance.lifeTime = 0;
  if (o.fall) r.behaviors = [{ type: "gravity", magnitude: [0, -o.fall, 0] }];
  if (o.spin) spin(r, -o.spin, o.spin, 0, true);
  setCurves(r, undefined, o.twinkle === false ? fadeOut(1, 0.6) : twinkle());
  kit.prism(r, o.pal);
  kit.add(name, delay(r, o.at ?? 0));
  return [name];
}

/** Thin streaks flying outward from a point, each pointing along its motion (speed lines, shards, flame tongues). */
export function streaks(kit: Kit, name: string, o: { pos?: Vec3; at?: number; radius?: number; speed?: number; count?: number; bursts?: number; gap?: number; life?: number; scale?: number; pal: Pal; shape?: "sphere" | "circle"; tex?: number; flat?: boolean; lift?: number; scaleCurve?: Curve3 }): string[] {
  const r = kit.spray([228, 3], o.tex ?? kit.tex(T.hairStreak), o.pos ?? FOE, { radius: o.radius ?? 0.4, speed: o.speed ?? 0.4, count: o.count ?? 6, bursts: o.bursts ?? 1, gap: o.gap ?? 3, life: o.life ?? 10, scale: o.scale ?? 1.1, shape: o.shape ?? "circle", directional: true });
  if (o.flat) r.emissionAxis = 1; // a ring lying on the ground instead of facing the camera
  if (o.lift) { r.axis = [0, 1, 0]; r.initVelAxisAmplifier = o.lift; }
  setCurves(r, o.scaleCurve ?? STEADY, fadeOut(1, 0.45));
  kit.prism(r, o.pal);
  kit.add(name, delay(r, o.at ?? 0));
  return [name];
}

/** Particles rising round a Pokemon from the ground: buff auras, heat, healing motes. */
export function risers(kit: Kit, name: string, o: { pos?: Vec3; at?: number; frames: number; radius?: number; speed?: number; scale?: number; life?: number; every?: number; count?: number; pal: Pal; tex?: number; streak?: boolean }): string[] {
  const shell: readonly [number, number] = o.streak ? [228, 3] : [333, 1];
  const every = o.every ?? 2;
  const r = kit.spray(shell, o.tex ?? kit.tex(o.streak ? T.hairStreak : T.dot), o.pos ?? USER_FLOOR, { radius: o.radius ?? 1.3, speed: 0, count: o.count ?? 1, bursts: Math.max(1, Math.round(o.frames / every)), gap: every, life: o.life ?? 14, scale: o.scale ?? (o.streak ? 1.0 : 0.16), shape: "circle", directional: o.streak ? true : undefined });
  r.emissionAxis = 1;
  r.axis = [0, 1, 0];
  r.initVelAxisAmplifier = o.speed ?? 0.22;
  r.airResistance = 1.0;
  r.variance.lifeTime = 0;
  setCurves(r, o.streak ? STEADY : undefined, fadeInOut(0.95, 0.2, 0.6));
  kit.prism(r, o.pal);
  kit.add(name, delay(r, o.at ?? 0));
  return [name];
}

/** Point a cloned donor resource's texture and texture animation at this move's copies of the donor's textures. */
export function remapAnim(kit: Kit, r: Res, spaId: number): Res {
  r.textureIndex = kit.tex(spaId, r.textureIndex);
  if (r.texAnim) r.texAnim.textures = r.texAnim.textures.map((t, i) => (i < r.texAnim!.textureCount ? kit.tex(spaId, t) : 0));
  return r;
}

/** Retail flames (Fire Blast's flickering orange flame frames) burning at a spot and licking upward. Needs donor 295. */
export function flames(kit: Kit, name: string, o: { pos?: Vec3; at?: number; frames: number; every?: number; life?: number; scale?: number; rise?: number; radius?: number }): string[] {
  const r = remapAnim(kit, kit.shell(295, 1), 295);
  Object.assign(r, { emitterBasePos: [...(o.pos ?? USER)], baseScale: o.scale ?? 0.9, emitterLifeFrames: o.frames, emissionIntervalFrames: o.every ?? 3, particleLifeFrames: o.life ?? 10, initVelAxisAmplifier: o.rise ?? 0.03, radius: o.radius ?? 0.2, axis: [0, 1, 0] });
  kit.add(name, delay(r, o.at ?? 0));
  return [name];
}

/** Sing's music notes drifting up from a spot, each one of three note shapes in one of the palette's colours. Needs donor 212. */
export function notes(kit: Kit, p: string, o: { pos?: Vec3; at?: number; frames: number; every?: number; life?: number; scale?: number; rise?: number; radius?: number; pal: Pal }): string[] {
  const every = o.every ?? 6;
  return [0, 1, 2].map((i) => {
    const r = kit.spray([333, 1], kit.tex(212, 1 + i), o.pos ?? USER, { radius: o.radius ?? 1.2, speed: 0.01, count: 1, bursts: Math.max(1, Math.round(o.frames / every)), gap: every, life: o.life ?? 18, scale: o.scale ?? 0.4, shape: "ball" });
    r.variance.lifeTime = 0;
    r.axis = [i === 1 ? -0.2 : 0.2, 1, 0];
    r.initVelAxisAmplifier = o.rise ?? 0.07;
    r.airResistance = 1.0;
    setCurves(r, hold(1), fadeInOut(1, 0.15, 0.7));
    kit.prism(r, [o.pal[i]!, o.pal[(i + 1) % 3]!, o.pal[(i + 2) % 3]!]);
    kit.add(`${p}${i}`, delay(r, (o.at ?? 0) + Math.round((i * every) / 3)));
    return `${p}${i}`;
  });
}

/**
 * Hurricane's tornado: crescent swooshes circling a Pokemon (needs donor 711).
 * Emit the returned names with circleEmits(), not emits(): they ride an
 * orbiting emitter.
 * `pace` slows the whole thing down (1 = Hurricane's own): the swooshes rise
 * that much slower and live that much longer, so the tornado keeps its height
 * (`life` is the swooshes' life at pace 1, which sets that height).
 * `alpha` makes it fainter (1 = Hurricane's own).
 * `down` turns it over: the swooshes start at the top and sink, widening as
 * they go, so it bears down on the Pokemon instead of lifting off it. Give
 * circleEmits() a `y` above the Pokemon to start it from.
 */
export function vortex(kit: Kit, p: string, o: { at?: number; frames: number; pal: Pal; widen?: number; life?: number; pace?: number; alpha?: number; down?: boolean }): string[] {
  const pace = o.pace ?? 1;
  const layer = (index: number, at: number, every: number, life: number, c: Rgb, start: Rgb, end: Rgb) => {
    const r = kit.shell(711, index);
    r.textureIndex = kit.tex(711, r.textureIndex);
    Object.assign(r, { baseScale: r.baseScale * (o.widen ?? 1.3), startDelayFrames: (o.at ?? 0) + at, emitterLifeFrames: Math.max(1, o.frames - at), emissionIntervalFrames: Math.round(every / pace), particleLifeFrames: Math.round(life / pace), initVelAxisAmplifier: r.initVelAxisAmplifier * pace, baseAlpha: r.baseAlpha * (o.alpha ?? 1) });
    if (o.down) Object.assign(r, { axis: [0, -1, 0], emitterBasePos: [r.emitterBasePos[0], -r.emitterBasePos[1], r.emitterBasePos[2]] });
    paint(r, c, start, end, 0.5);
    return r;
  };
  kit.add(`${p}Inner`, layer(2, 0, 4, o.life ?? 20, o.pal[0], o.pal[1], o.pal[2]));
  kit.add(`${p}Outer`, layer(4, 4, 5, (o.life ?? 20) + 2, o.pal[2], o.pal[1], o.pal[0]));
  return [`${p}Inner`, `${p}Outer`];
}
/**
 * EmitCircle lines for vortex() resources, centred on a Pokemon. `y` lifts
 * or lowers the tornado (Hurricane's own sits at -1, on the ground), `frames`
 * is how long the emitter takes to circle once, `radius` how wide it circles.
 */
export const circleEmits = (kit: Kit, names: string[], who: Side, o: { y?: number; frames?: number; radius?: number } = {}) =>
  names.map((n) => `EmitCircle ${kit.options.spaId}, ${kit.idx(n)}, ${who}_LEFT, ${o.radius ?? 0.5}px, ${o.radius ?? 0.5}px, ${o.y ?? -1}px, ${o.frames ?? 120}, 0, 1, 0`).join("\n");

/** Thunder's crackling squiggle arcs (animated) round a point. Needs donor 257. */
export function zaps(kit: Kit, name: string, o: { pos?: Vec3; at?: number; radius?: number; speed?: number; count?: number; bursts?: number; gap?: number; life?: number; scale?: number; pal: Pal; shape?: "sphere" | "ball" | "circle" }): string[] {
  const shell = remapAnim(kit, kit.shell(257, 0), 257);
  const r = kit.spray(shell, shell.textureIndex, o.pos ?? FOE, { radius: o.radius ?? 1.0, speed: o.speed ?? 0, count: o.count ?? 1, bursts: o.bursts ?? 4, gap: o.gap ?? 3, life: o.life ?? 6, scale: o.scale ?? 0.6, shape: o.shape ?? "ball" });
  r.texAnim = structuredClone(shell.texAnim); // spray() retextures; put the animation back
  spin(r, 0, 0, 0, true);
  if (r.alphaAnim) setCurves(r, undefined, fadeOut(1, 0.6));
  r.loopFrames = 7;
  if (r.colorAnim) kit.prism(r, o.pal);
  else paint(r, o.pal[0]);
  kit.add(name, delay(r, o.at ?? 0));
  return [name];
}

/**
 * A bite with Crunch's fang textures (needs donor 413): upper and lower fangs
 * hang open over the point, snap shut, and hold for a moment. The jaws meet
 * BITE_FRAMES after `at`. (Crunch's own resources rely on a magnet behaviour
 * the preview does not follow, so the motion is built here instead.)
 */
export const BITE_FRAMES = 9;
export function fangs(kit: Kit, p: string, o: { pos?: Vec3; at?: number; tint?: Rgb; scale?: number; hold?: number } = {}): string[] {
  const pos = o.pos ?? FOE, at = o.at ?? 0, scale = o.scale ?? 1.5, colour = o.tint ?? WHITE;
  const GAPE = 1.5 * scale, SHUT = 0.42 * scale, OPEN = 6, SNAP = BITE_FRAMES - OPEN;
  const names: string[] = [];
  for (const [jaw, tex, side] of [["Upper", kit.tex(413, 1), 1], ["Lower", kit.tex(413, 0), -1]] as const) {
    const quad = (y: number, life: number, start: number) => {
      const r = kit.parked(tex, [pos[0], pos[1] + side * y, pos[2] + 0.25], scale, life);
      paint(r, colour);
      return delay(r, at + start);
    };
    const open = quad(GAPE, OPEN + 1, 0);
    setCurves(open, grow(0.75, 0.5, 1), { start: 0, mid: 1, end: 1, curveIn: 0.35, curveOut: 1 });
    const snap = quad(GAPE, SNAP + 1, OPEN);
    snap.axis = [0, -side, 0];
    snap.initVelAxisAmplifier = (GAPE - SHUT) / SNAP;
    setCurves(snap, hold(1), hold(1));
    const shut = quad(SHUT, o.hold ?? 8, BITE_FRAMES);
    setCurves(shut, { start: 1.15, mid: 1, end: 1, curveIn: 0.2, curveOut: 1 }, fadeOut(1, 0.6));
    for (const [n, r] of [["Open", open], ["Snap", snap], ["Shut", shut]] as const) { kit.add(p + jaw + n, r); names.push(p + jaw + n); }
  }
  return names;
}

/** A single slash mark: Slash's streak laid across a point at `angle` degrees from horizontal. */
export function slash(kit: Kit, name: string, o: { pos?: Vec3; at?: number; angle: number; scale?: number; pal: Pal; life?: number; tex?: number; aspect?: number }): string[] {
  const r = kit.parked(o.tex ?? kit.tex(T.streak), o.pos ?? off(FOE, 0, 0, 0.1), o.scale ?? 3.0, o.life ?? 8);
  r.aspectRatio = o.aspect ?? 0.2;
  r.initAngle = deg(90 + o.angle); // the streak texture is a vertical line
  setCurves(r, grow(0.15, 0.2, 1.05), fadeOut(1, 0.45));
  paint(r, o.pal[0], WHITE, o.pal[2]);
  kit.add(name, delay(r, o.at ?? 0));
  return [name];
}

// --- script --------------------------------------------------------------------

export type Side = "ATTACKER" | "DEFENDER";
export const emits = (kit: Kit, names: string[], who: Side, toward = "NONE", y = "2px") => names.map((n) => kit.emit(n, who, toward, y)).join("\n");

/** PlaySound line. side "A" plays from the user's side, "D" from the foe's. */
export const snd = (id: number, at: number, o: { ch?: "SE1" | "SE2" | "PSG"; side?: "A" | "D" | "FLAT"; pitch?: number; vol?: number } = {}) =>
  `PlaySound ${id}, ${o.ch ?? "SE1"}, ${o.side === "FLAT" ? "FLAT" : o.side === "D" ? 16 : 14}, ${at}, ${o.pitch ?? 0}, ${o.vol ?? 110}, 0, 0, 0`;
export const audio = (...lines: string[]) => ["AudioContainer CONTINUE", ...lines, "AudioContainer SUSPEND"].join("\n");

/** Camera pushes in on the user, then the move's SPA loads. */
export const intro = (spa: number, frames = 12) => `MoveCamera INTERPOLATION, ATTACKER, ${frames}, 0, 8\nLetCMDsFinish CAMERA\nLoadSPA ${spa}`;
/** For multi-hit moves and quick moves: no camera move. */
export const introStill = (spa: number) => `LoadSPA ${spa}`;
export const pan = (to: Side | "INIT", frames = 10) => `MoveCamera INTERPOLATION, ${to}, ${frames}, 0, 8`;
export const outro = (o: { camera?: boolean; unfreeze?: Side | "BOTH" | "NONE" } = {}) =>
  ["LetCMDsFinish PARTICLE", ...(o.unfreeze === "NONE" ? [] : o.unfreeze === "BOTH" ? ["ToggleFreezeSprite ATTACKER, STOP", "ToggleFreezeSprite DEFENDER, STOP"] : [`ToggleFreezeSprite ${o.unfreeze ?? "DEFENDER"}, STOP`]), ...(o.camera === false ? [] : ["MoveCamera INTERPOLATION, INIT, 12, 0, 8"]), "LetCMDsFinish ALL", "TerminateMoveScript", ""].join("\n");

/**
 * The full script of a two-turn move: part 0 plays on the charging turn and
 * part 1 on the attack (as retail Solar Beam). Each part is a complete command
 * list, with its own LoadSPA, ending in TerminateMoveScript.
 */
export function twoPart(charge: string, fire: string): string {
  const header = (label: string) => Array.from({ length: 14 }, () => `.word ${label}`).join("\n");
  return `.include "B2W2_MOVSCRCMD.s"\n.align 4\n\n.word 2 @ Count\n${header("SCRIPT_CHARGE")}\n${header("SCRIPT_FIRE")}\n\nSCRIPT_CHARGE:\n${charge.trimEnd()}\n\nSCRIPT_FIRE:\n${fire.trimEnd()}\n`;
}

/**
 * Several whole scripts in one animation. The battle engine picks which one
 * plays by an index it passes in - retail Weather Ball's five are chosen by
 * the weather, Techno Blast's by the Drive - so the scripts themselves cannot
 * choose: whatever runs the move has to pass the index. Index 0 plays when
 * nothing is passed. Each body is a complete script (its own LoadSPA, ending
 * in TerminateMoveScript).
 */
export function variants(bodies: string[]): string {
  const header = (label: string) => Array.from({ length: 14 }, () => `.word ${label}`).join("\n");
  const table = bodies.map((_, i) => header(`SCRIPT_V${i}`)).join("\n");
  const scripts = bodies.map((body, i) => `SCRIPT_V${i}:\n${body.trimEnd()}`).join("\n\n");
  return `.include "B2W2_MOVSCRCMD.s"\n.align 4\n\n.word ${bodies.length} @ Count\n${table}\n\n${scripts}\n`;
}

/**
 * The engine's colour fades move the blend one step every (wait + 1) frames:
 * the command's fourth argument is that wait, not a duration (retail only
 * ever passes 0-12). This turns "from, to, over this many frames" into the
 * engine's terms. 0 frames sets the blend at once, which the engine spells as
 * a fade from the value to itself; nothing is quicker than a step a frame.
 */
const fade = (from: number, to: number, frames: number): string => {
  const steps = Math.abs(to - from);
  if (steps === 0 || frames <= 0) return `${to}, ${to}, 0`;
  return `${from}, ${to}, ${Math.max(0, Math.round(frames / steps) - 1)}`;
};
/** Sprite tint: blend 0-16 toward a 5-bit colour over about `frames` (see `fade`). */
export const tint = (who: Side, from: number, to: number, frames: number, [r, g, b]: [number, number, number]) => `ChangeSpriteColor ${who}, ${fade(from, to, frames)}, ${r}, ${g}, ${b}`;
/** Arena tint (blend 0-16 toward a 5-bit colour) over about `frames` (see `fade`). */
export const arena = (from: number, to: number, frames: number, [r, g, b]: [number, number, number]) => `ChangeBackgroundColor 4, ${fade(from, to, frames)}, ${r}, ${g}, ${b}`;
/** The user lunges toward the foe and back. */
export const lunge = (who: Side = "ATTACKER", px = 2) => `MoveSprite ${who}, ROUNDTRIP, 0, 0, ${px}px, 49152, 0, 4096, 0`;
/**
 * A squash and spring back: the sprite's scale moves by (x, y) over `frames`
 * frames and returns over as many (ScaleSprite ROUNDTRIP: steps, wait per step,
 * count). The engine adds a round trip onto whatever the scale is when it
 * starts, so one that begins before the last has finished never springs fully
 * back: leave at least 2 x frames between squashes of the same sprite.
 */
export const squash = (who: Side, x = 1229, y = -1229, frames = 3) => `ScaleSprite ${who}, ROUNDTRIP, ${x}, ${y}, ${Math.max(1, Math.round(frames))}, 0, 1`;
export const shake = (who: Side, strength = 1638, beats = 8) => `ShakeSprite ${who}, 2, ${strength}, 0, 2, 1, ${Math.max(1, Math.round(beats))}`;
export const quake = (strength: "0.5x" | "1x" | "2458" = "1x", beats = 6, axis: "VERTICAL" | "HORIZON" = "VERTICAL") => `ShakeScreen ${axis}, ${strength}, 0, 2, 0, ${Math.max(1, Math.round(beats))}`;

/**
 * The foe takes the hit: freeze, flash to `rgb`, hold for the hit-stop, then
 * squash and shake. Lasts `stop` frames; follow with a Wait for the aftermath.
 * power 1 = light, 2 = solid, 3 = heavy (adds a screen shake).
 */
export function hit(o: { rgb?: [number, number, number]; stop?: number; power?: 1 | 2 | 3; freeze?: boolean; who?: Side } = {}): string {
  const who = o.who ?? "DEFENDER", rgb = o.rgb ?? [31, 31, 31], power = o.power ?? 2, stop = o.stop ?? [2, 4, 6][power - 1]!;
  return [
    ...(o.freeze === false ? [] : [`ToggleFreezeSprite ${who}, START`]),
    tint(who, 0, [10, 13, 15][power - 1]!, 0, rgb),
    ...(power === 3 ? [quake("1x", 4)] : []),
    `Wait ${stop}`,
    tint(who, [10, 13, 15][power - 1]!, 0, 3, rgb),
    squash(who, [819, 1229, 1638][power - 1]!, [-819, -1229, -1638][power - 1]!, [2, 3, 4][power - 1]!), // over in 4, 6, 8 frames: quick hits 5 frames apart do not overlap
    shake(who, [1229, 1638, 1638][power - 1]!, [6, 8, 12][power - 1]!),
    ...(power === 1 ? [] : [quake(power === 3 ? "2458" : "1x", power === 3 ? 8 : 6)]),
  ].join("\n");
}
