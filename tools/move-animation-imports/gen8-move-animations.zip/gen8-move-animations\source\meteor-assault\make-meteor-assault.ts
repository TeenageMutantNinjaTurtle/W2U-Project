import { aimed, createKit, fadeOut, grow, hold, paint, setCurves, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FOE_FLOOR, gather, glow, hit, impact, intro, pan, puffs, quake, ring, risers, shake, slash, snd, sparks, streaks, tint, USER, WHITE, type Pal } from "../tools/phrases";

// Meteor Assault (move 794) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user blazes solid gold, light pouring off it as it gathers itself.
//   2. It charges, lance levelled: a mass of gold light ringed with hoops of
//      golden fire, which runs straight through the foe and on past it,
//      leaving a line of light across it.
//   3. A moment later the blow tells: the foe erupts in a great burst of
//      yellow fire, torn into jagged tongues, with black smoke rolling out
//      under it and red sparks, and the ground shakes.
// The charge carrying on past the foe before the damage lands is Logan's
// direction and screenshot (2026-10-03).
// A 150-power move with a recharge turn: a long build-up and a heavy finish.
// The user is hidden while it charges (ToggleSpriteVisibility 3/4).

const SPA = 974;
const kit = await createKit({ workDir: import.meta.dirname, slug: "meteor-assault", moveId: 794, spaId: SPA, donors: [228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 12;
const BLAZE = 36;
const HOLD = 6;
const TRAVEL = 5;
const BEYOND = 7; // frames the charge keeps going after it reaches the foe
const PASS = 16; // from the charge passing through to the blow telling
const AFTER = 40;

const GOLD: Rgb = [1.0, 0.85, 0.15];
const PALE: Rgb = [1.0, 0.98, 0.7];
const ORANGE: Rgb = [1.0, 0.6, 0.1];
const RED: Rgb = [1.0, 0.2, 0.15];
const SMOKE: Pal = [[0.03, 0.03, 0.03], [0.14, 0.12, 0.1], [0, 0, 0]];
const PAL: Pal = [GOLD, PALE, ORANGE];

const user = [
  ...gather(kit, "draw", { pos: USER, frames: BLAZE - 6, pal: PAL, radius: 3.0, scale: 3.0 }),
  ...risers(kit, "light", { frames: BLAZE, radius: 1.3, speed: 0.36, scale: 1.2, life: 9, every: 2, pal: [PALE, WHITE, GOLD], streak: true }),
  ...ring(kit, "pulse", { pos: USER, at: BLAZE - 10, scale: 1.8, pal: [PALE, WHITE, GOLD], to: 2.2, life: 12 }),
  ...glow(kit, "core", { pos: USER, at: BLAZE - 6, life: HOLD + 8, scale: 2.2, pal: [PALE, WHITE, GOLD], tex: kit.tex(T.spiky), spin: 0.15, level: 1, scaleCurve: grow(0.5, 0.3, 1.3) }),
];
// The charge: the user as a mass of gold light with its lance out in front
// and hoops of golden fire round it, one behind another. Each part keeps
// its speed for BEYOND frames after reaching the foe, so the charge runs
// through it and off past it.
const CHARGE_FROM: [number, number, number] = [0.2, 0.4, -0.6];
const charge: string[] = [];
for (const [name, tex, scale, aspect, colours, count, level] of [
  ["chargeLance", kit.tex(T.spike), 1.3, 3.0, [WHITE, WHITE, PALE], 1, 1],
  ["chargeBody", kit.tex(T.softDisc), 1.2, 1.5, [PALE, WHITE, GOLD], 1, 0.95],
  ["chargeHoops", kit.tex(T.hoop), 1.9, 0.5, [GOLD, PALE, ORANGE], 5, 0.9],
  ["chargeGlow", kit.tex(T.fuzzyGlow), 2.6, 1.6, [GOLD, ORANGE, PALE], 3, 0.75],
] as const) {
  const r = kit.parked(tex, CHARGE_FROM, scale, TRAVEL + BEYOND);
  r.startDelayFrames = BLAZE + HOLD;
  r.aspectRatio = aspect;
  aimed(r, 16 / TRAVEL, TRAVEL + BEYOND);
  r.airResistance = 1.0;
  if (count > 1) Object.assign(r, { emitterLifeFrames: count, emissionIntervalFrames: 1 });
  setCurves(r, hold(1), hold(level));
  paint(r, colours[0] as Rgb, colours[1] as Rgb, colours[2] as Rgb);
  kit.add(name, r);
  charge.push(name);
}

// On the foe as the charge goes through: a long line of light across it,
// golden streaks along its path and sparkles hanging in the air.
const through = [
  ...slash(kit, "throughLine", { angle: 8, scale: 4.6, pal: [WHITE, WHITE, PALE], life: 9, aspect: 0.1 }),
  ...slash(kit, "throughGlow", { angle: 8, scale: 4.8, pal: [GOLD, PALE, ORANGE], life: PASS, aspect: 0.3 }),
  ...streaks(kit, "pathLines", { pos: [0, 0.3, 0.9], radius: 1.2, speed: 0.5, count: 5, bursts: 2, gap: 2, life: 8, scale: 1.2, pal: [GOLD, PALE, ORANGE], flat: true }),
  ...sparks(kit, "hangingStars", { pos: [0, 0.6, 0.9], at: 2, radius: 1.8, speed: 0, count: 2, bursts: PASS / 4, gap: 3, life: 8, scale: 0.4, pal: [WHITE, PALE, GOLD], shape: "ball", tex: kit.tex(T.sparkle4) }),
];

const foe = [
  ...impact(kit, "strike", { pal: PAL, size: 1.9, rays: 10, flecks: 0 }),
  ...streaks(kit, "fire", { radius: 0.7, speed: 0.5, count: 9, life: 12, scale: 1.3, pal: [GOLD, PALE, ORANGE], tex: kit.tex(T.shard) }),
  ...streaks(kit, "fire2", { at: 5, radius: 0.7, speed: 0.4, count: 7, life: 12, scale: 1.1, pal: [ORANGE, GOLD, [1.0, 0.45, 0.05]], tex: kit.tex(T.shard) }),
  ...glow(kit, "whiteout", { pos: FOE, life: 14, scale: 4.0, pal: [PALE, WHITE, GOLD], level: 1, scaleCurve: grow(0.4, 0.2, 1.2), alpha: fadeOut(1, 0.45) }),
  ...sparks(kit, "redSparks", { at: 4, radius: 1.8, speed: 0.1, count: 2, bursts: 5, gap: 4, life: 12, scale: 0.16, pal: [RED, [1.0, 0.6, 0.4], RED] }),
  ...puffs(kit, "smoke", { pos: [0, FOE_FLOOR[1] + 0.5, 0.7], at: 4, radius: 2.0, count: 2, bursts: 5, gap: 4, life: 20, scale: 1.3, pal: SMOKE, speed: 0.12, rise: 0.03, level: 0.9, tex: kit.tex(T.clumps), to: 1.7 }),
];
for (const n of ["fire", "fire2"]) setCurves(kit.resources[kit.idx(n)]!, grow(1.2, 0.3, 0.7), fadeOut(1, 0.5));

const chargeAt = BLAZE + HOLD;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1497, 0, { vol: 110 }),
  snd(1480, 0, { ch: "SE2", pitch: 200, vol: 95 }),
  snd(1376, chargeAt, { vol: 0 }),
  snd(1688, chargeAt, { ch: "SE2", pitch: 400, vol: 127 }),
  snd(1514, chargeAt + TRAVEL, { side: "D", pitch: 300, vol: 120 }),
  snd(1784, chargeAt + TRAVEL + 3, { ch: "SE2", side: "D", pitch: 300, vol: 95 }),
  snd(1475, chargeAt + TRAVEL + PASS, { side: "D", pitch: -500, vol: 127 }),
  snd(1413, chargeAt + TRAVEL + PASS, { ch: "SE2", side: "D", pitch: -400, vol: 127 }),
  snd(1475, chargeAt + TRAVEL + PASS + 10, { side: "D", pitch: -700, vol: 120 }),
  snd(1426, chargeAt + TRAVEL + PASS + 6, { ch: "SE2", side: "D", vol: 115 }),
)}
${arena(0, 10, 10, [3, 3, 9])}
${tint("ATTACKER", 0, 13, 12, [31, 27, 6])}
${emits(kit, user, "ATTACKER")}
${emits(kit, charge, "ATTACKER", "DEFENDER")}
${shake("ATTACKER", 819, BLAZE / 2 - 6)}
Wait ${BLAZE - 12}
${tint("ATTACKER", 13, 16, 8, [31, 30, 16])}
${shake("ATTACKER", 1229, 6)}
Wait 12
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, ${HOLD}, 0, 1
Wait ${HOLD}
ToggleSpriteVisibility ATTACKER, 3
${pan("DEFENDER", TRAVEL + 2)}
Wait ${TRAVEL}
${emits(kit, through, "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
${tint("DEFENDER", 0, 8, 0, [31, 30, 16])}
${shake("DEFENDER", 819, 3)}
Wait 2
${tint("DEFENDER", 8, 0, 6, [31, 30, 16])}
Wait ${PASS - 2}
${emits(kit, foe, "DEFENDER")}
${arena(10, 15, 0, [31, 30, 20])}
${hit({ rgb: [31, 30, 16], power: 3, stop: 7, freeze: false })}
${arena(15, 10, 4, [3, 3, 9])}
${shake("DEFENDER", 1638, 14)}
Wait 10
${quake("2458", 8)}
Wait 12
${quake("1x", 8)}
${arena(10, 0, 12, [3, 3, 9])}
Wait ${AFTER - 22}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
${tint("ATTACKER", 16, 0, 0, [31, 30, 16])}
ToggleSpriteVisibility ATTACKER, 4
${pan("INIT", 12)}
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 153, 129, 427],
  references: ["reference/Meteor_Assault_VIII.png", "reference/Meteor_Assault_VIII_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("light")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("chargeHoops")}, ATTACKER, DEFENDER`, `Emit ${SPA}, ${kit.idx("throughLine")}, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 3", "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("fire")}, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 4", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  blaze f${CAMERA_IN}, charge f${CAMERA_IN + chargeAt}, passes through f${CAMERA_IN + chargeAt + TRAVEL}, blow tells f${CAMERA_IN + chargeAt + TRAVEL + PASS}`);
