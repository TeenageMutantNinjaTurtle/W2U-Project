MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 958
AudioContainer CONTINUE
PlaySound 1474, SE1, 14, 0, -300, 85, 0, 0, 0
PlaySound 1525, SE1, 14, 8, 0, 122, 0, 0, 0
PlaySound 1525, SE2, 14, 16, 150, 122, 0, 0, 0
PlaySound 1525, SE1, 14, 24, 0, 122, 0, 0, 0
PlaySound 1525, SE2, 14, 32, 150, 122, 0, 0, 0
PlaySound 1884, SE1, 16, 54, 0, 105, 0, 0, 0
PlaySound 1708, SE2, 16, 54, 0, 112, 0, 0, 0
PlaySound 1708, SE1, 16, 61, 150, 112, 0, 0, 0
PlaySound 1708, SE2, 16, 68, 300, 112, 0, 0, 0
PlaySound 1475, SE1, 16, 71, -200, 125, 0, 0, 0
AudioContainer SUSPEND
Emit 958, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 11, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 12, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 13, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 14, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 15, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 16, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 17, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 18, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 19, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 20, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 21, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 8
ScaleSprite ATTACKER, ROUNDTRIP, 410, -410, 2, 0, 1
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 2
Wait 8
ScaleSprite ATTACKER, ROUNDTRIP, 410, -410, 2, 0, 1
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 2
Wait 8
ScaleSprite ATTACKER, ROUNDTRIP, 410, -410, 2, 0, 1
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 2
Wait 8
ScaleSprite ATTACKER, ROUNDTRIP, 410, -410, 2, 0, 1
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 2
Wait 8
Wait 4
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
Emit 958, 26, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 27, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 22, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 23, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 24, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 25, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 28, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 29, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 30, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 31, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 32, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 33, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 958, 34, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 3
ToggleFreezeSprite DEFENDER, START
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 3
Wait 7
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 3
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 3
Wait 10
ChangeSpriteColor DEFENDER, 15, 15, 0, 28, 31, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 28, 31, 12
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 18
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
