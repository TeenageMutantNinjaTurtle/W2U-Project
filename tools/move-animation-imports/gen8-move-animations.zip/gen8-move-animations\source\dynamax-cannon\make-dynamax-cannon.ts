import { createKit, fadeInOut, grow, paint, setCurves, spin, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, beam, emits, FOE, FRONT, gather, glow, hit, impact, intro, lunge, outro, pan, puffs, ring, shake, snd, sparks, streaks, tint, WHITE, type Pal } from "../tools/phrases";

// Dynamax Cannon (move 744) - from the Bulbapedia stills (reference/sheet.png:
// Sword/Shield top row, Scarlet/Violet bottom row).
//   1. Charge: the arena turns crimson; a thin pink ring stands round the user
//      with sparkles on it while pink light is drawn in to its mouth.
//   2. Fire: a huge pink-white beam, wider than the user, with bright dashes
//      streaming along it.
//   3. Impact: an enormous pink-white burst with streaks radiating across the
//      whole screen.
// Hyper Beam's stream is the beam.

const SPA = 942;
const kit = await createKit({ workDir: import.meta.dirname, slug: "dynamax-cannon", moveId: 744, spaId: SPA, donors: [228, 465, 579, 411, 321, 298] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const CHARGE = 30;
const HOLD = 6; // the charged beat before it fires
const TRAVEL = 8;
const POUR = 26;
const AFTER = 22;

const PINK: Rgb = [1.0, 0.45, 0.75];
const HOT_PINK: Rgb = [1.0, 0.2, 0.6];
const PALE_PINK: Rgb = [1.0, 0.85, 0.93];
const CRIMSON: Rgb = [0.85, 0.1, 0.35];
const PAL: Pal = [PINK, PALE_PINK, HOT_PINK];

// --- 1. charge ---
const user = [
  ...gather(kit, "charge", { pos: FRONT, frames: CHARGE, pal: PAL, radius: 3.0, scale: 2.2, streaks: true }),
  ...ring(kit, "halo", { pos: [0, 0.3, -0.6], life: CHARGE + HOLD, scale: 3.3, pal: [PINK, PALE_PINK, HOT_PINK], to: 1.05, level: 0.85 }),
  ...sparks(kit, "haloSparkles", { pos: [0, 0.3, -0.6], radius: 3.3, speed: 0, count: 1, bursts: CHARGE / 2, gap: 2, life: 8, scale: 0.3, pal: [WHITE, PALE_PINK, PINK], shape: "circle", tex: kit.tex(T.sparkle4) }),
  // The charged ball that stays blazing at the mouth while the beam pours.
  ...glow(kit, "ball", { pos: FRONT, at: CHARGE - 4, life: HOLD + POUR + 6, scale: 1.5, pal: [PALE_PINK, WHITE, PINK], tex: kit.tex(T.spiky), spin: 0.2, level: 1, scaleCurve: grow(1.5, 0.15, 1.1), alpha: fadeInOut(1, 0.1, 0.85) }),
  ...ring(kit, "muzzleRing", { pos: FRONT, at: CHARGE + HOLD, life: 10, scale: 1.6, pal: [PALE_PINK, WHITE, PINK], to: 2.2 }),
];
// The halo holds its size instead of swelling.
const halo = kit.resources[kit.idx("halo")]!;
setCurves(halo, grow(0.7, 0.2, 1.05), fadeInOut(0.85, 0.15, 0.8));

const shots = [
  ...beam(kit, "beam", { at: CHARGE + HOLD, pour: POUR, travel: TRAVEL, width: 1.7, pal: [PINK, PALE_PINK, HOT_PINK], tex: kit.tex(T.softDisc) }),
  ...streaks(kit, "dashes", { pos: FRONT, at: CHARGE + HOLD, radius: 0.7, speed: 0, count: 1, bursts: POUR / 2, gap: 2, life: TRAVEL + 1, scale: 0.7, pal: [WHITE, PALE_PINK, WHITE] }),
];
// The dashes fly along the beam rather than outward.
const dashes = kit.resources[kit.idx("dashes")]!;
Object.assign(dashes, { axis: [1, 0, 0], initVelAxisAmplifier: (16 / TRAVEL) * 1.1, airResistance: 1.0 });

// --- 3. impact, renewed while the beam pours ---
const foe = [
  ...impact(kit, "hit", { pal: PAL, size: 1.45, rays: 10, flecks: 6 }),
  ...impact(kit, "hit2", { at: 10, pal: [HOT_PINK, WHITE, CRIMSON], size: 1.4, rays: 10, flecks: 0, spiky: false }),
  ...ring(kit, "shock", { at: 2, scale: 2.4, pal: [PALE_PINK, WHITE, PINK], to: 2.4, life: 14 }),
  ...ring(kit, "shock2", { at: 12, scale: 2.0, pal: [PINK, WHITE, HOT_PINK], to: 2.4, life: 14 }),
  ...glow(kit, "blaze", { pos: FOE, life: POUR + 6, scale: 3.4, pal: [PINK, WHITE, HOT_PINK], level: 0.9 }),
  ...puffs(kit, "cloud", { radius: 1.1, count: 2, bursts: POUR / 5, gap: 5, life: 14, scale: 1.5, pal: [PALE_PINK, WHITE, PINK], speed: 0.12, to: 1.7 }),
  ...sparks(kit, "embers", { at: POUR - 4, radius: 1.4, speed: 0.1, count: 3, bursts: 4, gap: 4, life: 14, pal: [PINK, WHITE, HOT_PINK], fall: -0.006 }),
];
const blaze = kit.resources[kit.idx("blaze")]!;
spin(blaze, 0.03);
paint(blaze, PINK, WHITE, HOT_PINK);

// --- script ---
const fireAt = CHARGE + HOLD;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1497, 0, { vol: 115 }),
  snd(1480, 0, { ch: "SE2", pitch: -300, vol: 100 }),
  snd(1975, fireAt, { vol: 127 }),
  snd(1424, fireAt, { ch: "SE2", pitch: -400, vol: 120 }),
  `SwitchAudioSide SE2, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0`,
  snd(1475, fireAt + TRAVEL, { side: "D", pitch: -300, vol: 127 }),
  snd(1420, fireAt + TRAVEL + 8, { ch: "SE2", side: "D", vol: 127 }),
  snd(1420, fireAt + TRAVEL + 16, { side: "D", vol: 127 }),
)}
${arena(0, 9, 6, [24, 4, 10])}
${tint("ATTACKER", 0, 9, 6, [31, 14, 22])}
${emits(kit, user, "ATTACKER")}
${emits(kit, shots, "ATTACKER", "DEFENDER")}
${shake("ATTACKER", 819, CHARGE / 2 - 2)}
Wait ${CHARGE}
${tint("ATTACKER", 9, 14, 2, [31, 24, 28])}
Wait ${HOLD}
${lunge("ATTACKER", -2)}
${shake("ATTACKER", 1229, POUR / 2)}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${arena(9, 14, 0, [31, 20, 26])}
${hit({ rgb: [31, 24, 28], power: 3 })}
${arena(14, 9, 4, [24, 4, 10])}
Wait ${POUR - 6}
${tint("ATTACKER", 14, 0, 4, [31, 24, 28])}
${arena(9, 0, 8, [24, 4, 10])}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 153, 129],
  references: ["reference/Dynamax_Cannon_VIII.png", "reference/Dynamax_Cannon_VIII_2.png", "reference/Dynamax_Cannon_IX.png", "reference/Dynamax_Cannon_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("beamJet")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("hitFlash")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
const at = CAMERA_IN + fireAt;
console.log(`  charge f${CAMERA_IN}, fire f${at}, lands f${at + TRAVEL}, beam ends f${at + POUR}, done ~f${at + TRAVEL + POUR + AFTER}`);
