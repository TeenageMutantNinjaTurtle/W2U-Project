import { aimed, createKit, fadeOut, grow, hold, paint, setCurves, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FOE_FLOOR, glow, hit, impact, intro, pan, puffs, ring, risers, shake, snd, sparks, streaks, tint, USER, USER_FLOOR, WHITE, type Pal } from "../tools/phrases";

// Wave Crash (move 834) - from the Bulbapedia stills (reference/sheet.png).
//   1. Water surges up round the user: a ring of white foam spreading over
//      the ground, bubbles streaming up, a blue glow over it.
//   2. It throws itself at the foe as a wave - a mass of bright water with a
//      white crest.
//   3. The wave breaks over the foe in a huge burst of spray and foam.
//   4. Back in its place, the user shudders from the recoil.
// The user is hidden while it is the wave (ToggleSpriteVisibility 3/4).
// The water orb and splash ring are Aqua Jet's (SPA 632).

const SPA = 1014;
const kit = await createKit({ workDir: import.meta.dirname, slug: "wave-crash", moveId: 834, spaId: SPA, donors: [632, 228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 10;
const SURGE = 22;
const TRAVEL = 6;
const AFTER = 28;

const CYAN: Rgb = [0.45, 0.88, 1.0];
const PALE: Rgb = [0.9, 0.97, 1.0];
const BLUE: Rgb = [0.15, 0.45, 1.0];
const DEEP: Rgb = [0.1, 0.25, 0.8];
const WATER: Pal = [CYAN, PALE, BLUE];
const orbTex = kit.tex(632, 0);
const splashTex = kit.tex(632, 2);
const BODY: Vec3 = [0, 0.3, 0.3];

// --- 1. the surge ---
const user = [
  ...risers(kit, "bubbles", { pos: USER_FLOOR, frames: SURGE - 2, radius: 1.2, speed: 0.16, scale: 0.26, life: 14, every: 2, pal: [WHITE, WHITE, WHITE], tex: orbTex }),
  ...puffs(kit, "foam", { pos: USER_FLOOR, radius: 1.5, count: 4, bursts: 4, gap: 5, life: 13, scale: 0.6, pal: [WHITE, PALE, CYAN], speed: 0.1, rise: 0.01, level: 0.9 }),
  ...ring(kit, "foamRing", { pos: USER_FLOOR, life: SURGE, scale: 0.8, pal: [WHITE, PALE, CYAN], tex: splashTex, to: 1.5, aspect: 2.6, level: 0.9 }),
  ...ring(kit, "foamRing2", { pos: USER_FLOOR, at: 9, life: SURGE - 9, scale: 0.8, pal: [PALE, WHITE, CYAN], tex: splashTex, to: 1.5, aspect: 2.6, level: 0.8 }),
  ...streaks(kit, "upSpray", { pos: USER_FLOOR, radius: 1.3, speed: 0.3, count: 3, bursts: SURGE / 4, gap: 4, life: 8, scale: 0.8, pal: [PALE, WHITE, CYAN], lift: 0.5 }),
  ...glow(kit, "depth", { life: SURGE + 2, scale: 3.0, pal: [BLUE, CYAN, DEEP], level: 0.7 }),
];

// --- 2. the wave: a body of water and its white crest, thrown at the foe ---
const wave: string[] = [];
for (const [name, tex, scale, colours, level, lift] of [
  ["crest", kit.tex(T.puff), 1.5, [WHITE, WHITE, PALE], 0.95, 0.9],
  ["body", orbTex, 2.2, [WHITE, WHITE, WHITE], 0.95, 0],
  ["swell", kit.tex(T.fuzzyGlow), 3.0, [CYAN, PALE, BLUE], 0.75, 0],
] as const) {
  const r = kit.parked(tex, [BODY[0], BODY[1] + lift, BODY[2]], scale, TRAVEL + 1);
  r.startDelayFrames = SURGE;
  aimed(r, 16 / TRAVEL, TRAVEL + 1);
  r.airResistance = 1.0;
  setCurves(r, hold(1.05), hold(level));
  paint(r, colours[0] as Rgb, colours[1] as Rgb, colours[2] as Rgb);
  kit.add(name, r);
  wave.push(name);
}
const wake = streaks(kit, "wake", { pos: USER, at: SURGE, radius: 1.4, speed: 0.4, count: 4, bursts: 3, gap: 2, life: 7, scale: 0.9, pal: [PALE, WHITE, CYAN], flat: true });

// --- 3. it breaks ---
const foe = [
  ...impact(kit, "crash", { pal: [PALE, WHITE, CYAN], size: 2.0, rays: 8, flecks: 0 }),
  ...ring(kit, "crashRing", { scale: 1.8, pal: [PALE, WHITE, CYAN], tex: splashTex, to: 2.2, life: 12 }),
  ...ring(kit, "floorRing", { pos: FOE_FLOOR, at: 2, scale: 0.8, pal: [WHITE, PALE, CYAN], tex: splashTex, to: 1.8, life: 14, aspect: 2.6 }),
  ...streaks(kit, "spray", { radius: 0.6, speed: 0.5, count: 8, life: 12, scale: 1.0, pal: [BLUE, PALE, CYAN], tex: kit.tex(T.spike) }),
  ...sparks(kit, "orbs", { radius: 0.7, speed: 0.28, count: 5, life: 18, scale: 0.3, pal: [WHITE, WHITE, WHITE], fall: 0.014, tex: orbTex, twinkle: false }),
  ...sparks(kit, "droplets", { at: 1, radius: 0.8, speed: 0.34, count: 6, life: 16, scale: 0.14, pal: [PALE, WHITE, CYAN], fall: 0.014, twinkle: false }),
  ...puffs(kit, "breakers", { pos: FOE_FLOOR, at: 2, radius: 1.6, count: 5, life: 16, scale: 0.8, pal: [WHITE, PALE, CYAN], speed: 0.16, rise: 0.02, level: 0.9 }),
  ...glow(kit, "flood", { pos: FOE, life: 16, scale: 3.4, pal: WATER, level: 0.7 }),
];
setCurves(kit.resources[kit.idx("spray")]!, grow(1.2, 0.3, 0.6), fadeOut());

const hitAt = SURGE + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1418, 0, { vol: 115 }),
  snd(1511, 4, { ch: "SE2", pitch: -300, vol: 105 }),
  snd(1418, 11, { ch: "SE2", pitch: 200, vol: 110 }),
  snd(1407, SURGE, { pitch: -200, vol: 122 }),
  snd(1511, hitAt, { ch: "SE2", side: "D", pitch: -200, vol: 127 }),
  snd(1475, hitAt, { side: "D", pitch: -300, vol: 127 }),
  snd(1413, hitAt + 2, { ch: "SE2", side: "D", vol: 115 }),
)}
${arena(0, 8, 8, [4, 10, 22])}
${tint("ATTACKER", 0, 10, 6, [12, 24, 31])}
${emits(kit, user, "ATTACKER")}
${emits(kit, [...wave, ...wake], "ATTACKER", "DEFENDER")}
${shake("ATTACKER", 819, SURGE / 2 - 3)}
Wait ${SURGE}
ToggleSpriteVisibility ATTACKER, 3
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [24, 30, 31], power: 3 })}
Wait ${AFTER - 8}
${arena(8, 0, 8, [4, 10, 22])}
Wait 8
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
${tint("ATTACKER", 10, 0, 6, [12, 24, 31])}
ToggleSpriteVisibility ATTACKER, 4
${pan("INIT", 12)}
Wait 12
${shake("ATTACKER", 1229, 6)}
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [453, 63, 605, 400, 240, 153, 129, 57],
  references: ["reference/Wave_Crash_LA.png", "reference/Wave_Crash_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("foamRing")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("body")}, ATTACKER, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 3", "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("crashFlash")}, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 4", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  surge f${CAMERA_IN}, wave f${CAMERA_IN + SURGE}, breaks f${CAMERA_IN + hitAt}`);
