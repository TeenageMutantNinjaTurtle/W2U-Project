MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 975
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, -300, 115, 0, 0, 0
PlaySound 1480, SE2, 14, 0, -500, 105, 0, 0, 0
PlaySound 1975, SE1, 14, 48, 0, 127, 0, 0, 0
PlaySound 1424, SE2, 14, 48, -600, 127, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 8, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 56, -500, 127, 0, 0, 0
PlaySound 1420, SE2, 16, 64, 0, 127, 0, 0, 0
PlaySound 1475, SE1, 16, 72, -700, 127, 0, 0, 0
PlaySound 1420, SE2, 16, 80, 0, 127, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 15, 0, 1, 0, 2
ChangeSpriteColor ATTACKER, 0, 9, 0, 31, 10, 20
Emit 975, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 9, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 10, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 11, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 16
Wait 40
ChangeSpriteColor ATTACKER, 9, 14, 0, 31, 22, 27
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 4
Wait 8
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -2px, 49152, 0, 4096, 0
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 17
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 975, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 20, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 21, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 22, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 975, 23, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeBackgroundColor 4, 16, 16, 0, 31, 20, 26
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 24, 28
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 7
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 24, 28
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 16, 15, 4, 1, 0, 2
Wait 8
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 9
ChangeSpriteColor ATTACKER, 14, 0, 0, 31, 22, 27
ChangeBackgroundColor 4, 15, 0, 0, 1, 0, 2
Wait 30
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
