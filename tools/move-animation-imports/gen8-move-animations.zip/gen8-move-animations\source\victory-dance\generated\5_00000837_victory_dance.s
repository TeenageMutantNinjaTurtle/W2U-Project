MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1017
AudioContainer CONTINUE
PlaySound 1862, SE1, 14, 0, 0, 120, 0, 0, 0
PlaySound 1820, SE2, 14, 14, 0, 100, 0, 0, 0
PlaySound 1820, SE2, 14, 26, 200, 100, 0, 0, 0
PlaySound 1452, SE1, 14, 40, 0, 115, 0, 0, 0
PlaySound 1784, SE2, 14, 42, 200, 105, 0, 0, 0
AudioContainer SUSPEND
EmitCircle 1017, 0, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 1017, 1, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
Emit 1017, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1017, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1017, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1017, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1017, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1017, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1017, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1017, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1017, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1017, 11, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1017, 12, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1017, 13, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveSprite ATTACKER, ROUNDTRIP, 2, 2px, 2px, 40960, 0, 12288, 0
Wait 12
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 5, 0, 1
Wait 12
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 5, 0, 1
Wait 16
ChangeSpriteColor ATTACKER, 0, 12, 0, 31, 30, 14
ScaleSprite ATTACKER, ROUNDTRIP, -1229, 1229, 6, 0, 1
Wait 16
ChangeSpriteColor ATTACKER, 12, 0, 0, 31, 30, 14
Wait 10
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
