MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1019
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, 300, 105, 0, 0, 0
PlaySound 1727, SE2, 14, 4, 300, 95, 0, 0, 0
PlaySound 1539, SE1, 14, 18, 200, 118, 0, 0, 0
PlaySound 1539, SE2, 14, 22, 300, 118, 0, 0, 0
PlaySound 1539, SE1, 14, 26, 400, 118, 0, 0, 0
PlaySound 1423, SE2, 16, 24, 300, 118, 0, 0, 0
PlaySound 1423, SE2, 16, 28, 300, 118, 0, 0, 0
PlaySound 1423, SE2, 16, 32, 300, 118, 0, 0, 0
PlaySound 1727, SE1, 16, 34, 0, 125, 0, 0, 0
PlaySound 1475, SE2, 16, 34, 200, 120, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 9, 0, 18, 6, 26
Emit 1019, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1019, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1019, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1019, 3, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1019, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, 1229, 819, 14, 0, 1
Wait 18
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 9, 0, 0, 18, 6, 26
MoveCamera INTERPOLATION, DEFENDER, 6, 0, 8
Wait 6
Emit 1019, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1019, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1019, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1019, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1019, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1019, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1019, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1019, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1019, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 10, 10, 0, 28, 10, 28
Wait 2
ChangeSpriteColor DEFENDER, 10, 0, 0, 28, 10, 28
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 2, 0, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 6
Wait 3
ChangeSpriteColor DEFENDER, 10, 10, 0, 28, 10, 28
Wait 2
ChangeSpriteColor DEFENDER, 10, 0, 0, 28, 10, 28
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 2, 0, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 6
Wait 3
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 14, 30
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 14, 30
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 24
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
