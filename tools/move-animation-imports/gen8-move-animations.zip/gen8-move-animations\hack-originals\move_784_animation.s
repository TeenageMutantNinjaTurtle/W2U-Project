ToggleSpriteShadow ALL, ON
LetCMDsFinish ALL
LoadSPA 710
Emit 710, 2, DEFENDER, NONE, 0.5px, 0, 0, 1x, 1x, 2867, 1x
Emit 710, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 710, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
AudioContainer CONTINUE
PlaySound 1651, SE1, 16, 0, 0, 127, 0, 0, 0
PlaySound 1427, SE2, 16, 0, 0, 50, 0, 0, 0
AudioContainer SUSPEND
Wait 10
ToggleFreezeSprite DEFENDER, START
ScaleSprite DEFENDER, ROUNDTRIP, -1638, 1638, 4, 1, 1
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, STOP
ToggleSpriteShadow ALL, OFF
LetCMDsFinish ALL
TerminateMoveScript
