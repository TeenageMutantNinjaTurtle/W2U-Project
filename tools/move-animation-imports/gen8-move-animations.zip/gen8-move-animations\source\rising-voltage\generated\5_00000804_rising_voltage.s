MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 984
AudioContainer CONTINUE
PlaySound 1483, SE2, 14, 0, 0, 100, 0, 0, 0
PlaySound 1458, SE1, 14, 4, 200, 105, 0, 0, 0
PlaySound 1376, SE2, 14, 18, 0, 0, 0, 0, 0
PlaySound 1522, SE1, 14, 18, 300, 115, 0, 0, 0
PlaySound 1483, SE1, 16, 26, 200, 110, 0, 0, 0
PlaySound 1458, SE2, 16, 32, 300, 118, 0, 0, 0
PlaySound 1458, SE1, 16, 37, 450, 118, 0, 0, 0
PlaySound 1458, SE2, 16, 42, 600, 118, 0, 0, 0
PlaySound 1683, SE2, FLAT, 46, 0, 127, 0, 0, 0
PlaySound 1475, SE1, 16, 47, -300, 127, 0, 0, 0
PlaySound 1710, SE2, 16, 55, 300, 105, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 9, 0, 31, 30, 12
Emit 984, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 3, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 7
Wait 18
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 3, 0, 1
ChangeSpriteColor ATTACKER, 9, 0, 0, 31, 30, 12
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 984, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 984, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 6
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 10, 10, 0, 31, 31, 14
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 2
Wait 1
ChangeSpriteColor DEFENDER, 10, 0, 0, 31, 31, 14
Wait 4
ChangeSpriteColor DEFENDER, 10, 10, 0, 31, 31, 14
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 2
Wait 1
ChangeSpriteColor DEFENDER, 10, 0, 0, 31, 31, 14
Wait 4
ChangeSpriteColor DEFENDER, 10, 10, 0, 31, 31, 14
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 2
Wait 1
ChangeSpriteColor DEFENDER, 10, 0, 0, 31, 31, 14
Wait 4
ChangeBackgroundColor 4, 10, 10, 0, 31, 31, 20
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 31, 14
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 31, 14
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 10, 0, 0, 31, 31, 20
Wait 26
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
