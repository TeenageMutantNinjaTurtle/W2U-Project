import { createKit, fadeInOut, hold, paint, setCurves, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, FOE, glow, hit, impact, intro, lunge, outro, pan, puffs, shot, snd, sparks, streaks, tint, WHITE, type Pal } from "../tools/phrases";

// Infernal Parade (move 844) - from the Bulbapedia stills (reference/sheet.png).
//   1. Ghost fires light up round the user one after another: magenta flames
//      with black hearts, soot and pink petals drifting off them.
//   2. They file off at the foe, one behind the other.
//   3. Each bursts on it in magenta; the last sets it ablaze in red and
//      magenta flame, a dark star flashing at the heart of it.
// The burn chance and the doubled power on a foe with a status condition are
// the engine's.

const SPA = 1024;
const kit = await createKit({ workDir: import.meta.dirname, slug: "infernal-parade", moveId: 844, spaId: SPA, donors: [228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 10;
const LIGHT_GAP = 6;
const CONJURE = 26;
const FIRES = 3;
const FIRE_GAP = 5;
const TRAVEL = 7;
const BLAZE = 20;
const AFTER = 12;

const MAGENTA: Rgb = [1.0, 0.2, 0.85];
const PINK: Rgb = [1.0, 0.65, 0.95];
const PURPLE: Rgb = [0.5, 0.15, 0.8];
const RED: Rgb = [1.0, 0.15, 0.25];
const INK: Rgb = [0.03, 0.01, 0.06];
const SOOT: Pal = [INK, [0.12, 0.04, 0.2], INK];

// Where each ghost fire lights (round the user).
const SPOTS: Vec3[] = [[-1.5, 0.2, 0.0], [1.4, 0.9, 0.1], [0.2, 1.7, -0.2]];
const user: string[] = [];
const parade: string[] = [];
for (const [i, at] of SPOTS.entries()) {
  const lightAt = i * LIGHT_GAP, goAt = CONJURE + i * FIRE_GAP;
  // Burning in place: a black heart in a magenta flame, with a paler crown.
  for (const [layer, tex, scale, colours, level] of [
    ["Heart", kit.tex(T.softDisc), 0.42, [INK, INK, INK], 0.95],
    ["Crown", kit.tex(T.spikeRing), 0.8, [PINK, WHITE, MAGENTA], 0.85],
    ["Flame", kit.tex(T.fuzzyGlow), 1.25, [MAGENTA, PINK, PURPLE], 0.9],
  ] as const) {
    const r = kit.parked(tex, at, scale, goAt - lightAt);
    r.startDelayFrames = lightAt;
    setCurves(r, { start: 0.2, mid: 1.08, end: 1, curveIn: 0.25, curveOut: 0.7 }, fadeInOut(level, 0.15, 0.95));
    paint(r, colours[0] as Rgb, colours[1] as Rgb, colours[2] as Rgb);
    kit.add(`fire${i}${layer}`, r);
    user.push(`fire${i}${layer}`);
  }
  // Filing off: the same fire, thrown at the foe.
  shot(kit, `go${i}Heart`, kit.tex(T.softDisc), { from: at, at: goAt, travel: TRAVEL, scale: 0.42, pal: [INK, INK, INK], dive: (at[1] - 0.3) / 16, lateral: at[0], alpha: hold(0.95) });
  shot(kit, `go${i}Flame`, kit.tex(T.fuzzyGlow), { from: at, at: goAt, travel: TRAVEL, scale: 1.25, pal: [MAGENTA, PINK, PURPLE], dive: (at[1] - 0.3) / 16, lateral: at[0], alpha: hold(0.9) });
  parade.push(`go${i}Heart`, `go${i}Flame`);
}
user.push(
  ...sparks(kit, "petals", { pos: [0, 0.9, 0], at: 2, radius: 2.0, speed: 0.05, count: 1, bursts: CONJURE / 3, gap: 3, life: 14, scale: 0.18, pal: [PINK, WHITE, MAGENTA], fall: -0.01, tex: kit.tex(T.shard), twinkle: false, spin: 0.2 }),
  ...sparks(kit, "soot", { pos: [0, 0.9, 0], at: 4, radius: 2.0, speed: 0.04, count: 1, bursts: CONJURE / 4, gap: 4, life: 14, scale: 0.16, pal: SOOT, fall: -0.012, tex: kit.tex(T.clumps), twinkle: false }),
);

// --- 3. the bursts, and the blaze ---
const lastAt = (FIRES - 1) * FIRE_GAP;
const foe = [
  ...sparks(kit, "darkStar", { at: lastAt, radius: 0, speed: 0, count: 1, life: 10, scale: 1.1, pal: [INK, PURPLE, INK], shape: "ball", tex: kit.tex(T.star4Big), twinkle: false }),
  ...impact(kit, "burst0", { pos: [-0.4, 0.5, 0.9], pal: [MAGENTA, PINK, PURPLE], size: 1.1, rays: 0, flecks: 0 }),
  ...impact(kit, "burst1", { pos: [0.4, 0.1, 0.9], at: FIRE_GAP, pal: [MAGENTA, PINK, PURPLE], size: 1.1, rays: 0, flecks: 0 }),
  ...impact(kit, "burst2", { at: lastAt, pal: [PINK, WHITE, MAGENTA], size: 1.7, rays: 8, flecks: 0 }),
  ...streaks(kit, "lashes", { at: lastAt, radius: 0.6, speed: 0.42, count: 7, life: 10, scale: 1.0, pal: [MAGENTA, PINK, RED] }),
  ...puffs(kit, "redFlames", { pos: [0.5, -0.4, 0.8], at: lastAt, radius: 1.0, count: 2, bursts: BLAZE / 4, gap: 4, life: 12, scale: 0.9, pal: [RED, [1.0, 0.5, 0.4], [0.7, 0.05, 0.2]], speed: 0.04, rise: 0.12, level: 0.9, tex: kit.tex(T.clumps), to: 0.7 }),
  ...puffs(kit, "ghostFlames", { pos: [-0.5, -0.4, 0.8], at: lastAt + 2, radius: 1.0, count: 2, bursts: BLAZE / 4, gap: 4, life: 12, scale: 0.9, pal: [MAGENTA, PINK, PURPLE], speed: 0.04, rise: 0.12, level: 0.9, tex: kit.tex(T.clumps), to: 0.7 }),
  ...sparks(kit, "fallingPetals", { at: lastAt, radius: 1.0, speed: 0.24, count: 6, life: 16, scale: 0.18, pal: [PINK, WHITE, MAGENTA], fall: 0.01, tex: kit.tex(T.shard), twinkle: false, spin: 0.25 }),
  ...glow(kit, "hellGlow", { pos: FOE, life: lastAt + BLAZE, scale: 3.2, pal: [MAGENTA, PURPLE, RED], level: 0.6 }),
];

const landAt = CONJURE + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  ...SPOTS.map((_, i) => snd(1426, i * LIGHT_GAP, { ch: i % 2 ? "SE2" : "SE1", pitch: 500 + i * 150, vol: 100 })),
  snd(1815, 2, { ch: "SE2", pitch: 200, vol: 100 }),
  ...SPOTS.map((_, i) => snd(1407, CONJURE + i * FIRE_GAP, { ch: "SE2", pitch: 300, vol: 110 })),
  ...SPOTS.map((_, i) => snd(i === FIRES - 1 ? 1475 : 1420, landAt + i * FIRE_GAP, { side: "D", pitch: i === FIRES - 1 ? -100 : 300, vol: 122 })),
  snd(1426, landAt + lastAt + 1, { ch: "SE2", side: "D", pitch: -200, vol: 120 }),
)}
${arena(0, 10, 10, [5, 2, 9])}
${tint("ATTACKER", 0, 8, 6, [24, 8, 26])}
${emits(kit, user, "ATTACKER")}
${emits(kit, parade, "ATTACKER", "DEFENDER")}
Wait ${CONJURE}
${lunge("ATTACKER", 3)}
${tint("ATTACKER", 8, 0, 4, [24, 8, 26])}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [30, 10, 28], power: 1, stop: 2 })}
Wait ${FIRE_GAP - 2}
${hit({ rgb: [30, 10, 28], power: 1, stop: 2, freeze: false })}
Wait ${FIRE_GAP - 2}
${hit({ rgb: [31, 16, 28], power: 3, freeze: false })}
Wait ${BLAZE - 6 - 8}
${arena(10, 0, 8, [5, 2, 9])}
Wait ${8 + AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [261, 247, 63, 605, 400, 240, 153, 129],
  references: ["reference/Infernal_Parade_LA.png", "reference/Infernal_Parade_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("fire0Flame")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("go2Flame")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("redFlames")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  fires light f${CAMERA_IN}+, file off f${CAMERA_IN + CONJURE}+, land f${CAMERA_IN + landAt} / +${FIRE_GAP} / +${2 * FIRE_GAP}`);
