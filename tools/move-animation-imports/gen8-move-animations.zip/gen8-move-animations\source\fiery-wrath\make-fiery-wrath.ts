import { createKit, fadeInOut, paint, setCurves, spin, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FOE_FLOOR, glow, hit, impact, intro, outro, pan, risers, shake, snd, sparks, tint, USER, WHITE, type Pal } from "../tools/phrases";

// Fiery Wrath (move 822) - from the Bulbapedia stills (reference/sheet.png).
//   1. The light dies. A great wheel of dark fire builds up round the user:
//      violet at its heart, magenta round that, red at its ragged rim, all of
//      it turning - a dark flame, not a hot one.
//   2. Under the foe the same dark fire bursts up out of the ground in a tall
//      roaring column, black shards torn up with it.
// The wheel is drawn (generated/texture-aura.png), from the Sword/Shield
// screenshot Logan sent on 2026-10-03 in place of the whirl I had first.

const SPA = 1002;
const kit = await createKit({ workDir: import.meta.dirname, slug: "fiery-wrath", moveId: 822, spaId: SPA, donors: [228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const WHIRL = 28;
const PAN = 10;
const COLUMN = 34;
const AFTER = 12;

const CRIMSON: Rgb = [0.95, 0.08, 0.2];
const MAGENTA: Rgb = [1.0, 0.25, 0.7];
const VIOLET: Rgb = [0.55, 0.2, 0.95];
const DARK: Rgb = [0.35, 0.02, 0.1];
const BLACK: Rgb = [0, 0, 0];
const PAL: Pal = [CRIMSON, MAGENTA, VIOLET];

// --- the wheel of dark fire: bands of colour from a violet heart out to a red
// rim, their edges torn into tongues that lean with the turn ---
const mix = (a: number[], b: number[], t: number) => a.map((v, i) => v + (b[i]! - v) * t);
const auraTex = await kit.drawn("aura", 64, 64, "a3i5", (x, y) => {
  const px = (x + 0.5 - 32) / 32, py = (y + 0.5 - 32) / 32;
  const angle = Math.atan2(py, px), d = Math.hypot(px, py);
  const lean = angle + d * 2.4; // the further out, the further round: a swirl
  const r = d + 0.06 * Math.sin(5 * lean) + 0.04 * Math.sin(9 * lean + 1.3) + 0.025 * Math.sin(14 * angle - 0.7);
  const INNER = 0.4, OUTER = 0.96; // the hole in the middle leaves the user in view
  if (r > OUTER || r < INNER) return undefined;
  const edge = Math.min(1, (OUTER - r) / 0.1, (r - INNER) / 0.1);
  const t = (r - INNER) / (OUTER - INNER);
  const bands: Array<[number, number[]]> = [[0, [55, 40, 220]], [0.28, [125, 30, 200]], [0.5, [220, 20, 120]], [0.72, [215, 10, 35]], [1, [140, 0, 25]]];
  let colour = bands[bands.length - 1]![1];
  for (let i = 1; i < bands.length; i++) if (t <= bands[i]![0]) { colour = mix(bands[i - 1]![1], bands[i]![1], (t - bands[i - 1]![0]) / (bands[i]![0] - bands[i - 1]![0])); break; }
  const streak = 0.72 + 0.28 * Math.sin(7 * lean + 2); // darker veins through the fire
  return [Math.round(colour[0]! * streak), Math.round(colour[1]! * streak), Math.round(colour[2]! * streak), Math.round(235 * edge)];
});
const wheel = (name: string, at: number, scale: number, rate: number, level: number) => {
  const r = kit.parked(auraTex, [0, 0.4, 0.3], scale, WHIRL + 6 - at);
  r.startDelayFrames = at;
  spin(r, rate, rate, at);
  // It builds: small and faint at first, full by two-thirds of the way.
  setCurves(r, { start: 0.25, mid: 1.0, end: 1.1, curveIn: 0.65, curveOut: 0.9 }, { start: 0, mid: level, end: 0, curveIn: 0.3, curveOut: 0.85 });
  paint(r, WHITE);
  kit.add(name, r);
  return name;
};
const user = [
  wheel("wheel", 0, 2.7, 0.07, 0.95),
  wheel("wheelUnder", 3, 2.5, -0.05, 0.55),
  ...sparks(kit, "wrathMotes", { pos: USER, radius: 1.6, speed: 0.08, count: 2, bursts: WHIRL / 3, gap: 3, life: 12, scale: 0.15, pal: [MAGENTA, VIOLET, CRIMSON], fall: -0.012 }),
  ...glow(kit, "wrath", { pos: USER, life: WHIRL + 4, scale: 3.2, pal: [CRIMSON, DARK, VIOLET], level: 0.3 }),
];

// The column: a tall shaft of crimson with a violet heart, fire streaming up through it.
const shaft = (name: string, scale: number, aspect: number, colours: [Rgb, Rgb, Rgb], level: number) => {
  const r = kit.parked(kit.tex(T.streak), [0, 1.5, 0.8], scale, COLUMN);
  r.aspectRatio = aspect;
  setCurves(r, { start: 0.15, mid: 1.05, end: 1.1, curveIn: 0.15, curveOut: 0.9 }, fadeInOut(level, 0.08, 0.8));
  paint(r, colours[0], colours[1], colours[2]);
  kit.add(name, r);
  return name;
};
const foe = [
  ...risers(kit, "blackShards", { pos: FOE_FLOOR, at: 1, frames: COLUMN - 12, radius: 1.5, speed: 0.34, scale: 0.7, life: 9, every: 3, pal: [BLACK, DARK, BLACK], streak: true, tex: kit.tex(T.shard) }),
  shaft("shaftHeart", 3.6, 0.3, [VIOLET, MAGENTA, [0.3, 0.1, 0.7]], 0.9),
  shaft("shaft", 3.8, 0.75, [CRIMSON, MAGENTA, DARK], 0.8),
  ...risers(kit, "fire", { pos: FOE_FLOOR, frames: COLUMN - 10, radius: 1.2, speed: 0.44, scale: 1.4, life: 8, every: 2, count: 2, pal: [CRIMSON, MAGENTA, DARK], streak: true }),
  ...impact(kit, "erupt", { pos: [0, -0.6, 0.8], pal: PAL, size: 1.4, rays: 0, flecks: 0, spiky: false }),
  ...glow(kit, "pool", { pos: FOE_FLOOR, life: COLUMN, scale: 1.7, pal: [CRIMSON, MAGENTA, DARK], aspect: 2.6, level: 0.8 }),
  ...sparks(kit, "glitter", { at: 4, radius: 1.5, speed: 0.06, count: 2, bursts: COLUMN / 4 - 2, gap: 4, life: 12, scale: 0.12, pal: [MAGENTA, WHITE, VIOLET], fall: -0.014 }),
];

const eruptAt = WHIRL + PAN;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1426, 0, { pitch: -500, vol: 110 }),
  snd(1425, 4, { ch: "SE2", pitch: -600, vol: 100 }),
  snd(1376, WHIRL, { ch: "SE2", vol: 0 }),
  snd(1475, eruptAt, { side: "D", pitch: -500, vol: 125 }),
  snd(1426, eruptAt, { ch: "SE2", side: "D", pitch: -700, vol: 125 }),
  snd(1426, eruptAt + 14, { ch: "SE2", side: "D", pitch: -500, vol: 110 }),
)}
${arena(0, 13, 8, [2, 0, 4])}
${tint("ATTACKER", 0, 9, 6, [28, 4, 12])}
${emits(kit, user, "ATTACKER")}
${shake("ATTACKER", 819, WHIRL / 2 - 4)}
Wait ${WHIRL}
${tint("ATTACKER", 9, 0, 4, [28, 4, 12])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [31, 8, 16], power: 3 })}
${shake("DEFENDER", 1229, COLUMN / 2 - 6)}
Wait ${COLUMN - 12}
${arena(13, 0, 8, [2, 0, 4])}
Wait ${AFTER + 6}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 381],
  references: ["reference/SwShCT_Prerelease_Fiery_Wrath_2.png", "reference/Fiery_Wrath_IX.png", "reference/Fiery_Wrath_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("wheel")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("shaft")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("fire")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  wheel f${CAMERA_IN}, column f${CAMERA_IN + eruptAt}-${CAMERA_IN + eruptAt + COLUMN}`);
