MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 943
AudioContainer CONTINUE
PlaySound 1418, PSG, 14, 0, 600, 95, 0, 0, 0
PlaySound 1445, SE2, 14, 2, 1200, 90, 0, 0, 0
PlaySound 1509, SE1, 14, 12, 900, 100, 0, 0, 0
PlaySound 1407, SE1, 14, 20, 700, 125, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 4, 0, 50, 0, 0
PlaySound 1511, SE2, 16, 24, 500, 120, 0, 0, 0
PlaySound 1475, SE1, 16, 24, 0, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 0, 2, 3, 10
ChangeSpriteColor ATTACKER, 0, 6, 0, 20, 28, 31
Emit 943, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 943, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 943, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 943, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 943, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 943, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 20
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -1px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 6, 0, 0, 20, 28, 31
MoveCamera INTERPOLATION, DEFENDER, 6, 0, 8
Wait 4
Emit 943, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 943, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 943, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 943, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 943, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 943, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 24, 30, 31
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 24, 30, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ChangeBackgroundColor 4, 8, 0, 0, 2, 3, 10
Wait 22
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
