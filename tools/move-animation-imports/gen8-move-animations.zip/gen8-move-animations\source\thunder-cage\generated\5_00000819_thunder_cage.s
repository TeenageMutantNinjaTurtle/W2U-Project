MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 999
AudioContainer CONTINUE
PlaySound 1483, SE2, 14, 0, 0, 100, 0, 0, 0
PlaySound 1458, SE1, 14, 6, 300, 105, 0, 0, 0
PlaySound 1376, SE2, 14, 20, 0, 0, 0, 0, 0
PlaySound 1522, SE1, 14, 20, 0, 120, 0, 0, 0
PlaySound 1683, SE2, 16, 34, 0, 127, 0, 0, 0
PlaySound 1475, SE1, 16, 36, -200, 125, 0, 0, 0
PlaySound 1710, SE2, 16, 46, 200, 110, 0, 0, 0
PlaySound 1710, SE1, 16, 58, 400, 105, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 9, 0, 31, 30, 12
Emit 999, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 999, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 999, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 999, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 8
Wait 20
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -1px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 9, 0, 0, 31, 30, 12
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
Emit 999, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 999, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 999, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 999, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 999, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 999, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 999, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 999, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 999, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 999, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 999, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeBackgroundColor 4, 0, 9, 0, 4, 4, 12
Wait 6
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 31, 31, 14
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 31, 31, 14
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 12
Wait 26
ChangeBackgroundColor 4, 9, 0, 0, 4, 4, 12
Wait 16
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
