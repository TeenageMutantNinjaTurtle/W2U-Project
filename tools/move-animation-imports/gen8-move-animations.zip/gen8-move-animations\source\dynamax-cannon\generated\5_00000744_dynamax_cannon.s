MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 942
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, 0, 115, 0, 0, 0
PlaySound 1480, SE2, 14, 0, -300, 100, 0, 0, 0
PlaySound 1975, SE1, 14, 36, 0, 127, 0, 0, 0
PlaySound 1424, SE2, 14, 36, -400, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 8, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 44, -300, 127, 0, 0, 0
PlaySound 1420, SE2, 16, 52, 0, 127, 0, 0, 0
PlaySound 1420, SE1, 16, 60, 0, 127, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 9, 0, 24, 4, 10
ChangeSpriteColor ATTACKER, 0, 9, 0, 31, 14, 22
Emit 942, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 6, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 7, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 8, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 13
Wait 30
ChangeSpriteColor ATTACKER, 9, 14, 0, 31, 24, 28
Wait 6
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -2px, 49152, 0, 4096, 0
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 13
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 942, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 942, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeBackgroundColor 4, 14, 14, 0, 31, 20, 26
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 24, 28
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 24, 28
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 14, 9, 0, 24, 4, 10
Wait 20
ChangeSpriteColor ATTACKER, 14, 0, 0, 31, 24, 28
ChangeBackgroundColor 4, 9, 0, 0, 24, 4, 10
Wait 22
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
