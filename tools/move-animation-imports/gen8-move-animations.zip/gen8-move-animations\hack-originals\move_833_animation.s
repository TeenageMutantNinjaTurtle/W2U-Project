MoveCamera INTERPOLATION, ATTACKER, 16, 0, 12
ChangeBackgroundColor 2, 0, 16, 1, 0, 0, 0
LetCMDsFinish ALL
LoadBackground 54
MoveBackground ROUNDTRIP, 0, 8, 1, 1, 24
BackgroundPaletteAnimation 4, 5
ApplyBackground ON, 1
ApplyBackground OFF, 1
ApplyBackground 2, 0
ToggleFreezeSprite ATTACKER, START
AudioContainer CONTINUE
PlaySound 1475, SE2, 14, 10, 0, 100, 0, 0, 0
PlaySound 1475, SE1, 14, 20, 200, 90, 0, 0, 0
PlaySound 1475, SE2, 14, 30, 300, 95, 0, 0, 0
PlaySound 1475, SE1, 14, 40, 0, 100, 0, 0, 0
PlaySound 1475, SE2, 14, 50, 300, 90, 0, 0, 0
PlaySound 1475, SE1, 14, 60, -100, 95, 0, 0, 0
PlaySound 1475, SE1, 14, 70, 0, 127, 0, 0, 0
PlaySound 1475, SE2, 14, 70, 0, 127, 0, 0, 0
AudioContainer SUSPEND
LoadSPA 289
Emit 289, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 289, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 289, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor ATTACKER, 0, 12, 1, 12, 0, 0
ShakeSprite ATTACKER, 2, 0.5px, 0, 2, 0, 12
Wait 24
ShakeSprite DEFENDER, 2, 0.5px, 0, 2, 0, 3
ChangeSpriteColor ATTACKER, 12, 0, 1, 12, 0, 0
LetCMDsFinish ALL
ChangeBackgroundColor 3, 0, 16, 1, 0, 0, 0
LetCMDsFinish ALL
ChangeBackgroundColor 2, 16, 0, 0, 0, 0, 0
ApplyBackground ON, 0
ApplyBackground OFF, 0
ApplyBackground 2, 1
ToggleFreezeSprite ATTACKER, STOP
MoveCamera INTERPOLATION, INIT, 16, 0, 12
LetCMDsFinish ALL
ChangeBackgroundColor 3, 16, 0, 0, 0, 0, 0
LetCMDsFinish ALL
TerminateMoveScript
