import { aimed, createKit, hold, paint, setCurves, spin, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, FOE, FRONT, glow, hit, intro, lunge, outro, pan, shake, snd, sparks, squash, tint, WHITE } from "../tools/phrases";

// Apple Acid (move 787) - from the Bulbapedia stills (reference/sheet.png) and
// the Scarlet/Violet screenshot Logan sent on 2026-10-03: thick, glossy
// orange-yellow liquid, "like applesauce being thrown at the target".
//   1. The user heaves and flings gobs of the stuff: they lob through the air
//      one after another, smaller gobs strung out behind each.
//   2. They land on the foe with a splat - a wide spatter of sauce with
//      thick fingers running out from it - a second splat over the first,
//      gobs thrown off, and it slides and drips down off the foe.
// Both textures are drawn (generated/texture-gob.png, texture-splat.png):
// rounded shapes with a darker rim and a pale shine, so they read as liquid.

const SPA = 967;
const kit = await createKit({ workDir: import.meta.dirname, slug: "apple-acid", moveId: 787, spaId: SPA, donors: [228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 10;
const WINDUP = 10;
const GOBS = 4;
const GOB_GAP = 3;
const TRAVEL = 10;
const LOB = 1.6; // how high above a straight line each gob climbs
const AFTER = 30;
const VOLLEY = (GOBS - 1) * GOB_GAP;

// The sauce's colours, as stored (the preview shows them a little paler).
const BODY = [236, 168, 28], RIM = [196, 102, 10], SHINE = [255, 238, 160], PULP = [222, 148, 20];
const SAUCE: Rgb = [0.93, 0.66, 0.11];
const PALE: Rgb = [1.0, 0.92, 0.6];
const ORANGE: Rgb = [0.8, 0.42, 0.05];

// --- a gob of sauce: a lumpy round blob, darker at the rim, a shine on its
// upper left and flecks of pulp in it ---
const gobTex = await kit.drawn("gob", 32, 32, "a3i5", (x, y) => {
  const px = (x + 0.5 - 16) / 16, py = (y + 0.5 - 16) / 16;
  const a = Math.atan2(py, px), d = Math.hypot(px, py);
  const edge = 0.8 + 0.07 * Math.sin(3 * a + 0.6) + 0.05 * Math.sin(5 * a + 2.1);
  if (d > edge) return undefined;
  if (d > edge - 0.15) return [...RIM, 255];
  const sx = (px + 0.3) * 0.8 + (py + 0.36) * 0.6, sy = -(px + 0.3) * 0.6 + (py + 0.36) * 0.8;
  if ((sx * sx) / 0.07 + (sy * sy) / 0.02 < 1) return [...SHINE, 255];
  if (Math.hypot(px - 0.05, py + 0.58) < 0.07) return [...SHINE, 255];
  const fleck = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453;
  return fleck - Math.floor(fleck) > 0.86 ? [...PULP, 255] : [...BODY, 255];
});

// --- a splat: a pool with thick fingers running out of it, each ending in a
// bead, and a few loose drops between them ---
const FINGERS: Array<[number, number]> = [[0.3, 0.9], [1.25, 0.55], [2.05, 1.0], [2.95, 0.65], [3.75, 0.95], [4.55, 0.55], [5.45, 0.8]];
const LOOSE: Array<[number, number, number]> = [[0.8, 0.86, 0.06], [2.5, 0.9, 0.05], [4.15, 0.88, 0.06], [5.0, 0.8, 0.045]];
const splatTex = await kit.drawn("splat", 64, 64, "a3i5", (x, y) => {
  const px = (x + 0.5 - 32) / 32, py = (y + 0.5 - 32) / 32;
  const a = Math.atan2(py, px), d = Math.hypot(px, py);
  let reach = 0.4 + 0.05 * Math.sin(4 * a + 1);
  let bead = false;
  for (const [fa, len] of FINGERS) {
    reach = Math.max(reach, 0.4 + 0.5 * len * Math.pow(Math.max(0, Math.cos(a - fa)), 16));
    const tip = 0.4 + 0.5 * len - 0.04;
    if (Math.hypot(px - Math.cos(fa) * tip, py - Math.sin(fa) * tip) < 0.085) bead = true;
  }
  for (const [la, lr, size] of LOOSE) if (Math.hypot(px - Math.cos(la) * lr, py - Math.sin(la) * lr) < size) bead = true;
  if (!bead && d > reach) return undefined;
  if (!bead && d > reach - 0.07) return [...RIM, 255];
  if (bead && d > reach) return [...BODY, 255];
  // The pool's shine: a curved streak across its upper left.
  const shine = Math.abs(Math.hypot(px + 0.05, py + 0.02) - 0.24) < 0.035 && px < 0.05 && py < 0.05;
  if (shine) return [...SHINE, 255];
  const fleck = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453;
  return fleck - Math.floor(fleck) > 0.88 ? [...PULP, 255] : [...BODY, 255];
});

// --- 1. the gobs: lobbed, each with two smaller ones strung out behind it ---
const lobSlope = LOB / 4; // rise per unit forward at the start, for an arc LOB high
const lobSpeed = (16 / TRAVEL) * Math.hypot(1, lobSlope);
const lobFall: Vec3 = [0, (-8 * LOB) / (TRAVEL * TRAVEL), 0];
const thrown: string[] = [];
for (const [name, scale, behind] of [["gobs", 0.62, 0], ["gobTails", 0.36, 1], ["gobTips", 0.22, 2]] as const) {
  const r = kit.parked(gobTex, [...FRONT] as Vec3, scale, TRAVEL + 1);
  r.startDelayFrames = WINDUP + behind;
  aimed(r, lobSpeed, TRAVEL + 1, -lobSlope);
  r.airResistance = 1.0;
  Object.assign(r, { emitterLifeFrames: VOLLEY + 1, emissionIntervalFrames: GOB_GAP });
  r.behaviors = [{ type: "gravity", magnitude: lobFall }];
  spin(r, 0.12, 0.2, 0, true);
  setCurves(r, { start: 0.85, mid: 1.1, end: 0.95, curveIn: 0.4, curveOut: 0.8 }, hold(1));
  paint(r, WHITE);
  kit.add(name, r);
  thrown.push(name);
}
const user = sparks(kit, "flung", { pos: FRONT, at: WINDUP, radius: 0.4, speed: 0.14, count: 2, bursts: GOBS, gap: GOB_GAP, life: 12, scale: 0.16, pal: [WHITE, WHITE, WHITE], fall: 0.02, twinkle: false, tex: gobTex, spin: 0.2 });

// --- 2. the splat ---
function splat(name: string, at: number, pos: Vec3, scale: number, turn: number, life: number): string {
  const r = kit.parked(splatTex, pos, scale, life);
  r.startDelayFrames = at;
  spin(r, 0, 0, turn);
  // It slaps on at once, a touch too wide, settles - and then slides down.
  Object.assign(r, { axis: [0, -1, 0], initVelAxisAmplifier: 0.025, airResistance: 1.0 });
  setCurves(r, { start: 0.3, mid: 1.12, end: 1.0, curveIn: 3 / life, curveOut: 0.5 }, { start: 1, mid: 1, end: 0, curveIn: 0, curveOut: 0.7 });
  paint(r, WHITE);
  kit.add(name, r);
  return name;
}
const foe = [
  // Gobs thrown off by each landing, falling away.
  ...sparks(kit, "spatter", { radius: 0.5, speed: 0.26, count: 3, bursts: GOBS, gap: GOB_GAP, life: 16, scale: 0.24, pal: [WHITE, WHITE, WHITE], fall: 0.03, twinkle: false, tex: gobTex, spin: 0.2, shape: "circle" }),
  // Drips running down off the foe: gobs drawn tall and narrow, falling slowly.
  ...sparks(kit, "drips", { pos: [0, 0.1, 0.95], at: 4, radius: 1.0, speed: 0.01, count: 1, bursts: (VOLLEY + 12) / 3, gap: 3, life: 16, scale: 0.26, pal: [WHITE, WHITE, WHITE], fall: 0.012, twinkle: false, shape: "ball", tex: gobTex }),
  splat("splatTop", VOLLEY, [0.25, 0.5, 1.0], 1.25, 2.2, 22),
  splat("splatMain", 0, [-0.1, 0.25, 0.95], 1.6, 0.4, VOLLEY + 24),
  ...glow(kit, "soaked", { pos: FOE, life: VOLLEY + 18, scale: 2.6, pal: [SAUCE, ORANGE, PALE], level: 0.4 }),
];
kit.resources[kit.idx("drips")]!.aspectRatio = 0.55;

const landAt = WINDUP + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1727, WINDUP, { pitch: 300, vol: 120 }),
  snd(1407, WINDUP, { ch: "SE2", pitch: -300, vol: 105 }),
  snd(1727, WINDUP + GOB_GAP * 2, { pitch: 500, vol: 110 }),
  snd(1727, landAt, { side: "D", pitch: -100, vol: 127 }),
  snd(1511, landAt, { ch: "SE2", side: "D", pitch: -400, vol: 110 }),
  snd(1727, landAt + VOLLEY, { side: "D", pitch: -300, vol: 125 }),
  snd(1727, landAt + VOLLEY + 10, { ch: "SE2", side: "D", pitch: -600, vol: 100 }),
)}
${tint("ATTACKER", 0, 7, 4, [31, 26, 6])}
${squash("ATTACKER", -819, 819, 4)}
${emits(kit, user, "ATTACKER")}
${emits(kit, thrown, "ATTACKER", "DEFENDER")}
Wait ${WINDUP}
${lunge("ATTACKER", 2)}
${shake("ATTACKER", 819, VOLLEY / 2)}
${tint("ATTACKER", 7, 0, 4, [31, 26, 6])}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [31, 26, 8], power: 2 })}
Wait ${VOLLEY - 4}
ToggleFreezeSprite DEFENDER, START
${tint("DEFENDER", 0, 9, 0, [31, 26, 8])}
${shake("DEFENDER", 1229, 4)}
Wait 2
${tint("DEFENDER", 9, 0, 8, [31, 26, 8])}
Wait ${AFTER - 2}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 153, 129, 188],
  references: ["reference/Apple_Acid_VIII.png", "reference/Apple_Acid_IX.png", "reference/Apple_Acid_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("gobs")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("splatMain")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("drips")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  gobs thrown f${CAMERA_IN + WINDUP}-${CAMERA_IN + WINDUP + VOLLEY}, first lands f${CAMERA_IN + landAt}, second splat f${CAMERA_IN + landAt + VOLLEY}`);
