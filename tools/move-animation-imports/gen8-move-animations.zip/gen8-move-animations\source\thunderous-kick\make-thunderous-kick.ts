import { createKit, deg, fadeOut, grow, paint, setCurves, spin, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, emits, FOE, glow, hit, impact, intro, lunge, outro, pan, quake, shake, snd, sparks, streaks, tint, USER_FLOOR, WHITE, zaps, type Pal } from "../tools/phrases";

// Thunderous Kick (move 823) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user sets its legs, power crackling at its feet.
//   2. The kick: a great foot drives into the foe, sparks flying across it.
//   3. It lands like a thunderclap: a blinding yellow-white blast, jagged
//      and torn at the edges.
// The foot is Double Kick's (SPA 190), in electric yellow - Logan's direction
// (2026-10-03); the sparks and arcs are Thunder's (SPA 257).

const SPA = 1003;
const kit = await createKit({ workDir: import.meta.dirname, slug: "thunderous-kick", moveId: 823, spaId: SPA, donors: [190, 257, 228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const SET = 16;
const PAN = 7;
const SWEEP = 3; // the foot drives in, then the blast
const FOOT = 18; // how long the foot shows
const AFTER = 28;

const YELLOW: Rgb = [1.0, 0.9, 0.25];
const PALE: Rgb = [1.0, 0.98, 0.75];
const ORANGE: Rgb = [1.0, 0.6, 0.15];
const PAL: Pal = [YELLOW, PALE, ORANGE];

const user = [
  ...zaps(kit, "footArcs", { pos: [0, USER_FLOOR[1] + 0.4, 0.4], radius: 1.1, count: 1, bursts: SET / 3, gap: 3, life: 6, scale: 0.55, pal: [YELLOW, WHITE, PALE], shape: "circle" }),
  ...streaks(kit, "footLines", { pos: [0, USER_FLOOR[1] + 0.3, 0.4], radius: 0.6, speed: 0.3, count: 3, bursts: SET / 4, gap: 4, life: 7, scale: 0.6, pal: [YELLOW, WHITE, ORANGE], flat: true, lift: 0.1 }),
  ...glow(kit, "power", { pos: [0, -0.6, 0.3], life: SET + 4, scale: 2.0, pal: [YELLOW, ORANGE, PALE], level: 0.6 }),
];

// The foot: it comes in big and close and drives down onto the foe, then
// holds there while the sparks run over it.
const footTex = kit.tex(190, 2);
function foot(name: string, scale: number, level: number, colours: [Rgb, Rgb, Rgb]): string {
  const r = kit.parked(footTex, [0.15, 0.45, 1.0], scale, FOOT);
  spin(r, 0, 0, deg(-18));
  setCurves(r, { start: 2.1, mid: 1.0, end: 1.06, curveIn: SWEEP / FOOT, curveOut: 0.8 }, { start: 0.5, mid: level, end: 0, curveIn: SWEEP / FOOT, curveOut: 0.7 });
  paint(r, colours[0], colours[1], colours[2]);
  kit.add(name, r);
  return name;
}
const foe = [
  // Sparks flying across the foot, in front of it.
  ...zaps(kit, "footSparks", { pos: [0.15, 0.45, 1.05], at: SWEEP - 1, radius: 1.2, speed: 0.1, count: 2, bursts: 6, gap: 2, life: 6, scale: 0.8, pal: [YELLOW, WHITE, PALE], shape: "circle" }),
  foot("foot", 1.45, 1, [YELLOW, PALE, YELLOW]), // one foot only: a glow copy behind it read as a second foot (Logan, 2026-10-03)
  ...impact(kit, "clap", { at: SWEEP, pal: PAL, size: 1.8, rays: 10, flecks: 0 }),
  ...glow(kit, "whiteout", { pos: FOE, at: SWEEP, life: 12, scale: 3.8, pal: [PALE, WHITE, YELLOW], level: 0.85, scaleCurve: grow(0.4, 0.2, 1.2), alpha: fadeOut(0.85, 0.45) }),
  ...streaks(kit, "jags", { at: SWEEP, radius: 0.7, speed: 0.48, count: 9, life: 11, scale: 1.1, pal: [YELLOW, ORANGE, PALE], tex: kit.tex(T.shard) }),
  ...zaps(kit, "forks", { at: SWEEP + 1, radius: 0.7, speed: 0.24, count: 3, bursts: 3, gap: 3, life: 8, scale: 0.9, pal: [YELLOW, WHITE, PALE], shape: "circle" }),
  ...sparks(kit, "after", { at: SWEEP + 8, radius: 1.5, speed: 0.12, count: 3, bursts: 3, gap: 4, life: 12, scale: 0.14, pal: [YELLOW, WHITE, ORANGE], fall: 0.008 }),
];

const kickAt = SET + PAN;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1458, 0, { pitch: 300, vol: 105 }),
  snd(1452, 4, { ch: "SE2", pitch: -200, vol: 105 }),
  snd(1407, SET, { pitch: 100, vol: 125 }),
  snd(1438, kickAt, { ch: "SE2", side: "D", pitch: 300, vol: 120 }),
  snd(1683, kickAt + SWEEP - 1, { side: "D", vol: 127 }),
  snd(1475, kickAt + SWEEP, { ch: "SE2", side: "D", pitch: -400, vol: 127 }),
)}
${tint("ATTACKER", 0, 9, 5, [31, 29, 10])}
${emits(kit, user, "ATTACKER")}
ScaleSprite ATTACKER, ROUNDTRIP, 819, -1229, ${SET - 4}, 0, 1
${shake("ATTACKER", 819, SET / 2 - 2)}
Wait ${SET}
${lunge("ATTACKER", 5)}
${tint("ATTACKER", 9, 0, 4, [31, 29, 10])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
Wait ${SWEEP}
${arena(0, 13, 0, [31, 31, 22])}
${hit({ rgb: [31, 31, 16], power: 3, freeze: false })}
${arena(13, 0, 5, [31, 31, 22])}
Wait 10
${quake("1x", 8)}
Wait ${AFTER - 10}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [24, 87, 63, 605, 400, 240, 129],
  references: ["reference/SwShCT_Prerelease_Thunderous_Kick_2.png", "reference/Thunderous_Kick_IX.png", "reference/Thunderous_Kick_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("footArcs")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("foot")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("footSparks")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("clapFlash")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  sets f${CAMERA_IN}, kick f${CAMERA_IN + kickAt}, lands f${CAMERA_IN + kickAt + SWEEP}`);
