import { createKit, fadeOut, grow, setCurves, T, type Rgb } from "../tools/anim-kit";
import { audio, BITE_FRAMES, emits, fangs, FOE, glow, hit, impact, intro, lunge, outro, pan, ring, slash, snd, sparks, squash, streaks, tint, WHITE, type Pal } from "../tools/phrases";

// Fishious Rend (move 755) - from the Bulbapedia still (reference/sheet.png).
// The user bites into the foe and the bite bursts in water: a great
// blue-white splash with a bright horizontal slash through it, spray and
// droplets flying.
// The fangs are Crunch's, tinted pale blue; the splash ring and water orbs
// are Aqua Jet's.

const SPA = 953;
const kit = await createKit({ workDir: import.meta.dirname, slug: "fishious-rend", moveId: 755, spaId: SPA, donors: [413, 632, 228, 465, 579, 411, 321] });

const CAMERA_IN = 10;
const WINDUP = 8;
const PAN = 8;
const AFTER = 24;

const BLUE: Rgb = [0.25, 0.6, 1.0];
const CYAN: Rgb = [0.5, 0.88, 1.0];
const PALE: Rgb = [0.86, 0.96, 1.0];
const PAL: Pal = [CYAN, PALE, BLUE];
const BITE = BITE_FRAMES;

const jaws = fangs(kit, "fang", { tint: [0.8, 0.95, 1.0], scale: 1.6 });
const foe = [
  ...jaws,
  ...glow(kit, "wet", { pos: FOE, life: BITE + 16, scale: 2.8, pal: [CYAN, BLUE, PALE], level: 0.55 }),
  ...slash(kit, "rend", { at: BITE, angle: 0, scale: 3.6, pal: [PALE, WHITE, CYAN], life: 9 }),
  ...impact(kit, "burst", { at: BITE, pal: PAL, size: 1.35, rays: 0, flecks: 0 }),
  ...ring(kit, "splash", { at: BITE, scale: 1.5, pal: [PALE, WHITE, CYAN], tex: kit.tex(632, 2), to: 2.0, life: 11 }),
  ...streaks(kit, "spray", { at: BITE, radius: 0.5, speed: 0.45, count: 10, life: 11, scale: 0.85, pal: [BLUE, PALE, CYAN], tex: kit.tex(T.spike) }),
  ...streaks(kit, "spray2", { at: BITE + 3, radius: 0.5, speed: 0.3, count: 6, life: 10, scale: 0.6, pal: [CYAN, WHITE, BLUE], tex: kit.tex(T.spike) }),
  ...sparks(kit, "orbs", { at: BITE, radius: 0.6, speed: 0.26, count: 6, life: 16, scale: 0.26, pal: [WHITE, WHITE, WHITE], fall: 0.014, tex: kit.tex(632, 0), twinkle: false }),
  ...sparks(kit, "droplets", { at: BITE + 1, radius: 0.7, speed: 0.34, count: 8, life: 16, scale: 0.13, pal: [PALE, WHITE, CYAN], fall: 0.012, twinkle: false }),
];
for (const n of ["spray", "spray2"]) setCurves(kit.resources[kit.idx(n)]!, grow(1.1, 0.3, 0.6), fadeOut());

const user = glow(kit, "ready", { life: WINDUP + 4, scale: 2.2, pal: PAL, level: 0.55 });

const biteAt = WINDUP + PAN + BITE;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1445, 0, { pitch: 600, vol: 95 }),
  snd(1720, biteAt, { side: "D", pitch: -500, vol: 127 }),
  snd(1488, biteAt, { ch: "SE2", side: "D", pitch: -100, vol: 127 }),
  snd(1511, biteAt + 1, { side: "D", pitch: 300, vol: 120 }),
)}
${tint("ATTACKER", 0, 8, 3, [12, 24, 31])}
${emits(kit, user, "ATTACKER")}
${squash("ATTACKER", -819, 819, 4)}
Wait ${WINDUP}
${lunge("ATTACKER", 4)}
${tint("ATTACKER", 8, 0, 4, [12, 24, 31])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
Wait ${BITE}
${hit({ rgb: [22, 29, 31], power: 3 })}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [242, 453, 63, 605, 400, 240, 153],
  references: ["reference/Fishious_Rend_VIII.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("fangUpperShut")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("rend")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  jaws f${CAMERA_IN + WINDUP + PAN}, bite f${CAMERA_IN + biteAt}`);
