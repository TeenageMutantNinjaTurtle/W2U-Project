ToggleSpriteShadow ALL, ON
MoveCamera INTERPOLATION, DEFENDER, 16, 0, 8
LetCMDsFinish ALL
AudioContainer CONTINUE
PlaySound 1439, SE1, 16, 0, 0, 100, 0, 0, 0
PlaySound 1497, SE2, 16, 0, 0, 120, 0, 0, 0
PlaySound 1376, SE2, 16, 130, 0, 0, 0, 0, 0
PlaySound 1376, SE1, 16, 130, 0, 0, 0, 0, 0
AdjustSound SE1, 0, 1, 100, 0, 100, 30, 0, 0
AdjustSound SE2, 0, 1, 120, 0, 100, 30, 0, 0
AudioContainer SUSPEND
LoadSPA 502
Emit 502, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 502, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 502, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
Wait 30
ShakeSprite DEFENDER, 2, 1px, 0, 3, 1, 8
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, STOP
ToggleSpriteShadow ALL, OFF
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
