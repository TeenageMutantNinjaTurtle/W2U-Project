AdjustCamera INTERPOLATION_RELATIVE, 3px, 0, 5px, 0, 0, 0, 32, 0, 28
ChangeBackgroundColor 4, 0, 16, 2, 0, 0, 0
LetCMDsFinish ALL
AudioContainer CONTINUE
PlaySound 1536, SE1, 14, 0, 0, 120, 0, 0, 0
PlaySound 1535, SE2, 14, 50, 0, 120, 0, 0, 0
AudioContainer SUSPEND
LoadSPA 530
LoadSPA 644
Emit 644, 1, ATTACKER, NONE, 1229, 0, 0, 1x, 1x, 1x, 1x
Emit 644, 2, ATTACKER, NONE, 819, 0, 0, 1x, 1x, 5x, 1x
Emit 644, 0, ATTACKER, NONE, 819, 0, 0, 1x, 1x, 1x, 1x
Emit 644, 4, ATTACKER, NONE, 819, 0, 0, 1x, 1x, 1x, 1x
Wait 20
LetCMDsFinish ALL
AudioContainer CONTINUE
PlaySound 1445, SE1, 16, 0, 0, 100, 0, 0, 0
PlaySound 1376, SE1, 16, 100, 0, 0, 0, 0, 0
AdjustSound SE1, 0, 0, -1000, 3000, 0, 100, 0, 0
AdjustSound SE1, 0, 1, 120, 0, 60, 40, 0, 0
AudioContainer SUSPEND
ToggleFreezeSprite DEFENDER, START
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 2, 2, 6
Emit 530, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 20
Emit 530, 1, DEFENDER, NONE, 1px, 0, 0, 1x, 1x, 1x, 1x
Wait 30
Emit 530, 1, DEFENDER, NONE, 1px, 0, 0, 1x, 1x, 1x, 1x
Wait 20
LetCMDsFinish ALL
ApplyBackground OFF, 0
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 16, 0, 2, 0, 0, 0
MoveCamera INTERPOLATION, INIT, 16, 0, 12
LetCMDsFinish ALL
TerminateMoveScript
