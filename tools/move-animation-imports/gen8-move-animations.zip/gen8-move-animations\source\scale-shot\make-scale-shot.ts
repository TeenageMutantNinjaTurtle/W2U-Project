import { assert, createKit, hold, T, twinkle, type Rgb } from "../tools/anim-kit";
import { audio, emits, FOE, glow, hit, introStill, lunge, outro, shot, snd, sparks, streaks, tint, WHITE, type Pal } from "../tools/phrases";

// Scale Shot (move 799) - from the Bulbapedia stills (reference/sheet.png).
// The user flings its scales: flat, silvery plates with darker bands spin
// across and strike in small violet sparks.
// Two to five hits: Gen 5 replays the animation per hit, so the camera stays
// still and one hit (a volley of three scales) is under a second.
// The scale is drawn (generated/texture-scale.png).

const SPA = 979;
const kit = await createKit({ workDir: import.meta.dirname, slug: "scale-shot", moveId: 799, spaId: SPA, donors: [228, 465, 579, 411, 298, 407] });

const WINDUP = 4;
const SCALES = 3;
const SCALE_GAP = 2;
const TRAVEL = 7;
const AFTER = 12;

const VIOLET: Rgb = [0.7, 0.35, 1.0];
const PALE: Rgb = [0.93, 0.85, 1.0];
const PAL: Pal = [VIOLET, PALE, [0.45, 0.2, 0.85]];

// --- the drawn scale: a pointed plate of dark blue with darker bands and a
// paler sheen along one edge (darker blue at Logan's request, 2026-10-03) ---
const scaleTex = await kit.drawn("scale", 32, 16, "a3i5", (x, y) => {
  const u = (x + 0.5) / 32, py = y + 0.5 - 8;
  // A leaf shape: pointed at both ends, widest a third of the way along.
  const half = 6.5 * Math.sin(Math.PI * Math.pow(u, 0.75));
  if (Math.abs(py) > half) return undefined;
  if (Math.abs(py) > half - 1.1) return [10, 20, 78];
  const band = Math.floor(u * 7) % 2 === 0;
  const light = Math.max(0, 1 - Math.abs(py + 2) / 6);
  const base = band ? [22, 48, 140] : [40, 84, 185];
  return [Math.round(base[0]! + 60 * light), Math.round(base[1]! + 75 * light), Math.round(Math.min(255, base[2]! + 55 * light))];
});

shot(kit, "scales", scaleTex, { from: [0.3, 0.6, -0.8], at: WINDUP, travel: TRAVEL, scale: 0.42, pal: [WHITE, WHITE, WHITE], count: SCALES, gap: SCALE_GAP, spin: 0.6, aspect: 2, scaleCurve: hold(1), alpha: hold(1) });
const user = sparks(kit, "shed", { pos: [0.3, 0.6, -0.4], at: WINDUP, radius: 0.4, speed: 0.14, count: 2, bursts: SCALES, gap: SCALE_GAP, life: 8, scale: 0.12, pal: [[0.35, 0.55, 0.95], [0.7, 0.82, 1.0], [0.15, 0.3, 0.75]] });

const LAND = TRAVEL;
const foe = [
  ...Array.from({ length: SCALES }, (_, i) => glow(kit, `spark${i}`, { pos: [-0.5 + i * 0.5, 0.6 - i * 0.3, 1.0], at: i * SCALE_GAP, life: 7, scale: 0.8, pal: [PALE, WHITE, VIOLET], tex: kit.tex(T.hitStar), spin: 0.15, level: 1, scaleCurve: twinkle(1.25), alpha: twinkle(1) })).flat(),
  ...streaks(kit, "chips", { radius: 0.4, speed: 0.3, count: 3, bursts: SCALES, gap: SCALE_GAP, life: 8, scale: 0.5, pal: [VIOLET, PALE, WHITE] }),
  ...sparks(kit, "flecks", { radius: 0.5, speed: 0.22, count: 2, bursts: SCALES, gap: SCALE_GAP, life: 12, scale: 0.13, pal: [[0.35, 0.55, 0.95], [0.7, 0.82, 1.0], VIOLET], fall: 0.012, twinkle: false }),
];

const script = `${introStill(SPA)}
${audio(
  ...Array.from({ length: SCALES }, (_, i) => snd(1539, WINDUP + i * SCALE_GAP, { ch: i % 2 ? "SE2" : "SE1", pitch: 300 + i * 120, vol: 110 })),
  ...Array.from({ length: SCALES }, (_, i) => snd(1423, WINDUP + LAND + i * SCALE_GAP, { ch: i % 2 ? "SE1" : "SE2", side: "D", pitch: 400 + i * 100, vol: 105 })),
)}
${tint("ATTACKER", 0, 6, 2, [26, 27, 31])}
${emits(kit, user, "ATTACKER")}
${emits(kit, ["scales"], "ATTACKER", "DEFENDER")}
Wait ${WINDUP}
${lunge("ATTACKER", 2)}
${tint("ATTACKER", 6, 0, 3, [26, 27, 31])}
Wait ${LAND}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [27, 22, 31], power: 1 })}
Wait ${(SCALES - 1) * SCALE_GAP + AFTER}
${outro({ camera: false })}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 236, 163],
  references: ["reference/Scale_Shot_VIII.png", "reference/Scale_Shot_IX.png", "reference/Scale_Shot_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("scales")}, ATTACKER, DEFENDER`, `Emit ${SPA}, ${kit.idx("spark0")}, DEFENDER`],
});
assert.ok(!script.includes("MoveCamera"), "Multi-hit animation moves the camera");
console.log(`  scales f${WINDUP}, first lands f${WINDUP + LAND}, one hit ~${WINDUP + LAND + 2 + (SCALES - 1) * SCALE_GAP + AFTER} frames`);
