import { aimed, createKit, fadeInOut, hold, setCurves, T, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, glow, introStill, outro, ring, risers, snd, sparks, squash, WHITE, type Pal, type Side } from "../tools/phrases";

// Court Change (move 756) - from the Bulbapedia stills (reference/sheet.png).
// A glowing white court marking lights up on the ground under each side;
// hollow bubbles of light rise off each - gold on the user's side, cyan on
// the foe's - and the two sets swap courts.
// A field move: the wide shot is kept throughout. Swapping the sides' field
// effects is the engine's part.

const SPA = 954;
const kit = await createKit({ workDir: import.meta.dirname, slug: "court-change", moveId: 756, spaId: SPA, donors: [228, 465, 298, 560, 407] });

const RISE = 24; // courts light, bubbles rise
const CROSS = 14; // bubbles fly to the other court
const SETTLE = 24;

const GOLD: Rgb = [1.0, 0.82, 0.3];
const PALE_GOLD: Rgb = [1.0, 0.95, 0.7];
const CYAN: Rgb = [0.4, 0.9, 1.0];
const PALE_CYAN: Rgb = [0.8, 0.97, 1.0];
const GOLDS: Pal = [GOLD, PALE_GOLD, [1.0, 0.65, 0.15]];
const CYANS: Pal = [CYAN, PALE_CYAN, [0.2, 0.7, 1.0]];
const COURT: Vec3 = [0, -1.6, 0.4];
const TOTAL = RISE + CROSS + SETTLE;

function side(who: "user" | "foe", own: Pal, other: Pal): { first: string[]; cross: string } {
  const first = [
    // The court marking: a wide ring of light lying on the ground, with a second inside it.
    ...ring(kit, `${who}Court`, { pos: COURT, life: TOTAL, scale: 1.25, pal: [WHITE, WHITE, own[1]], tex: kit.tex(T.ring), aspect: 2.5, to: 1.02, level: 0.95 }),
    ...ring(kit, `${who}CourtInner`, { pos: COURT, at: 3, life: TOTAL - 3, scale: 0.8, pal: [own[1], WHITE, own[0]], tex: kit.tex(T.hoop), aspect: 2.5, to: 1.02, level: 0.7 }),
    ...glow(kit, `${who}CourtGlow`, { pos: COURT, life: TOTAL, scale: 1.3, pal: [own[1], WHITE, own[0]], aspect: 2.6, level: 0.45 }),
    // Its bubbles, rising.
    ...risers(kit, `${who}Bubbles`, { pos: [0, -1.3, 0.5], frames: RISE - 4, radius: 1.7, speed: 0.09, scale: 0.24, life: 18, every: 2, pal: own, tex: kit.tex(T.ring) }),
    // After the swap: the other side's bubbles settle here and the court takes their colour.
    ...sparks(kit, `${who}Arrived`, { pos: [0, 0.2, 0.5], at: RISE + CROSS - 2, radius: 1.6, speed: 0.02, count: 2, bursts: 6, gap: 3, life: 14, scale: 0.24, pal: other, fall: 0.006, shape: "ball", tex: kit.tex(T.ring) }),
    ...ring(kit, `${who}Pulse`, { pos: COURT, at: RISE + CROSS, life: 14, scale: 1.3, pal: [other[0], WHITE, other[2]], tex: kit.tex(T.hoop), aspect: 2.5, to: 1.6 }),
    ...glow(kit, `${who}Glint`, { pos: [0, 0.6, 0.6], at: RISE + CROSS, life: 9, scale: 0.9, pal: [WHITE, WHITE, other[1]], tex: kit.tex(T.star4Big), scaleCurve: twinkle(1.3), alpha: twinkle(1) }),
  ];
  // The court markings hold steady instead of swelling away.
  for (const n of [`${who}Court`, `${who}CourtInner`]) setCurves(kit.resources[kit.idx(n)]!, { start: 0.6, mid: 1, end: 1, curveIn: 0.1, curveOut: 1 }, fadeInOut(kit.resources[kit.idx(n)]!.alphaAnim!.mid, 0.1, 0.9));
  // Its bubbles flying across to the other court.
  const cross = kit.spray([333, 1], kit.tex(T.ring), [0, 1.2, 0.3], { radius: 1.2, speed: 0.01, count: 2, bursts: 5, gap: 2, life: CROSS + 2, scale: 0.24, shape: "ball" });
  cross.startDelayFrames = RISE;
  aimed(cross, 16 / CROSS, CROSS + 2);
  cross.airResistance = 1.0;
  cross.variance.lifeTime = 0;
  setCurves(cross, hold(1), fadeInOut(1, 0.15, 0.8));
  kit.prism(cross, own);
  kit.add(`${who}Cross`, cross);
  return { first, cross: `${who}Cross` };
}
const user = side("user", GOLDS, CYANS);
const foe = side("foe", CYANS, GOLDS);

const at = (who: Side, names: string[]) => emits(kit, names, who);
const script = `${introStill(SPA)}
${audio(
  snd(1510, 0, { vol: 110 }),
  snd(1510, 2, { ch: "SE2", side: "D", pitch: 200, vol: 105 }),
  snd(1455, RISE, { ch: "SE2", side: "FLAT", vol: 115 }),
  snd(1452, RISE + CROSS, { vol: 110 }),
  snd(1452, RISE + CROSS + 2, { ch: "SE2", side: "D", pitch: 100, vol: 110 }),
)}
${arena(0, 9, 8, [2, 4, 10])}
${at("ATTACKER", user.first)}
${at("DEFENDER", foe.first)}
${kit.emit(user.cross, "ATTACKER", "DEFENDER")}
${kit.emit(foe.cross, "DEFENDER", "ATTACKER")}
Wait ${RISE + CROSS}
${squash("ATTACKER", 819, -819, 4)}
${squash("DEFENDER", 819, -819, 4)}
Wait ${SETTLE - 8}
${arena(9, 0, 8, [2, 4, 10])}
Wait 8
${outro({ camera: false, unfreeze: "NONE" })}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 129, 381, 236],
  references: ["reference/Court_Change_VIII.png", "reference/Court_Change_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("userCourt")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("foeCross")}, DEFENDER, ATTACKER`],
});
console.log(`  courts f0, swap f${RISE}-${RISE + CROSS}, settle until f${TOTAL}`);
