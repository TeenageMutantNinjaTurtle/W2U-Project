MoveCamera INTERPOLATION, ATTACKER, 16, 0, 12
AudioContainer CONTINUE
PlaySound 1589, SE1, 14, 0, 0, 127, 0, 0, 0
PlaySound 1654, SE2, 14, 0, -1000, 127, 0, 0, 0
PlaySound 1489, SE1, 14, 80, 500, 127, 0, 0, 0
PlaySound 1438, SE2, 14, 100, 500, 127, 0, 0, 0
AudioContainer SUSPEND
ToggleFreezeSprite ATTACKER, START
ChangeSpriteColor ATTACKER, 0, 14, 1, 22, 22, 12
LoadSPA 685
Emit 685, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor ATTACKER, 14, 0, 1, 22, 22, 12
ChangeBackgroundColor 2, 0, 8, 0, 31, 31, 31
LetCMDsFinish ALL
ChangeBackgroundColor 2, 8, 0, 0, 31, 31, 31
LetCMDsFinish ALL
ChangeBackgroundColor 2, 0, 8, 0, 31, 31, 31
LetCMDsFinish ALL
ChangeBackgroundColor 2, 8, 0, 0, 31, 31, 31
MoveSprite ATTACKER, DIRECT, 0, 4px, 0, 40960, 0, 4096, 0
LetCMDsFinish CAMERA
Wait 16
MoveCamera INTERPOLATION, DEFENDER, 16, 0, 12
Emit 685, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 0.5x, 0.5x, 1x
Wait 10
Emit 685, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
AudioContainer CONTINUE
PlaySound 1420, SE1, 16, 0, 0, 127, 0, 0, 0
PlaySound 1420, SE2, 16, 7, 0, 127, 0, 0, 0
PlaySound 1420, SE1, 16, 13, 0, 127, 0, 0, 0
PlaySound 1420, SE2, 16, 22, 0, 127, 0, 0, 0
PlaySound 1420, SE1, 16, 30, -500, 127, 0, 0, 0
AudioContainer SUSPEND
Wait 10
Emit 685, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 10
ScaleSprite DEFENDER, ROUNDTRIP, -819, 819, 4, 0, 2
MoveSprite DEFENDER, DIRECT, 0, 4px, 0, 40960, 0, 4096, 0
ToggleFreezeSprite ATTACKER, STOP
Wait 20
MoveCamera INTERPOLATION, INIT, 16, 0, 12
LetCMDsFinish ALL
TerminateMoveScript
