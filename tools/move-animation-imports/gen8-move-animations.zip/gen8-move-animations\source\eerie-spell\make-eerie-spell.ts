import { createKit, fadeInOut, grow, setCurves, spin, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, circleEmits, emits, FOE, FOE_FLOOR, glow, hit, impact, intro, outro, pan, ring, risers, shake, snd, sparks, streaks, tint, USER_FLOOR, vortex, WHITE, type Pal } from "../tools/phrases";

// Eerie Spell (move 826) - from the Bulbapedia stills (reference/sheet.png).
//   1. The light sinks to violet. The user chants: tangled knots of glowing
//      pink line - the spell - bloom in the air round it over a dark pool,
//      thin green-cyan light streaming upward.
//   2. Round the foe the spell closes in a whirl of violet and white bands,
//      the knots flaring in it.
// The spell knot is drawn (generated/texture-knot.png); the whirl is
// Hurricane's tornado in violet.

const SPA = 1006;
const kit = await createKit({ workDir: import.meta.dirname, slug: "eerie-spell", moveId: 826, spaId: SPA, donors: [711, 228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const CHANT = 30;
const PAN = 10;
const WHIRL = 34;
const AFTER = 12;

const MAGENTA: Rgb = [1.0, 0.3, 0.9];
const PINK: Rgb = [1.0, 0.72, 0.97];
const VIOLET: Rgb = [0.55, 0.3, 1.0];
const DEEP: Rgb = [0.18, 0.06, 0.4];
const TEAL: Rgb = [0.45, 1.0, 0.8];
const YELLOW: Rgb = [1.0, 0.92, 0.4];
const SPELL: Pal = [MAGENTA, PINK, [0.9, 0.2, 0.75]];

// --- the drawn spell knot: tangled loops of line, a white mask to be tinted ---
const LOOPS: Array<[number, number, number, number, number]> = [[16, 16, 11, 7, 0.5], [15, 17, 8, 11, -0.4], [18, 14, 6, 9, 1.2], [14, 15, 10, 5, -1.0], [17, 18, 5, 6, 0.2]];
const knotTex = await kit.drawn("knot", 32, 32, "a5i3", (x, y) => {
  let best = 9;
  for (const [cx, cy, rx, ry, turn] of LOOPS) {
    const dx = x + 0.5 - cx, dy = y + 0.5 - cy;
    const c = Math.cos(turn), s = Math.sin(turn);
    const u = (dx * c + dy * s) / rx, v = (-dx * s + dy * c) / ry;
    best = Math.min(best, Math.abs(Math.hypot(u, v) - 1) * Math.min(rx, ry));
  }
  if (best > 1.3) return undefined;
  return [255, 255, 255, best < 0.6 ? 255 : 150];
});

function knots(name: string, pos: Vec3, at: number, frames: number, radius: number, scale: number): string {
  const r = kit.spray([333, 1], knotTex, pos, { radius, speed: 0.02, count: 1, bursts: Math.round(frames / 4), gap: 4, life: 14, scale, shape: "ball" });
  r.startDelayFrames = at;
  r.variance.lifeTime = 0;
  spin(r, -0.08, 0.08, 0, true);
  setCurves(r, grow(0.3, 0.3, 1.15), fadeInOut(1, 0.15, 0.6));
  kit.prism(r, SPELL);
  kit.add(name, r);
  return name;
}

const user = [
  knots("userKnots", [0, 0.2, 0.5], 2, CHANT - 4, 2.2, 0.7),
  ...risers(kit, "greenLight", { pos: USER_FLOOR, frames: CHANT, radius: 1.8, speed: 0.36, scale: 1.2, life: 9, every: 3, pal: [TEAL, WHITE, [0.4, 0.9, 1.0]], streak: true }),
  ...sparks(kit, "motes", { pos: [0, 0.4, 0.4], radius: 2.0, speed: 0.03, count: 1, bursts: CHANT / 3, gap: 3, life: 12, scale: 0.13, pal: [TEAL, YELLOW, PINK], shape: "ball" }),
  ...ring(kit, "ripple", { pos: USER_FLOOR, at: 4, scale: 1.3, pal: [VIOLET, PINK, DEEP], tex: kit.tex(T.thinRings), aspect: 2.6, to: 1.6, life: CHANT - 6, level: 0.85 }),
  ...glow(kit, "pool", { pos: USER_FLOOR, life: CHANT + 4, scale: 1.7, pal: [DEEP, VIOLET, [0.05, 0, 0.15]], aspect: 2.6, level: 0.9 }),
];

// The whirl is turned over (Logan's direction, 2026-10-03): it starts above
// the foe and sinks onto it, widening, pressing it down.
const whirl = vortex(kit, "whirl", { frames: WHIRL - 8, pal: [VIOLET, WHITE, MAGENTA], widen: 1.4, life: 16, down: true });
const foe = [
  knots("foeKnots", [0, 0.3, 1.0], 2, WHIRL - 10, 1.8, 0.65),
  ...ring(kit, "bandLow", { pos: [0, -0.4, 0.8], at: 10, life: WHIRL - 14, scale: 1.4, pal: [WHITE, WHITE, VIOLET], tex: kit.tex(T.ring), aspect: 2.6, to: 1.25, level: 0.9 }),
  ...ring(kit, "bandMid", { pos: [0, 0.5, 0.8], at: 6, life: WHIRL - 10, scale: 1.25, pal: [YELLOW, WHITE, PINK], tex: kit.tex(T.ring), aspect: 2.6, to: 1.25, level: 0.8 }),
  ...ring(kit, "bandHigh", { pos: [0, 1.4, 0.8], at: 2, life: WHIRL - 6, scale: 1.05, pal: [PINK, WHITE, VIOLET], tex: kit.tex(T.ring), aspect: 2.6, to: 1.25, level: 0.8 }),
  ...streaks(kit, "spikes", { pos: [0, -1.1, 0.8], at: 4, radius: 1.0, speed: 0.1, count: 3, bursts: 6, gap: 4, life: 9, scale: 0.8, pal: [MAGENTA, PINK, VIOLET], tex: kit.tex(T.spike), flat: true, lift: 0.3 }),
  ...impact(kit, "spell", { at: 2, pal: [MAGENTA, PINK, VIOLET], size: 1.2, rays: 0, flecks: 0, spiky: false }),
  ...glow(kit, "floor", { pos: FOE_FLOOR, life: WHIRL, scale: 1.7, pal: [DEEP, VIOLET, [0.05, 0, 0.15]], aspect: 2.6, level: 0.85 }),
];

const closeAt = CHANT + PAN;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1869, 0, { pitch: -2200, vol: 95 }),
  snd(1434, 4, { ch: "SE2", pitch: 200, vol: 100 }),
  snd(1869, 14, { pitch: -1800, vol: 95 }),
  snd(1510, closeAt, { ch: "SE2", side: "D", pitch: -300, vol: 110 }),
  snd(1919, closeAt, { side: "D", vol: 100 }),
  snd(1420, closeAt + 2, { ch: "SE2", side: "D", pitch: 200, vol: 115 }),
  snd(1420, closeAt + 16, { ch: "SE2", side: "D", pitch: 400, vol: 110 }),
)}
${arena(0, 12, 8, [6, 2, 14])}
${tint("ATTACKER", 0, 7, 6, [24, 14, 31])}
${emits(kit, user, "ATTACKER")}
${shake("ATTACKER", 819, CHANT / 2 - 4)}
Wait ${CHANT}
${tint("ATTACKER", 7, 0, 4, [24, 14, 31])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${circleEmits(kit, whirl, "DEFENDER", { y: 1.6 })}
${emits(kit, foe, "DEFENDER")}
Wait 2
${hit({ rgb: [31, 18, 30], power: 2 })}
${shake("DEFENDER", 1229, WHIRL / 2 - 6)}
Wait 6
ScaleSprite DEFENDER, ROUNDTRIP, 410, -819, 8, 0, 1
Wait ${WHIRL - 12 - 6}
${arena(12, 0, 8, [6, 2, 14])}
Wait ${AFTER + 6}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [542, 63, 605, 400, 240, 129, 564],
  references: ["reference/Eerie_Spell_VIII.png", "reference/Eerie_Spell_VIII_2.png", "reference/Eerie_Spell_IX.png", "reference/Eerie_Spell_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("userKnots")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `EmitCircle ${SPA}, ${kit.idx("whirlInner")}, DEFENDER_LEFT`, `Emit ${SPA}, ${kit.idx("bandMid")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  chant f${CAMERA_IN}, whirl f${CAMERA_IN + closeAt}-${CAMERA_IN + closeAt + WHIRL}`);
