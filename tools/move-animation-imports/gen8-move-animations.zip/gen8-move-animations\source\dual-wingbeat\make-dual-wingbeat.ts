import { assert, createKit, deg, fadeOut, grow, paint, setCurves, spin, T, type Rgb } from "../tools/anim-kit";
import { audio, emits, FOE, hit, impact, introStill, lunge, outro, snd, sparks, streaks, tint, WHITE, type Pal, glow } from "../tools/phrases";

// Dual Wingbeat (move 814) - from the Bulbapedia stills (reference/sheet.png).
// The user beats the foe with a wing: a broad white-blue arc of light sweeps
// down across it in a white flash.
// Two hits: Gen 5 replays the animation per hit, so the camera stays still
// and one hit is under a second.
// Psycho Cut's blade arc is the wing.

const SPA = 994;
const kit = await createKit({ workDir: import.meta.dirname, slug: "dual-wingbeat", moveId: 814, spaId: SPA, donors: [228, 465, 579, 411, 298] });

const WINDUP = 6;
const AFTER = 14;

const SKY: Rgb = [0.7, 0.88, 1.0];
const PALE: Rgb = [0.93, 0.97, 1.0];
const BLUE: Rgb = [0.45, 0.65, 1.0];
const PAL: Pal = [SKY, PALE, BLUE];

function wing(name: string, angle: number, scale: number, colours: [Rgb, Rgb, Rgb], at: number): string {
  const r = kit.parked(kit.tex(T.bladeArc), [0.1, 0.5, 1.0], scale, 9);
  r.startDelayFrames = at;
  r.aspectRatio = 1.8;
  spin(r, 0, 0, deg(angle));
  setCurves(r, grow(0.4, 0.3, 1.2), fadeOut(1, 0.45));
  paint(r, colours[0], colours[1], colours[2]);
  kit.add(name, r);
  return name;
}
const foe = [
  wing("wing", -38, 1.7, [WHITE, WHITE, PALE], 0),
  wing("wingGlow", -38, 2.0, [SKY, PALE, BLUE], 0),
  ...impact(kit, "beat", { at: 1, pal: PAL, size: 1.15, rays: 7, flecks: 0 }),
  ...streaks(kit, "feathers", { at: 1, radius: 0.5, speed: 0.3, count: 5, life: 10, scale: 0.5, pal: [WHITE, PALE, SKY], tex: kit.tex(T.shard) }),
  ...sparks(kit, "down", { at: 2, radius: 0.7, speed: 0.16, count: 5, life: 12, scale: 0.13, pal: [WHITE, PALE, SKY], fall: 0.01, twinkle: false }),
];
// No streaks over the user at the start: Logan had the same lines removed from
// Triple Axel and Surging Strikes (2026-10-03), so they are gone here too. A
// brief pale glow marks the flap instead.
const user = glow(kit, "flap", { pos: [0, 0.5, 0.3], life: 6, scale: 1.8, pal: [PALE, WHITE, SKY], level: 0.45 });

const script = `${introStill(SPA)}
${audio(
  snd(1425, 0, { pitch: 500, vol: 105 }),
  snd(1438, WINDUP - 1, { ch: "SE2", side: "D", pitch: 600, vol: 115 }),
  snd(1423, WINDUP + 1, { side: "D", pitch: 300, vol: 120 }),
)}
${tint("ATTACKER", 0, 6, 2, [24, 28, 31])}
${emits(kit, user, "ATTACKER")}
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 3, 0, 1
Wait ${WINDUP - 3}
${lunge("ATTACKER", 3)}
Wait 3
${tint("ATTACKER", 6, 0, 3, [24, 28, 31])}
${emits(kit, foe, "DEFENDER")}
Wait 1
${hit({ rgb: [28, 30, 31], power: 2, stop: 3 })}
Wait ${AFTER}
${outro({ camera: false })}`;

await kit.finish({
  script,
  donorMoveIds: [427, 63, 605, 400, 240, 129],
  references: ["reference/Dual_Wingbeat_VIII.png", "reference/Dual_Wingbeat_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("wing")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("beatFlash")}, DEFENDER`],
});
assert.ok(!script.includes("MoveCamera"), "Multi-hit animation moves the camera");
console.log(`  beat f${WINDUP}, one hit ~${WINDUP + 1 + 3 + AFTER} frames`);
