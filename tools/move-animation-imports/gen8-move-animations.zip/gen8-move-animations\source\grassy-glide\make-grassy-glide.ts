import { createKit, fadeOut, hold, setCurves, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, FOE, glow, hit, impact, intro, outro, pan, shot, snd, sparks, streaks, tint, WHITE, type Pal } from "../tools/phrases";

// Grassy Glide (move 803) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user slides over the ground as a long streak of green-white
//      light, leaves whirling off it.
//   2. It strikes in a green-white burst with white speed lines and leaves
//      thrown everywhere.
// A priority move, so it is quick. The user is hidden during the glide
// (ToggleSpriteVisibility 3/4). The leaves are Razor Leaf's.

const SPA = 983;
const kit = await createKit({ workDir: import.meta.dirname, slug: "grassy-glide", moveId: 803, spaId: SPA, donors: [242, 228, 465, 579, 411, 298] });

const CAMERA_IN = 8;
const READY = 8;
const TRAVEL = 6;
const AFTER = 22;

const GREEN: Rgb = [0.35, 0.95, 0.5];
const LIME: Rgb = [0.75, 1.0, 0.4];
const PALE: Rgb = [0.9, 1.0, 0.85];
const TEAL: Rgb = [0.3, 0.9, 0.8];
const PAL: Pal = [GREEN, PALE, LIME];
const LEAFY: Pal = [WHITE, [1.0, 1.0, 0.55], [0.75, 1.0, 0.8]]; // the leaf texture is already green
const LOW: Vec3 = [0.2, -0.8, -0.4];
const leaf = kit.tex(242, 1);

// --- 1. the glide: a long low streak of light ---
shot(kit, "glideCore", kit.tex(T.softDisc), { from: LOW, at: READY, travel: TRAVEL, scale: 0.75, pal: [PALE, WHITE, LIME], aspect: 3.4, count: 2, gap: 1 });
shot(kit, "glideGlow", kit.tex(T.fuzzyGlow), { from: LOW, at: READY, travel: TRAVEL, scale: 1.3, pal: [GREEN, LIME, TEAL], aspect: 3.0, count: 3, gap: 1, alpha: fadeOut(0.85, 0.4) });
shot(kit, "glideLeaves", leaf, { from: [0.2, -0.5, -0.4], at: READY + 1, travel: TRAVEL + 2, scale: 0.3, pal: LEAFY, count: 4, gap: 1, spin: 0.5 });
const user = [
  ...sparks(kit, "kickedLeaves", { pos: [0, -1.0, 0.3], at: READY - 2, radius: 0.8, speed: 0.2, count: 6, life: 14, scale: 0.28, pal: LEAFY, fall: 0.012, tex: leaf, twinkle: false, spin: 0.3 }),
  ...glow(kit, "ready", { life: READY + 2, scale: 2.4, pal: PAL, level: 0.6 }),
];

// --- 2. the strike ---
const foe = [
  ...sparks(kit, "leaves", { radius: 0.6, speed: 0.32, count: 9, life: 18, scale: 0.32, pal: LEAFY, fall: 0.012, tex: leaf, twinkle: false, spin: 0.3, shape: "circle" }),
  ...impact(kit, "strike", { pal: PAL, size: 1.4, rays: 0, flecks: 0 }),
  ...streaks(kit, "speedLines", { radius: 0.6, speed: 0.6, count: 10, life: 8, scale: 1.0, pal: [WHITE, PALE, WHITE] }),
  ...streaks(kit, "greenJags", { at: 1, radius: 0.5, speed: 0.38, count: 7, life: 10, scale: 0.8, pal: [GREEN, LIME, TEAL], tex: kit.tex(T.shard) }),
  ...sparks(kit, "motes", { at: 3, radius: 1.2, speed: 0.12, count: 3, bursts: 3, gap: 4, life: 12, scale: 0.16, pal: [LIME, WHITE, TEAL], tex: kit.tex(T.softDisc) }),
];
setCurves(kit.resources[kit.idx("leaves")]!, hold(1), fadeOut(1, 0.75));

const hitAt = READY + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1718, 0, { pitch: 500, vol: 105 }),
  snd(1425, READY, { ch: "SE2", pitch: 600, vol: 120 }),
  snd(1423, hitAt, { side: "D", vol: 127 }),
  snd(1415, hitAt + 1, { ch: "SE2", side: "D", vol: 110 }),
)}
${tint("ATTACKER", 0, 10, 4, [14, 31, 16])}
${emits(kit, user, "ATTACKER")}
${emits(kit, ["glideCore", "glideGlow", "glideLeaves"], "ATTACKER", "DEFENDER")}
ScaleSprite ATTACKER, ROUNDTRIP, 819, -1229, ${READY - 2}, 0, 1
Wait ${READY}
ToggleSpriteVisibility ATTACKER, 3
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [24, 31, 20], power: 2 })}
Wait ${AFTER}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
${tint("ATTACKER", 10, 0, 0, [14, 31, 16])}
ToggleSpriteVisibility ATTACKER, 4
${pan("INIT", 10)}
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [75, 63, 605, 400, 240, 129],
  references: ["reference/Grassy_Glide_VIII.png", "reference/Grassy_Glide_VIII_2.png", "reference/Grassy_Glide_IX.png", "reference/Grassy_Glide_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("glideCore")}, ATTACKER, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 3", "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("leaves")}, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 4", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  glide f${CAMERA_IN + READY}, strike f${CAMERA_IN + hitAt}`);
