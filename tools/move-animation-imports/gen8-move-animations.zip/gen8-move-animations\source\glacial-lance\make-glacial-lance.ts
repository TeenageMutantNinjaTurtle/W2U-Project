import { createKit, deg, fadeOut, hold, paint, setCurves, spin, T, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, bolt, emits, FOE, glow, hit, impact, intro, lunge, outro, pan, quake, shake, shot, slash, snd, sparks, streaks, tint, WHITE, type Pal } from "../tools/phrases";

// Glacial Lance (move 824) - from the Bulbapedia stills (reference/sheet.png)
// and the Sword/Shield screenshot and description Logan sent on 2026-10-03.
//   1. Night-blue. A lance of ice gathers slowly in the air above the user,
//      levelled at the foe; as it grows, smaller icicles form alongside it.
//   2. It is loosed: the lance and its icicles go straight through the foe
//      and on past it, quickly, leaving a line of cold light.
//   3. The screen dims and everything holds still.
//   4. Then a great glacier of ice bursts up over the foe - and explodes in a
//      white blast of shards and frost.
// The lance, the icicles and the glacier's crystals are one drawn texture
// (generated/texture-lance.png), point up.

const SPA = 1004;
const kit = await createKit({ workDir: import.meta.dirname, slug: "glacial-lance", moveId: 824, spaId: SPA, donors: [228, 465, 579, 411, 298, 407] });

const CAMERA_IN = 12;
const FORM = 54; // the lance gathers, slowly
const HOLD = 5;
const TRAVEL = 4; // fast
const BEYOND = 5; // frames it keeps going past the foe
const PAUSE = 16; // dimmed and still
const ENCASE = 10; // the glacier stands before it explodes
const AFTER = 32;

const ICE: Rgb = [0.65, 0.92, 1.0];
const PALE: Rgb = [0.9, 0.98, 1.0];
const BLUE: Rgb = [0.35, 0.65, 1.0];
const PAL: Pal = [ICE, PALE, BLUE];

// --- the drawn lance: a long facetted ice crystal, pointed at the top ---
const lanceTex = await kit.drawn("lance", 16, 64, "a3i5", (x, y) => {
  const px = x + 0.5 - 8, py = y + 0.5;
  // Point at the top, widest two-thirds down, a short taper to the butt.
  const half = py < 44 ? 0.4 + 6.2 * (py / 44) : 6.6 * Math.max(0, 1 - (py - 44) / 22);
  if (Math.abs(px) > half) return undefined;
  if (Math.abs(px) > half - 1) return [150, 200, 240, 255];
  // Two facets: the left one lit, the right one in shade, with a bright ridge between.
  if (Math.abs(px) < 0.6) return [250, 253, 255, 255];
  const lit = px < 0;
  const shade = 0.8 + 0.2 * Math.sin(py * 0.35);
  return lit ? [Math.round(225 * shade + 25), Math.round(244 * shade + 10), 255, 235] : [Math.round(150 * shade + 30), Math.round(205 * shade + 20), 250, 235];
});

// --- 1. the lance gathers above the user, levelled at the foe ---
// Seen from behind the user the foe is up and to the right, so the lance
// leans that way: its point 62 degrees over from straight up.
const LEAN = 62;
const along: [number, number] = [Math.sin((LEAN * Math.PI) / 180), Math.cos((LEAN * Math.PI) / 180)]; // the way it points
const across: [number, number] = [-along[1], along[0]];
const ABOVE: Vec3 = [-0.1, 2.0, 0.4]; // low enough that its point stays in view
const main = kit.parked(lanceTex, ABOVE, 2.3, FORM + HOLD + 1);
main.aspectRatio = 0.25;
spin(main, 0, 0, deg(-LEAN));
// Slow: it is a splinter for the first third, and not full size until near the end.
setCurves(main, { start: 0.12, mid: 1, end: 1.04, curveIn: 0.85, curveOut: 0.95 }, { start: 0, mid: 1, end: 1, curveIn: 0.15, curveOut: 1 });
paint(main, WHITE);
kit.add("lanceForm", main);
// Smaller icicles join it, one after another, once it has some size.
const ICICLES: Array<{ side: number; back: number; scale: number; at: number }> = [
  { side: 0.75, back: 0.5, scale: 1.05, at: 0.4 },
  { side: -0.75, back: 0.7, scale: 1.0, at: 0.52 },
  { side: 1.35, back: 1.2, scale: 0.8, at: 0.64 },
  { side: -1.35, back: 1.4, scale: 0.75, at: 0.76 },
];
const icicles: string[] = [];
for (const [i, c] of ICICLES.entries()) {
  const at = Math.round(FORM * c.at);
  const pos: Vec3 = [ABOVE[0] + across[0] * c.side - along[0] * c.back, ABOVE[1] + across[1] * c.side - along[1] * c.back, ABOVE[2] - 0.02 * (i + 1)];
  const r = kit.parked(lanceTex, pos, c.scale, FORM + HOLD + 1 - at);
  r.startDelayFrames = at;
  r.aspectRatio = 0.25;
  spin(r, 0, 0, deg(-LEAN));
  setCurves(r, { start: 0.15, mid: 1.06, end: 1, curveIn: 0.3, curveOut: 0.7 }, { start: 0, mid: 1, end: 1, curveIn: 0.15, curveOut: 1 });
  paint(r, WHITE);
  kit.add(`icicle${i}`, r);
  icicles.push(`icicle${i}`);
}
const TIP: Vec3 = [ABOVE[0] + along[0] * 2.2, ABOVE[1] + along[1] * 2.2, ABOVE[2] + 0.1];
const user = [
  ...glow(kit, "tipStar", { pos: TIP, at: FORM - 10, life: 14, scale: 1.2, pal: [WHITE, WHITE, ICE], tex: kit.tex(T.star4Big), spin: 0.08, scaleCurve: twinkle(1.3), alpha: twinkle(1) }),
  "lanceForm",
  ...icicles,
  ...sparks(kit, "frost", { pos: ABOVE, radius: 2.2, speed: 0.02, count: 1, bursts: FORM / 3, gap: 3, life: 10, scale: 0.3, pal: [WHITE, PALE, ICE], shape: "ball", tex: kit.tex(T.sparkle4) }),
  ...streaks(kit, "cold", { pos: ABOVE, radius: 2.6, speed: -0.28, count: 2, bursts: FORM / 4, gap: 4, life: 7, scale: 0.7, pal: [ICE, WHITE, BLUE] }),
  ...glow(kit, "chill", { pos: [0, 0.3, 0.2], life: FORM + HOLD, scale: 2.8, pal: [BLUE, ICE, PALE], level: 0.55 }),
];

// --- 2. loosed: point first, through the foe and on past it ---
const FROM: Vec3 = [0.4, 1.6, -0.4];
const DIVE = (FROM[1] - 0.4) / 16;
const flying = bolt(kit, "lanceFly", { from: FROM, at: FORM + HOLD, travel: TRAVEL, scale: 2.2, pal: [WHITE, WHITE, WHITE], tex: lanceTex, dive: DIVE });
Object.assign(flying, { aspectRatio: 0.25, particleLifeFrames: TRAVEL + BEYOND });
const escort = bolt(kit, "icicleFly", { from: FROM, at: FORM + HOLD + 1, travel: TRAVEL, scale: 0.95, pal: [WHITE, WHITE, WHITE], tex: lanceTex, count: 4, gap: 1, spread: 0.9, dive: DIVE });
Object.assign(escort, { aspectRatio: 0.25, particleLifeFrames: TRAVEL + BEYOND });
shot(kit, "lanceTrail", kit.tex(T.fuzzyGlow), { from: FROM, at: FORM + HOLD, travel: TRAVEL, scale: 1.2, pal: [ICE, PALE, BLUE], count: 3, gap: 1, dive: DIVE, alpha: fadeOut(0.8, 0.4) });

// On the foe as it goes through: a line of cold light and a scatter of frost.
const through = [
  ...slash(kit, "throughLine", { angle: 10, scale: 4.6, pal: [WHITE, WHITE, PALE], life: 8, aspect: 0.1 }),
  ...slash(kit, "throughGlow", { angle: 10, scale: 4.8, pal: [ICE, PALE, BLUE], life: PAUSE, aspect: 0.28 }),
  ...streaks(kit, "pathLines", { pos: [0, 0.3, 0.9], radius: 1.2, speed: 0.5, count: 5, bursts: 2, gap: 2, life: 7, scale: 1.1, pal: [ICE, WHITE, BLUE], flat: true }),
  ...sparks(kit, "hangingFrost", { pos: [0, 0.5, 0.9], at: 2, radius: 1.8, speed: 0, count: 1, bursts: PAUSE / 3, gap: 3, life: 8, scale: 0.34, pal: [WHITE, PALE, ICE], shape: "ball", tex: kit.tex(T.sparkle4) }),
  ...glow(kit, "stillGlint", { pos: [0.1, 0.5, 1.0], at: PAUSE - 8, life: 8, scale: 1.0, pal: [WHITE, WHITE, ICE], tex: kit.tex(T.star4Big), spin: 0.08, scaleCurve: twinkle(1.3), alpha: twinkle(1) }),
];

// --- 4. the glacier: crystals standing shoulder to shoulder over the foe,
// the tallest in the middle - and then the blast ---
const crystals: string[] = [];
for (const [i, [x, tilt, scale]] of ([[0.1, -3, 3.1], [-0.8, 9, 2.6], [1.0, -11, 2.4], [-1.7, 19, 1.9], [1.8, -21, 1.8]] as const).entries()) {
  const r = kit.parked(lanceTex, [x, scale - 1.7, 0.95 - Math.abs(x) * 0.08], scale, ENCASE + 2);
  r.startDelayFrames = i;
  r.aspectRatio = 0.36;
  spin(r, 0, 0, deg(tilt));
  setCurves(r, { start: 0.2, mid: 1.06, end: 1, curveIn: 0.3, curveOut: 0.7 }, hold(0.95));
  paint(r, WHITE);
  kit.add(`crystal${i}`, r);
  crystals.push(`crystal${i}`);
}
const glacier = [
  // The blast is listed first so it draws over the ice.
  ...impact(kit, "shatter", { at: ENCASE, pal: [PALE, WHITE, ICE], size: 2.1, rays: 9, flecks: 0 }),
  ...streaks(kit, "shards", { at: ENCASE, radius: 1.0, speed: 0.5, count: 10, life: 12, scale: 1.1, pal: [ICE, WHITE, BLUE], tex: kit.tex(T.shard) }),
  ...crystals,
  ...sparks(kit, "frostBurst", { at: ENCASE + 1, radius: 1.3, speed: 0.22, count: 7, life: 14, scale: 0.32, pal: [WHITE, PALE, ICE], shape: "circle", tex: kit.tex(T.sparkle4) }),
  ...sparks(kit, "chunks", { at: ENCASE, radius: 0.8, speed: 0.26, count: 6, life: 16, scale: 0.3, pal: [ICE, WHITE, BLUE], fall: 0.03, tex: kit.tex(T.shard), twinkle: false, spin: 0.3, shape: "circle" }),
  ...sparks(kit, "snow", { pos: [0, 1.0, 0.9], at: ENCASE + 4, radius: 1.8, speed: 0.04, count: 2, bursts: 4, gap: 4, life: 16, scale: 0.13, pal: [WHITE, PALE, ICE], fall: 0.01, shape: "ball", twinkle: false }),
  ...glow(kit, "frozen", { pos: FOE, life: ENCASE + 10, scale: 3.2, pal: [ICE, BLUE, PALE], level: 0.6 }),
];

const throwAt = FORM + HOLD;
const passAt = throwAt + TRAVEL;
const glacierAt = passAt + PAUSE;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1497, 0, { pitch: 600, vol: 95 }),
  ...ICICLES.map((c, i) => snd(1509, Math.round(FORM * c.at), { ch: "SE2", pitch: 600 + i * 120, vol: 90 })),
  snd(1509, FORM - 10, { ch: "SE2", pitch: 900, vol: 100 }),
  snd(1376, throwAt, { vol: 0 }),
  snd(1539, throwAt, { ch: "SE2", pitch: -300, vol: 125 }),
  snd(1514, passAt, { side: "D", pitch: 500, vol: 120 }),
  snd(1435, glacierAt, { side: "D", pitch: 600, vol: 122 }),
  snd(1475, glacierAt + ENCASE, { side: "D", pitch: 300, vol: 127 }),
  snd(1423, glacierAt + ENCASE, { ch: "SE2", side: "D", pitch: 600, vol: 120 }),
)}
${arena(0, 11, 10, [2, 4, 16])}
${tint("ATTACKER", 0, 8, 8, [20, 28, 31])}
${emits(kit, user, "ATTACKER")}
${emits(kit, ["lanceFly", "icicleFly", "lanceTrail"], "ATTACKER", "DEFENDER")}
Wait ${FORM}
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, ${HOLD}, 0, 1
Wait ${HOLD}
${lunge("ATTACKER", 3)}
${tint("ATTACKER", 8, 0, 4, [20, 28, 31])}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, through, "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
${tint("DEFENDER", 0, 10, 0, [22, 29, 31])}
${shake("DEFENDER", 819, 3)}
Wait 2
${tint("DEFENDER", 10, 0, 6, [22, 29, 31])}
${arena(11, 15, 6, [0, 1, 6])}
Wait ${PAUSE - 2}
${emits(kit, glacier, "DEFENDER")}
${tint("DEFENDER", 0, 12, 3, [22, 29, 31])}
${shake("DEFENDER", 410, ENCASE / 2)}
Wait ${ENCASE}
${tint("DEFENDER", 12, 0, 0, [22, 29, 31])}
${arena(15, 14, 0, [28, 31, 31])}
${hit({ rgb: [28, 31, 31], power: 3, freeze: false })}
${arena(14, 11, 4, [2, 4, 16])}
Wait 10
${quake("2458", 8)}
Wait 10
${quake("1x", 6)}
Wait ${AFTER - 30}
${arena(11, 0, 10, [2, 4, 16])}
Wait 10
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 236],
  references: ["reference/Glacial_Lance_VIII.png", "reference/Glacial_Lance_VIII_2.png", "reference/Glacial_Lance_IX.png", "reference/Glacial_Lance_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("lanceForm")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("icicle3")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("lanceFly")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("throughLine")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("crystal0")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("shards")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  lance gathers f${CAMERA_IN}-${CAMERA_IN + FORM}, loosed f${CAMERA_IN + throwAt}, through the foe f${CAMERA_IN + passAt}, still until f${CAMERA_IN + glacierAt}, glacier f${CAMERA_IN + glacierAt}, explodes f${CAMERA_IN + glacierAt + ENCASE}`);
