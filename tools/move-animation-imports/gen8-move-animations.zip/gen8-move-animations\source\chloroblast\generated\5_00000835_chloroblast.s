MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1015
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, 0, 115, 0, 0, 0
PlaySound 1480, SE2, 14, 10, 300, 105, 0, 0, 0
PlaySound 1450, SE1, 14, 33, -200, 127, 0, 0, 0
PlaySound 1962, SE2, 14, 33, 0, 115, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 8, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 41, -200, 127, 0, 0, 0
PlaySound 1420, SE1, 16, 53, 200, 120, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 9, 0, 6, 12, 3
ChangeSpriteColor ATTACKER, 0, 10, 0, 26, 31, 10
Emit 1015, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1015, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1015, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1015, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1015, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1015, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1015, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1015, 7, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1015, 8, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 10
Wait 33
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -3px, 49152, 0, 4096, 0
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 13
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 1015, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1015, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1015, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1015, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1015, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1015, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1015, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeBackgroundColor 4, 13, 13, 0, 29, 31, 20
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 29, 31, 16
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 29, 31, 16
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 13, 9, 0, 6, 12, 3
Wait 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 10
ChangeSpriteColor ATTACKER, 10, 0, 0, 26, 31, 10
ChangeBackgroundColor 4, 9, 0, 0, 6, 12, 3
Wait 22
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
Wait 12
ChangeSpriteColor ATTACKER, 0, 8, 0, 31, 31, 31
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 6
Wait 3
ChangeSpriteColor ATTACKER, 8, 0, 0, 31, 31, 31
LetCMDsFinish ALL
TerminateMoveScript
