MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1027
AudioContainer CONTINUE
PlaySound 1425, SE1, 14, 0, 200, 110, 0, 0, 0
PlaySound 1445, SE2, 14, 2, -200, 100, 0, 0, 0
PlaySound 1919, SE1, 16, 34, 0, 115, 0, 0, 0
PlaySound 1425, SE2, 16, 34, -300, 120, 0, 0, 0
PlaySound 1420, SE2, 16, 36, 0, 110, 0, 0, 0
PlaySound 1420, SE2, 16, 50, 200, 110, 0, 0, 0
PlaySound 1475, SE2, 16, 66, -200, 125, 0, 0, 0
PlaySound 1522, SE2, 14, 6, 300, 100, 0, 0, 0
PlaySound 1458, SE2, 16, 38, 0, 120, 0, 0, 0
PlaySound 1522, SE2, 16, 48, -200, 120, 0, 0, 0
PlaySound 1458, SE2, 16, 58, 200, 120, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 9, 0, 5, 5, 11
ChangeSpriteColor ATTACKER, 0, 8, 0, 31, 29, 12
EmitCircle 1027, 3, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 1027, 4, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
Emit 1027, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1027, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1027, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 8
Wait 24
ChangeSpriteColor ATTACKER, 8, 0, 0, 31, 29, 12
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
EmitCircle 1027, 7, DEFENDER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 1027, 8, DEFENDER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 1027, 9, DEFENDER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 1027, 10, DEFENDER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
Emit 1027, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1027, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1027, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1027, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1027, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1027, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1027, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1027, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1027, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 2
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 31, 29, 12
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 31, 29, 12
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 12
Wait 26
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 31, 31
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 31, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ChangeBackgroundColor 4, 9, 0, 0, 5, 5, 11
Wait 8
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
