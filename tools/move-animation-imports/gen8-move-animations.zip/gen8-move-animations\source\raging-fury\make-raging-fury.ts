import { aimed, createKit, fadeOut, grow, hold, paint, setCurves, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, flames, FOE, FOE_FLOOR, glow, hit, impact, intro, pan, puffs, quake, ring, shake, snd, sparks, squash, streaks, tint, USER, USER_FLOOR, WHITE } from "../tools/phrases";

// Raging Fury (move 833) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user's fury builds in three beats: on each it flashes hotter and
//      shudders, a ring of fire bursts out from its body with a jagged flare
//      behind it and lashes of flame flying, embers thrown up, and the arena
//      goes a deeper red.
//   2. It hurls itself at the foe, a mass of fire.
//   3. It slams into it: a great burst of flame, fire thrown out all round,
//      the ground shaking, the foe left burning.
// The slam (no slashes) is Logan's direction (2026-10-03), and so is the
// opening: it used to be flames on the user under a red whirl, the recipe too
// many of my fire moves shared. The user is hidden while it is the fire
// (ToggleSpriteVisibility 3/4). The flames on the foe and the fire puffs are
// Fire Blast's (SPA 295). The rampage lock and confusion are the engine's.

const SPA = 1013;
const kit = await createKit({ workDir: import.meta.dirname, slug: "raging-fury", moveId: 833, spaId: SPA, donors: [295, 228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const BEATS = 3;
const BEAT_GAP = 9;
const ERUPT = BEATS * BEAT_GAP + 1;
const TRAVEL = 6;
const BURN = 22; // the foe burning after the slam
const AFTER = 10;

const ORANGE: Rgb = [1.0, 0.55, 0.1];
const YELLOW: Rgb = [1.0, 0.9, 0.3];
const RED: Rgb = [0.95, 0.25, 0.08];
const PALE: Rgb = [1.0, 0.97, 0.75];
const BODY: Vec3 = [0, 0.3, 0.3];

// --- 1. the fury builds, beat by beat ---
const user = [
  ...Array.from({ length: BEATS }, (_, i) => [
    ...ring(kit, `furyRing${i}`, { pos: USER, at: i * BEAT_GAP, life: 10, scale: 1.0 + i * 0.15, pal: [ORANGE, YELLOW, RED], to: 2.3 + i * 0.3, level: 0.95 }),
    ...glow(kit, `furyFlare${i}`, { pos: USER, at: i * BEAT_GAP, life: 8, scale: 1.2 + i * 0.2, pal: [ORANGE, YELLOW, RED], tex: kit.tex(T.spiky), spin: 0.12, level: 0.75, scaleCurve: grow(0.5, 0.3, 1.3), alpha: fadeOut(0.9, 0.4) }),
  ]).flat(),
  ...streaks(kit, "lashes", { pos: [0, 0.2, 0.3], radius: 0.9, speed: 0.5, count: 6, bursts: BEATS, gap: BEAT_GAP, life: 8, scale: 1.1, pal: [YELLOW, PALE, ORANGE] }),
  ...sparks(kit, "embers", { pos: [0, -0.4, 0.3], radius: 1.0, speed: 0.26, count: 5, bursts: BEATS, gap: BEAT_GAP, life: 14, scale: 0.16, pal: [YELLOW, PALE, ORANGE], fall: -0.012, twinkle: false }),
  ...glow(kit, "scorch", { pos: USER_FLOOR, life: ERUPT + 2, scale: 0.9, pal: [RED, ORANGE, [0.6, 0.08, 0.02]], tex: kit.tex(T.softDisc), aspect: 2.6, level: 0.6 }),
  ...glow(kit, "heat", { life: ERUPT + 2, scale: 2.8, pal: [RED, [0.6, 0.08, 0.02], ORANGE], level: 0.55 }),
];

// --- 2. the charge: the user as a mass of fire, thrown at the foe ---
const charge: string[] = [];
for (const [name, tex, scale, colours, level] of [
  ["chargeCore", kit.tex(T.softDisc), 1.5, [YELLOW, PALE, ORANGE], 0.95],
  ["chargeFire", kit.tex(295, 4), 2.4, [WHITE, WHITE, WHITE], 0.95],
  ["chargeGlow", kit.tex(T.fuzzyGlow), 3.0, [ORANGE, YELLOW, RED], 0.85],
] as const) {
  const r = kit.parked(tex, BODY, scale, TRAVEL + 1);
  r.startDelayFrames = ERUPT;
  aimed(r, 16 / TRAVEL, TRAVEL + 1);
  r.airResistance = 1.0;
  setCurves(r, hold(1.05), hold(level));
  paint(r, colours[0] as Rgb, colours[1] as Rgb, colours[2] as Rgb);
  kit.add(name, r);
  charge.push(name);
}
const wake = [
  ...streaks(kit, "wake", { pos: USER, at: ERUPT, radius: 1.5, speed: 0.42, count: 4, bursts: 3, gap: 2, life: 7, scale: 1.0, pal: [YELLOW, PALE, ORANGE], flat: true }),
  ...sparks(kit, "wakeEmbers", { pos: USER, at: ERUPT, radius: 1.0, speed: 0.2, count: 5, life: 12, scale: 0.15, pal: [YELLOW, PALE, ORANGE], fall: 0.012, twinkle: false }),
];

// --- 3. the slam ---
const foe = [
  ...impact(kit, "slam", { pal: [YELLOW, PALE, ORANGE], size: 2.1, rays: 9, flecks: 0 }),
  // Fire thrown out all round by the blow.
  ...sparks(kit, "fireballs", { radius: 0.5, speed: 0.34, count: 5, life: 12, scale: 0.6, pal: [WHITE, WHITE, WHITE], shape: "circle", tex: kit.tex(295, 4), twinkle: false, spin: 0.2 }),
  ...streaks(kit, "blastLines", { at: 1, radius: 0.8, speed: 0.5, count: 6, life: 9, scale: 1.1, pal: [YELLOW, PALE, ORANGE] }),
  ...ring(kit, "shock", { pos: FOE_FLOOR, at: 1, life: 13, scale: 0.8, pal: [YELLOW, PALE, ORANGE], to: 2.0, aspect: 2.6 }),
  ...sparks(kit, "cinders", { at: 1, radius: 0.8, speed: 0.3, count: 5, life: 14, scale: 0.15, pal: [YELLOW, PALE, ORANGE], fall: 0.014, twinkle: false, shape: "circle" }),
  ...puffs(kit, "smoke", { pos: FOE_FLOOR, at: 3, radius: 1.5, count: 3, life: 16, scale: 0.9, pal: [[0.3, 0.2, 0.16], [0.5, 0.36, 0.26], [0.14, 0.09, 0.07]], speed: 0.14, rise: 0.02, level: 0.7 }),
  ...flames(kit, "burning", { pos: [0, -0.2, 0.9], at: 4, frames: BURN, every: 3, life: 9, scale: 1.1, rise: 0.06, radius: 1.0 }),
  ...glow(kit, "blaze", { pos: FOE, life: BURN + 6, scale: 3.4, pal: [ORANGE, RED, YELLOW], level: 0.7 }),
];
setCurves(kit.resources[kit.idx("fireballs")]!, grow(0.8, 0.3, 1.3), fadeOut(1, 0.5));
setCurves(kit.resources[kit.idx("blastLines")]!, grow(1.2, 0.3, 0.6), fadeOut());

const slamAt = ERUPT + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  ...Array.from({ length: BEATS }, (_, i) => snd(1426, i * BEAT_GAP, { ch: i % 2 ? "SE2" : "SE1", pitch: -200 + i * 200, vol: 110 + i * 5 })),
  ...Array.from({ length: BEATS }, (_, i) => snd(1452, i * BEAT_GAP, { ch: i % 2 ? "SE1" : "SE2", pitch: -300, vol: 100 })),
  snd(1688, ERUPT, { pitch: -300, vol: 125 }),
  snd(1475, slamAt, { side: "D", pitch: -400, vol: 127 }),
  snd(1413, slamAt, { ch: "SE2", side: "D", vol: 127 }),
  snd(1426, slamAt + 3, { ch: "SE2", side: "D", pitch: -200, vol: 120 }),
)}
${emits(kit, user, "ATTACKER")}
${emits(kit, [...charge, ...wake], "ATTACKER", "DEFENDER")}
${Array.from({ length: BEATS }, (_, i) => [
  arena(i * 3, (i + 1) * 3, 3, [20, 6, 3]),
  tint("ATTACKER", i === 0 ? 0 : 4 + i * 2, 16, 0, [31, 24, 12]),
  squash("ATTACKER", 819 + i * 205, -(819 + i * 205), 2),
  shake("ATTACKER", 1229 + i * 205, 3),
  ...(i === BEATS - 1 ? [quake("0.5x", 3)] : []),
  "Wait 2",
  tint("ATTACKER", 16, 6 + i * 2, 4, [31, 14, 4]),
  `Wait ${BEAT_GAP - 2}`,
].join(String.fromCharCode(10))).join(String.fromCharCode(10))}
Wait ${ERUPT - BEATS * BEAT_GAP}
ToggleSpriteVisibility ATTACKER, 3
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${arena(9, 13, 0, [31, 24, 10])}
${hit({ rgb: [31, 26, 12], power: 3 })}
${arena(13, 9, 4, [20, 6, 3])}
Wait 8
${quake("2458", 8)}
Wait ${BURN - 8 - 8}
${arena(9, 0, 10, [20, 6, 3])}
Wait ${8 + AFTER}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
${tint("ATTACKER", 10, 0, 4, [31, 14, 4])}
ToggleSpriteVisibility ATTACKER, 4
${pan("INIT", 12)}
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [542, 126, 63, 605, 400, 240, 129, 564],
  references: ["reference/Raging_Fury_LA.png", "reference/Raging_Fury_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("furyRing0")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("furyRing2")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("chargeFire")}, ATTACKER, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 3", "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("slamFlash")}, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 4", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  fury builds f${CAMERA_IN} in ${BEATS} beats, charge f${CAMERA_IN + ERUPT}, slam f${CAMERA_IN + slamAt}, burning until f${CAMERA_IN + slamAt + 4 + BURN}`);
