MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 972
AudioContainer CONTINUE
PlaySound 1869, SE1, 14, 0, -1200, 110, 0, 0, 0
PlaySound 1505, SE2, 14, 2, -300, 110, 0, 0, 0
PlaySound 1514, SE1, 14, 12, -300, 120, 0, 0, 0
PlaySound 1435, SE2, 14, 13, -200, 120, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 0, 31, 6, 8
Emit 972, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 972, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 972, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 972, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 972, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 972, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 972, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 972, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 972, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 972, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 972, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, -1229, 1229, 4, 0, 1
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 6
Wait 12
ChangeSpriteColor ATTACKER, 8, 0, 0, 31, 6, 8
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 3, 0, 1
Wait 32
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
