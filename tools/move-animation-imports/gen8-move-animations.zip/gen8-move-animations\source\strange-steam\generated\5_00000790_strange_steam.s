MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 970
AudioContainer CONTINUE
PlaySound 1445, SE1, 14, 8, 900, 100, 0, 0, 0
PlaySound 1474, SE2, 14, 12, 0, 85, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 10, 0, 50, 0, 0
PlaySound 1463, SE2, 16, 22, 400, 105, 0, 0, 0
PlaySound 1784, SE1, 16, 26, 300, 100, 0, 0, 0
PlaySound 1420, SE2, 16, 24, 300, 100, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 0, 2, 4, 12
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 10, 0, 1
Emit 970, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 970, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 970, 2, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 970, 3, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 970, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 12
ChangeSpriteColor ATTACKER, 0, 6, 0, 28, 24, 31
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 13
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
Emit 970, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 970, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 970, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 970, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 970, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 29, 26, 31
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 29, 26, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 9
Wait 18
ChangeSpriteColor ATTACKER, 6, 0, 0, 28, 24, 31
ChangeBackgroundColor 4, 10, 0, 0, 2, 4, 12
Wait 20
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
