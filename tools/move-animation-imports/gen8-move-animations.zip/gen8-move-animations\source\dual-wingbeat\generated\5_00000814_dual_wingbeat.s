LoadSPA 994
AudioContainer CONTINUE
PlaySound 1425, SE1, 14, 0, 500, 105, 0, 0, 0
PlaySound 1438, SE2, 16, 5, 600, 115, 0, 0, 0
PlaySound 1423, SE1, 16, 7, 300, 120, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 6, 0, 24, 28, 31
Emit 994, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 3, 0, 1
Wait 3
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
Wait 3
ChangeSpriteColor ATTACKER, 6, 0, 0, 24, 28, 31
Emit 994, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 994, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 994, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 994, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 994, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 994, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 994, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 1
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 28, 30, 31
Wait 3
ChangeSpriteColor DEFENDER, 13, 0, 0, 28, 30, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 14
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
