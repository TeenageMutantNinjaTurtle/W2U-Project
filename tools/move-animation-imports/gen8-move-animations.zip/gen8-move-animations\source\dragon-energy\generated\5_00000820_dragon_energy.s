MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1000
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, -200, 110, 0, 0, 0
PlaySound 1474, SE2, 14, 6, -300, 90, 0, 0, 0
PlaySound 1505, SE2, 14, 30, 0, 110, 0, 0, 0
PlaySound 1975, SE1, 14, 38, 0, 127, 0, 0, 0
PlaySound 1424, SE2, 14, 38, -500, 125, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 8, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 46, -400, 127, 0, 0, 0
PlaySound 1420, SE2, 16, 56, 0, 127, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 12, 0, 6, 1, 10
ChangeSpriteColor ATTACKER, 0, 9, 0, 16, 3, 22
Emit 1000, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1000, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1000, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1000, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1000, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1000, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1000, 6, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1000, 7, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 11
Wait 30
ChangeSpriteColor ATTACKER, 9, 14, 0, 26, 6, 10
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 4
Wait 8
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -2px, 49152, 0, 4096, 0
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 10
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 1000, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1000, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1000, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1000, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1000, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1000, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1000, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1000, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeBackgroundColor 4, 15, 15, 0, 24, 4, 8
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 28, 6, 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 7
ChangeSpriteColor DEFENDER, 15, 0, 0, 28, 6, 10
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 15, 12, 0, 6, 1, 10
Wait 10
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 3
ChangeSpriteColor ATTACKER, 14, 0, 0, 26, 6, 10
ChangeBackgroundColor 4, 12, 0, 0, 6, 1, 10
Wait 26
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
