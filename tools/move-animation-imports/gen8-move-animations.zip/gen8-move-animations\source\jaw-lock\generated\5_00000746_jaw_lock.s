MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 944
AudioContainer CONTINUE
PlaySound 1407, SE1, 14, 0, -300, 105, 0, 0, 0
PlaySound 1514, SE1, 16, 26, -500, 115, 0, 0, 0
PlaySound 1475, SE2, 16, 29, -200, 125, 0, 0, 0
PlaySound 1423, SE1, 16, 30, 300, 115, 0, 0, 0
PlaySound 1420, SE2, 16, 39, -300, 100, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 0, 31, 26, 8
Emit 944, 14, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 4, 0, 1
Wait 8
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 8, 0, 0, 31, 26, 8
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 944, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 944, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 944, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 944, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 944, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 944, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 944, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 944, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 944, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 944, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 944, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 944, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 944, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 944, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 13
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 31, 28, 12
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 31, 28, 12
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ScaleSprite DEFENDER, ROUNDTRIP, 0, -1229, 8, 0, 1
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 8
Wait 20
ShakeScreen HORIZON, 0.5x, 0, 2, 0, 3
Wait 14
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
