import { createKit, deg, hold, paint, setCurves, spin, T, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, FOE, glow, hit, introStill, lunge, outro, snd, sparks, streaks, tint, WHITE } from "../tools/phrases";

// Branch Poke (move 785) - from the Bulbapedia stills (reference/sheet.png).
// A pointed branch jabs the foe: a yellow star pops where it lands, with
// short green lines and a few leaves.
// A light, quick move: no camera moves. The branch is drawn
// (generated/texture-branch.png).

const SPA = 965;
const kit = await createKit({ workDir: import.meta.dirname, slug: "branch-poke", moveId: 785, spaId: SPA, donors: [228, 465, 411, 298] });

const WINDUP = 6;
const JAB = 4;
const STUCK = 6; // the branch stays in for a beat
const AFTER = 16;

const YELLOW: Rgb = [1.0, 0.92, 0.25];
const GREEN: Rgb = [0.4, 0.85, 0.3];
const LIME: Rgb = [0.75, 1.0, 0.4];

// --- the drawn branch: a brown stick tapering to a point on the right, a side twig and a leaf ---
const branchTex = await kit.drawn("branch", 64, 32, "a3i5", (x, y) => {
  const px = x + 0.5, py = y + 0.5;
  const along = px / 64; // 0 at the butt, 1 at the point
  // Main stem, slightly bowed.
  const stemY = 17 + 2 * Math.sin(along * 3.1);
  const half = 3.2 * (1 - along * 0.92);
  if (px > 2 && px < 62 && Math.abs(py - stemY) <= half) return Math.abs(py - stemY) > half - 1 ? [96, 60, 30] : [186 - Math.round(40 * Math.abs(py - stemY) / (half + 0.1)), 140, 60];
  // A side twig rising from a third of the way along.
  const t = (px - 20) / 14;
  if (t >= 0 && t <= 1 && Math.abs(py - (15 - t * 9)) <= 1.4) return [150, 100, 45];
  // A leaf at the twig's tip.
  if (((px - 37) / 5.5) ** 2 + ((py - 5.5) / 3) ** 2 <= 1) return Math.abs(py - 5.5) < 0.7 ? [40, 130, 50] : [90, 200, 80];
  return undefined;
});

const START: Vec3 = [-3.2, 0.9, 1.0]; // to the foe's left, where the jab comes from
const REACH = 2.2;
const TILT = -14; // angled down into the foe
function branch(at: number, life: number, pos: Vec3): ReturnType<typeof kit.parked> {
  const r = kit.parked(branchTex, pos, 0.75, life);
  r.aspectRatio = 2;
  r.startDelayFrames = at;
  spin(r, 0, 0, deg(TILT));
  paint(r, WHITE);
  return r;
}
const jab = branch(0, JAB + 1, START);
jab.axis = [Math.cos(deg(TILT)), Math.sin(deg(TILT)), 0];
jab.initVelAxisAmplifier = REACH / JAB;
setCurves(jab, hold(1), { start: 0, mid: 1, end: 1, curveIn: 0.3, curveOut: 1 });
kit.add("jab", jab);
const stuck = branch(JAB, STUCK + 4, [START[0] + REACH * Math.cos(deg(TILT)), START[1] + REACH * Math.sin(deg(TILT)), START[2]]);
setCurves(stuck, hold(1), { start: 1, mid: 1, end: 0, curveIn: 0, curveOut: 0.6 });
kit.add("stuck", stuck);

const POINT: Vec3 = [-0.3, 0.3, 1.1];
const foe = [
  "jab", "stuck",
  ...glow(kit, "star", { pos: POINT, at: JAB, life: 9, scale: 1.2, pal: [YELLOW, WHITE, [1.0, 0.75, 0.1]], tex: kit.tex(T.hitStar), spin: 0.12, level: 1, scaleCurve: twinkle(1.25), alpha: twinkle(1) }),
  ...streaks(kit, "lines", { pos: POINT, at: JAB, radius: 0.5, speed: 0.3, count: 6, life: 8, scale: 0.55, pal: [GREEN, LIME, YELLOW] }),
  ...sparks(kit, "leaves", { pos: POINT, at: JAB, radius: 0.4, speed: 0.2, count: 5, life: 14, scale: 0.15, pal: [GREEN, LIME, [0.25, 0.6, 0.2]], fall: 0.012, twinkle: false, shape: "circle" }),
];

const script = `${introStill(SPA)}
${audio(
  snd(1407, WINDUP - 2, { pitch: 600, vol: 100 }),
  snd(1539, WINDUP, { ch: "SE2", side: "D", pitch: 300, vol: 110 }),
  snd(1423, WINDUP + JAB, { side: "D", pitch: 400, vol: 115 }),
)}
${tint("ATTACKER", 0, 6, 2, [14, 28, 10])}
Wait ${WINDUP - 2}
${lunge("ATTACKER", 2)}
Wait 2
${emits(kit, foe, "DEFENDER")}
${tint("ATTACKER", 6, 0, 3, [14, 28, 10])}
Wait ${JAB}
${hit({ rgb: [31, 31, 18], power: 1 })}
Wait ${AFTER}
${outro({ camera: false })}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 240, 129, 163],
  references: ["reference/Branch_Poke_VIII.png", "reference/Branch_Poke_VIII_2.png", "reference/Branch_Poke_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("jab")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("star")}, DEFENDER`],
});
console.log(`  jab f${WINDUP}, hit f${WINDUP + JAB}, done ~f${WINDUP + JAB + 2 + AFTER}`);
