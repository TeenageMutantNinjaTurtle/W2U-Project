MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1025
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, 200, 105, 0, 0, 0
PlaySound 1651, SE2, 14, 6, 300, 105, 0, 0, 0
PlaySound 1407, SE1, 14, 13, 300, 115, 0, 0, 0
PlaySound 1514, SE1, 16, 21, -300, 125, 0, 0, 0
PlaySound 1514, SE2, 16, 26, -150, 125, 0, 0, 0
PlaySound 1514, SE1, 16, 31, 0, 125, 0, 0, 0
PlaySound 1514, SE2, 16, 36, 150, 125, 0, 0, 0
PlaySound 1514, SE1, 16, 41, 300, 125, 0, 0, 0
PlaySound 1475, SE1, 16, 48, 100, 125, 0, 0, 0
PlaySound 1423, SE2, 16, 48, -200, 120, 0, 0, 0
PlaySound 1435, SE2, 16, 58, 700, 95, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 0, 8, 1, 3
ChangeSpriteColor ATTACKER, 0, 9, 0, 20, 3, 6
Emit 1025, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 10, 0, 1
Wait 14
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 6px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 9, 0, 0, 20, 3, 6
MoveCamera INTERPOLATION, DEFENDER, 7, 0, 8
Wait 7
Emit 1025, 23, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 24, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 25, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 26, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 27, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 28, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 20, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 21, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 22, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1025, 29, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 10, 10, 0, 31, 10, 12
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 3
Wait 1
ChangeSpriteColor DEFENDER, 10, 0, 0, 31, 10, 12
Wait 4
ChangeSpriteColor DEFENDER, 10, 10, 0, 31, 10, 12
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 3
Wait 1
ChangeSpriteColor DEFENDER, 10, 0, 0, 31, 10, 12
Wait 4
ChangeSpriteColor DEFENDER, 10, 10, 0, 31, 10, 12
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 3
Wait 1
ChangeSpriteColor DEFENDER, 10, 0, 0, 31, 10, 12
Wait 4
ChangeSpriteColor DEFENDER, 10, 10, 0, 31, 10, 12
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 3
Wait 1
ChangeSpriteColor DEFENDER, 10, 0, 0, 31, 10, 12
Wait 4
ChangeSpriteColor DEFENDER, 10, 10, 0, 31, 10, 12
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 3
Wait 1
ChangeSpriteColor DEFENDER, 10, 0, 0, 31, 10, 12
Wait 4
Wait 2
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 16, 18
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 16, 18
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 6
ChangeBackgroundColor 4, 8, 0, 0, 8, 1, 3
Wait 28
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
