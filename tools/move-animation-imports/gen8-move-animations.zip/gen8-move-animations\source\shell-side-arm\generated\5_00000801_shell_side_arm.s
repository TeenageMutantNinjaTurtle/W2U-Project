MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 981
AudioContainer CONTINUE
PlaySound 1487, SE1, 14, 0, 300, 100, 0, 0, 0
PlaySound 1727, SE1, 14, 12, 0, 120, 0, 0, 0
PlaySound 1407, SE2, 14, 12, -300, 115, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 9, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 21, -200, 127, 0, 0, 0
PlaySound 1727, SE2, 16, 21, -400, 120, 0, 0, 0
PlaySound 1884, SE1, 16, 24, 0, 100, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 0, 14, 4, 18
ChangeSpriteColor ATTACKER, 0, 8, 0, 26, 10, 31
Emit 981, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 981, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 981, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 981, 3, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 981, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 981, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 12
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -2px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 8, 0, 0, 26, 10, 31
MoveCamera INTERPOLATION, DEFENDER, 9, 0, 8
Wait 9
Emit 981, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 981, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 981, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 981, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 981, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 981, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 981, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 981, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 981, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 28, 14, 31
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 28, 14, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 20
ChangeBackgroundColor 4, 8, 0, 0, 14, 4, 18
Wait 8
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
