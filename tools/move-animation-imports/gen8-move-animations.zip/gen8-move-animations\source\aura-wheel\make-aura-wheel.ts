import { aimed, createKit, fadeInOut, hold, paint, setCurves, spin, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, FOE, glow, hit, impact, intro, outro, pan, shake, snd, sparks, streaks, tint, USER, USER_FLOOR, WHITE, zaps, type Pal } from "../tools/phrases";

// Aura Wheel (move 783) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user runs up a wheel of energy round itself: a blazing white rim
//      with pink and blue lightning swirling inside it, sparks spraying off
//      the ground behind.
//   2. The wheel rolls into the foe.
//   3. It bursts in jagged yellow and black, cyan and red lightning forking
//      out.
// The user is hidden while it is the wheel (ToggleSpriteVisibility 3/4).
// The lightning is Thunder's.

const SPA = 963;
const kit = await createKit({ workDir: import.meta.dirname, slug: "aura-wheel", moveId: 783, spaId: SPA, donors: [257, 228, 465, 579, 411, 298, 560] });

const CAMERA_IN = 10;
const SPIN_UP = 24;
const TRAVEL = 9;
const AFTER = 26;

const PINK: Rgb = [1.0, 0.4, 0.85];
const BLUE: Rgb = [0.35, 0.7, 1.0];
const PALE: Rgb = [1.0, 0.95, 1.0];
const YELLOW: Rgb = [1.0, 0.92, 0.25];
const RED: Rgb = [1.0, 0.25, 0.25];
const CYAN: Rgb = [0.5, 0.95, 1.0];
const WHEEL: Vec3 = [0, 0.3, 0.3];

// The wheel's layers, front to back (earlier emits draw in front): two
// counter-turning swirls of pink and blue, then the white rim.
type Layer = { name: string; tex: number; scale: number; rate: number; colours: [Rgb, Rgb, Rgb]; level: number };
const LAYERS: Layer[] = [
  { name: "SwirlPink", tex: kit.tex(T.swirlRings), scale: 2.0, rate: 0.35, colours: [PINK, PALE, RED], level: 0.9 },
  { name: "SwirlBlue", tex: kit.tex(T.swirlRings), scale: 1.6, rate: -0.3, colours: [BLUE, CYAN, PINK], level: 0.85 },
  { name: "Rim", tex: kit.tex(T.ring), scale: 2.35, rate: 0.3, colours: [WHITE, WHITE, PALE], level: 0.95 },
];
const user: string[] = [];
const rolling: string[] = [];
for (const l of LAYERS) {
  // Spinning up on the spot...
  const up = kit.parked(l.tex, WHEEL, l.scale, SPIN_UP + 1);
  spin(up, l.rate);
  setCurves(up, { start: 0.3, mid: 1, end: 1.05, curveIn: 0.5, curveOut: 0.9 }, { start: 0, mid: l.level, end: l.level, curveIn: 0.3, curveOut: 1 });
  paint(up, l.colours[0], l.colours[1], l.colours[2]);
  kit.add(`up${l.name}`, up);
  user.push(`up${l.name}`);
  // ...then rolling across.
  const roll = kit.parked(l.tex, WHEEL, l.scale, TRAVEL + 1);
  roll.startDelayFrames = SPIN_UP;
  aimed(roll, 16 / TRAVEL, TRAVEL + 1);
  roll.airResistance = 1.0;
  spin(roll, l.rate * 1.4);
  setCurves(roll, hold(1.05), hold(l.level));
  paint(roll, l.colours[0], l.colours[1], l.colours[2]);
  kit.add(`roll${l.name}`, roll);
  rolling.push(`roll${l.name}`);
}
user.push(
  ...zaps(kit, "crackle", { pos: WHEEL, radius: 1.5, count: 1, bursts: SPIN_UP / 3, gap: 3, life: 6, scale: 0.7, pal: [PINK, WHITE, BLUE] }),
  ...streaks(kit, "groundSparks", { pos: [0, USER_FLOOR[1] + 0.2, 0.4], at: 4, radius: 0.5, speed: 0.4, count: 2, bursts: (SPIN_UP - 4) / 2, gap: 2, life: 7, scale: 0.55, pal: [YELLOW, WHITE, [1.0, 0.7, 0.2]], flat: true, lift: 0.08 }),
  ...glow(kit, "wheelGlow", { pos: USER, life: SPIN_UP, scale: 3.0, pal: [PINK, BLUE, PALE], level: 0.5 }),
);

const foe = [
  ...impact(kit, "crash", { pal: [YELLOW, PALE, [1.0, 0.7, 0.15]], size: 1.5, rays: 8, flecks: 0 }),
  ...streaks(kit, "blackJags", { radius: 0.5, speed: 0.4, count: 7, life: 11, scale: 0.85, pal: [[0, 0, 0], [0.1, 0.02, 0.08], [0, 0, 0]], tex: kit.tex(T.shard) }),
  ...streaks(kit, "yellowJags", { at: 1, radius: 0.6, speed: 0.34, count: 7, life: 11, scale: 0.9, pal: [YELLOW, [1.0, 0.7, 0.15], PALE], tex: kit.tex(T.shard) }),
  ...zaps(kit, "forks", { radius: 0.6, speed: 0.26, count: 3, bursts: 4, gap: 3, life: 8, scale: 1.0, pal: [CYAN, WHITE, RED], shape: "circle" }),
  ...glow(kit, "blaze", { pos: FOE, life: 14, scale: 2.8, pal: [YELLOW, PINK, BLUE], level: 0.75 }),
  ...sparks(kit, "after", { at: 8, radius: 1.4, speed: 0.12, count: 3, bursts: 3, gap: 4, life: 12, scale: 0.13, pal: [PINK, WHITE, CYAN], fall: 0.008 }),
];

const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1483, 0, { ch: "SE2", vol: 100 }),
  snd(1425, 4, { pitch: 500, vol: 105 }),
  snd(1376, SPIN_UP, { ch: "SE2", vol: 0 }),
  snd(1522, SPIN_UP, { vol: 127 }),
  snd(1514, SPIN_UP + TRAVEL, { ch: "SE2", side: "D", pitch: -200, vol: 127 }),
  snd(1475, SPIN_UP + TRAVEL, { side: "D", pitch: -200, vol: 125 }),
  snd(1458, SPIN_UP + TRAVEL + 8, { ch: "SE2", side: "D", vol: 110 }),
)}
${tint("ATTACKER", 0, 8, 6, [31, 20, 31])}
${emits(kit, user, "ATTACKER")}
${emits(kit, rolling, "ATTACKER", "DEFENDER")}
${shake("ATTACKER", 819, SPIN_UP / 2 - 2)}
Wait ${SPIN_UP}
ToggleSpriteVisibility ATTACKER, 3
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [31, 30, 14], power: 3 })}
Wait ${AFTER}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
${tint("ATTACKER", 8, 0, 0, [31, 20, 31])}
ToggleSpriteVisibility ATTACKER, 4
${pan("INIT", 12)}
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [87, 63, 605, 400, 240, 129, 381],
  references: ["reference/Aura_Wheel_VIII.png", "reference/Aura_Wheel_VIII_2.png", "reference/Aura_Wheel_IX.png", "reference/Aura_Wheel_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("upRim")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("rollRim")}, ATTACKER, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 3", "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("forks")}, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 4", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  wheel spins up f${CAMERA_IN}, rolls f${CAMERA_IN + SPIN_UP}, crash f${CAMERA_IN + SPIN_UP + TRAVEL}`);
