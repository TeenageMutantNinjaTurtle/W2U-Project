MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1003
AudioContainer CONTINUE
PlaySound 1458, SE1, 14, 0, 300, 105, 0, 0, 0
PlaySound 1452, SE2, 14, 4, -200, 105, 0, 0, 0
PlaySound 1407, SE1, 14, 16, 100, 125, 0, 0, 0
PlaySound 1438, SE2, 16, 23, 300, 120, 0, 0, 0
PlaySound 1683, SE1, 16, 25, 0, 127, 0, 0, 0
PlaySound 1475, SE2, 16, 26, -400, 127, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 9, 0, 31, 29, 10
Emit 1003, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1003, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1003, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, 819, -1229, 12, 0, 1
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 6
Wait 16
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 5px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 9, 0, 0, 31, 29, 10
MoveCamera INTERPOLATION, DEFENDER, 7, 0, 8
Wait 7
Emit 1003, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1003, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1003, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1003, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1003, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1003, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1003, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1003, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1003, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
Wait 3
ChangeBackgroundColor 4, 13, 13, 0, 31, 31, 22
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 31, 16
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 31, 16
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 13, 0, 0, 31, 31, 22
Wait 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 8
Wait 18
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
