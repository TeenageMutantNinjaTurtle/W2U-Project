import { createKit, fadeOut, hold, paint, setCurves, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, glow, intro, outro, ring, risers, snd, sparks, squash, tint, USER_FLOOR, WHITE, type Pal } from "../tools/phrases";

// Life Dew (move 791) - from the Bulbapedia stills (reference/sheet.png).
//   1. A bright cyan drop of dew falls out of the sky onto the user.
//   2. Where it lands, rings of pale green-white light ripple out across the
//      ground and soft green light and white flecks rise round the user.
// Stays on the user; the healing is the engine's.

const SPA = 971;
const kit = await createKit({ workDir: import.meta.dirname, slug: "life-dew", moveId: 791, spaId: SPA, donors: [228, 465, 411, 298, 407] });

const CAMERA_IN = 10;
const WAIT = 6;
const FALL = 12;
const BLOOM = 40;

const CYAN: Rgb = [0.4, 0.95, 1.0];
const MINT: Rgb = [0.6, 1.0, 0.75];
const GREEN: Rgb = [0.35, 0.9, 0.5];
const PALE: Rgb = [0.92, 1.0, 0.92];
const HEAL: Pal = [MINT, PALE, GREEN];
const HEIGHT = 5.0;
const POOL: Vec3 = [0, USER_FLOOR[1], 0.3];

// --- 1. the drop, with two fainter drops strung out above it ---
function drop(name: string, lag: number, scale: number, level: number): string {
  const r = kit.parked(kit.tex(T.softDisc), [0, 0.4 + HEIGHT, 0.4], scale, FALL + 1);
  r.startDelayFrames = WAIT + lag;
  r.aspectRatio = 0.6;
  r.axis = [0, -1, 0];
  r.initVelAxisAmplifier = HEIGHT / FALL;
  setCurves(r, hold(1), hold(level));
  paint(r, CYAN, WHITE, CYAN);
  kit.add(name, r);
  return name;
}
const LAND = WAIT + FALL;
const user = [
  drop("dew", 0, 0.42, 1), drop("dewTrail", 2, 0.3, 0.7), drop("dewTrail2", 4, 0.2, 0.45),
  // --- 2. the ripples and the rising light ---
  ...glow(kit, "splash", { pos: [0, 0.3, 0.4], at: LAND, life: 10, scale: 1.6, pal: [PALE, WHITE, CYAN], tex: kit.tex(T.spiky), spin: 0.1, level: 1, alpha: fadeOut(1, 0.4) }),
  ...Array.from({ length: 3 }, (_, i) => ring(kit, `ripple${i}`, { pos: POOL, at: LAND + i * 8, scale: 1.2, pal: [PALE, WHITE, MINT], tex: kit.tex(T.ring), aspect: 2.6, to: 2.3, life: 18, level: 0.9 })).flat(),
  ...glow(kit, "pool", { pos: POOL, at: LAND, life: BLOOM, scale: 1.5, pal: [MINT, GREEN, PALE], aspect: 2.6, level: 0.8 }),
  ...glow(kit, "aura", { pos: [0, 0.3, 0.2], at: LAND, life: BLOOM, scale: 2.8, pal: [MINT, GREEN, PALE], level: 0.55 }),
  ...risers(kit, "light", { pos: POOL, at: LAND + 2, frames: BLOOM - 16, radius: 1.5, speed: 0.3, scale: 0.9, life: 10, every: 3, pal: [MINT, WHITE, GREEN], streak: true }),
  ...risers(kit, "flecks", { pos: POOL, at: LAND + 2, frames: BLOOM - 14, radius: 1.7, speed: 0.14, scale: 0.15, life: 16, every: 2, pal: [WHITE, PALE, MINT] }),
  ...sparks(kit, "glints", { pos: [0, 0.8, 0.4], at: LAND + 6, radius: 1.5, speed: 0, count: 1, bursts: 6, gap: 4, life: 9, scale: 0.34, pal: [WHITE, PALE, CYAN], shape: "ball", tex: kit.tex(T.sparkle4) }),
];

const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1509, WAIT, { pitch: 1000, vol: 90 }),
  snd(1445, WAIT + FALL - 3, { ch: "SE2", pitch: 1600, vol: 85 }),
  snd(1511, WAIT + FALL, { pitch: 900, vol: 105 }),
  snd(1427, WAIT + FALL + 4, { ch: "SE2", vol: 115 }),
  snd(1784, WAIT + FALL + 16, { pitch: 300, vol: 95 }),
)}
${emits(kit, user, "ATTACKER")}
Wait ${LAND}
${tint("ATTACKER", 0, 10, 4, [18, 31, 22])}
${squash("ATTACKER", 819, -819, 4)}
Wait ${BLOOM - 10}
${tint("ATTACKER", 10, 0, 8, [18, 31, 22])}
Wait 10
${outro({ unfreeze: "NONE" })}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 240, 129, 236],
  references: ["reference/Life_Dew_VIII.png", "reference/Life_Dew_IX.png", "reference/Life_Dew_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("dew")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("ripple0")}, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  dew falls f${CAMERA_IN + WAIT}, lands f${CAMERA_IN + LAND}, bloom until f${CAMERA_IN + LAND + BLOOM}`);
