import { createKit, grow, hold, paint, setCurves, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, glow, intro, outro, ring, risers, snd, sparks, squash, tint, USER, USER_FLOOR, WHITE } from "../tools/phrases";

// Lunar Blessing (move 849) - from the Bulbapedia stills (reference/sheet.png).
//   1. Night falls over the arena; a crescent moon rises over the user in a
//      column of deep blue light.
//   2. The blessing: a sphere of pink-white light opens round the user, rings
//      of pale light tilting round it, stars of pink, white and cyan flashing.
//   3. It heals: teal sparkles and small crescents float up off the user.
// Stays on the user; the healing and the status cure are the engine's. The
// crescent moon is drawn (generated/texture-moon.png).

const SPA = 1029;
const kit = await createKit({ workDir: import.meta.dirname, slug: "lunar-blessing", moveId: 849, spaId: SPA, donors: [228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const MOONRISE = 20;
const BLESS = 26;
const HEAL = 24;
const TOTAL = MOONRISE + BLESS + HEAL;

const NIGHT: Rgb = [0.2, 0.32, 0.95];
const DUSK: Rgb = [0.1, 0.14, 0.6];
const SKY: Rgb = [0.5, 0.68, 1.0];
const PINK: Rgb = [1.0, 0.7, 0.95];
const PALE: Rgb = [1.0, 0.94, 1.0];
const CYAN: Rgb = [0.6, 0.95, 1.0];
const TEAL: Rgb = [0.4, 1.0, 0.8];
const MOONLIGHT: Rgb = [1.0, 0.97, 0.8];

// --- a crescent moon, open to the right ---
const moonTex = await kit.drawn("moon", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5 - 16, py = y + 0.5 - 16;
  const outer = Math.hypot(px, py), bite = Math.hypot(px - 5.5, py + 1.5);
  if (outer > 13 || bite < 11) return undefined;
  if (outer > 11.8 || bite < 12.2) return [235, 215, 150, 255];
  return [255, 252, 225, 255];
});
const MOON: Vec3 = [0.3, 2.0, 0.0];

const moon = kit.parked(moonTex, MOON, 0.85, MOONRISE + BLESS);
// It rises into place.
moon.axis = [0, 1, 0];
moon.initVelAxisAmplifier = 0.03;
moon.airResistance = 0.86;
setCurves(moon, hold(1), { start: 0, mid: 1, end: 0, curveIn: 0.25, curveOut: 0.85 });
paint(moon, WHITE);
kit.add("moon", moon);

const blessAt = MOONRISE, healAt = MOONRISE + BLESS - 4;
const user = [
  "moon",
  // --- 2. the blessing ---
  ...sparks(kit, "stars", { pos: USER, at: blessAt, radius: 2.4, speed: 0, count: 1, bursts: BLESS / 2, gap: 2, life: 9, scale: 0.36, pal: [PINK, WHITE, CYAN], shape: "sphere", tex: kit.tex(T.sparkle4) }),
  ...glow(kit, "orbitA", { pos: USER, at: blessAt + 2, life: 16, scale: 1.0, pal: [WHITE, WHITE, CYAN], tex: kit.tex(T.ring), aspect: 2.6, angle: 0.5, level: 0.9, scaleCurve: grow(0.5, 0.3, 1.2) }),
  ...glow(kit, "orbitB", { pos: USER, at: blessAt + 8, life: 16, scale: 1.0, pal: [PALE, WHITE, PINK], tex: kit.tex(T.ring), aspect: 2.6, angle: -0.5, level: 0.9, scaleCurve: grow(0.5, 0.3, 1.2) }),
  ...ring(kit, "sphereRim", { pos: USER, at: blessAt, life: BLESS, scale: 2.2, pal: [PALE, WHITE, PINK], to: 1.08, level: 0.9 }),
  ...glow(kit, "sphere", { pos: USER, at: blessAt, life: BLESS, scale: 2.2, pal: [PINK, PALE, [0.8, 0.5, 1.0]], tex: kit.tex(T.softDisc), level: 0.6, scaleCurve: grow(0.3, 0.25, 1.06) }),
  // --- 3. the healing ---
  ...risers(kit, "healSparkles", { pos: USER_FLOOR, at: healAt, frames: HEAL - 6, radius: 1.5, speed: 0.12, scale: 0.3, life: 16, every: 2, pal: [TEAL, WHITE, CYAN], tex: kit.tex(T.sparkle4) }),
  ...sparks(kit, "crescents", { pos: USER, at: healAt, radius: 1.6, speed: 0.03, count: 1, bursts: HEAL / 4, gap: 4, life: 14, scale: 0.26, pal: [PALE, WHITE, PINK], fall: -0.012, shape: "ball", tex: moonTex, twinkle: false }),
  ...glow(kit, "healGlow", { pos: USER, at: healAt, life: HEAL, scale: 2.6, pal: [TEAL, CYAN, WHITE], level: 0.5 }),
  // --- 1. the moon's light ---
  ...glow(kit, "moonGlow", { pos: MOON, life: MOONRISE + BLESS, scale: 1.6, pal: [MOONLIGHT, WHITE, SKY], level: 0.7 }),
  ...glow(kit, "column", { pos: [0, 1.4, 0.1], life: TOTAL - 6, scale: 3.6, pal: [NIGHT, SKY, DUSK], tex: kit.tex(T.softDisc), aspect: 0.38, level: 0.55, scaleCurve: grow(0.7, 0.2, 1.02) }),
];

const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1510, 0, { pitch: -200, vol: 105 }),
  snd(1474, 8, { ch: "SE2", vol: 95 }),
  snd(1505, blessAt, { pitch: 300, vol: 110 }),
  snd(1784, blessAt + 4, { ch: "SE2", pitch: 200, vol: 100 }),
  snd(1474, blessAt + 12, { ch: "SE2", pitch: 300, vol: 95 }),
  snd(1427, healAt, { vol: 115 }),
)}
${arena(0, 10, 10, [3, 5, 16])}
${emits(kit, user, "ATTACKER")}
Wait ${MOONRISE}
${tint("ATTACKER", 0, 10, 6, [31, 25, 31])}
Wait ${BLESS - 4 - 10}
${tint("ATTACKER", 10, 0, 10, [31, 25, 31])}
Wait 10
${tint("ATTACKER", 0, 8, 8, [16, 31, 26])}
${squash("ATTACKER", -819, 819, 6)}
Wait ${HEAL - 10}
${tint("ATTACKER", 8, 0, 8, [16, 31, 26])}
${arena(10, 0, 10, [3, 5, 16])}
Wait 14
${outro({ unfreeze: "NONE" })}`;

await kit.finish({
  script,
  donorMoveIds: [236, 461, 63, 605, 240, 129, 381],
  references: ["reference/Lunar_Blessing_LA.png", "reference/Lunar_Blessing_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("moon")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("sphere")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("healSparkles")}, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  moonrise f${CAMERA_IN}, blessing f${CAMERA_IN + blessAt}, healing f${CAMERA_IN + healAt}-${CAMERA_IN + healAt + HEAL}`);
