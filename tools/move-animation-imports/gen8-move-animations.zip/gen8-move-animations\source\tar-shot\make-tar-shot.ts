import { createKit, fadeOut, grow, hold, paint, setCurves, spin, T } from "../tools/anim-kit";
import { audio, emits, FOE, FRONT, glow, intro, lunge, outro, pan, puffs, shake, shot, snd, sparks, squash, tint, WHITE, type Pal } from "../tools/phrases";

// Tar Shot (move 749) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user spits a stream of glossy black tar: big blobs with small
//      droplets flung off them.
//   2. It splatters over the foe in a black mass, drops flying and dripping.
// A status move: the foe is coated and shudders, with no hit flash.
// The tar blob is drawn (generated/texture-blob.png).

const SPA = 947;
const kit = await createKit({ workDir: import.meta.dirname, slug: "tar-shot", moveId: 749, spaId: SPA, donors: [228, 465, 321, 298] });

const CAMERA_IN = 10;
const WINDUP = 10;
const BLOBS = 6;
const BLOB_GAP = 3;
const TRAVEL = 9;
const COAT = 30; // the tar sits on the foe
const AFTER = 10;
const STREAM = (BLOBS - 1) * BLOB_GAP;

// Everything is painted from the texture, which is already black with a white gloss.
const TAR: Pal = [WHITE, WHITE, WHITE];
const INK: Pal = [[0.07, 0.06, 0.08], [0.16, 0.15, 0.18], [0.03, 0.03, 0.04]];

// --- the drawn tar blob: a black drop with a white gloss highlight ---
const blobTex = await kit.drawn("blob", 32, 32, "a3i5", (x, y) => {
  const dx = x + 0.5 - 16, dy = y + 0.5 - 16;
  // A lumpy outline.
  const edge = 12.5 + 1.6 * Math.sin(Math.atan2(dy, dx) * 3 + 0.6) + 0.9 * Math.sin(Math.atan2(dy, dx) * 5);
  const d = Math.hypot(dx, dy);
  if (d > edge) return undefined;
  const gloss = Math.hypot(dx + 4.5, dy + 5) < 3.2 || Math.hypot(dx + 1, dy + 7.5) < 1.5;
  if (gloss) return [235, 235, 240];
  if (d > edge - 2) return [0, 0, 0];
  return [3, 3, 4];
});

// --- 1. the stream ---
shot(kit, "blobs", blobTex, { at: WINDUP, travel: TRAVEL, scale: 0.75, pal: TAR, count: BLOBS, gap: BLOB_GAP, spin: 0.12, dive: 0.02 });
shot(kit, "smallBlobs", blobTex, { from: [0.3, 0.3, -1.0], at: WINDUP + 1, travel: TRAVEL + 1, scale: 0.4, pal: TAR, count: BLOBS, gap: BLOB_GAP, spin: -0.2 });
const user = [
  ...puffs(kit, "spit", { pos: FRONT, at: WINDUP, radius: 0.4, count: 1, bursts: BLOBS, gap: BLOB_GAP, life: 8, scale: 0.6, pal: INK, speed: 0.08, level: 0.9 }),
  ...sparks(kit, "drips", { pos: FRONT, at: WINDUP, radius: 0.5, speed: 0.14, count: 2, bursts: BLOBS, gap: BLOB_GAP, life: 12, scale: 0.16, pal: TAR, fall: 0.016, tex: blobTex, twinkle: false }),
];

// --- 2. the splatter ---
const LAND = 0; // emitted as the first blob lands
const mass = kit.parked(blobTex, [0, 0.4, 0.9], 1.5, COAT);
spin(mass, 0.01);
setCurves(mass, { start: 0.4, mid: 1.15, end: 1.0, curveIn: 0.25, curveOut: 0.7 }, { start: 1, mid: 1, end: 0, curveIn: 0, curveOut: 0.8 });
paint(mass, WHITE);
kit.add("mass", mass);
const foe = [
  "mass",
  ...sparks(kit, "splat", { at: LAND, radius: 0.6, speed: 0.3, count: 3, bursts: BLOBS, gap: BLOB_GAP, life: 14, scale: 0.3, pal: TAR, fall: 0.02, tex: blobTex, twinkle: false, shape: "circle" }),
  ...puffs(kit, "smear", { pos: FOE, at: LAND, radius: 0.9, count: 2, bursts: BLOBS, gap: BLOB_GAP, life: 14, scale: 0.9, pal: INK, speed: 0.06, level: 0.95, tex: kit.tex(T.clumps) }),
  ...sparks(kit, "dripping", { pos: [0, 0, 0.9], at: STREAM, radius: 1.0, speed: 0.02, count: 1, bursts: 6, gap: 3, life: 14, scale: 0.2, pal: TAR, fall: 0.018, tex: blobTex, twinkle: false, shape: "ball" }),
  ...glow(kit, "shade", { pos: FOE, life: COAT, scale: 2.6, pal: INK, level: 0.5 }),
];
// The splat blobs shrink as they fly.
setCurves(kit.resources[kit.idx("splat")]!, grow(1, 0.2, 0.5), fadeOut(1, 0.7));
setCurves(kit.resources[kit.idx("drips")]!, hold(1), fadeOut(1, 0.7));

const landAt = WINDUP + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1727, WINDUP, { vol: 120 }),
  snd(1480, WINDUP, { ch: "SE2", pitch: -400, vol: 100 }),
  `SwitchAudioSide SE2, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0`,
  snd(1727, landAt, { side: "D", pitch: -300, vol: 125 }),
  snd(1727, landAt + 6, { ch: "SE2", side: "D", pitch: -500, vol: 115 }),
  snd(1727, landAt + 12, { side: "D", pitch: -200, vol: 105 }),
)}
${squash("ATTACKER", -819, 819, 4)}
${emits(kit, user, "ATTACKER")}
${emits(kit, ["blobs", "smallBlobs"], "ATTACKER", "DEFENDER")}
Wait ${WINDUP}
${lunge("ATTACKER", -1)}
${shake("ATTACKER", 819, STREAM / 2)}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
${tint("DEFENDER", 0, 12, STREAM, [3, 3, 4])}
${shake("DEFENDER", 819, STREAM / 2 + 4)}
Wait ${STREAM + 4}
${squash("DEFENDER", 819, -819, 4)}
Wait ${COAT - STREAM - 4 - 8}
${tint("DEFENDER", 12, 0, 8, [3, 3, 4])}
Wait ${8 + AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 153, 129],
  references: ["reference/Tar_Shot_VIII.png", "reference/Tar_Shot_VIII_2.png", "reference/Tar_Shot_IX.png", "reference/Tar_Shot_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("blobs")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("mass")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  stream f${CAMERA_IN + WINDUP}-${CAMERA_IN + WINDUP + STREAM}, lands f${CAMERA_IN + landAt}, coated until f${CAMERA_IN + landAt + COAT}`);
