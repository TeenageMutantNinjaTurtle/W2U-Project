MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 945
AudioContainer CONTINUE
PlaySound 1470, SE1, 14, 0, 300, 90, 0, 0, 0
PlaySound 1720, SE1, 14, 14, 200, 120, 0, 0, 0
PlaySound 1720, SE2, 14, 21, -100, 120, 0, 0, 0
PlaySound 1720, SE1, 14, 28, 100, 120, 0, 0, 0
PlaySound 1779, SE2, 14, 34, 0, 127, 0, 0, 0
PlaySound 1427, SE1, 14, 37, 200, 110, 0, 0, 0
PlaySound 1452, SE2, 14, 43, 300, 105, 0, 0, 0
AudioContainer SUSPEND
Emit 945, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 945, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 945, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 945, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 945, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 945, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 945, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 945, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 945, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 945, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 14
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 3, 0, 1
Wait 7
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 3, 0, 1
Wait 7
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 3, 0, 1
Wait 7
ChangeSpriteColor ATTACKER, 0, 11, 0, 31, 28, 12
ScaleSprite ATTACKER, ROUNDTRIP, -1229, 1229, 4, 0, 1
Wait 20
ChangeSpriteColor ATTACKER, 11, 0, 0, 31, 28, 12
Wait 8
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
