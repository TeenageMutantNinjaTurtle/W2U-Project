MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1006
AudioContainer CONTINUE
PlaySound 1869, SE1, 14, 0, -2200, 95, 0, 0, 0
PlaySound 1434, SE2, 14, 4, 200, 100, 0, 0, 0
PlaySound 1869, SE1, 14, 14, -1800, 95, 0, 0, 0
PlaySound 1510, SE2, 16, 40, -300, 110, 0, 0, 0
PlaySound 1919, SE1, 16, 40, 0, 100, 0, 0, 0
PlaySound 1420, SE2, 16, 42, 200, 115, 0, 0, 0
PlaySound 1420, SE2, 16, 56, 400, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 12, 0, 6, 2, 14
ChangeSpriteColor ATTACKER, 0, 7, 0, 24, 14, 31
Emit 1006, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1006, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1006, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1006, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1006, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 11
Wait 30
ChangeSpriteColor ATTACKER, 7, 0, 0, 24, 14, 31
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
EmitCircle 1006, 5, DEFENDER_LEFT, 0.5px, 0.5px, 1.6px, 120, 0, 1, 0
EmitCircle 1006, 6, DEFENDER_LEFT, 0.5px, 0.5px, 1.6px, 120, 0, 1, 0
Emit 1006, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1006, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1006, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1006, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1006, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1006, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1006, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 2
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 31, 18, 30
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 31, 18, 30
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 11
Wait 6
ScaleSprite DEFENDER, ROUNDTRIP, 410, -819, 8, 0, 1
Wait 16
ChangeBackgroundColor 4, 12, 0, 0, 6, 2, 14
Wait 18
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
