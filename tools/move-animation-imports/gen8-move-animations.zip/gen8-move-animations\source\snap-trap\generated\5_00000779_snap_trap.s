MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 959
AudioContainer CONTINUE
PlaySound 1509, SE1, 14, 5, 800, 95, 0, 0, 0
PlaySound 1509, SE2, 16, 24, 600, 90, 0, 0, 0
PlaySound 1435, SE1, 16, 35, 300, 127, 0, 0, 0
PlaySound 1423, SE2, 16, 35, 0, 120, 0, 0, 0
PlaySound 1435, SE1, 16, 47, -300, 90, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 6, 0, 14, 26, 10
ScaleSprite ATTACKER, ROUNDTRIP, 819, -1229, 12, 0, 1
Emit 959, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 959, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 14
ChangeSpriteColor ATTACKER, 6, 0, 0, 14, 26, 10
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 959, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 959, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 959, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 959, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 959, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 959, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 959, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 959, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 959, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 959, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 959, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 13
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 28, 29, 31
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 28, 29, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ScaleSprite DEFENDER, ROUNDTRIP, 0, -1229, 8, 0, 1
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 11
Wait 26
ShakeScreen HORIZON, 0.5x, 0, 2, 0, 3
Wait 10
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
