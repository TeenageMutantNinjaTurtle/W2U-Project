MoveCamera INTERPOLATION, ZOOM_OUT, 24, 0, 0
LetCMDsFinish ALL
AudioContainer CONTINUE
PlaySound 1461, SE1, 14, 5, 0, 120, 0, 0, 0
PlaySound 1454, SE2, 14, 15, 0, 115, 0, 0, 0
PlaySound 1454, SE1, 14, 25, 0, 70, 0, 0, 0
PlaySound 1454, SE2, 14, 35, 0, 50, 0, 0, 0
AudioContainer SUSPEND
AudioContainer CONTINUE
PlaySound 1461, SE1, 16, 40, 0, 120, 0, 0, 0
PlaySound 1454, SE2, 16, 55, 0, 115, 0, 0, 0
PlaySound 1454, SE1, 16, 65, 0, 100, 0, 0, 0
PlaySound 1454, SE2, 16, 75, 0, 90, 0, 0, 0
PlaySound 1454, SE1, 16, 85, 0, 80, 0, 0, 0
PlaySound 1454, SE2, 16, 95, 0, 70, 0, 0, 0
PlaySound 1454, SE1, 16, 105, 0, 60, 0, 0, 0
PlaySound 1454, SE2, 16, 115, 0, 50, 0, 0, 0
PlaySound 1454, SE1, 16, 125, 0, 40, 0, 0, 0
PlaySound 1454, SE2, 16, 135, 0, 30, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 2, 0, 8, 2, 0, 0, 0
ShakeSprite ATTACKER, 2, 819, 0, 2, 0, 30
LoadSPA 554
EmitOrtho 554, 0, ATTACKER, NONE, 0, 2px, 0, 0.5x, 1x, 0.5x, 1x
Wait 10
EmitOrtho 554, 2, ATTACKER, NONE, 0, 2px, 0, 0.5x, 1x, 0.5x, 1x
Wait 20
EmitOrtho 554, 1, DEFENDER, NONE, 0, 2px, 0, 0.5x, 1x, 0.5x, 1x
ShakeSprite DEFENDER, 2, 819, 0, 2, 0, 30
Wait 10
EmitOrtho 554, 0, DEFENDER, NONE, 0, 2px, 0, 0.5x, 1x, 0.5x, 1x
Wait 10
EmitOrtho 554, 2, ATTACKER, NONE, 0, 2px, 0, 0.5x, 1x, 0.5x, 1x
Wait 20
EmitOrtho 554, 1, DEFENDER, NONE, 0, 2px, 0, 0.5x, 1x, 0.5x, 1x
Wait 50
ChangeBackgroundColor 2, 8, 0, 2, 0, 0, 0
LetCMDsFinish ALL
MoveCamera INTERPOLATION, INIT_ORTHO, 24, 0, 0
LetCMDsFinish ALL
TerminateMoveScript
