MoveCamera INTERPOLATION, DEFENDER, 16, 0, 8
LetCMDsFinish ALL
ChangeBackgroundColor 4, 0, 13, 2, 0, 0, 0
AudioContainer CONTINUE
PlaySound 1455, SE1, 16, 0, 0, 100, 0, 0, 0
PlaySound 1467, SE2, 14, 0, 0, 90, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 16, 0, 30, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 16, 0, 30, 0, 0
AudioContainer SUSPEND
AudioContainer CONTINUE
PlaySound 1426, SE1, 16, 50, 0, 120, 0, 0, 0
AudioContainer SUSPEND
LoadSPA 825
Emit 825, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 825, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 20
ToggleFreezeSprite DEFENDER, START
ScaleSprite DEFENDER, ROUNDTRIP, -819, 819, 2, 1, 4
LetCMDsFinish ALL
ChangeBackgroundColor 4, 13, 0, 2, 0, 0, 0
MoveCamera INTERPOLATION, INIT, 16, 0, 8
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
