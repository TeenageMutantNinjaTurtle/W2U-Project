# Gen 8 move animations for White 2 (White2Upgrade)

89 moves, #744-756 and #775-850, as installed in `work/moves-preview.nds` on 2026-10-03.
The Max moves (Max Guard #743 and #757-774) are not included, as asked.

## What is here

- `moves.csv` - one line per move: id, name, folder, and its two files.
- `GEN8-PROGRESS.md` - what each animation does, with notes. Rows marked "Revised 2026-10-03" were reworked to review notes.
- `TERRAIN-PULSE-VERSIONS.md` - **read this if you will run Terrain Pulse in a battle.** Its animation holds
  five versions (one per terrain) and the battle code has to say which one to play; the note explains the
  order, where the table is, and how to change it to suit your code.
- `narc-files/` - the compiled files, ready to put in a ROM:
  - `a065-move-scripts/5_<moveId>.bin` is file number <moveId> of NARC `a/0/6/5` (the move's animation script).
  - `a006-particles/6_<spaId>.bin` is file number <spaId> of NARC `a/0/0/6` (the particle archive that script loads).
- `source/` - what built them, laid out as in `work/`:
  - `source/<folder>/make-<folder>.ts` is the generator, `moveanim.json` the install manifest, and `generated/` holds the script source (`.s`), the two compiled files and any drawn textures (`.png`).
  - `source/tools/` is the shared toolkit (`anim-kit.ts`, `phrases.ts`, `storm.ts`, `ship.sh`, `verify.ts`, `installed.json`, ...).
- `hack-originals/` - the hack's own animation scripts for the 28 Gen 8 moves it already animated (776, 779, 781-784, 787, 789, 792, 796, 799, 800, 806, 812-815, 817, 825, 828, 833, 834, 837-841, 844), as they are in `White2Upgrade_gen9.nds`, each with a `restore-<id>.json` manifest that puts it back.

## Putting them in a ROM

Each script loads its particle archive by number (`LoadSPA <spaId>`), so the particle files must sit at exactly
the numbers in `moves.csv` (942-1030, one per move, in order).

With the Pokeweb-Serverless tools, copy `source/`'s contents into `work/` and, from `Pokeweb-Serverless/`, run once per move:

```powershell
npm run moveanim:install -- --manifest ../work/<folder>/moveanim.json --preview-rom <rom-in.nds> --out <rom-out.nds>
```

To put one of the hack's own animations back instead, use its manifest from `hack-originals/` the same way
(the particle archives it loads are the hack's own and are already in the ROM).

## Things to know

- **Terrain Pulse (#805) holds five versions, one per terrain** (0 none, 1 Electric, 2 Grassy, 3 Misty, 4 Psychic).
  An animation script cannot read the terrain: the battle code has to pass the version index, as the game does
  for Weather Ball. If it passes nothing, version 0 (pale gold) always plays. Whether this hack's battle code
  passes it has not been checked. See `TERRAIN-PULSE-VERSIONS.md` for how to reorder the versions or change how
  the move chooses one.
- Meteor Beam (#800) is a two-turn script (charge, then fire).
- Multi-hit moves (Dragon Darts, Scale Shot, Triple Axel, Dual Wingbeat, Surging Strikes) replay per hit.
- None of these has been run in a battle; each was checked in the Pokeweb preview.

## Not included

- No ROMs.
- The reference stills (`reference/` in each folder: Bulbapedia screenshots). The manifests still name them.
- The retail donor dumps the generators read when they are re-run (`work/donor-pool`). The compiled files above
  do not need them; only regenerating does.
