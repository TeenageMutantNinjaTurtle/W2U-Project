MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1021
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -300, 115, 0, 0, 0
PlaySound 1815, SE2, 14, 6, -200, 105, 0, 0, 0
PlaySound 1815, SE1, 16, 34, -500, 115, 0, 0, 0
PlaySound 1434, SE2, 16, 42, -500, 120, 0, 0, 0
PlaySound 1420, SE1, 16, 43, -300, 115, 0, 0, 0
PlaySound 1475, SE1, 16, 56, -500, 125, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 11, 0, 3, 1, 8
ChangeSpriteColor ATTACKER, 0, 10, 0, 6, 3, 14
Emit 1021, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1021, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1021, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1021, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1021, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 8
Wait 24
ChangeSpriteColor ATTACKER, 10, 0, 0, 6, 3, 14
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
Emit 1021, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1021, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1021, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1021, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1021, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1021, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1021, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1021, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1021, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 9
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 10, 10, 0, 16, 12, 31
Wait 2
ChangeSpriteColor DEFENDER, 10, 0, 0, 16, 12, 31
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 2, 0, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 6
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 5
Wait 11
ChangeSpriteColor DEFENDER, 15, 15, 0, 14, 14, 31
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 14, 14, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 2
ChangeBackgroundColor 4, 11, 0, 0, 3, 1, 8
Wait 22
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
