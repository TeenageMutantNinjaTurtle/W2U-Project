import { createKit, fadeOut, grow, hold, setCurves, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FOE_FLOOR, glow, hit, impact, intro, outro, pan, ring, risers, shake, shot, snd, sparks, streaks, tint, USER_FLOOR, WHITE, type Pal } from "../tools/phrases";

// Burning Jealousy (move 807) - from the Bulbapedia stills (reference/sheet.png).
//   1. The sky reddens. The ground round the user flares: a wide pool of
//      yellow-white light spreads out over it, rings of red and magenta
//      running out along the ground, tongues of flame leaping at its rim and
//      embers rising.
//   2. It lets the fire go: a blast of flame rolls out along the ground at
//      the foe.
//   3. The blast bursts on the foe in yellow and orange, tongues of fire and
//      magenta embers flying - no flames left burning on it.
// The flaring ground (in place of flames on the user and a red whirl, which
// too many of my fire moves shared) is Logan's direction and screenshot,
// 2026-10-03, as is taking the burning flames off the foe. The blast's flame
// is Fire Blast's fire puff (SPA 295).

const SPA = 987;
const kit = await createKit({ workDir: import.meta.dirname, slug: "burning-jealousy", moveId: 807, spaId: SPA, donors: [295, 228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const WHIRL = 28;
const TRAVEL = 9;
const BURN = 16; // the blast's afterglow on the foe
const AFTER = 14;

const YELLOW: Rgb = [1.0, 0.88, 0.25];
const ORANGE: Rgb = [1.0, 0.55, 0.12];
const PALE: Rgb = [1.0, 0.97, 0.7];
const MAGENTA: Rgb = [1.0, 0.25, 0.6];
const RED: Rgb = [1.0, 0.18, 0.1];
const FIRE: Pal = [YELLOW, PALE, ORANGE];

// --- 1. the ground flares ---
const GROUND: [number, number, number] = [0, USER_FLOOR[1], 0.3];
const RIM = 2.3; // how far out the pool reaches
const user = [
  // Tongues of flame leaping at the rim of the pool, and shorter, brighter ones inside it.
  ...risers(kit, "rimFlames", { pos: GROUND, at: 3, frames: WHIRL - 3, radius: RIM, speed: 0.3, scale: 1.3, life: 8, every: 1, count: 2, pal: [RED, ORANGE, [1.0, 0.4, 0.05]], streak: true }),
  ...risers(kit, "innerFlames", { pos: GROUND, at: 6, frames: WHIRL - 8, radius: RIM * 0.55, speed: 0.22, scale: 0.9, life: 7, every: 2, pal: [ORANGE, YELLOW, RED], streak: true, tex: kit.tex(T.spike) }),
  ...sparks(kit, "embers", { pos: [0, -0.6, 0.3], radius: 2.0, speed: 0.08, count: 2, bursts: WHIRL / 3, gap: 3, life: 14, scale: 0.14, pal: [YELLOW, MAGENTA, ORANGE], fall: -0.02, twinkle: false }),
  // Rings of red and magenta running out along the ground.
  ...ring(kit, "flareRing0", { pos: GROUND, at: 1, life: 12, scale: 0.5, pal: [RED, ORANGE, MAGENTA], to: 2.3, aspect: 2.6, level: 0.95 }),
  ...ring(kit, "flareRing1", { pos: GROUND, at: 10, life: 12, scale: 0.5, pal: [RED, ORANGE, MAGENTA], to: 2.3, aspect: 2.6, level: 0.9 }),
  ...ring(kit, "flareRing2", { pos: GROUND, at: 19, life: 12, scale: 0.5, pal: [RED, YELLOW, MAGENTA], to: 2.3, aspect: 2.6, level: 0.95 }),
  // The pool itself: white-hot in the middle, orange beyond, red at its edge.
  ...glow(kit, "poolHeart", { pos: GROUND, life: WHIRL + 4, scale: 0.45, pal: [YELLOW, PALE, ORANGE], tex: kit.tex(T.softDisc), aspect: 2.6, level: 0.95, scaleCurve: grow(0.2, 0.35, 1.15) }),
  ...glow(kit, "pool", { pos: GROUND, life: WHIRL + 4, scale: 0.95, pal: [ORANGE, [1.0, 0.72, 0.2], RED], tex: kit.tex(T.softDisc), aspect: 2.6, level: 0.9, scaleCurve: grow(0.2, 0.35, 1.1) }),
  ...glow(kit, "poolEdge", { pos: GROUND, life: WHIRL + 4, scale: 1.3, pal: [RED, ORANGE, MAGENTA], aspect: 2.6, level: 0.8, scaleCurve: grow(0.2, 0.35, 1.1) }),
];
// The wave: a broad front of flame rolling along the ground.
shot(kit, "wave", kit.tex(295, 4), { from: [0.2, -0.7, -0.6], at: WHIRL, travel: TRAVEL, scale: 1.5, pal: [WHITE, WHITE, WHITE], count: 5, gap: 1, aspect: 1.5, scaleCurve: grow(0.7, 0.3, 1.1), alpha: fadeOut(0.95, 0.5) });
shot(kit, "waveGlow", kit.tex(T.fuzzyGlow), { from: [0.2, -0.7, -0.6], at: WHIRL, travel: TRAVEL, scale: 1.8, pal: [YELLOW, PALE, ORANGE], count: 3, gap: 1, aspect: 1.6, alpha: fadeOut(0.8, 0.4) });

const foe = [
  ...impact(kit, "ignite", { pal: FIRE, size: 1.8, rays: 8, flecks: 0 }),
  ...ring(kit, "blastRing", { at: 1, life: 12, scale: 1.6, pal: [RED, ORANGE, MAGENTA], to: 2.2 }),
  ...streaks(kit, "blastLines", { at: 1, radius: 0.7, speed: 0.46, count: 7, life: 9, scale: 1.0, pal: [YELLOW, PALE, ORANGE] }),
  ...streaks(kit, "tongues", { pos: [0, -0.6, 0.8], radius: 0.6, speed: 0.4, count: 7, life: 10, scale: 0.9, pal: [YELLOW, ORANGE, PALE], tex: kit.tex(T.spike), flat: true, lift: 0.2 }),
  ...sparks(kit, "pinkEmbers", { radius: 1.2, speed: 0.16, count: 3, bursts: BURN / 4, gap: 4, life: 14, scale: 0.15, pal: [MAGENTA, [1.0, 0.6, 0.8], ORANGE], fall: -0.012 }),
  ...glow(kit, "blaze", { pos: FOE, life: BURN + 6, scale: 3.0, pal: [YELLOW, ORANGE, PALE], level: 0.75 }),
  ...glow(kit, "floorFire", { pos: FOE_FLOOR, life: BURN + 6, scale: 1.5, pal: [ORANGE, YELLOW, MAGENTA], aspect: 2.6, level: 0.7 }),
];
setCurves(kit.resources[kit.idx("tongues")]!, grow(1.2, 0.3, 0.6), fadeOut());

const landAt = WHIRL + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1426, 0, { vol: 115 }),
  snd(1425, 4, { ch: "SE2", pitch: -300, vol: 100 }),
  snd(1376, WHIRL, { ch: "SE2", vol: 0 }),
  snd(1425, WHIRL, { pitch: 200, vol: 120 }),
  `SwitchAudioSide SE1, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0`,
  snd(1475, landAt, { side: "D", pitch: -200, vol: 120 }),
  snd(1426, landAt, { ch: "SE2", side: "D", vol: 120 }),
  snd(1426, landAt + 12, { ch: "SE2", side: "D", pitch: -200, vol: 100 }),
)}
${arena(0, 11, 8, [18, 2, 4])}
${tint("ATTACKER", 0, 8, 6, [31, 20, 8])}
${emits(kit, user, "ATTACKER")}
${emits(kit, ["wave", "waveGlow"], "ATTACKER", "DEFENDER")}
${shake("ATTACKER", 819, WHIRL / 2 - 4)}
Wait ${WHIRL}
${tint("ATTACKER", 8, 0, 4, [31, 20, 8])}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [31, 27, 12], power: 3 })}
${shake("DEFENDER", 1229, BURN / 2 - 4)}
Wait ${BURN - 8}
${arena(11, 0, 8, [18, 2, 4])}
Wait ${AFTER + 4}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [126, 63, 605, 400, 240, 129, 381],
  references: ["reference/Burning_Jealousy_VIII.png", "reference/Burning_Jealousy_VIII_2.png", "reference/Burning_Jealousy_IX.png", "reference/Burning_Jealousy_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("rimFlames")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("pool")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("wave")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("igniteFlash")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  ground flares f${CAMERA_IN}, wave f${CAMERA_IN + WHIRL}, engulfs f${CAMERA_IN + landAt}`);
