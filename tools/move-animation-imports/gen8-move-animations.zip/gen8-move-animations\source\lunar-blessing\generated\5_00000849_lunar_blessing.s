MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1029
AudioContainer CONTINUE
PlaySound 1510, SE1, 14, 0, -200, 105, 0, 0, 0
PlaySound 1474, SE2, 14, 8, 0, 95, 0, 0, 0
PlaySound 1505, SE1, 14, 20, 300, 110, 0, 0, 0
PlaySound 1784, SE2, 14, 24, 200, 100, 0, 0, 0
PlaySound 1474, SE2, 14, 32, 300, 95, 0, 0, 0
PlaySound 1427, SE1, 14, 42, 0, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 0, 3, 5, 16
Emit 1029, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1029, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1029, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1029, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1029, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1029, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1029, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1029, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1029, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1029, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1029, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 20
ChangeSpriteColor ATTACKER, 0, 10, 0, 31, 25, 31
Wait 12
ChangeSpriteColor ATTACKER, 10, 0, 0, 31, 25, 31
Wait 10
ChangeSpriteColor ATTACKER, 0, 8, 0, 16, 31, 26
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 6, 0, 1
Wait 14
ChangeSpriteColor ATTACKER, 8, 0, 0, 16, 31, 26
ChangeBackgroundColor 4, 10, 0, 0, 3, 5, 16
Wait 14
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
