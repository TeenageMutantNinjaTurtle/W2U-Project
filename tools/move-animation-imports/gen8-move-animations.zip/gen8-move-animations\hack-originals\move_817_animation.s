MoveCamera INTERPOLATION, ATTACKER, 16, 0, 12
ToggleFreezeSprite ATTACKER, START
AudioContainer CONTINUE
PlaySound 1425, SE1, 14, 0, 0, 115, 0, 0, 0
PlaySound 1376, SE1, 14, 80, 0, 0, 0, 0, 0
AdjustSound SE1, 0, 0, -1000, 3000, 0, 70, 0, 0
AdjustSound SE1, 0, 1, 115, 0, 60, 20, 0, 0
AudioContainer SUSPEND
LoadSPA 511
Emit 511, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 511, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor ATTACKER, 0, 12, 1, 31, 0, 0
ShakeSprite ATTACKER, 2, 0, 819, 1, 1, 12
Wait 40
ChangeSpriteColor ATTACKER, 12, 0, 1, 31, 0, 0
MoveCamera INTERPOLATION, DEFENDER, 16, 0, 8
LetCMDsFinish ALL
AudioContainer CONTINUE
PlaySound 1421, SE2, 16, 0, 0, 120, 0, 0, 0
AudioContainer SUSPEND
AudioContainer CONTINUE
PlaySound 1424, SE1, 16, 10, 0, 90, 0, 0, 0
PlaySound 1475, SE2, 16, 20, 0, 120, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 13, 0, 0, 0, 0
LoadSPA 169
Emit 169, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 169, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 169, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 169, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 8
ShakeScreen VERTICAL, 1638, 0, 1, 0, 8
ToggleFreezeSprite DEFENDER, START
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -819, 2, 1, 4
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, STOP
ToggleFreezeSprite ATTACKER, STOP
ChangeBackgroundColor 4, 13, 0, 2, 0, 0, 0
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
