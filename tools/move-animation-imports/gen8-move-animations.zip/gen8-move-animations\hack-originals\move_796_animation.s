LoadBackground 30
MoveCamera INTERPOLATION, ATTACKER, 16, 0, 8
AudioContainer CONTINUE
PlaySound 1487, SE1, 14, 30, 0, 110, 0, 0, 0
AdjustSound SE1, 0, 1, 110, 0, 100, 30, 0, 0
AudioContainer SUSPEND
LoadSPA 609
LoadSPA 610
Emit 609, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 609, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 609, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 609, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 609, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 610, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 610, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
AudioContainer CONTINUE
PlaySound 1975, SE1, 14, 0, 0, 127, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 2, 0, 16, 0, 0, 0, 0
LetCMDsFinish ALL
ChangeBackgroundColor 3, 16, 0, 0, 0, 0, 0
MoveCamera INTERPOLATION, ATTACKER, 16, 0, 12
ApplyBackground OFF, 1
ApplyBackground ON, 1
ApplyBackground 2, 0
MoveBackground INTERPOLATION_DIRECT, -30, 0, 140, 1, 0
ToggleFreezeSprite ATTACKER, START
MoveCamera INTERPOLATION, DEFENDER, 58, 0, 50
AudioContainer CONTINUE
PlaySound 1424, SE1, 14, 0, -300, 120, 0, 0, 0
PlaySound 1376, SE1, 14, 100, 0, 0, 0, 0, 0
PlaySound 1962, SE2, 14, 0, 0, 100, 0, 0, 0
PlaySound 1420, SE2, 16, 50, 0, 127, 0, 0, 0
PlaySound 1420, SE1, 16, 55, 0, 127, 0, 0, 0
PlaySound 1420, SE2, 16, 60, 0, 127, 0, 0, 0
PlaySound 1420, SE1, 16, 65, 0, 127, 0, 0, 0
AdjustSound SE1, 0, 0, 0, 2000, 0, 50, 0, 0
AdjustSound SE1, 0, 1, 120, 0, 80, 20, 0, 0
AdjustSound SE2, 0, 1, 125, 0, 60, 40, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 16, 0, 50, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 16, 0, 50, 0, 0
AudioContainer SUSPEND
LoadSPA 818
Emit 818, 0, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 818, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 818, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 818, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 14
ShakeSprite DEFENDER, 2, 1229, 0, 1, 2, 8
Wait 58
ChangeBackgroundColor 3, 0, 16, 1, 0, 0, 0
LetCMDsFinish ALL
ChangeBackgroundColor 2, 16, 0, 0, 0, 0, 0
ApplyBackground OFF, 0
ApplyBackground ON, 0
ApplyBackground 2, 1
ToggleFreezeSprite ATTACKER, STOP
MoveCamera INTERPOLATION, INIT, 16, 0, 12
LetCMDsFinish ALL
ChangeBackgroundColor 3, 16, 0, 0, 0, 0, 0
TerminateMoveScript
