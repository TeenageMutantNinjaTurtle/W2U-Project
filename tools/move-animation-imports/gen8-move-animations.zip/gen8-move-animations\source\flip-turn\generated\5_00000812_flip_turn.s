MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 992
AudioContainer CONTINUE
PlaySound 1445, SE1, 14, 0, 400, 105, 0, 0, 0
PlaySound 1418, SE2, 14, 2, 500, 90, 0, 0, 0
PlaySound 1407, SE1, 14, 14, 300, 120, 0, 0, 0
PlaySound 1511, SE2, 16, 20, 300, 125, 0, 0, 0
PlaySound 1475, SE1, 16, 20, 0, 120, 0, 0, 0
PlaySound 1407, SE1, 16, 28, 600, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 0, 14, 28, 31
Emit 992, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 992, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 992, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 992, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 992, 1, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 992, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 6
ToggleSpriteVisibility ATTACKER, 3
Wait 8
MoveCamera INTERPOLATION, DEFENDER, 6, 0, 8
Wait 6
Emit 992, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 992, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 992, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 992, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 992, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 992, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 992, 2, DEFENDER, ATTACKER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 992, 5, DEFENDER, ATTACKER, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 24, 30, 31
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 24, 30, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 4
MoveCamera INTERPOLATION, INIT, 10, 0, 8
Wait 19
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 10, 0, 0, 14, 28, 31
ToggleSpriteVisibility ATTACKER, 4
LetCMDsFinish ALL
TerminateMoveScript
