import { createKit, fadeInOut, grow, T, type Rgb } from "../tools/anim-kit";
import { audio, emits, FRONT, glow, hit, impact, intro, lunge, outro, pan, ring, risers, shake, shot, snd, sparks, streaks, tint, USER_FLOOR, variants, WHITE, type Pal } from "../tools/phrases";

// Terrain Pulse (move 805) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user draws power up out of the ground: light rises round it and
//      gathers into a flare.
//   2. It fires the pulse: a string of rings of light, one behind another,
//      running to the foe.
//   3. The rings break on the foe in a burst and ripples.
// Five versions in one animation, one for each terrain, each in that
// terrain's colour - as Weather Ball has one for each weather. A script
// cannot tell which terrain is up: the battle engine picks the version by an
// index it passes (0 when it passes nothing), so whatever runs the move must
// pass the terrain. The order here: 0 none, 1 Electric, 2 Grassy, 3 Misty,
// 4 Psychic.
// The smaller ring beam and the terrain colours are Logan's direction
// (2026-10-03).

const SPA = 985;
const kit = await createKit({ workDir: import.meta.dirname, slug: "terrain-pulse", moveId: 805, spaId: SPA, donors: [228, 465, 579, 411, 298, 560] });

const CAMERA_IN = 10;
const DRAW = 24;
const TRAVEL = 8;
const RINGS = 6;
const RING_GAP = 2;
const AFTER = 24;

interface Terrain { key: string; pal: Pal; tint: [number, number, number]; pitch: number }
const TERRAINS: Terrain[] = [
  { key: "Plain", pal: [[1.0, 0.86, 0.45], [1.0, 0.98, 0.85], [1.0, 0.65, 0.2]], tint: [31, 28, 16], pitch: 0 },
  { key: "Electric", pal: [[1.0, 0.96, 0.1], [1.0, 1.0, 0.65], [0.95, 0.75, 0.0]], tint: [31, 31, 6], pitch: 300 },
  { key: "Grassy", pal: [[0.35, 0.92, 0.3], [0.82, 1.0, 0.72], [0.08, 0.65, 0.22]], tint: [12, 31, 12], pitch: -100 },
  { key: "Misty", pal: [[1.0, 0.55, 0.82], [1.0, 0.88, 0.96], [0.92, 0.3, 0.65]], tint: [31, 18, 27], pitch: 200 },
  { key: "Psychic", pal: [[0.68, 0.32, 1.0], [0.9, 0.78, 1.0], [0.45, 0.12, 0.82]], tint: [21, 10, 31], pitch: -200 },
];

function version(t: Terrain): string {
  const n = (name: string) => `${name}${t.key}`;
  const [MAIN, LIGHT, DEEP] = t.pal as [Rgb, Rgb, Rgb];
  const user = [
    ...risers(kit, n("groundLight"), { frames: DRAW, radius: 1.5, speed: 0.3, scale: 1.0, life: 9, every: 2, pal: [MAIN, WHITE, LIGHT], streak: true }),
    ...risers(kit, n("groundMotes"), { frames: DRAW, radius: 1.7, speed: 0.14, scale: 0.16, life: 14, every: 3, pal: [LIGHT, WHITE, MAIN] }),
    ...glow(kit, n("floorGlow"), { pos: [0, USER_FLOOR[1], 0.3], life: DRAW + 4, scale: 1.4, pal: [MAIN, DEEP, LIGHT], aspect: 2.6, level: 0.7 }),
    ...glow(kit, n("flare"), { pos: FRONT, at: 6, life: DRAW + RINGS * RING_GAP, scale: 0.9, pal: [LIGHT, WHITE, MAIN], tex: kit.tex(T.spiky), spin: 0.18, level: 1, scaleCurve: grow(0.3, 0.45, 1.1), alpha: fadeInOut(1, 0.12, 0.85) }),
  ];
  // The pulse: rings one behind another, seen a little from the side, with a
  // brighter one inside each.
  shot(kit, n("rings"), kit.tex(T.hoop), { from: FRONT, at: DRAW, travel: TRAVEL, scale: 0.8, pal: [MAIN, LIGHT, DEEP], count: RINGS, gap: RING_GAP, aspect: 0.55, scaleCurve: grow(0.5, 0.3, 1.05), alpha: fadeInOut(0.95, 0.1, 0.85) });
  shot(kit, n("ringCores"), kit.tex(T.ring), { from: FRONT, at: DRAW, travel: TRAVEL, scale: 0.55, pal: [LIGHT, WHITE, MAIN], count: RINGS, gap: RING_GAP, aspect: 0.55, scaleCurve: grow(0.5, 0.3, 1.05), alpha: fadeInOut(0.8, 0.1, 0.85) });
  const shots = [n("ringCores"), n("rings")];
  const foe = [
    ...impact(kit, n("burst"), { pal: [MAIN, LIGHT, DEEP], size: 1.2, rays: 7, flecks: 0 }),
    // The rings breaking on it: ripples running out, one for every other ring.
    ...ring(kit, n("ripple0"), { at: 1, scale: 0.9, pal: [LIGHT, WHITE, MAIN], to: 2.2, life: 10 }),
    ...ring(kit, n("ripple1"), { at: 1 + 2 * RING_GAP, scale: 0.9, pal: [MAIN, LIGHT, DEEP], to: 2.2, life: 10 }),
    ...ring(kit, n("ripple2"), { at: 1 + 4 * RING_GAP, scale: 0.9, pal: [LIGHT, WHITE, MAIN], to: 2.2, life: 10 }),
    ...streaks(kit, n("jags"), { radius: 0.5, speed: 0.38, count: 6, life: 10, scale: 0.8, pal: [MAIN, LIGHT, WHITE], tex: kit.tex(T.shard) }),
    ...sparks(kit, n("motes"), { at: 4, radius: 1.3, speed: 0.12, count: 3, bursts: 3, gap: 4, life: 12, scale: 0.15, pal: [LIGHT, WHITE, MAIN], fall: -0.006 }),
  ];
  const landAt = DRAW + TRAVEL;
  return `${intro(SPA, CAMERA_IN)}
${audio(
    snd(1497, 0, { pitch: 300 + t.pitch, vol: 100 }),
    snd(1474, 4, { ch: "SE2", pitch: t.pitch, vol: 85 }),
    snd(1376, DRAW, { vol: 0 }),
    snd(1510, DRAW, { ch: "SE2", pitch: 300 + t.pitch, vol: 110 }),
    snd(1407, DRAW, { pitch: -200, vol: 110 }),
    `SwitchAudioSide SE2, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0`,
    snd(1475, landAt, { side: "D", pitch: -100 + t.pitch, vol: 122 }),
  )}
${tint("ATTACKER", 0, 8, 6, t.tint)}
${emits(kit, user, "ATTACKER")}
${emits(kit, shots, "ATTACKER", "DEFENDER")}
${shake("ATTACKER", 819, DRAW / 2 - 4)}
Wait ${DRAW}
${lunge("ATTACKER", -1)}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: t.tint, power: 2 })}
${tint("ATTACKER", 8, 0, 4, t.tint)}
Wait ${AFTER}
${outro()}`;
}

const script = variants(TERRAINS.map(version));

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 381, 311],
  references: ["reference/Terrain_Pulse_VIII.png", "reference/Terrain_Pulse_VIII_2.png", "reference/Terrain_Pulse_IX_Normal.png", "reference/Terrain_Pulse_IX_Normal_2.png"],
  expectText: [".word 5 @ Count", `LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("groundLightPlain")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("ringsPlain")}, ATTACKER, DEFENDER`, `Emit ${SPA}, ${kit.idx("ringsPsychic")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("jagsGrassy")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  five versions (${TERRAINS.map((t) => t.key).join(", ")}): draws f${CAMERA_IN}, rings f${CAMERA_IN + DRAW}, first lands f${CAMERA_IN + DRAW + TRAVEL}`);
