MoveCamera INTERPOLATION, DEFENDER, 16, 0, 8
LetCMDsFinish ALL
LoadSPA 175
Emit 175, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 175, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 175, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
AudioContainer CONTINUE
PlaySound 1424, SE1, 16, 0, 0, 120, 0, 0, 0
AudioContainer SUSPEND
ToggleFreezeSprite DEFENDER, START
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 2, 1, 1
LetCMDsFinish ALL
MoveCamera INTERPOLATION, INIT, 16, 0, 8
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
