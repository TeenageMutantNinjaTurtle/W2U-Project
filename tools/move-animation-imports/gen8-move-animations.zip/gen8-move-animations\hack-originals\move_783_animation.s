MoveCamera INTERPOLATION, ATTACKER, 16, 0, 8
LetCMDsFinish ALL
LoadSPA 824
AudioContainer CONTINUE
PlaySound 1458, SE1, 14, 20, 0, 120, 0, 0, 0
PlaySound 1483, SE2, 14, 0, 0, 100, 0, 0, 0
PlaySound 1376, SE2, 14, 90, 0, 0, 0, 0, 0
PlaySound 1421, SE1, 14, 140, 0, 115, 0, 0, 0
AdjustSound SE2, 0, 0, -1000, 2000, 0, 90, 0, 0
AudioContainer SUSPEND
Emit 824, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 824, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 40
ShakeSprite ATTACKER, 2, 2px, 1px, 4, 2, 1
MoveCamera INTERPOLATION, DEFENDER, 16, 0, 8
Wait 12
AudioContainer CONTINUE
PlaySound 1505, SE1, 16, 20, 0, 120, 0, 0, 0
PlaySound 1458, SE2, 16, 20, 0, 120, 0, 0, 0
AudioContainer SUSPEND
Emit 824, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 824, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 824, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 824, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 824, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 824, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite DEFENDER, 2, 1229, 0, 1, 2, 3
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
