MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1030
AudioContainer CONTINUE
PlaySound 1418, SE1, 14, 0, 700, 90, 0, 0, 0
PlaySound 1474, SE2, 14, 4, 200, 90, 0, 0, 0
PlaySound 1474, SE2, 14, 12, 400, 90, 0, 0, 0
PlaySound 1784, SE1, 14, 22, 300, 115, 0, 0, 0
PlaySound 1509, SE2, 14, 23, 500, 100, 0, 0, 0
PlaySound 1452, SE1, 14, 34, 0, 110, 0, 0, 0
PlaySound 1427, SE2, 14, 38, 200, 105, 0, 0, 0
AudioContainer SUSPEND
Emit 1030, 14, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 15, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 16, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 17, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 11, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 12, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 13, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 18, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 19, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 20, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 21, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 22, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1030, 23, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 22
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 4, 0, 1
Wait 12
ChangeSpriteColor ATTACKER, 0, 10, 0, 31, 22, 30
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 6, 0, 1
Wait 16
ChangeSpriteColor ATTACKER, 10, 0, 0, 31, 22, 30
Wait 14
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
