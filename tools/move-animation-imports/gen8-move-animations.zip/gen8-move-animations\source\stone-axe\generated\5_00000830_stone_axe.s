MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1010
AudioContainer CONTINUE
PlaySound 1407, SE1, 14, 8, -200, 115, 0, 0, 0
PlaySound 1514, SE1, 16, 17, -300, 127, 0, 0, 0
PlaySound 1435, SE2, 16, 20, 200, 110, 0, 0, 0
PlaySound 1884, SE1, 16, 24, -600, 100, 0, 0, 0
PlaySound 1417, SE2, 16, 36, 0, 115, 0, 0, 0
PlaySound 1884, SE1, 16, 37, 0, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 7, 0, 31, 27, 10
Emit 1010, 16, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 4, 0, 1
Wait 10
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 4px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 7, 0, 0, 31, 27, 10
MoveCamera INTERPOLATION, DEFENDER, 7, 0, 8
Wait 7
Emit 1010, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1010, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1010, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1010, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1010, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1010, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1010, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1010, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1010, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1010, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1010, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1010, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1010, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1010, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1010, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1010, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 3
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 31, 29, 16
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 31, 29, 16
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 0
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 6
ShakeSprite DEFENDER, 2, 410, 0, 2, 1, 6
Wait 12
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 3
Wait 34
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
