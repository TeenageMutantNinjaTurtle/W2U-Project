import { createKit, fadeInOut, fadeOut, grow, setCurves, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FOE_FLOOR, glow, hit, impact, intro, outro, pan, ring, shake, snd, sparks, streaks, tint, USER_FLOOR, WHITE, zaps, type Pal } from "../tools/phrases";

// Overdrive (move 786) - from the Bulbapedia stills (reference/sheet.png).
//   1. The arena darkens. The user strums: a pool of white light on the
//      ground with yellow and cyan shards spraying out of it in a ring, cyan
//      lightning crackling, an arc of yellow sound sweeping over it.
//   2. Round the foe, columns of stacked bars - a wall of sound in yellow,
//      cyan and white - leap up and pulse, rings of sound popping on it.
// The bars are drawn (generated/texture-bars.png). The lightning is Thunder's.

const SPA = 966;
const kit = await createKit({ workDir: import.meta.dirname, slug: "overdrive", moveId: 786, spaId: SPA, donors: [257, 228, 465, 579, 411, 298, 560] });

const CAMERA_IN = 10;
const STRUM = 26;
const PAN = 10;
const WALL = 30; // the wall of sound round the foe
const AFTER = 12;

const YELLOW: Rgb = [1.0, 0.92, 0.25];
const CYAN: Rgb = [0.4, 0.95, 1.0];
const PALE: Rgb = [0.95, 1.0, 0.9];
const LIME: Rgb = [0.8, 1.0, 0.3];
const SOUND: Pal = [YELLOW, CYAN, WHITE];

// --- the drawn column of bars: five rounded blocks stacked, a white mask to be tinted ---
const barsTex = await kit.drawn("bars", 16, 32, "a5i3", (x, y) => {
  const row = Math.floor(y / 6.4), within = y - row * 6.4;
  if (within > 5 || x < 2 || x > 13) return undefined;
  const corner = (x === 2 || x === 13) && (within < 1 || within > 4);
  if (corner) return undefined;
  return [255, 255, 255, row === 0 ? 150 : 255]; // the top block fainter, as a level meter's peak
});

// --- 1. the strum ---
const user = [
  ...glow(kit, "pool", { pos: [0, USER_FLOOR[1], 0.3], life: STRUM + 4, scale: 1.3, pal: [PALE, WHITE, CYAN], aspect: 2.6, level: 0.85 }),
  ...ring(kit, "poolRing", { pos: [0, USER_FLOOR[1], 0.35], at: 2, life: STRUM, scale: 1.3, pal: [CYAN, WHITE, YELLOW], tex: kit.tex(T.ring), aspect: 2.6, to: 1.2, level: 0.8 }),
  ...streaks(kit, "shards", { pos: [0, USER_FLOOR[1] + 0.2, 0.3], radius: 1.4, speed: 0.3, count: 5, bursts: STRUM / 4, gap: 4, life: 9, scale: 0.6, pal: SOUND, tex: kit.tex(T.shard), flat: true, lift: 0.06 }),
  ...zaps(kit, "crackle", { pos: [0, 0.6, 0.3], radius: 2.0, count: 1, bursts: STRUM / 3, gap: 3, life: 6, scale: 0.8, pal: [CYAN, WHITE, YELLOW] }),
  ...ring(kit, "soundArc", { pos: [0, 0.3, 0.1], at: 6, life: 12, scale: 1.4, pal: [LIME, YELLOW, YELLOW], to: 2.3 }),
  ...ring(kit, "soundArc2", { pos: [0, 0.3, 0.1], at: 16, life: 12, scale: 1.4, pal: [YELLOW, WHITE, LIME], to: 2.3 }),
];

// --- 2. the wall of sound ---
const bars = kit.spray([333, 1], barsTex, [0, FOE_FLOOR[1] + 1.1, 0.8], { radius: 2.3, speed: 0, count: 7, bursts: 3, gap: 9, life: 11, scale: 1.1, shape: "circle" });
bars.emissionAxis = 1; // a ring standing round the foe
bars.variance.lifeTime = 0;
bars.aspectRatio = 0.5;
setCurves(bars, { start: 0.3, mid: 1.15, end: 0.6, curveIn: 0.25, curveOut: 0.6 }, fadeInOut(0.95, 0.1, 0.7));
kit.prism(bars, SOUND);
kit.add("bars", bars);
const foe = [
  ...Array.from({ length: 3 }, (_, i) => ring(kit, `pop${i}`, { pos: [i === 1 ? 0.9 : -0.7 + i * 0.3, 0.5 + (i % 2) * 0.6, 1.0], at: i * 9 + 2, scale: 0.9, pal: i % 2 ? [YELLOW, WHITE, LIME] : [WHITE, WHITE, CYAN], to: 2.0, life: 10 })).flat(),
  "bars",
  ...impact(kit, "blare", { at: 2, pal: [YELLOW, PALE, CYAN], size: 1.25, rays: 8, flecks: 0 }),
  ...zaps(kit, "shock", { at: 2, radius: 1.5, count: 2, bursts: 7, gap: 4, life: 6, scale: 0.8, pal: [CYAN, WHITE, YELLOW] }),
  ...glow(kit, "floor", { pos: [0, FOE_FLOOR[1], 0.8], life: WALL, scale: 1.5, pal: [YELLOW, CYAN, PALE], aspect: 2.6, level: 0.6 }),
  ...sparks(kit, "notes", { at: 4, radius: 1.8, speed: 0.1, count: 2, bursts: 6, gap: 4, life: 12, scale: 0.14, pal: SOUND, fall: -0.008 }),
];

const blareAt = STRUM + PAN + 2;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1869, 0, { pitch: -600, vol: 100 }),
  snd(1458, 4, { ch: "SE2", vol: 105 }),
  snd(1869, 12, { pitch: -300, vol: 105 }),
  snd(1522, blareAt, { ch: "SE2", side: "D", vol: 120 }),
  snd(1869, blareAt, { side: "D", pitch: -800, vol: 127 }),
  snd(1475, blareAt, { ch: "SE2", side: "D", pitch: 200, vol: 115 }),
  snd(1458, blareAt + 12, { side: "D", vol: 110 }),
)}
${arena(0, 11, 6, [2, 3, 8])}
${tint("ATTACKER", 0, 7, 4, [28, 31, 12])}
${emits(kit, user, "ATTACKER")}
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 4, 0, 1
${shake("ATTACKER", 819, STRUM / 2 - 2)}
Wait ${STRUM}
${tint("ATTACKER", 7, 0, 4, [28, 31, 12])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
Wait 2
${hit({ rgb: [30, 31, 14], power: 2 })}
${shake("DEFENDER", 1229, WALL / 2 - 4)}
Wait ${WALL - 10}
${arena(11, 0, 8, [2, 3, 8])}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [87, 63, 605, 400, 240, 129, 381],
  references: ["reference/Overdrive_VIII.png", "reference/Overdrive_VIII_2.png", "reference/Overdrive_IX.png", "reference/Overdrive_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("shards")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("bars")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  strum f${CAMERA_IN}, wall of sound f${CAMERA_IN + STRUM + PAN}-${CAMERA_IN + STRUM + PAN + WALL}`);
