MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 962
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, 0, 105, 0, 0, 0
PlaySound 1435, SE2, 14, 8, -400, 110, 0, 0, 0
PlaySound 1376, SE1, 14, 36, 0, 0, 0, 0, 0
PlaySound 1688, SE2, 14, 36, 200, 125, 0, 0, 0
PlaySound 1475, SE1, 16, 42, -400, 127, 0, 0, 0
PlaySound 1413, SE2, 16, 42, -300, 127, 0, 0, 0
PlaySound 1505, SE1, 16, 44, 0, 120, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 13, 0, 9, 0, 1
ChangeSpriteColor ATTACKER, 0, 11, 0, 31, 8, 6
Emit 962, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 962, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 962, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 962, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 962, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 962, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 10
Wait 28
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 8, 0, 1
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 4
Wait 8
ToggleSpriteVisibility ATTACKER, 3
MoveCamera INTERPOLATION, DEFENDER, 6, 0, 8
Wait 6
Emit 962, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 962, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 962, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 962, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 962, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 962, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 962, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeBackgroundColor 4, 15, 15, 0, 31, 28, 22
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 26, 20
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 26, 20
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 15, 13, 1, 9, 0, 1
Wait 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 8
ChangeBackgroundColor 4, 13, 0, 0, 9, 0, 1
Wait 20
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 0, 0, 0, 31, 8, 6
ToggleSpriteVisibility ATTACKER, 4
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
