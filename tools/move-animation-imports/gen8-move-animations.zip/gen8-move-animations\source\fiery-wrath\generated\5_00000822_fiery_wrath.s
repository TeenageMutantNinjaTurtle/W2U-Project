MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1002
AudioContainer CONTINUE
PlaySound 1426, SE1, 14, 0, -500, 110, 0, 0, 0
PlaySound 1425, SE2, 14, 4, -600, 100, 0, 0, 0
PlaySound 1376, SE2, 14, 28, 0, 0, 0, 0, 0
PlaySound 1475, SE1, 16, 38, -500, 125, 0, 0, 0
PlaySound 1426, SE2, 16, 38, -700, 125, 0, 0, 0
PlaySound 1426, SE2, 16, 52, -500, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 13, 0, 2, 0, 4
ChangeSpriteColor ATTACKER, 0, 9, 0, 28, 4, 12
Emit 1002, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1002, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1002, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1002, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 10
Wait 28
ChangeSpriteColor ATTACKER, 9, 0, 0, 28, 4, 12
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
Emit 1002, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1002, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1002, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1002, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1002, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1002, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1002, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 8, 16
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 8, 16
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 11
Wait 22
ChangeBackgroundColor 4, 13, 0, 0, 2, 0, 4
Wait 18
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
