#!/usr/bin/env bash
# usage: tools/fetch-gen8-refs.sh [moveId...]      (no ids: every move in gen8-refs.txt)
# Downloads each move's Bulbapedia stills (640px thumbnails) into
# work/<slug>/reference/ and tiles them into reference/sheet.png.
W="${ANIMATION_WORK_DIR:-work}"
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"
while IFS= read -r line; do
  [ -z "$line" ] && continue
  id=${line%% *}; rest=${line#* }; name=${rest%%:*}; files=${rest#*:}
  if [ $# -gt 0 ]; then case " $* " in *" $id "*) ;; *) continue ;; esac; fi
  slug=$(echo "$name" | tr 'A-Z_' 'a-z-')
  D="$W/$slug/reference"; mkdir -p "$D"
  got=()
  IFS=',' read -ra items <<< "$files"
  for item in "${items[@]}"; do
    hash=${item%%/*}; file=${item#*/}
    out="$D/$(printf '%b' "${file//%/\\x}")"
    if [ ! -s "$out" ]; then
      code=$(curl -s -A "$UA" -H "Referer: https://bulbapedia.bulbagarden.net/" -o "$out" -w "%{http_code}" --max-time 60 "https://archives.bulbagarden.net/media/upload/thumb/${hash:0:1}/$hash/$file/640px-$file")
      if [ "$code" != 200 ]; then
        # Small originals have no 640px thumbnail; take the original.
        code=$(curl -s -A "$UA" -H "Referer: https://bulbapedia.bulbagarden.net/" -o "$out" -w "%{http_code}" --max-time 60 "https://archives.bulbagarden.net/media/upload/${hash:0:1}/$hash/$file")
      fi
      [ "$code" = 200 ] || { echo "$id $file: HTTP $code"; rm -f "$out"; continue; }
      sleep 0.3
    fi
    got+=("$out")
  done
  echo "$id $slug: ${#got[@]} stills"
done < "$W/tools/gen8-refs.txt"
