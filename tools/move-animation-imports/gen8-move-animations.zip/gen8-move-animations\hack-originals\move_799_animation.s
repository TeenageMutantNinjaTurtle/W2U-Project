ToggleFreezeSprite ATTACKER, START
AudioContainer CONTINUE
PlaySound 1411, SE1, 14, 0, 0, 120, 0, 0, 0
PlaySound 1376, SE1, 14, 60, 0, 0, 0, 0, 0
AdjustSound SE1, 0, 1, 120, 0, 30, 30, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 16, 0, 30, 0, 0
AudioContainer SUSPEND
AudioContainer CONTINUE
PlaySound 1420, SE2, 16, 20, 0, 120, 0, 0, 0
PlaySound 1420, SE2, 16, 25, 0, 120, 0, 0, 0
PlaySound 1420, SE2, 16, 30, 0, 120, 0, 0, 0
PlaySound 1420, SE2, 16, 35, 0, 120, 0, 0, 0
AudioContainer SUSPEND
LoadSPA 819
Emit 819, 1, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 819, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 14
ToggleFreezeSprite DEFENDER, START
ShakeSprite DEFENDER, 2, 1229, 0, 1, 2, 3
LetCMDsFinish ALL
ToggleFreezeSprite ATTACKER, STOP
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
