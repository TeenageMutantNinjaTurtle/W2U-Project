import { aimed, createKit, fadeOut, grow, hold, paint, setCurves, spin, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, FOE, glow, hit, impact, intro, outro, pan, ring, snd, sparks, streaks, tint, USER, WHITE, type Pal } from "../tools/phrases";

// Flip Turn (move 812) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user wraps itself in a ball of bright water, bubbles inside it.
//   2. The ball shoots into the foe and bursts in a great splash.
//   3. It flips away and shoots back the way it came (the user then switches
//      out - the engine's part).
// The user is hidden while it is the ball (ToggleSpriteVisibility 3/4).
// The water orb and splash ring are Aqua Jet's.

const SPA = 992;
const kit = await createKit({ workDir: import.meta.dirname, slug: "flip-turn", moveId: 812, spaId: SPA, donors: [632, 228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 10;
const WRAP = 14;
const TRAVEL = 6;
const HIT_HOLD = 8; // splash before it flips back
const RETURN = 7;
const AFTER = 12;

const CYAN: Rgb = [0.45, 0.9, 1.0];
const PALE: Rgb = [0.88, 0.97, 1.0];
const BLUE: Rgb = [0.2, 0.55, 1.0];
const PAL: Pal = [CYAN, PALE, BLUE];
const BALL: Vec3 = [0, 0.3, 0.3];
const orbTex = kit.tex(632, 0);

// The ball's two layers: the water orb, and a cyan glow round it.
function ball(name: string, tex: number, scale: number, colours: [Rgb, Rgb, Rgb], level: number, rate: number): { form: string; go: string; back: string } {
  const make = (life: number, at: number) => {
    const r = kit.parked(tex, BALL, scale, life);
    r.startDelayFrames = at;
    if (rate) spin(r, rate);
    paint(r, colours[0], colours[1], colours[2]);
    return r;
  };
  const form = make(WRAP + 1, 0);
  setCurves(form, grow(0.3, 0.5, 1.05), { start: 0, mid: level, end: level, curveIn: 0.3, curveOut: 1 });
  kit.add(`${name}Form`, form);
  const go = make(TRAVEL + 1, WRAP);
  aimed(go, 16 / TRAVEL, TRAVEL + 1);
  go.airResistance = 1.0;
  setCurves(go, hold(1.05), hold(level));
  kit.add(`${name}Go`, go);
  // The way back: emitted on the foe, aimed at the user's side.
  const back = make(RETURN + 1, HIT_HOLD);
  back.emitterBasePos = [0, 0.3, 0.9];
  aimed(back, 16 / RETURN, RETURN + 1);
  back.airResistance = 1.0;
  setCurves(back, hold(1.0), hold(level));
  kit.add(`${name}Back`, back);
  return { form: `${name}Form`, go: `${name}Go`, back: `${name}Back` };
}
const orb = ball("orb", orbTex, 1.6, [WHITE, WHITE, WHITE], 0.95, 0.25);
const halo = ball("halo", kit.tex(T.fuzzyGlow), 2.3, [CYAN, PALE, BLUE], 0.7, 0);

const user = [
  orb.form, halo.form,
  ...sparks(kit, "bubbles", { pos: USER, radius: 1.5, speed: 0.04, count: 2, bursts: WRAP / 3, gap: 3, life: 10, scale: 0.2, pal: [PALE, WHITE, CYAN], shape: "ball", tex: kit.tex(T.ring) }),
  ...streaks(kit, "inward", { pos: USER, radius: 2.2, speed: -0.24, count: 3, bursts: 3, gap: 3, life: 7, scale: 0.6, pal: [PALE, WHITE, CYAN] }),
];
const foe = [
  ...impact(kit, "splash", { pal: PAL, size: 1.5, rays: 0, flecks: 0 }),
  ...ring(kit, "splashRing", { scale: 1.6, pal: [PALE, WHITE, CYAN], tex: kit.tex(632, 2), to: 2.0, life: 11 }),
  ...streaks(kit, "spray", { radius: 0.5, speed: 0.45, count: 9, life: 11, scale: 0.85, pal: [BLUE, PALE, CYAN], tex: kit.tex(T.spike) }),
  ...sparks(kit, "droplets", { at: 1, radius: 0.7, speed: 0.32, count: 8, life: 16, scale: 0.14, pal: [PALE, WHITE, CYAN], fall: 0.012, twinkle: false }),
  ...sparks(kit, "orbs", { radius: 0.6, speed: 0.24, count: 5, life: 16, scale: 0.26, pal: [WHITE, WHITE, WHITE], fall: 0.014, tex: orbTex, twinkle: false }),
];
setCurves(kit.resources[kit.idx("spray")]!, grow(1.1, 0.3, 0.6), fadeOut());

const hitAt = WRAP + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1445, 0, { pitch: 400, vol: 105 }),
  snd(1418, 2, { ch: "SE2", pitch: 500, vol: 90 }),
  snd(1407, WRAP, { pitch: 300, vol: 120 }),
  snd(1511, hitAt, { ch: "SE2", side: "D", pitch: 300, vol: 125 }),
  snd(1475, hitAt, { side: "D", vol: 120 }),
  snd(1407, hitAt + HIT_HOLD, { side: "D", pitch: 600, vol: 110 }),
)}
${tint("ATTACKER", 0, 10, 4, [14, 28, 31])}
${emits(kit, user, "ATTACKER")}
${emits(kit, [orb.go, halo.go], "ATTACKER", "DEFENDER")}
Wait 6
ToggleSpriteVisibility ATTACKER, 3
Wait ${WRAP - 6}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${emits(kit, [orb.back, halo.back], "DEFENDER", "ATTACKER")}
${hit({ rgb: [24, 30, 31], power: 2 })}
Wait ${HIT_HOLD - 4}
${pan("INIT", RETURN + 3)}
Wait ${RETURN + AFTER}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
${tint("ATTACKER", 10, 0, 4, [14, 28, 31])}
ToggleSpriteVisibility ATTACKER, 4
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [453, 63, 605, 400, 240, 153, 129],
  references: ["reference/Flip_Turn_VIII.png", "reference/Flip_Turn_VIII_2.png", "reference/Flip_Turn_IX.png", "reference/Flip_Turn_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("orbForm")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("orbGo")}, ATTACKER, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 3", "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("orbBack")}, DEFENDER, ATTACKER`, "ToggleSpriteVisibility ATTACKER, 4", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  wraps f${CAMERA_IN}, shoots f${CAMERA_IN + WRAP}, hits f${CAMERA_IN + hitAt}, flips back f${CAMERA_IN + hitAt + HIT_HOLD}`);
