import { createKit, deg, fadeOut, grow, hold, paint, setCurves, spin, T, type Rgb } from "../tools/anim-kit";
import { audio, emits, FOE, glow, hit, impact, intro, lunge, outro, pan, slash, snd, sparks, streaks, tint, WHITE, zaps, type Pal } from "../tools/phrases";

// Breaking Swipe (move 784) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user whips its tail round in a wide, flat sweep: bands of pink,
//      magenta and violet light trailing the tail.
//   2. The sweep comes straight across the foe, level, from the user's side:
//      three crescents of the same colours one behind another with a line of
//      light through them, bursting white and violet, small red sparks
//      crackling off it.
// Psycho Cut's wide blade arc is the sweep round the user; its crescent,
// turned to lead with its curved edge, is the cut across the foe. The level
// cut (in place of an arc over the top of the foe) is Logan's direction,
// 2026-10-03.

const SPA = 964;
const kit = await createKit({ workDir: import.meta.dirname, slug: "breaking-swipe", moveId: 784, spaId: SPA, donors: [257, 228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const WINDUP = 10;
const SWEEP = 8; // the tail comes round
const PAN = 8;
const AFTER = 24;

const MAGENTA: Rgb = [1.0, 0.3, 0.75];
const PINK: Rgb = [1.0, 0.65, 0.9];
const VIOLET: Rgb = [0.6, 0.35, 1.0];
const PALE: Rgb = [0.95, 0.88, 1.0];
const RED: Rgb = [1.0, 0.2, 0.25];
const PAL: Pal = [VIOLET, PALE, MAGENTA];

// A band of the sweep: Psycho Cut's blade arc lying flat, swelling outward as the tail comes round.
function band(name: string, pos: [number, number, number], scale: number, at: number, life: number, colours: [Rgb, Rgb, Rgb], angle: number): string {
  const r = kit.parked(kit.tex(T.bladeArc), pos, scale, life);
  r.startDelayFrames = at;
  r.aspectRatio = 2.2;
  spin(r, 0, 0, deg(angle));
  setCurves(r, grow(0.4, 0.4, 1.25), fadeOut(0.95, 0.45));
  paint(r, colours[0], colours[1], colours[2]);
  kit.add(name, r);
  return name;
}

const user = [
  band("sweepInner", [0, 0.1, 0.5], 1.0, WINDUP, SWEEP + 3, [PALE, WHITE, PINK], 0),
  band("sweepMid", [0, 0.0, 0.45], 1.35, WINDUP + 1, SWEEP + 3, [MAGENTA, PINK, VIOLET], 4),
  band("sweepOuter", [0, -0.1, 0.4], 1.7, WINDUP + 2, SWEEP + 3, [VIOLET, MAGENTA, [0.35, 0.15, 0.75]], -4),
  ...streaks(kit, "sweepLines", { pos: [0, 0.0, 0.4], at: WINDUP, radius: 1.6, speed: 0.5, count: 4, bursts: 3, gap: 2, life: 7, scale: 0.9, pal: [PINK, WHITE, MAGENTA], flat: true }),
  ...glow(kit, "ready", { life: WINDUP + SWEEP, scale: 2.4, pal: PAL, level: 0.5 }),
];

// The cut across the foe: level, left to right. The crescent is drawn in the
// left of its texture; turned half round it leads with its curve and sits to
// the right of its quad's middle.
const CROSS = 6; // frames to cross the foe
const CUT_FROM = -2.4;
const CRESCENT_SITS = 0.9;
function crescent(name: string, at: number, scale: number, level: number, colours: [Rgb, Rgb, Rgb]): string {
  const r = kit.parked(kit.tex(T.crescent), [CUT_FROM - CRESCENT_SITS, 0.3, 1.0], scale, CROSS + 2);
  r.startDelayFrames = at;
  spin(r, 0, 0, deg(180));
  Object.assign(r, { axis: [1, 0, 0], initVelAxisAmplifier: (-2 * CUT_FROM) / CROSS, airResistance: 1.0 });
  setCurves(r, hold(1), { start: level * 0.6, mid: level, end: 0, curveIn: 0.15, curveOut: 0.7 });
  paint(r, colours[0], colours[1], colours[2]);
  kit.add(name, r);
  return name;
}
const STRIKE = Math.floor(CROSS / 2);
const foe = [
  ...slash(kit, "cut", { angle: 0, scale: 4.2, pal: [PALE, WHITE, PINK], life: 8, aspect: 0.12 }),
  crescent("crossInner", 0, 1.5, 1, [PALE, WHITE, PINK]),
  crescent("crossMid", 1, 1.75, 0.9, [MAGENTA, PINK, VIOLET]),
  crescent("crossOuter", 2, 2.0, 0.75, [VIOLET, MAGENTA, [0.35, 0.15, 0.75]]),
  ...streaks(kit, "crossLines", { pos: [0, 0.3, 0.9], radius: 1.3, speed: 0.5, count: 4, bursts: 2, gap: 2, life: 7, scale: 0.9, pal: [PINK, WHITE, MAGENTA], flat: true }),
  ...impact(kit, "burst", { at: STRIKE, pal: [VIOLET, PALE, MAGENTA], size: 1.3, rays: 9, flecks: 6 }),
  ...zaps(kit, "redSparks", { at: 3, radius: 1.4, count: 2, bursts: 3, gap: 3, life: 6, scale: 0.45, pal: [RED, [1.0, 0.5, 0.5], RED], shape: "circle" }),
  ...sparks(kit, "shimmer", { at: 4, radius: 1.2, speed: 0.1, count: 3, bursts: 3, gap: 4, life: 12, scale: 0.13, pal: [PINK, WHITE, VIOLET] }),
];

const hitAt = WINDUP + SWEEP + PAN;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1425, WINDUP - 2, { pitch: 300, vol: 115 }),
  snd(1438, WINDUP + SWEEP - 2, { ch: "SE2", pitch: 500, vol: 120 }),
  snd(1423, hitAt, { side: "D", vol: 127 }),
  snd(1475, hitAt + STRIKE, { ch: "SE2", side: "D", vol: 115 }),
)}
${tint("ATTACKER", 0, 8, 4, [24, 12, 31])}
${emits(kit, user, "ATTACKER")}
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, ${WINDUP - 2}, 0, 1
Wait ${WINDUP}
${lunge("ATTACKER", 3)}
Wait ${SWEEP}
${tint("ATTACKER", 8, 0, 4, [24, 12, 31])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
Wait ${STRIKE}
${hit({ rgb: [28, 22, 31], power: 2 })}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [427, 87, 63, 605, 400, 240, 129],
  references: ["reference/Breaking_Swipe_VIII.png", "reference/Breaking_Swipe_IX.png", "reference/Breaking_Swipe_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("sweepMid")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("cut")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("crossInner")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  windup f${CAMERA_IN}, sweep f${CAMERA_IN + WINDUP}, cut crosses f${CAMERA_IN + hitAt}-${CAMERA_IN + hitAt + CROSS}`);
