import { createKit, deg, hold, paint, setCurves, spin, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FOE_FLOOR, glow, hit, impact, intro, lunge, outro, pan, shake, snd, sparks, squash, streaks, tint, USER, WHITE } from "../tools/phrases";

// Ceaseless Edge (move 845) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user readies its blade, a dark red light on it, the edge glinting.
//   2. It cuts the foe five times, one cut after another, each a black
//      stroke edged in red with a flash of white as it lands - and the five
//      strokes make a star over it.
//   3. The star bursts red, and splinters of shell scatter over the ground
//      round the foe and lie there glinting.
// The star is Logan's direction (2026-10-03). Laying the spikes is the engine's.

const SPA = 1025;
const kit = await createKit({ workDir: import.meta.dirname, slug: "ceaseless-edge", moveId: 845, spaId: SPA, donors: [228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 10;
const READY = 14;
const PAN = 7;
const CUTS = 5;
const CUT_GAP = 5; // one stroke at a time
const BURST = CUTS * CUT_GAP + 2; // the finished star holds a moment, then bursts
const FADE = 8; // the strokes die away under the burst
const LIE = 22; // the splinters on the ground
const AFTER = 8;

const RED: Rgb = [1.0, 0.2, 0.25];
const PINK: Rgb = [1.0, 0.65, 0.7];
const CRIMSON: Rgb = [0.6, 0.05, 0.12];
const INK: Rgb = [0.04, 0.02, 0.04];
const SHELL: Rgb = [0.95, 0.92, 0.85];

// --- 1. the ready ---
const user = [
  ...sparks(kit, "edgeGlint", { pos: [0.7, 1.0, -0.2], at: READY - 8, radius: 0, speed: 0, count: 1, life: 8, scale: 0.8, pal: [WHITE, WHITE, PINK], shape: "ball", tex: kit.tex(T.star4Big) }),
  ...streaks(kit, "intent", { pos: USER, radius: 2.2, speed: -0.22, count: 3, bursts: 3, gap: 4, life: 7, scale: 0.6, pal: [RED, PINK, CRIMSON] }),
  ...glow(kit, "menace", { pos: USER, life: READY + 4, scale: 2.7, pal: [CRIMSON, INK, RED], level: 0.75 }),
];

// --- 2. the star: five strokes, drawn point to point without lifting the blade ---
const STAR_CENTRE: [number, number] = [0, 0.35];
const STAR_RADIUS = 1.9;
const point = (k: number): [number, number] => [STAR_CENTRE[0] + STAR_RADIUS * Math.sin((k * 2 * Math.PI) / 5), STAR_CENTRE[1] + STAR_RADIUS * Math.cos((k * 2 * Math.PI) / 5)];
const ORDER = [0, 2, 4, 1, 3, 0]; // top, lower right, upper left, upper right, lower left, top
const flashes: string[] = [], blades: string[] = [], edges: string[] = [];
for (let i = 0; i < CUTS; i++) {
  const a = point(ORDER[i]!), b = point(ORDER[i + 1]!);
  const middle: Vec3 = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, 1.0];
  const half = Math.hypot(b[0] - a[0], b[1] - a[1]) / 2;
  const tilt = (Math.atan2(b[1] - a[1], b[0] - a[0]) * 180) / Math.PI;
  const stays = BURST + FADE - i * CUT_GAP;
  for (const [list, name, aspect, length, life, colours] of [
    [flashes, "flash", 0.12, 1.12, 5, [WHITE, WHITE, PINK]],
    [blades, "blade", 0.2, 1.0, stays, [INK, INK, CRIMSON]],
    [edges, "edge", 0.4, 1.06, stays, [RED, PINK, CRIMSON]],
  ] as const) {
    const r = kit.parked(kit.tex(T.streak), middle, half * length, life);
    r.startDelayFrames = i * CUT_GAP;
    r.aspectRatio = aspect;
    spin(r, 0, 0, deg(90 + tilt)); // the streak texture is a vertical line
    // The stroke opens out from its middle in a couple of frames, then stays.
    setCurves(r, { start: 0.15, mid: 1.04, end: 1, curveIn: Math.min(0.5, 2.5 / life), curveOut: 0.9 }, life <= 5 ? { start: 1, mid: 1, end: 0, curveIn: 0, curveOut: 0.4 } : { start: 1, mid: 1, end: 0, curveIn: 0, curveOut: 1 - FADE / life });
    paint(r, colours[0] as Rgb, colours[1] as Rgb, colours[2] as Rgb);
    kit.add(`${name}${i}`, r);
    (list as string[]).push(`${name}${i}`);
  }
}

const lying: string[] = [];
for (const [i, [x, z, tilt]] of ([[-1.9, 0.9, 20], [-0.9, 0.5, -30], [0.2, 0.4, 10], [1.2, 0.6, -15], [2.0, 0.95, 35]] as const).entries()) {
  const r = kit.parked(kit.tex(T.shard), [x, FOE_FLOOR[1] + 0.15, z], 0.32, LIE - i);
  r.startDelayFrames = BURST + 10 + i;
  spin(r, 0, 0, deg(tilt));
  setCurves(r, hold(1), { start: 0, mid: 1, end: 0, curveIn: 0.15, curveOut: 0.8 });
  paint(r, SHELL, WHITE, PINK);
  kit.add(`splinter${i}`, r);
  lying.push(`splinter${i}`);
}
const foe = [
  ...impact(kit, "burst", { pos: [STAR_CENTRE[0], STAR_CENTRE[1], 0.9], at: BURST, pal: [RED, PINK, CRIMSON], size: 1.7, rays: 8, flecks: 0 }),
  ...flashes,
  ...blades,
  ...edges,
  ...streaks(kit, "crimson", { pos: [STAR_CENTRE[0], STAR_CENTRE[1], 0.9], at: 1, radius: 0.5, speed: 0.4, count: 3, bursts: CUTS, gap: CUT_GAP, life: 8, scale: 0.9, pal: [RED, PINK, CRIMSON] }),
  // --- 3. the splinters: thrown out, then lying on the ground ---
  ...sparks(kit, "thrown", { at: BURST, radius: 0.5, speed: 0.26, count: 7, life: 12, scale: 0.2, pal: [SHELL, WHITE, PINK], fall: 0.024, tex: kit.tex(T.shard), twinkle: false, spin: 0.3 }),
  ...glow(kit, "wound", { pos: FOE, life: BURST + 14, scale: 3.0, pal: [RED, CRIMSON, PINK], level: 0.5 }),
  ...lying,
  ...sparks(kit, "groundGlints", { pos: FOE_FLOOR, at: BURST + 12, radius: 2.0, speed: 0, count: 1, bursts: 4, gap: 4, life: 7, scale: 0.26, pal: [WHITE, PINK, WHITE], shape: "circle", tex: kit.tex(T.sparkle4) }),
];

const cutAt = READY + PAN;
// Each stroke is a red flash and a jolt; the burst is the heavy hit. (No squash
// on the strokes: they come faster than a squash can settle, and overlapping
// squashes add up until the foe is flattened out of sight.)
const strokes = Array.from({ length: CUTS }, (_, i) => [
  ...(i === 0 ? ["ToggleFreezeSprite DEFENDER, START"] : []),
  tint("DEFENDER", 0, 10, 0, [31, 10, 12]),
  shake("DEFENDER", 1229, 3),
  "Wait 1",
  tint("DEFENDER", 10, 0, 4, [31, 10, 12]),
  `Wait ${CUT_GAP - 1}`,
].join("\n")).join("\n");
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1434, 0, { pitch: 200, vol: 105 }),
  snd(1651, READY - 8, { ch: "SE2", pitch: 300, vol: 105 }),
  snd(1407, READY - 1, { pitch: 300, vol: 115 }),
  ...Array.from({ length: CUTS }, (_, i) => snd(1514, cutAt + i * CUT_GAP, { ch: i % 2 ? "SE2" : "SE1", side: "D", pitch: -300 + i * 150, vol: 125 })),
  snd(1475, cutAt + BURST, { side: "D", pitch: 100, vol: 125 }),
  snd(1423, cutAt + BURST, { ch: "SE2", side: "D", pitch: -200, vol: 120 }),
  snd(1435, cutAt + BURST + 10, { ch: "SE2", side: "D", pitch: 700, vol: 95 }),
)}
${arena(0, 8, 8, [8, 1, 3])}
${tint("ATTACKER", 0, 9, 6, [20, 3, 6])}
${emits(kit, user, "ATTACKER")}
${squash("ATTACKER", -819, 819, READY - 4)}
Wait ${READY}
${lunge("ATTACKER", 6)}
${tint("ATTACKER", 9, 0, 5, [20, 3, 6])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
${strokes}
Wait ${BURST - CUTS * CUT_GAP}
${hit({ rgb: [31, 16, 18], power: 3, freeze: false })}
Wait 6
${arena(8, 0, 10, [8, 1, 3])}
Wait ${10 + LIE - 6 - 6 + AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [427, 400, 63, 605, 240, 153, 129],
  references: ["reference/Ceaseless_Edge_LA.png", "reference/Ceaseless_Edge_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("menace")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("blade0")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("blade4")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("splinter4")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  ready f${CAMERA_IN}, strokes f${CAMERA_IN + cutAt} then every ${CUT_GAP}, star whole f${CAMERA_IN + cutAt + (CUTS - 1) * CUT_GAP + 3}, burst f${CAMERA_IN + cutAt + BURST}, splinters lie f${CAMERA_IN + cutAt + BURST + 10}-${CAMERA_IN + cutAt + BURST + 10 + LIE}`);
