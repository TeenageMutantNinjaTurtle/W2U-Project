import { createKit, grow, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FRONT, gather, glow, hit, impact, intro, lunge, outro, pan, shake, snd, sparks, streaks, tint, WHITE, zaps, type Pal } from "../tools/phrases";

// Bolt Beak (move 754) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user's beak blazes pale yellow with electricity crackling off it,
//      speed lines streaking past as it drives forward.
//   2. It stabs the foe: a big jagged yellow burst with forks of lightning.
// The crackling arcs are Thunder's.

const SPA = 952;
const kit = await createKit({ workDir: import.meta.dirname, slug: "bolt-beak", moveId: 754, spaId: SPA, donors: [257, 228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const CHARGE = 18;
const DASH = 7;
const AFTER = 24;

const YELLOW: Rgb = [1.0, 0.92, 0.25];
const PALE: Rgb = [1.0, 0.98, 0.72];
const GOLD: Rgb = [1.0, 0.72, 0.15];
const ICE: Rgb = [0.75, 0.95, 1.0];
const PAL: Pal = [YELLOW, PALE, GOLD];

const user = [
  ...gather(kit, "charge", { pos: FRONT, frames: CHARGE, pal: PAL, radius: 2.2, scale: 1.6 }),
  ...glow(kit, "beak", { pos: FRONT, at: 4, life: CHARGE + DASH, scale: 1.1, pal: [PALE, WHITE, YELLOW], tex: kit.tex(T.spiky), spin: 0.2, level: 1, scaleCurve: grow(0.5, 0.3, 1.2) }),
  ...zaps(kit, "crackle", { pos: FRONT, radius: 0.9, count: 1, bursts: CHARGE / 3, gap: 3, life: 6, scale: 0.55, pal: [YELLOW, WHITE, ICE] }),
  ...sparks(kit, "chargeSparks", { pos: FRONT, radius: 0.7, speed: 0.12, count: 2, bursts: CHARGE / 3, gap: 3, life: 9, scale: 0.12, pal: [YELLOW, WHITE, GOLD] }),
  // Speed lines as it drives forward.
  ...streaks(kit, "speedLines", { pos: [0, 0.6, 0.6], at: CHARGE, radius: 2.4, speed: 0.5, count: 3, bursts: DASH / 2, gap: 2, life: 6, scale: 1.2, pal: [WHITE, PALE, WHITE], shape: "circle" }),
];

const foe = [
  ...impact(kit, "stab", { pal: PAL, size: 1.4, rays: 9, flecks: 8 }),
  ...zaps(kit, "forks", { radius: 0.6, speed: 0.28, count: 3, bursts: 4, gap: 3, life: 8, scale: 1.0, pal: [YELLOW, WHITE, PALE], shape: "circle" }),
  ...zaps(kit, "after", { at: 12, radius: 1.5, count: 1, bursts: 4, gap: 3, life: 6, scale: 0.6, pal: [YELLOW, ICE, PALE] }),
  ...streaks(kit, "jags", { radius: 0.5, speed: 0.38, count: 8, life: 11, scale: 0.75, pal: [YELLOW, GOLD, PALE], tex: kit.tex(T.shard) }),
  ...glow(kit, "blaze", { pos: FOE, life: 16, scale: 2.8, pal: [YELLOW, WHITE, GOLD], level: 0.8 }),
];

const hitAt = CHARGE + DASH;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1483, 0, { ch: "SE2", vol: 100 }),
  snd(1458, 6, { pitch: 300, vol: 105 }),
  snd(1376, CHARGE, { ch: "SE2", vol: 0 }),
  snd(1489, CHARGE, { pitch: 200, vol: 120 }),
  snd(1522, hitAt, { ch: "SE2", side: "D", vol: 125 }),
  snd(1475, hitAt, { side: "D", pitch: -200, vol: 127 }),
  snd(1458, hitAt + 8, { ch: "SE2", side: "D", vol: 115 }),
)}
${tint("ATTACKER", 0, 9, 5, [31, 30, 12])}
${emits(kit, user, "ATTACKER")}
${shake("ATTACKER", 819, CHARGE / 2 - 2)}
Wait ${CHARGE}
${lunge("ATTACKER", 4)}
${pan("DEFENDER", DASH)}
Wait ${DASH}
${emits(kit, foe, "DEFENDER")}
${arena(0, 10, 0, [31, 31, 20])}
${hit({ rgb: [31, 31, 14], power: 3 })}
${arena(10, 0, 4, [31, 31, 20])}
${tint("ATTACKER", 9, 0, 4, [31, 30, 12])}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [87, 63, 605, 400, 240, 129],
  references: ["reference/Bolt_Beak_VIII.png", "reference/Bolt_Beak_VIII_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("crackle")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("forks")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  charge f${CAMERA_IN}, dash f${CAMERA_IN + CHARGE}, stab f${CAMERA_IN + hitAt}`);
