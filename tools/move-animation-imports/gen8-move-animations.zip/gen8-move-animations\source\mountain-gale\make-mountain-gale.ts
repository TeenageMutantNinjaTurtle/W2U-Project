import { createKit, fadeOut, grow, hold, paint, setCurves, spin, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FOE_FLOOR, glow, hit, impact, intro, lunge, outro, pan, puffs, ring, shot, snd, sparks, streaks, tint, USER, WHITE, type Pal } from "../tools/phrases";

// Mountain Gale (move 836) - from the Bulbapedia stills (reference/sheet.png).
//   1. Great boulders of ice form in the air over the user, one after
//      another, frost glittering round them.
//   2. It hurls them at the foe, one after another.
//   3. They smash on it: bursts of pale blue, shards and lumps of ice flying,
//      cold mist rolling off.
// The boulder is drawn (generated/texture-boulder.png).

const SPA = 1016;
const kit = await createKit({ workDir: import.meta.dirname, slug: "mountain-gale", moveId: 836, spaId: SPA, donors: [228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 10;
const FORM_GAP = 6;
const SUMMON = 26;
const THROW_GAP = 5;
const TRAVEL = 7;
const AFTER = 26;

const ICE: Rgb = [0.6, 0.85, 1.0];
const PALE: Rgb = [0.9, 0.97, 1.0];
const DEEP: Rgb = [0.3, 0.55, 1.0];
const COLD: Pal = [ICE, PALE, DEEP];

// --- a boulder of ice: an uneven lump cut in flat facets, lit from the upper left ---
const boulderTex = await kit.drawn("boulder", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5 - 16, py = y + 0.5 - 16;
  const a = Math.atan2(py, px), d = Math.hypot(px, py);
  const edge = 13 + 1.4 * Math.cos(3 * a + 0.5) + 0.9 * Math.cos(5 * a + 1.2);
  if (d > edge) return undefined;
  if (d > edge - 1.2) return [40, 100, 200, 255];
  // Facets: which of a few flat faces this point falls on.
  const face = ((Math.floor(((a + Math.PI) / (2 * Math.PI)) * 7 + 0.5 * Math.sin(d * 0.35)) % 7) + 7) % 7;
  const light = [0.75, 1.0, 0.9, 0.55, 0.25, 0.1, 0.4][face]!;
  const v = Math.min(1, light + (d < 5.5 ? 0.15 : 0));
  // A white vein through it.
  if (Math.abs(px * 0.55 + py * 0.83 - 1.5) < 0.5 && d < edge - 4) return [245, 252, 255, 255];
  return [Math.round(50 + 170 * v), Math.round(125 + 120 * v), Math.round(225 + 30 * v), 240];
});

// Where each boulder forms (over the user) and how big it is.
const BOULDERS: Array<{ at: Vec3; scale: number }> = [
  { at: [-1.5, 1.8, 0.1], scale: 0.95 },
  { at: [0.3, 2.5, 0.0], scale: 1.3 },
  { at: [1.6, 1.5, 0.2], scale: 0.85 },
];
const user: string[] = [];
const thrown: string[] = [];
for (const [i, b] of BOULDERS.entries()) {
  const formAt = i * FORM_GAP, throwAt = SUMMON + i * THROW_GAP;
  const hover = kit.parked(boulderTex, b.at, b.scale, throwAt - formAt);
  hover.startDelayFrames = formAt;
  spin(hover, 0.03, 0.03, i * 1.3);
  setCurves(hover, { start: 0.1, mid: 1.06, end: 1, curveIn: 0.25, curveOut: 0.7 }, hold(1));
  paint(hover, WHITE);
  kit.add(`hover${i}`, hover);
  user.push(`hover${i}`);
  // A puff of frost as it forms.
  user.push(...ring(kit, `frost${i}`, { pos: b.at, at: formAt, life: 9, scale: b.scale * 1.1, pal: [PALE, WHITE, ICE], to: 1.7 }));
  // The throw: the drop and the sideways drift bring it down onto the foe.
  shot(kit, `rock${i}`, boulderTex, { from: b.at, at: throwAt, travel: TRAVEL, scale: b.scale, pal: [WHITE, WHITE, WHITE], spin: 0.35, dive: (b.at[1] - 0.3) / 16, lateral: b.at[0] });
  thrown.push(`rock${i}`);
}
user.push(
  ...sparks(kit, "glitter", { pos: [0, 1.9, 0.1], radius: 2.4, speed: 0, count: 1, bursts: SUMMON / 3, gap: 3, life: 9, scale: 0.3, pal: [WHITE, PALE, ICE], shape: "sphere", tex: kit.tex(T.sparkle4) }),
  ...puffs(kit, "mist", { pos: [0, 1.6, 0.1], radius: 2.0, count: 1, bursts: SUMMON / 5, gap: 5, life: 16, scale: 1.0, pal: [PALE, WHITE, ICE], speed: 0.03, level: 0.45 }),
  ...glow(kit, "chill", { pos: USER, life: SUMMON + 6, scale: 2.8, pal: [ICE, DEEP, PALE], level: 0.55 }),
);

// --- 3. they smash, one after another ---
const foe: string[] = [];
for (const [i, b] of BOULDERS.entries()) {
  const at = i * THROW_GAP, last = i === BOULDERS.length - 1;
  const where: Vec3 = [[-0.5, 0.5, 0.9], [0.4, 0.1, 0.9], [0, 0.3, 0.9]][i] as Vec3;
  foe.push(
    ...impact(kit, `smash${i}`, { pos: where, at, pal: [PALE, WHITE, ICE], size: last ? 1.8 : 1.2, rays: last ? 8 : 0, flecks: 0, spiky: last }),
    ...sparks(kit, `lumps${i}`, { pos: where, at, radius: 0.5, speed: 0.26, count: last ? 5 : 3, life: 16, scale: b.scale * 0.3, pal: [WHITE, WHITE, WHITE], fall: 0.02, tex: boulderTex, twinkle: false, spin: 0.25 }),
  );
}
foe.push(
  ...streaks(kit, "shards", { radius: 0.6, speed: 0.42, count: 4, bursts: 3, gap: THROW_GAP, life: 10, scale: 0.9, pal: [PALE, WHITE, ICE], tex: kit.tex(T.shard) }),
  ...ring(kit, "shock", { at: 2 * THROW_GAP, life: 12, scale: 1.8, pal: [PALE, WHITE, ICE], to: 2.2 }),
  ...puffs(kit, "coldMist", { pos: FOE_FLOOR, at: 2, radius: 1.5, count: 2, bursts: 4, gap: 4, life: 18, scale: 1.0, pal: [PALE, WHITE, ICE], speed: 0.1, rise: 0.015, level: 0.6 }),
  ...sparks(kit, "frostFall", { at: 2 * THROW_GAP + 2, radius: 1.6, speed: 0.1, count: 6, life: 16, scale: 0.28, pal: [WHITE, PALE, ICE], shape: "circle", tex: kit.tex(T.sparkle4), fall: 0.006 }),
  ...glow(kit, "cold", { pos: FOE, life: 2 * THROW_GAP + 14, scale: 3.0, pal: COLD, level: 0.55 }),
);
setCurves(kit.resources[kit.idx("shards")]!, grow(1.1, 0.3, 0.6), fadeOut());

const landAt = SUMMON + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  ...BOULDERS.map((_, i) => snd(1509, i * FORM_GAP, { ch: i % 2 ? "SE2" : "SE1", pitch: 500 - i * 200, vol: 100 })),
  snd(1425, 4, { ch: "SE2", pitch: 600, vol: 90 }),
  ...BOULDERS.map((_, i) => snd(1539, SUMMON + i * THROW_GAP, { ch: "SE2", pitch: -500, vol: 118 })),
  ...BOULDERS.map((_, i) => snd(i === 2 ? 1475 : 1417, landAt + i * THROW_GAP, { side: "D", pitch: i === 2 ? -200 : 200, vol: 125 })),
  snd(1884, landAt + 2 * THROW_GAP + 1, { ch: "SE2", side: "D", pitch: 300, vol: 115 }),
)}
${arena(0, 8, 8, [10, 16, 26])}
${tint("ATTACKER", 0, 8, 6, [20, 27, 31])}
${emits(kit, user, "ATTACKER")}
${emits(kit, thrown, "ATTACKER", "DEFENDER")}
Wait ${SUMMON}
${lunge("ATTACKER", 3)}
${tint("ATTACKER", 8, 0, 4, [20, 27, 31])}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [24, 29, 31], power: 1, stop: 2 })}
Wait ${THROW_GAP - 2}
${hit({ rgb: [24, 29, 31], power: 1, stop: 2, freeze: false })}
Wait ${THROW_GAP - 2}
${hit({ rgb: [28, 31, 31], power: 3, freeze: false })}
Wait 6
${arena(8, 0, 10, [10, 16, 26])}
Wait ${AFTER - 6}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [420, 419, 63, 605, 400, 240, 153, 129],
  references: ["reference/Mountain_Gale_LA.png", "reference/Mountain_Gale_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("hover0")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("rock2")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("smash2Flash")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  boulders form f${CAMERA_IN}+, thrown f${CAMERA_IN + SUMMON}+, land f${CAMERA_IN + landAt} / +${THROW_GAP} / +${2 * THROW_GAP}`);
