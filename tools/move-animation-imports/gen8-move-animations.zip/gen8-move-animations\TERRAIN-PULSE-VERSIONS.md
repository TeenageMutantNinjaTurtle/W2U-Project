# Terrain Pulse (#805): how the animation picks its terrain version

Terrain Pulse's animation file holds **five complete animations**, one per terrain, each in that
terrain's colour. The animation script cannot find out which terrain is active: animation scripts have
no command that reads the field. **The battle code has to say which version to play**, by passing a
version index along with the move when it asks for the animation. This is the same mechanism the retail
game uses for Weather Ball (#311, one version per weather) and for two-turn moves (version 0 = charge
turn, version 1 = attack turn).

## The versions, as built

| Index | Terrain | Colour |
|---|---|---|
| 0 | none | pale gold |
| 1 | Electric Terrain | yellow |
| 2 | Grassy Terrain | green |
| 3 | Misty Terrain | pink |
| 4 | Psychic Terrain | violet |

**If the battle code passes nothing, index 0 plays** - the pale gold version, every time, whatever the
terrain. That is what will happen in a ROM whose Terrain Pulse code has not been taught to pass the
terrain.

## Where this lives in the files

- Compiled script: `narc-files/a065-move-scripts/5_00000805.bin` (file 805 of NARC `a/0/6/5`).
- Its particles: `narc-files/a006-particles/6_00000985.bin` (file 985 of NARC `a/0/0/6`). All five
  versions load this one archive; each uses its own recoloured effects inside it.
- Script source: `source/terrain-pulse/generated/5_00000805_terrain_pulse.s`.
- Generator: `source/terrain-pulse/make-terrain-pulse.ts`.

The script file starts with a table:

```
.word 5 @ Count            <- how many versions the file holds
.word SCRIPT_V0  (x14)     <- version 0: none
.word SCRIPT_V1  (x14)     <- version 1: Electric
.word SCRIPT_V2  (x14)     <- version 2: Grassy
.word SCRIPT_V3  (x14)     <- version 3: Misty
.word SCRIPT_V4  (x14)     <- version 4: Psychic
```

Each version has 14 pointers (the engine's slots for the different attacker/target layouts; all 14
point at the same script here, as they do in most retail moves). The version index the battle code
passes selects one block of 14. Weather Ball's own file (`a/0/6/5` file 311) has exactly this shape and
is the model to compare against.

## What to change, depending on how your battle code works

**1. Your battle code can pass a version index (the intended way).**
In the code that runs Terrain Pulse, where it already checks the terrain to double the power and change
the type, also set the move's animation version from the terrain, the way the Weather Ball handler sets
it from the weather. If your terrain numbering differs from the table above, you have two choices:

- map it in the battle code (terrain value -> index 0-4 above), or
- reorder the versions to match your numbering: in `make-terrain-pulse.ts`, the `TERRAINS` array is in
  version order - move the entries into the order your code will pass, and rebuild. Without the tools,
  edit the table at the top of `5_00000805_terrain_pulse.s` instead: swap which `SCRIPT_V<n>` label each
  block of 14 names (the scripts themselves need no change) and recompile it.

**2. Your battle code cannot pass an index.**
Then only version 0 ever plays. Pick the one you want as the always-played version and put it first
(same two ways as above), or keep pale gold.

**3. You would rather have separate moves or separate files.**
Each `SCRIPT_V<n>:` block in the `.s` file is a complete, self-contained animation. Any one of them can
be lifted out into a file of its own with a one-version table (`.word 1 @ Count` and 14 pointers to it)
and installed in whatever slot your code plays for that terrain. They all need particle archive 985.

## Changing a version's look

In `make-terrain-pulse.ts`, each `TERRAINS` entry is `{ key, pal, tint, pitch }`:

- `pal` - three colours (main, light, deep) as red/green/blue from 0 to 1, used for the rings, the
  rising light and the burst;
- `tint` - the flash colour on the Pokemon, 0-31 per channel;
- `pitch` - how much that version's sounds are shifted.

Adding a sixth entry adds a sixth version (index 5) with no other change.

## What has and has not been checked

- All five versions were built and the file's table was checked (5 versions, 14 pointers each).
  In the Pokeweb move-animation preview, the "1 | 2 | 3 | 4 | 5" selector plays each one.
- **Not checked: any battle.** I have not seen this hack's battle code, so I do not know whether it
  passes a version index for Terrain Pulse, nor how it numbers the terrains. Until someone confirms
  that, assume case 2 (pale gold always plays).
- From memory of the retail battle code, and not verified here: the function a move's handler calls to
  set the version is `BTL_SVFRET_SetWazaEffectIndex`, and Weather Ball's versions are numbered
  0 normal, 1 sun, 2 hail, 3 sandstorm, 4 rain. Check both against your own code before relying on them.
