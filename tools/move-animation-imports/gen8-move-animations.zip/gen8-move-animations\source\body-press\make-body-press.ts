import { createKit, fadeOut, grow, hold, paint, setCurves, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FOE_FLOOR, glow, hit, impact, intro, outro, pan, puffs, quake, ring, snd, sparks, squash, streaks, USER_FLOOR, WHITE, type Pal } from "../tools/phrases";

// Body Press (move 776) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user launches itself high into the air.
//   2. It drops onto the foe with its whole weight: a blinding yellow-white
//      burst, the ground breaking up into flying rock and clouds of dust.
// The user is hidden from the leap until the end (ToggleSpriteVisibility
// 3/4). The rock is Crunch's debris texture.

const SPA = 956;
const kit = await createKit({ workDir: import.meta.dirname, slug: "body-press", moveId: 776, spaId: SPA, donors: [413, 228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 10;
const CROUCH = 10;
const LEAP = 8;
const PAN = 10;
const DROP = 5;
const AFTER = 34;

const YELLOW: Rgb = [1.0, 0.88, 0.3];
const PALE: Rgb = [1.0, 0.97, 0.75];
const ORANGE: Rgb = [1.0, 0.65, 0.2];
const DUST: Rgb = [0.78, 0.68, 0.5];
const PALE_DUST: Rgb = [0.9, 0.84, 0.7];
const BROWN: Rgb = [0.55, 0.43, 0.3];
const PAL: Pal = [YELLOW, PALE, ORANGE];
const DROP_HEIGHT = 5;

// --- 1. the leap ---
const user = [
  ...puffs(kit, "kickDust", { pos: USER_FLOOR, at: CROUCH, radius: 0.8, count: 3, bursts: 2, gap: 2, life: 12, scale: 0.8, pal: [DUST, PALE_DUST, BROWN], speed: 0.1 }),
  ...streaks(kit, "upLines", { pos: [0, 0.3, 0.2], at: CROUCH, radius: 0.7, speed: 0, count: 3, bursts: 3, gap: 1, life: 6, scale: 1.3, pal: [WHITE, PALE, WHITE], flat: true, lift: 1.0 }),
];

// --- 2. the drop: the user as a pale mass coming down on the foe ---
const mass = kit.parked(kit.tex(T.fuzzyGlow), [FOE[0], FOE[1] + DROP_HEIGHT, FOE[2] + 0.1], 2.2, DROP + 1);
mass.axis = [0, -1, 0];
mass.initVelAxisAmplifier = DROP_HEIGHT / DROP;
setCurves(mass, hold(1), hold(0.95));
paint(mass, PALE, WHITE, YELLOW);
kit.add("mass", mass);
const foe = [
  "mass",
  ...streaks(kit, "dropLines", { pos: [0, 2.6, 0.8], radius: 1.0, speed: 0, count: 3, bursts: 3, gap: 1, life: 5, scale: 1.4, pal: [WHITE, PALE, WHITE], flat: true, lift: -1.0 }),
  // --- the crash ---
  ...impact(kit, "crash", { at: DROP, pal: PAL, size: 1.6, rays: 10, flecks: 0 }),
  ...ring(kit, "shock", { pos: FOE_FLOOR, at: DROP, scale: 1.6, pal: [PALE, WHITE, YELLOW], aspect: 2.6, to: 2.2, life: 12 }),
  ...streaks(kit, "groundSpikes", { pos: [0, -1.1, 0.8], at: DROP, radius: 0.6, speed: 0.6, count: 8, life: 10, scale: 0.85, pal: [YELLOW, PALE, WHITE], tex: kit.tex(T.spike), flat: true }),
  ...sparks(kit, "rocks", { pos: FOE_FLOOR, at: DROP, radius: 0.9, speed: 0.34, count: 8, life: 20, scale: 0.34, pal: [[0.8, 0.74, 0.62], [0.95, 0.9, 0.8], [0.6, 0.52, 0.42]], fall: 0.03, tex: kit.tex(413, 2), twinkle: false, spin: 0.2 }),
  ...puffs(kit, "dust", { pos: FOE_FLOOR, at: DROP + 1, radius: 1.6, count: 3, bursts: 4, gap: 3, life: 18, scale: 1.3, pal: [DUST, PALE_DUST, BROWN], speed: 0.14, rise: 0.03, to: 1.7 }),
  ...glow(kit, "blaze", { pos: FOE, at: DROP, life: 12, scale: 3.6, pal: [YELLOW, WHITE, ORANGE], level: 0.9 }),
];
// The rocks arc up before they fall.
const rocks = kit.resources[kit.idx("rocks")]!;
rocks.axis = [0, 1, 0];
rocks.initVelAxisAmplifier = 0.3;
setCurves(rocks, hold(1), fadeOut(1, 0.8));
setCurves(kit.resources[kit.idx("groundSpikes")]!, grow(1.2, 0.3, 0.6), fadeOut());

const slamAt = CROUCH + LEAP + PAN;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1463, 0, { vol: 105 }),
  snd(1407, CROUCH, { ch: "SE2", pitch: 300, vol: 115 }),
  snd(1560, slamAt - DROP, { ch: "SE2", side: "D", vol: 120 }),
  snd(1705, slamAt, { side: "D", pitch: -400, vol: 127 }),
  snd(1413, slamAt, { ch: "SE2", side: "D", pitch: -300, vol: 127 }),
  snd(1884, slamAt + 4, { side: "D", vol: 110 }),
)}
${emits(kit, user, "ATTACKER")}
${squash("ATTACKER", 1229, -1638, 5)}
Wait ${CROUCH}
ScaleSprite ATTACKER, ROUNDTRIP, -819, 1638, 2, 0, 1
Wait 3
ToggleSpriteVisibility ATTACKER, 3
Wait ${LEAP - 3}
${pan("DEFENDER", PAN)}
Wait ${PAN - DROP}
${emits(kit, foe, "DEFENDER")}
Wait ${DROP}
${arena(0, 12, 0, [31, 30, 20])}
${hit({ rgb: [31, 30, 18], power: 3 })}
${arena(12, 0, 4, [31, 30, 20])}
Wait 8
${quake("1x", 8)}
Wait ${AFTER - 8}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ToggleSpriteVisibility ATTACKER, 4
${pan("INIT", 12)}
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [242, 63, 605, 400, 240, 153, 129],
  references: ["reference/Body_Press_VIII.png", "reference/Body_Press_VIII_2.png", "reference/Body_Press_IX.png"],
  expectText: [`LoadSPA ${SPA}`, "ToggleSpriteVisibility ATTACKER, 3", "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("mass")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("rocks")}, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 4", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  crouch f${CAMERA_IN}, leap f${CAMERA_IN + CROUCH}, lands f${CAMERA_IN + slamAt}`);
