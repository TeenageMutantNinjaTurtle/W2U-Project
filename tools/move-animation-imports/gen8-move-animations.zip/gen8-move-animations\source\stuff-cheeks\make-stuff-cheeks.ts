import { createKit, fadeInOut, grow, paint, setCurves, spin, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, glow, impact, intro, outro, risers, ring, snd, sparks, squash, tint, WHITE, type Pal } from "../tools/phrases";

// Stuff Cheeks (move 747) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user holds up its Berry (a big brown nut in the Sword/Shield still).
//   2. It eats it: the Berry goes in a blaze of golden-white light at its
//      mouth, yellow motes drifting up.
// The user-only move stays on the user; Defense rising is the engine's.
// The Berry is drawn (generated/texture-berry.png).

const SPA = 945;
const kit = await createKit({ workDir: import.meta.dirname, slug: "stuff-cheeks", moveId: 747, spaId: SPA, donors: [228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const SHOW = 14;
const MUNCHES = 3;
const MUNCH_GAP = 7;
const EAT = MUNCHES * MUNCH_GAP;
const GLOW = 28;

const HELD: Vec3 = [1.0, 0.5, 0.5]; // beside the user's head, on the camera's side
const GOLD: Rgb = [1.0, 0.85, 0.25];
const PALE_GOLD: Rgb = [1.0, 0.97, 0.7];
const ORANGE: Rgb = [1.0, 0.6, 0.15];
const BROWN: Rgb = [0.6, 0.42, 0.25];
const PAL: Pal = [GOLD, PALE_GOLD, ORANGE];

// --- the drawn Berry: a brown nut with darker grain ---
const berryTex = await kit.drawn("berry", 32, 32, "a3i5", (x, y) => {
  const dx = (x + 0.5 - 16) / 14, dy = (y + 0.5 - 16) / 11;
  // A pointed oval lying on its side: narrower toward the right tip.
  const taper = 1 - 0.28 * Math.max(0, dx);
  const d = Math.hypot(dx, dy / taper);
  if (d > 1) return undefined;
  if (d > 0.9) return [82, 52, 30];
  const grain = Math.abs(Math.sin((dy / taper) * 6 + dx * 0.6)) < 0.18;
  const light = Math.max(0, 0.9 - 0.5 * (dy + 0.4) - 0.25 * Math.abs(dx));
  const base = grain ? [105, 70, 40] : [150 + 45 * light, 105 + 40 * light, 60 + 30 * light];
  return base.map((c) => Math.round(c));
});

const show = kit.parked(berryTex, HELD, 0.85, SHOW + 1);
setCurves(show, { start: 0.3, mid: 1.1, end: 1, curveIn: 0.35, curveOut: 0.6 }, { start: 0, mid: 1, end: 1, curveIn: 0.2, curveOut: 1 });
paint(show, WHITE);
kit.add("berryShow", show);

const eaten = kit.parked(berryTex, HELD, 0.85, EAT + 1);
eaten.startDelayFrames = SHOW;
spin(eaten, 0.03);
setCurves(eaten, { start: 1, mid: 0.6, end: 0.12, curveIn: 0.4, curveOut: 0.6 }, { start: 1, mid: 1, end: 0.6, curveIn: 0, curveOut: 0.9 });
paint(eaten, WHITE);
kit.add("berryEaten", eaten);

const GLOW_AT = SHOW + EAT;
const user = [
  "berryShow", "berryEaten",
  ...sparks(kit, "crumbs", { pos: HELD, at: SHOW, radius: 0.4, speed: 0.16, count: 4, bursts: MUNCHES, gap: MUNCH_GAP, life: 12, scale: 0.12, pal: [BROWN, [0.8, 0.62, 0.4], [0.42, 0.28, 0.16]], fall: 0.014, twinkle: false }),
  // The blaze of light as the last of it goes down.
  ...impact(kit, "gulp", { pos: HELD, at: GLOW_AT, pal: PAL, size: 1.15, rays: 8, flecks: 0, spiky: false }),
  ...glow(kit, "orb", { pos: HELD, at: GLOW_AT, life: 16, scale: 1.5, pal: [PALE_GOLD, WHITE, GOLD], tex: kit.tex(T.softDisc), level: 1, scaleCurve: grow(0.4, 0.25, 1.15), alpha: fadeInOut(1, 0.1, 0.55) }),
  ...ring(kit, "pulse", { pos: HELD, at: GLOW_AT + 2, scale: 1.2, pal: [PALE_GOLD, WHITE, GOLD], to: 2.2, life: 12 }),
  ...glow(kit, "aura", { pos: [0, 0.3, 0.2], at: GLOW_AT, life: GLOW, scale: 2.8, pal: [GOLD, ORANGE, PALE_GOLD], level: 0.6 }),
  ...risers(kit, "motes", { at: GLOW_AT, frames: GLOW - 12, radius: 1.3, speed: 0.16, scale: 0.26, life: 16, every: 3, pal: [GOLD, PALE_GOLD, WHITE], tex: kit.tex(T.softDisc) }),
  ...sparks(kit, "glints", { pos: [0, 0.8, 0.3], at: GLOW_AT + 4, radius: 1.5, speed: 0.02, count: 1, bursts: 6, gap: 3, life: 9, scale: 0.3, pal: [WHITE, PALE_GOLD, GOLD], shape: "ball", tex: kit.tex(T.sparkle4) }),
];

const munches = Array.from({ length: MUNCHES }, () => `${squash("ATTACKER", 819, -819, 3)}\nWait ${MUNCH_GAP}`).join("\n");
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1470, 0, { pitch: 300, vol: 90 }),
  ...Array.from({ length: MUNCHES }, (_, i) => snd(1720, SHOW + i * MUNCH_GAP, { ch: i % 2 ? "SE2" : "SE1", pitch: [200, -100, 100][i % 3], vol: 120 })),
  snd(1779, GLOW_AT - 1, { ch: "SE2", vol: 127 }),
  snd(1427, GLOW_AT + 2, { pitch: 200, vol: 110 }),
  snd(1452, GLOW_AT + 8, { ch: "SE2", pitch: 300, vol: 105 }),
)}
${emits(kit, user, "ATTACKER")}
Wait ${SHOW}
${munches}
${tint("ATTACKER", 0, 11, 2, [31, 28, 12])}
${squash("ATTACKER", -1229, 1229, 4)}
Wait ${GLOW - 8}
${tint("ATTACKER", 11, 0, 6, [31, 28, 12])}
Wait 8
${outro({ unfreeze: "NONE" })}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129],
  references: ["reference/Stuff_Cheeks_VIII.png", "reference/Stuff_Cheeks_VIII_2.png", "reference/Stuff_Cheeks_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("berryShow")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("orb")}, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  berry f${CAMERA_IN}, munching f${CAMERA_IN + SHOW}-${CAMERA_IN + GLOW_AT}, glow f${CAMERA_IN + GLOW_AT}-${CAMERA_IN + GLOW_AT + GLOW}`);
