import { T, type Rgb } from "../tools/anim-kit";
import { sparks, WHITE } from "../tools/phrases";
import { buildStorm } from "../tools/storm";

// Springtide Storm (move 831) - from the Bulbapedia stills (reference/sheet.png).
// The user whips up a warm pink wind; over the foe it spins into a tall pink
// tornado laced with fresh green, hearts and golden sparkles carried in it.
// Built by ../tools/storm.ts (shared with the other three storms). The heart
// is drawn (generated/texture-heart.png).

const PINK: Rgb = [1.0, 0.6, 0.82];
const PALE: Rgb = [1.0, 0.88, 0.95];
const HOT: Rgb = [1.0, 0.35, 0.65];
const SPRING: Rgb = [0.75, 1.0, 0.5];
const GOLD: Rgb = [1.0, 0.9, 0.45];

await buildStorm({
  workDir: import.meta.dirname,
  slug: "springtide-storm",
  moveId: 831,
  spaId: 1011,
  pal: [PINK, PALE, HOT],
  accent: SPRING,
  userTint: [31, 20, 26],
  arenaTint: [22, 10, 18],
  donors: [407],
  donorMoveIds: [236],
  references: ["reference/Springtide_Storm_LA.png", "reference/Springtide_Storm_LA_2.png", "reference/Springtide_Storm_IX.png"],
  describe: "springtide storm",
  carries: async (kit, { GATHER, STORM }) => {
    // A plump pink heart with a pale highlight.
    const heartTex = await kit.drawn("heart", 16, 16, "a3i5", (x, y) => {
      const px = (x + 0.5 - 8) / 7, py = (7.2 - (y + 0.5)) / 7;
      const v = (px * px + py * py - 0.42) ** 3 - px * px * py * py * py * 1.1;
      if (v > 0) return undefined;
      if (v > -0.012) return [225, 60, 120];
      return Math.hypot(px + 0.32, py - 0.3) < 0.24 ? [255, 215, 230] : [255, 120, 170];
    });
    return {
      user: [
        ...sparks(kit, "userHearts", { pos: [0, 0.8, 0.5], radius: 1.6, speed: 0.04, count: 1, bursts: GATHER / 4, gap: 4, life: 14, scale: 0.32, pal: [WHITE, WHITE, WHITE], fall: -0.008, tex: heartTex, twinkle: false, shape: "ball" }),
      ],
      foe: [
        ...sparks(kit, "hearts", { pos: [0, 0.6, 1.0], at: 2, radius: 1.8, speed: 0.06, count: 1, bursts: STORM / 4 - 2, gap: 4, life: 16, scale: 0.36, pal: [WHITE, WHITE, WHITE], fall: -0.014, tex: heartTex, twinkle: false, shape: "ball" }),
        ...sparks(kit, "goldSparkles", { pos: [0, 0.8, 1.0], at: 4, radius: 2.0, speed: 0, count: 1, bursts: STORM / 4 - 2, gap: 4, life: 9, scale: 0.36, pal: [GOLD, WHITE, PALE], shape: "ball", tex: kit.tex(T.sparkle4) }),
      ],
    };
  },
});
