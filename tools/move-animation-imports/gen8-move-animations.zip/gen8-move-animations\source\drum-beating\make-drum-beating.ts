import { createKit, deg, fadeOut, grow, hold, paint, setCurves, spin, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, FOE, FOE_FLOOR, glow, hit, impact, intro, outro, pan, puffs, quake, ring, shake, snd, sparks, squash, tint, USER_FLOOR, WHITE, type Pal } from "../tools/phrases";

// Drum Beating (move 778) - from the Bulbapedia stills (reference/sheet.png)
// and the two pictures and description Logan sent on 2026-10-03.
//   1. A drum made from a tree log - a round of pale wood with a green spot
//      at its heart, bark round it, two stubs of branch on top - pops up in
//      front of the user.
//   2. Two drumsticks appear, one on either side of it, and beat down on it
//      one at a time, a jagged yellow burst and a ring of sound off each beat.
//   3. After four beats, vines sprout out of the ground under the foe one at
//      a time: one to its left, one to its right, and last and largest one
//      straight up through the middle.
// The drum and the drumstick are drawn (generated/texture-drum.png,
// texture-stick.png); the vines are Frenzy Plant's roots (SPA 514). A stick has
// two poses, raised and striking, shown turn about. (The vines first slammed
// down on the foe; Logan had them simply sprout instead, 2026-10-03.)

const SPA = 958;
const kit = await createKit({ workDir: import.meta.dirname, slug: "drum-beating", moveId: 778, spaId: SPA, donors: [514, 413, 228, 465, 579, 411, 321, 298] });

const CAMERA_IN = 10;
const SPAWN = 8; // the drum pops up; the sticks follow
const BEATS = 4;
const BEAT_GAP = 8;
const STRIKE = 3; // how long a stick stays down on a beat
const DRUMMING = BEATS * BEAT_GAP;
const PAN = 10;
const SPROUT_GAP = 7; // between one vine and the next
const GROW = 5; // frames a vine takes to come up
const STAND = 22; // how long they stand once the last is up
const AFTER = 26;

const YELLOW: Rgb = [1.0, 0.92, 0.2];
const PALE: Rgb = [1.0, 0.98, 0.7];
const GREEN: Rgb = [0.45, 0.9, 0.25];
const LIME: Rgb = [0.75, 1.0, 0.35];
const DUST: Rgb = [0.72, 0.6, 0.42];
const PAL: Pal = [YELLOW, PALE, GREEN];
const DRUM: Vec3 = [0.7, 0.0, -0.4]; // in front of the user, toward the foe

// --- the drum: the end of a log ---
const drumTex = await kit.drawn("drum", 64, 64, "a3i5", (x, y) => {
  const px = x + 0.5 - 32, py = y + 0.5 - 36; // the log's middle sits a little low, leaving room for the stubs
  const d = Math.hypot(px, py);
  // Two stubs of branch standing off the top, left and right.
  for (const side of [-1, 1]) {
    const ux = side * 0.64, uy = -0.77; // along the stub, outward
    const along = px * ux + py * uy, across = Math.abs(px * -uy + py * ux);
    if (along > 20 && along < 35 && across < 5.5) {
      if (across > 4.2 || along > 33.6) return [95, 60, 30, 255];
      return along > 30 ? [226, 196, 140, 255] : [150, 100, 55, 255];
    }
  }
  if (d > 26) return undefined;
  if (d > 24.6) return [80, 50, 26, 255];
  if (d > 21) return Math.abs(Math.sin(Math.atan2(py, px) * 9)) > 0.86 ? [100, 64, 32, 255] : [140, 92, 48, 255]; // bark, scored
  if (d < 5.5) return d > 4.3 ? [34, 100, 55, 255] : [64, 160, 86, 255]; // the green spot
  for (const ringAt of [9, 13.5, 17.5]) if (Math.abs(d - ringAt) < 0.55) return [198, 164, 108, 255]; // growth rings
  const light = Math.max(0, 1 - Math.hypot(px + 8, py + 8) / 24);
  return [Math.round(224 + 22 * light), Math.round(198 + 28 * light), Math.round(142 + 40 * light), 255];
});
// --- a drumstick, head up: a wooden handle with a round pale head ---
const stickTex = await kit.drawn("stick", 16, 32, "a3i5", (x, y) => {
  const px = x + 0.5 - 8, py = y + 0.5;
  const head = Math.hypot(px, py - 5.5);
  if (head < 4.6) return head > 3.5 ? [150, 120, 80, 255] : [246, 236, 208, 255];
  if (py > 8 && py < 31.5 && Math.abs(px) < 2) return Math.abs(px) > 1.1 ? [130, 96, 58, 255] : [214, 178, 122, 255];
  return undefined;
});

// The drum pops up, then bounces on every beat (it is re-emitted each beat).
const drumRise = kit.parked(drumTex, DRUM, 1.1, SPAWN + 1);
setCurves(drumRise, { start: 0.15, mid: 1.12, end: 1, curveIn: 0.5, curveOut: 0.8 }, hold(1));
paint(drumRise, WHITE);
kit.add("drumRise", drumRise);
const drum = kit.parked(drumTex, DRUM, 1.1, BEAT_GAP + 1);
Object.assign(drum, { startDelayFrames: SPAWN, emitterLifeFrames: (BEATS + 1) * BEAT_GAP + 1, emissionIntervalFrames: BEAT_GAP });
setCurves(drum, { start: 1.14, mid: 0.96, end: 1.0, curveIn: 0.3, curveOut: 0.7 }, hold(1));
paint(drum, WHITE);
kit.add("drum", drum);
const burst = kit.parked(kit.tex(T.spiky), [DRUM[0], DRUM[1], DRUM[2] + 0.2], 1.9, 7);
Object.assign(burst, { startDelayFrames: SPAWN, emitterLifeFrames: (BEATS - 1) * BEAT_GAP + 1, emissionIntervalFrames: BEAT_GAP });
spin(burst, 0.1);
setCurves(burst, grow(0.5, 0.3, 1.3), fadeOut(1, 0.45));
paint(burst, YELLOW, PALE, [1.0, 0.75, 0.1]);
kit.add("burst", burst);

// The sticks. Each is drawn in pieces: raised between its beats, down on them.
// The left one takes beats 0 and 2, the right one beats 1 and 3.
const HALF = 0.62; // half a stick's length
const sticks: string[] = [];
function stickPiece(name: string, from: number, to: number, pos: Vec3, angle: number, popIn = false): void {
  if (to <= from) return;
  const r = kit.parked(stickTex, pos, HALF, to - from);
  r.startDelayFrames = from;
  r.aspectRatio = 0.5;
  spin(r, 0, 0, deg(angle));
  setCurves(r, popIn ? { start: 0.2, mid: 1.1, end: 1, curveIn: 0.4, curveOut: 0.8 } : hold(1), hold(1));
  paint(r, WHITE);
  kit.add(name, r);
  sticks.push(name);
}
for (const side of [-1, 1] as const) {
  const key = side === -1 ? "Left" : "Right";
  const raised: Vec3 = [DRUM[0] + side * 1.3, DRUM[1] + 1.35, DRUM[2] - 0.05];
  const down: Vec3 = [DRUM[0] + side * 0.84, DRUM[1] + 0.6, DRUM[2] - 0.1];
  const raisedAngle = -side * 28, downAngle = -side * -115; // head up and out; head down onto the drum
  const mine = Array.from({ length: BEATS }, (_, b) => b).filter((b) => b % 2 === (side === -1 ? 0 : 1));
  let from = SPAWN - 3;
  for (const [n, b] of mine.entries()) {
    const beatAt = SPAWN + b * BEAT_GAP;
    stickPiece(`stick${key}Up${n}`, from, beatAt, raised, raisedAngle, n === 0);
    stickPiece(`stick${key}Down${n}`, beatAt, beatAt + STRIKE, down, downAngle);
    from = beatAt + STRIKE;
  }
  stickPiece(`stick${key}UpLast`, from, SPAWN + DRUMMING + 4, raised, raisedAngle);
}

const user = [
  ...sticks, // in front of the drum
  ...Array.from({ length: BEATS }, (_, b) => glow(kit, `tap${b}`, { pos: [DRUM[0] + (b % 2 ? 0.3 : -0.3), DRUM[1] + 0.3, DRUM[2] - 0.15], at: SPAWN + b * BEAT_GAP, life: 5, scale: 0.6, pal: [WHITE, WHITE, PALE], tex: kit.tex(T.hitStar), spin: 0.2, level: 1, scaleCurve: grow(0.5, 0.3, 1.2), alpha: fadeOut(1, 0.4) })).flat(),
  "drumRise", "drum", "burst", // earlier emits draw in front: the burst sits behind the drum
  ...Array.from({ length: BEATS }, (_, b) => ring(kit, `sound${b}`, { pos: DRUM, at: SPAWN + b * BEAT_GAP + 1, scale: 1.2, pal: [PALE, WHITE, LIME], to: 2.4, life: 10, level: 0.8 })).flat(),
  ...puffs(kit, "beatDust", { pos: [DRUM[0], USER_FLOOR[1], DRUM[2]], at: SPAWN, radius: 1.2, count: 2, bursts: BEATS, gap: BEAT_GAP, life: 12, scale: 0.6, pal: [DUST, [0.85, 0.76, 0.6], DUST], speed: 0.08 }),
];

// --- 3. the vines: Frenzy Plant's roots stood on end (texture 4 tapers to
// the right, 3 to the left; turned a quarter they point up). Each comes up
// out of the ground: it grows from a stub to its full height while its
// middle climbs, so its foot stays on the ground; then it stands. ---
const GROUND = FOE_FLOOR[1] - 0.2;
const STUB = 0.25; // how much of it shows as it breaks the ground
const VINES = [
  { key: "Left", tex: 4, x: -1.15, scale: 0.72, lean: 80 },
  { key: "Right", tex: 3, x: 1.15, scale: 0.72, lean: -80 },
  { key: "Centre", tex: 4, x: 0.05, scale: 1.15, lean: 88 },
] as const;
const vinesEnd = (VINES.length - 1) * SPROUT_GAP + GROW + STAND;
const vines: string[] = [];
for (const [i, v] of VINES.entries()) {
  const at = i * SPROUT_GAP;
  const half = v.scale * 2; // half the vine's length: the texture is twice as long as it is tall
  const z = v.key === "Centre" ? 1.0 : 0.9;
  const rise = kit.parked(kit.tex(514, v.tex), [v.x, GROUND + half * STUB, z], v.scale, GROW);
  Object.assign(rise, { startDelayFrames: at, aspectRatio: 2, axis: [0, 1, 0], initVelAxisAmplifier: (half * (1 - STUB)) / GROW, airResistance: 1.0 });
  spin(rise, 0, 0, deg(v.lean));
  setCurves(rise, { start: STUB, mid: 1, end: 1, curveIn: 0.95, curveOut: 1 }, hold(1));
  paint(rise, WHITE);
  kit.add(`vine${v.key}Rise`, rise);
  const stand = kit.parked(kit.tex(514, v.tex), [v.x, GROUND + half, z], v.scale, vinesEnd - at - GROW);
  Object.assign(stand, { startDelayFrames: at + GROW, aspectRatio: 2 });
  spin(stand, 0, 0, deg(v.lean));
  setCurves(stand, { start: 1.04, mid: 1, end: 1, curveIn: 0.15, curveOut: 1 }, { start: 1, mid: 1, end: 0, curveIn: 0, curveOut: 0.75 });
  paint(stand, WHITE);
  kit.add(`vine${v.key}`, stand);
  vines.push(`vine${v.key}Rise`, `vine${v.key}`);
}
const lastUp = (VINES.length - 1) * SPROUT_GAP + GROW - 2; // the big one reaching the foe
const foe = [
  // The centre vine is listed first so it draws in front of the other two.
  ...vines.slice(4), ...vines.slice(0, 4),
  ...impact(kit, "strike", { at: lastUp, pal: [YELLOW, PALE, GREEN], size: 1.6, rays: 9, flecks: 0 }),
  ...puffs(kit, "sproutDust", { pos: FOE_FLOOR, radius: 1.5, count: 2, bursts: VINES.length, gap: SPROUT_GAP, life: 14, scale: 0.9, pal: [DUST, [0.85, 0.76, 0.6], [0.5, 0.4, 0.28]], speed: 0.1, rise: 0.03 }),
  ...sparks(kit, "dirt", { pos: FOE_FLOOR, radius: 1.6, speed: 0.18, count: 3, bursts: VINES.length, gap: SPROUT_GAP, life: 16, scale: 0.22, pal: [[0.7, 0.6, 0.45], [0.85, 0.78, 0.65], [0.5, 0.42, 0.32]], fall: 0.028, tex: kit.tex(413, 2), twinkle: false, spin: 0.2 }),
  ...sparks(kit, "leaves", { at: lastUp, radius: 0.6, speed: 0.26, count: 7, life: 14, scale: 0.15, pal: [GREEN, LIME, YELLOW], fall: 0.01, twinkle: false, shape: "circle" }),
  ...glow(kit, "green", { pos: FOE, at: lastUp, life: 10, scale: 2.4, pal: [LIME, YELLOW, GREEN], tex: kit.tex(T.spiky), spin: -0.1, level: 0.9, scaleCurve: grow(0.5, 0.3, 1.35), alpha: fadeOut(1, 0.4) }),
];
const dirt = kit.resources[kit.idx("dirt")]!;
dirt.axis = [0, 1, 0];
dirt.initVelAxisAmplifier = 0.32;

const rootsAt = SPAWN + DRUMMING + 4 + PAN;
const beats = Array.from({ length: BEATS }, () => `${squash("ATTACKER", 410, -410, 2)}\nShakeScreen VERTICAL, 0.5x, 0, 2, 0, 2\nWait ${BEAT_GAP}`).join("\n");
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1474, 0, { pitch: -300, vol: 85 }),
  ...Array.from({ length: BEATS }, (_, b) => snd(1525, SPAWN + b * BEAT_GAP, { ch: b % 2 ? "SE2" : "SE1", pitch: (b % 2) * 150, vol: 122 })),
  snd(1884, rootsAt, { side: "D", vol: 105 }),
  ...VINES.map((_, i) => snd(1708, rootsAt + i * SPROUT_GAP, { ch: i % 2 ? "SE1" : "SE2", side: "D", pitch: i * 150, vol: 112 })),
  snd(1475, rootsAt + lastUp, { side: "D", pitch: -200, vol: 125 }),
)}
${emits(kit, user, "ATTACKER")}
Wait ${SPAWN}
${beats}
Wait 4
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 3
ToggleFreezeSprite DEFENDER, START
${shake("DEFENDER", 819, 3)}
Wait ${SPROUT_GAP}
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 3
${shake("DEFENDER", 819, 3)}
Wait ${lastUp - SPROUT_GAP}
${hit({ rgb: [28, 31, 12], power: 3, freeze: false })}
Wait 8
${quake("1x", 6)}
Wait ${AFTER - 8}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [338, 242, 63, 605, 400, 240, 153, 129],
  references: ["reference/Drum_Beating_VIII.png", "reference/Drum_Beating_VIII_2.png", "reference/Drum_Beating_IX.png", "reference/Drum_Beating_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("drumRise")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("stickLeftDown0")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("stickRightDown0")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("vineLeftRise")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("vineCentre")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  drum f${CAMERA_IN}, beats f${CAMERA_IN + SPAWN} then every ${BEAT_GAP}, vines sprout f${CAMERA_IN + rootsAt} then every ${SPROUT_GAP}, the big one reaches the foe f${CAMERA_IN + rootsAt + lastUp}`);
