import { type Rgb } from "../tools/anim-kit";
import { flames, snd, sparks, streaks } from "../tools/phrases";
import { buildStorm } from "../tools/storm";

// Sandsear Storm (move 848) - from the Bulbapedia stills (reference/sheet.png).
// The user whips up a wind thick with hot sand; over the foe it spins into a
// tall sand-brown tornado laced with fiery red-orange, embers and streaks of
// fire carried in it, the ground under it alight.
// Built by ../tools/storm.ts (shared with the other three storms). The
// flames are Fire Blast's (SPA 295).

const SAND: Rgb = [0.8, 0.7, 0.55];
const PALE: Rgb = [0.96, 0.9, 0.78];
const BROWN: Rgb = [0.5, 0.4, 0.28];
const FIRE: Rgb = [1.0, 0.42, 0.12];
const YELLOW: Rgb = [1.0, 0.85, 0.35];
const RED: Rgb = [0.95, 0.2, 0.08];

await buildStorm({
  workDir: import.meta.dirname,
  slug: "sandsear-storm",
  moveId: 848,
  spaId: 1028,
  pal: [SAND, PALE, BROWN],
  accent: FIRE,
  userTint: [30, 22, 12],
  arenaTint: [15, 9, 4],
  donors: [295],
  donorMoveIds: [126],
  references: ["reference/Sandsear_Storm_LA.png", "reference/Sandsear_Storm_IX.png"],
  describe: "sandsear storm",
  sounds: (stormAt) => [
    snd(1426, stormAt + 2, { ch: "SE2", side: "D", pitch: -200, vol: 115 }),
    snd(1426, stormAt + 20, { ch: "SE2", side: "D", pitch: 100, vol: 110 }),
  ],
  carries: (kit, { GATHER, STORM }) => ({
    user: [
      ...sparks(kit, "userSand", { pos: [0, 0.4, 0.5], radius: 1.8, speed: 0.12, count: 2, bursts: GATHER / 4, gap: 4, life: 10, scale: 0.12, pal: [SAND, PALE, BROWN], fall: 0.006, twinkle: false }),
    ],
    foe: [
      // Streaks of fire whipped round in the sand, embers thrown up, the ground alight.
      ...streaks(kit, "fireStreaks", { pos: [0, 0.5, 1.0], at: 3, radius: 1.5, speed: 0.34, count: 2, bursts: STORM / 5, gap: 5, life: 8, scale: 1.0, pal: [FIRE, YELLOW, RED], flat: true, lift: 0.1 }),
      ...sparks(kit, "embers", { pos: [0, 0.2, 1.0], at: 2, radius: 1.6, speed: 0.1, count: 1, bursts: STORM / 4 - 2, gap: 4, life: 12, scale: 0.15, pal: [YELLOW, FIRE, RED], fall: -0.02, twinkle: false }),
      ...flames(kit, "scorch", { pos: [0, -0.9, 0.9], at: 4, frames: STORM - 8, every: 4, life: 9, scale: 0.9, rise: 0.05, radius: 1.3 }),
    ],
  }),
});
