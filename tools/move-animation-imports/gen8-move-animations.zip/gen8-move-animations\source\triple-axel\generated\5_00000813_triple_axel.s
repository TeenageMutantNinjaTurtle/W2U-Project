LoadSPA 993
AudioContainer CONTINUE
PlaySound 1425, SE1, 14, 0, 800, 105, 0, 0, 0
PlaySound 1514, SE2, 16, 8, 500, 120, 0, 0, 0
PlaySound 1509, SE1, 16, 9, 900, 95, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 7, 0, 20, 28, 31
Emit 993, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 993, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, -1638, 0, 3, 0, 1
Wait 5
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
Wait 3
ChangeSpriteColor ATTACKER, 7, 0, 0, 20, 28, 31
Emit 993, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 993, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 993, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 993, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 993, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 993, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 993, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 24, 30, 31
Wait 3
ChangeSpriteColor DEFENDER, 13, 0, 0, 24, 30, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 14
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
