MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1001
AudioContainer CONTINUE
PlaySound 1509, SE1, 14, 0, 300, 100, 0, 0, 0
PlaySound 1509, SE2, 14, 2, 500, 95, 0, 0, 0
PlaySound 1434, SE1, 14, 14, 300, 100, 0, 0, 0
PlaySound 1962, SE2, 14, 20, 600, 105, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 7, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 27, 200, 120, 0, 0, 0
PlaySound 1376, SE2, 14, 45, 0, 0, 0, 0, 0
PlaySound 1420, SE1, 16, 36, 300, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 9, 0, 4, 4, 12
ChangeSpriteColor ATTACKER, 0, 6, 0, 22, 18, 31
Emit 1001, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1001, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1001, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1001, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1001, 1, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1001, 2, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1001, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1001, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 20
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 9
MoveCamera INTERPOLATION, DEFENDER, 7, 0, 8
Wait 7
Emit 1001, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1001, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1001, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1001, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1001, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1001, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1001, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 26, 26, 31
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 26, 26, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 5
Wait 14
ChangeSpriteColor ATTACKER, 6, 0, 0, 22, 18, 31
ChangeBackgroundColor 4, 9, 0, 0, 4, 4, 12
Wait 24
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
