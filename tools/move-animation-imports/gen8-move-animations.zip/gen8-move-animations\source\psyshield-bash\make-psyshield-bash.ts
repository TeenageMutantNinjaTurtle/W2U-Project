import { aimed, createKit, hold, paint, setCurves, spin, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, FOE, hit, impact, intro, outro, pan, ring, snd, sparks, streaks, tint, USER, WHITE, type Pal } from "../tools/phrases";

// Psyshield Bash (move 828) - from the Bulbapedia stills (reference/sheet.png).
//   1. A shimmering dome of psychic force - cyan, pink and violet - closes
//      round the user.
//   2. It charges inside it, streaks of pink and cyan light trailing.
//   3. It rams the foe and the shield bursts in shards of the same colours.
// The user is hidden while it charges (ToggleSpriteVisibility 3/4). The
// Defense boost is the engine's.

const SPA = 1008;
const kit = await createKit({ workDir: import.meta.dirname, slug: "psyshield-bash", moveId: 828, spaId: SPA, donors: [228, 465, 579, 411, 298, 560] });

const CAMERA_IN = 10;
const SHIELD = 18;
const TRAVEL = 7;
const AFTER = 26;

const CYAN: Rgb = [0.4, 0.9, 1.0];
const PINK: Rgb = [1.0, 0.55, 0.9];
const VIOLET: Rgb = [0.6, 0.4, 1.0];
const PALE: Rgb = [0.9, 0.95, 1.0];
const PSY: Pal = [CYAN, PINK, VIOLET];
const DOME: Vec3 = [0, 0.3, 0.3];

// The shield's layers: a soft cyan body, a pink rim and a turning band of rings.
const LAYERS: Array<{ name: string; tex: number; scale: number; rate: number; colours: [Rgb, Rgb, Rgb]; level: number }> = [
  { name: "Bands", tex: kit.tex(T.thinRings), scale: 2.2, rate: 0.25, colours: [PALE, WHITE, PINK], level: 0.8 },
  { name: "Rim", tex: kit.tex(T.ring), scale: 2.4, rate: 0, colours: [PINK, PALE, VIOLET], level: 0.9 },
  { name: "Body", tex: kit.tex(T.softDisc), scale: 2.35, rate: 0, colours: [CYAN, PALE, VIOLET], level: 0.5 },
];
const forming: string[] = [];
const charging: string[] = [];
for (const l of LAYERS) {
  const make = (life: number, at: number) => {
    const r = kit.parked(l.tex, DOME, l.scale, life);
    r.startDelayFrames = at;
    if (l.rate) spin(r, l.rate);
    paint(r, l.colours[0], l.colours[1], l.colours[2]);
    return r;
  };
  const form = make(SHIELD + 1, 0);
  setCurves(form, { start: 0.3, mid: 1.05, end: 1, curveIn: 0.4, curveOut: 0.8 }, { start: 0, mid: l.level, end: l.level, curveIn: 0.3, curveOut: 1 });
  kit.add(`form${l.name}`, form);
  forming.push(`form${l.name}`);
  const go = make(TRAVEL + 1, SHIELD);
  aimed(go, 16 / TRAVEL, TRAVEL + 1);
  go.airResistance = 1.0;
  setCurves(go, hold(1), hold(l.level));
  kit.add(`charge${l.name}`, go);
  charging.push(`charge${l.name}`);
}
const user = [
  ...forming,
  ...sparks(kit, "glimmer", { pos: USER, radius: 2.2, speed: 0, count: 1, bursts: SHIELD / 3, gap: 3, life: 9, scale: 0.3, pal: [WHITE, CYAN, PINK], shape: "sphere", tex: kit.tex(T.sparkle4) }),
  // Streaks left behind as it sets off.
  ...streaks(kit, "trailLines", { pos: USER, at: SHIELD, radius: 1.6, speed: 0.4, count: 4, bursts: 3, gap: 2, life: 7, scale: 0.9, pal: [PINK, CYAN, WHITE] }),
];
const foe = [
  ...impact(kit, "ram", { pal: [CYAN, PALE, PINK], size: 1.6, rays: 9, flecks: 0 }),
  ...ring(kit, "burstRing", { scale: 2.0, pal: [PINK, WHITE, VIOLET], to: 2.2, life: 12 }),
  ...streaks(kit, "shards", { radius: 0.7, speed: 0.46, count: 10, life: 11, scale: 1.0, pal: PSY, tex: kit.tex(T.shard) }),
  ...sparks(kit, "glitter", { at: 2, radius: 1.2, speed: 0.18, count: 7, life: 13, scale: 0.28, pal: [WHITE, CYAN, PINK], shape: "circle", tex: kit.tex(T.sparkle4) }),
];

const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1474, 0, { vol: 90 }),
  snd(1505, 4, { ch: "SE2", pitch: 300, vol: 105 }),
  snd(1688, SHIELD, { pitch: 400, vol: 120 }),
  snd(1475, SHIELD + TRAVEL, { side: "D", pitch: -200, vol: 127 }),
  snd(1455, SHIELD + TRAVEL, { ch: "SE2", side: "D", vol: 115 }),
)}
${tint("ATTACKER", 0, 8, 6, [22, 26, 31])}
${emits(kit, user, "ATTACKER")}
${emits(kit, charging, "ATTACKER", "DEFENDER")}
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, ${SHIELD - 4}, 0, 1
Wait ${SHIELD}
ToggleSpriteVisibility ATTACKER, 3
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [26, 28, 31], power: 3 })}
Wait ${AFTER}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
${tint("ATTACKER", 8, 0, 4, [22, 26, 31])}
ToggleSpriteVisibility ATTACKER, 4
${pan("INIT", 12)}
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 381, 564],
  references: ["reference/Psyshield_Bash_LA.png", "reference/Psyshield_Bash_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("formBody")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("chargeBody")}, ATTACKER, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 3", "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("shards")}, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 4", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  shield f${CAMERA_IN}, charge f${CAMERA_IN + SHIELD}, rams f${CAMERA_IN + SHIELD + TRAVEL}`);
