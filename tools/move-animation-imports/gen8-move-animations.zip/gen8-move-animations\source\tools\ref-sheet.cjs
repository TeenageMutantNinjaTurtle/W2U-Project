// usage: node tools/ref-sheet.cjs <slug>...      (no slugs: every move in gen8-refs.txt)
// Tiles a move's reference stills, two per row, into <slug>/reference/sheet.png
// in the order gen8-refs.txt lists them (oldest game first).
const fs = require("fs");
const path = require("path");
const { PNG } = require("pngjs");
const WORK = path.join(__dirname, "..");
const CELL_W = 640, CELL_H = 360, GAP = 6;
const lines = fs.readFileSync(path.join(__dirname, "gen8-refs.txt"), "utf8").split(/\r?\n/).filter(Boolean);
const want = new Set(process.argv.slice(2));
for (const line of lines) {
  const [, name, files] = /^\d+ ([^:]+):(.*)$/.exec(line);
  const slug = name.toLowerCase().replace(/_/g, "-");
  if (want.size && !want.has(slug)) continue;
  const dir = path.join(WORK, slug, "reference");
  const pngs = files.split(",").map((f) => path.join(dir, decodeURIComponent(f.split("/")[1]))).filter((f) => fs.existsSync(f)).map((f) => PNG.sync.read(fs.readFileSync(f)));
  if (!pngs.length) { console.log(`${slug}: no stills`); continue; }
  const cols = pngs.length === 1 ? 1 : 2, rows = Math.ceil(pngs.length / cols);
  const sheet = new PNG({ width: cols * CELL_W + (cols - 1) * GAP, height: rows * CELL_H + (rows - 1) * GAP });
  for (let i = 0; i < sheet.data.length; i += 4) sheet.data.set([24, 24, 24, 255], i);
  pngs.forEach((p, i) => {
    // Nearest-neighbour fit into the cell, keeping proportions.
    const s = Math.min(CELL_W / p.width, CELL_H / p.height);
    const w = Math.round(p.width * s), h = Math.round(p.height * s);
    const ox = (i % cols) * (CELL_W + GAP) + Math.floor((CELL_W - w) / 2), oy = Math.floor(i / cols) * (CELL_H + GAP) + Math.floor((CELL_H - h) / 2);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const src = (Math.min(p.height - 1, Math.floor(y / s)) * p.width + Math.min(p.width - 1, Math.floor(x / s))) * 4;
      const dst = ((oy + y) * sheet.width + ox + x) * 4;
      sheet.data[dst] = p.data[src]; sheet.data[dst + 1] = p.data[src + 1]; sheet.data[dst + 2] = p.data[src + 2]; sheet.data[dst + 3] = 255;
    }
  });
  fs.writeFileSync(path.join(dir, "sheet.png"), PNG.sync.write(sheet));
  console.log(`${slug}: ${pngs.length} stills -> reference/sheet.png (${sheet.width}x${sheet.height})`);
}
