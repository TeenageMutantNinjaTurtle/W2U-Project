MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 995
AudioContainer CONTINUE
PlaySound 1463, SE1, 14, 8, -200, 110, 0, 0, 0
PlaySound 1426, SE2, 14, 10, 200, 95, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 11, 0, 50, 0, 0
PlaySound 1423, SE1, 16, 23, 200, 120, 0, 0, 0
PlaySound 1426, SE2, 16, 23, 0, 105, 0, 0, 0
PlaySound 1423, SE1, 16, 30, 400, 110, 0, 0, 0
PlaySound 1423, SE1, 16, 37, 100, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 0, 26, 10, 4
ChangeSpriteColor ATTACKER, 0, 6, 0, 31, 22, 10
Emit 995, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 995, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 995, 2, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 995, 3, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 4, 0, 1
Wait 12
ChangeSpriteColor ATTACKER, 6, 0, 0, 31, 22, 10
Wait 2
MoveCamera INTERPOLATION, DEFENDER, 9, 0, 8
Wait 9
Emit 995, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 995, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 995, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 995, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 995, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 995, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 995, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 31, 24, 10
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 31, 24, 10
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 9
Wait 18
ChangeBackgroundColor 4, 10, 0, 0, 26, 10, 4
Wait 16
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
