MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 986
AudioContainer CONTINUE
PlaySound 1470, SE1, 14, 0, -300, 80, 0, 0, 0
PlaySound 1407, SE2, 14, 14, 700, 105, 0, 0, 0
PlaySound 1407, SE1, 14, 18, 900, 100, 0, 0, 0
PlaySound 1425, SE2, 16, 32, 600, 115, 0, 0, 0
PlaySound 1423, SE1, 16, 37, 0, 127, 0, 0, 0
PlaySound 1475, SE2, 16, 37, 300, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 0, 2, 2, 5
ChangeSpriteColor ATTACKER, 0, 16, 0, 1, 1, 2
Emit 986, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 986, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 986, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 986, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 986, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 14
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 3, 0, 1
Wait 3
ToggleSpriteVisibility ATTACKER, 3
Wait 7
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 986, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 986, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 986, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 986, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 986, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 986, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 5
ChangeBackgroundColor 4, 10, 0, 0, 2, 2, 5
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 26, 31, 24
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 26, 31, 24
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 24
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 0, 0, 0, 1, 1, 2
ToggleSpriteVisibility ATTACKER, 4
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
