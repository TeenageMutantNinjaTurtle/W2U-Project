import { createKit, fadeOut, grow, hold, paint, setCurves, spin, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FOE_FLOOR, glow, hit, impact, intro, lunge, outro, pan, puffs, quake, ring, risers, shake, snd, sparks, streaks, tint, USER, type Pal } from "../tools/phrases";

// Lash Out (move 808) - from the Bulbapedia stills (reference/sheet.png) and
// the Scarlet/Violet screenshot and description Logan sent on 2026-10-03.
//   1. The scene goes dark red. The user seethes: violet fire streams up off
//      it, dark flecks lifting from the ground.
//   2. Small black strands whirl round the foe, starting over its head and
//      winding down round it to the ground.
//   3. As they reach the ground a great black mass slams down on the foe.
// The strands are Hurricane's swoosh (SPA 711) made small and black with a
// red glow behind; they ride the engine's "spin" behaviour, which turns a
// particle round its emitter, while they sink.

const SPA = 988;
const kit = await createKit({ workDir: import.meta.dirname, slug: "lash-out", moveId: 808, spaId: SPA, donors: [711, 228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const SEETHE = 24;
const PAN = 8;
const WIND = 14; // how long strands keep starting at the top
const SINK = 14; // how long one takes to wind down to the ground
const SLAM = WIND + SINK - 4; // the slam starts down as the last strands near the ground
const DROP = 4;
const AFTER = 26;

const VIOLET: Rgb = [0.65, 0.35, 1.0];
const PALE_VIOLET: Rgb = [0.9, 0.78, 1.0];
const DEEP: Rgb = [0.35, 0.12, 0.7];
const RED: Rgb = [1.0, 0.2, 0.12];
const DARK_RED: Rgb = [0.55, 0.03, 0.05];
const INK: Rgb = [0.02, 0.01, 0.02];
const BLACK: Rgb = [0, 0, 0];
const SOOT: Pal = [INK, [0.12, 0.03, 0.05], INK];

const user = [
  ...risers(kit, "violetFire", { frames: SEETHE, radius: 1.1, speed: 0.34, scale: 1.3, life: 9, every: 2, pal: [VIOLET, PALE_VIOLET, DEEP], streak: true }),
  ...glow(kit, "aura", { pos: USER, life: SEETHE + 4, scale: 2.7, pal: [VIOLET, DEEP, PALE_VIOLET], level: 0.7 }),
  ...risers(kit, "darkFlecks", { frames: SEETHE, radius: 1.8, speed: 0.12, scale: 0.14, life: 14, every: 3, pal: [BLACK, [0.2, 0.05, 0.1], BLACK] }),
];

// --- 2. the strands: three at a time on a ring over the foe's head, every
// few frames; each turns round the foe as it sinks to the ground ---
const TOP = 2.3, GROUND = FOE_FLOOR[1];
const swooshTex = kit.tex(711, 2);
function strands(name: string, scale: number, colours: [Rgb, Rgb, Rgb], level: number): string {
  const r = kit.parked(swooshTex, [0, TOP, 0.8], scale, SINK);
  Object.assign(r, {
    emissionType: 3, emissionAxis: 1, emissionCount: 3, radius: 1.5,
    emitterLifeFrames: WIND, emissionIntervalFrames: 3,
    axis: [0, -1, 0], initVelAxisAmplifier: (TOP - GROUND) / SINK, airResistance: 1.0,
    aspectRatio: 1.7,
  });
  r.behaviors = [{ type: "spin", axis: 1, angle: (2 * Math.PI) / 12 }];
  setCurves(r, hold(1), { start: 0, mid: level, end: 0, curveIn: 0.15, curveOut: 0.85 });
  paint(r, colours[0], colours[1], colours[2]);
  kit.add(name, r);
  return name;
}

// --- 3. the slam: a black mass dropping on the foe, and what it throws up ---
const HEAD: Vec3 = [0, 0.3, 0.9];
const drop = kit.parked(kit.tex(T.softDisc), [0, 0.3 + 4.4, 0.9], 1.9, DROP + 1);
Object.assign(drop, { startDelayFrames: SLAM, axis: [0, -1, 0], initVelAxisAmplifier: 4.4 / DROP, airResistance: 1.0, aspectRatio: 0.8 });
setCurves(drop, hold(1), hold(1));
paint(drop, INK);
kit.add("slamDrop", drop);
const dropEdge = kit.parked(kit.tex(T.fuzzyGlow), [0, 0.3 + 4.4, 0.9], 2.6, DROP + 1);
Object.assign(dropEdge, { startDelayFrames: SLAM, axis: [0, -1, 0], initVelAxisAmplifier: 4.4 / DROP, airResistance: 1.0, aspectRatio: 0.8 });
setCurves(dropEdge, hold(1), hold(0.8));
paint(dropEdge, DARK_RED, RED, DARK_RED);
kit.add("slamDropEdge", dropEdge);

const LAND = SLAM + DROP;
const foe = [
  ...glow(kit, "slamSplat", { pos: HEAD, at: LAND, life: 12, scale: 2.5, pal: [INK, INK, INK], tex: kit.tex(T.spiky), spin: 0.06, level: 1, scaleCurve: grow(0.5, 0.25, 1.25), alpha: fadeOut(1, 0.5) }),
  ...streaks(kit, "blackShards", { at: LAND, radius: 0.6, speed: 0.44, count: 9, life: 11, scale: 1.1, pal: SOOT, tex: kit.tex(T.shard) }),
  "slamDrop",
  "slamDropEdge",
  ...impact(kit, "burst", { at: LAND, pal: [RED, [1.0, 0.6, 0.5], DARK_RED], size: 1.7, rays: 8, flecks: 0 }),
  ...ring(kit, "shock", { pos: FOE_FLOOR, at: LAND + 1, life: 12, scale: 0.8, pal: [RED, [1.0, 0.6, 0.5], DARK_RED], to: 2.0, aspect: 2.6 }),
  ...puffs(kit, "blackDust", { pos: FOE_FLOOR, at: LAND + 1, radius: 1.5, count: 4, life: 16, scale: 0.9, pal: SOOT, speed: 0.14, rise: 0.02, level: 0.85 }),
  strands("strands", 0.42, [INK, DARK_RED, INK], 1),
  strands("strandGlow", 0.56, [DARK_RED, RED, DARK_RED], 0.7),
  ...sparks(kit, "redSparks", { pos: [0, 0.4, 0.9], at: 2, radius: 1.5, speed: 0.1, count: 2, bursts: WIND / 3, gap: 3, life: 10, scale: 0.13, pal: [RED, [1.0, 0.55, 0.2], [1.0, 0.8, 0.5]], shape: "circle" }),
  ...glow(kit, "violetBloom", { pos: FOE, life: LAND + 10, scale: 2.8, pal: [VIOLET, DEEP, PALE_VIOLET], level: 0.4 }),
];

const windAt = SEETHE + PAN;
const landAt = windAt + LAND;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1497, 0, { pitch: -400, vol: 95 }),
  snd(1869, 4, { ch: "SE2", pitch: -1500, vol: 80 }),
  snd(1376, SEETHE, { vol: 0 }),
  snd(1425, windAt, { side: "D", pitch: -300, vol: 110 }),
  snd(1514, windAt + 2, { ch: "SE2", side: "D", pitch: -200, vol: 105 }),
  snd(1514, windAt + 10, { ch: "SE2", side: "D", pitch: 0, vol: 105 }),
  snd(1407, windAt + SLAM, { side: "D", pitch: -500, vol: 120 }),
  snd(1705, landAt, { side: "D", pitch: -200, vol: 127 }),
  snd(1475, landAt, { ch: "SE2", side: "D", pitch: -400, vol: 125 }),
)}
${arena(0, 12, 8, [12, 1, 2])}
${tint("ATTACKER", 0, 9, 6, [22, 10, 31])}
${emits(kit, user, "ATTACKER")}
${shake("ATTACKER", 1229, SEETHE / 2 - 2)}
Wait ${SEETHE}
${lunge("ATTACKER", 4)}
${tint("ATTACKER", 9, 0, 4, [22, 10, 31])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
${shake("DEFENDER", 819, SLAM / 2)}
Wait ${LAND}
${arena(12, 15, 0, [20, 2, 3])}
${hit({ rgb: [6, 2, 3], power: 3, freeze: false })}
${arena(15, 12, 3, [12, 1, 2])}
Wait 8
${quake("2458", 6)}
Wait ${AFTER - 8 - 10}
${arena(12, 0, 8, [12, 1, 2])}
Wait 10
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [542, 63, 605, 400, 240, 129],
  references: ["reference/Lash_Out_VIII.png", "reference/Lash_Out_VIII_2.png", "reference/Lash_Out_IX.png", "reference/Lash_Out_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("violetFire")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("strands")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("slamDrop")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  seethes f${CAMERA_IN}, strands wind down f${CAMERA_IN + windAt}-${CAMERA_IN + windAt + WIND + SINK}, slam lands f${CAMERA_IN + landAt}`);
