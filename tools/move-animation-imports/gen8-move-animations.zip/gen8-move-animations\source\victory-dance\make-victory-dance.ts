import { createKit, deg, fadeOut, grow, paint, setCurves, spin, T, type Rgb } from "../tools/anim-kit";
import { audio, circleEmits, emits, glow, intro, outro, ring, risers, snd, sparks, squash, tint, USER, USER_FLOOR, vortex, WHITE } from "../tools/phrases";

// Victory Dance (move 837) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user dances: ribbons of golden light whirl round it and sweep
//      across in broad arcs, sparks of gold drifting off.
//   2. The dance ends in a blaze of yellow-white light over it, golden motes
//      floating up.
// Stays on the user; the Attack, Defense and Speed boosts are the engine's.
// The ribbons are Hurricane's swooshes (SPA 711) in gold; the sway is Quiver
// Dance's own.

const SPA = 1017;
const kit = await createKit({ workDir: import.meta.dirname, slug: "victory-dance", moveId: 837, spaId: SPA, donors: [711, 228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const DANCE = 40;
const BLAZE = 26;

const GOLD: Rgb = [1.0, 0.82, 0.2];
const YELLOW: Rgb = [1.0, 0.95, 0.4];
const PALE: Rgb = [1.0, 0.98, 0.8];
const LIME: Rgb = [0.8, 1.0, 0.4];
const AMBER: Rgb = [1.0, 0.6, 0.1];

// The whirl of ribbons: wide, slow and faint, so it reads as a glow turning
// round the dance rather than a wind.
const ribbons = vortex(kit, "ribbons", { frames: DANCE - 14, pal: [GOLD, PALE, LIME], widen: 1.6, life: 18, pace: 0.6, alpha: 0.6 });
// Arcs sweeping close round it, one for each turn of the dance: a leaf-green
// blade that burns out to orange, inside an orange one.
const GREEN: Rgb = [0.55, 0.95, 0.3];
const PALE_GREEN: Rgb = [0.85, 1.0, 0.6];
const ORANGE: Rgb = [1.0, 0.62, 0.15];
const sweeps: string[] = [];
for (const [i, [at, tilt, height]] of ([[2, -25, -0.1], [14, 20, 0.7], [26, -10, 0.1]] as const).entries()) {
  for (const [layer, scale, colours] of [["", 1.0, [GREEN, PALE_GREEN, ORANGE]], ["Glow", 1.2, [ORANGE, LIME, AMBER]]] as const) {
    const r = kit.parked(kit.tex(T.bladeArc), [0, height, 0.3], scale, 11);
    r.startDelayFrames = at;
    r.aspectRatio = 1.6; // the arch sits in the top of its texture, so each arc is centred a little off the user to pass close over or under it
    spin(r, 0, 0, deg(tilt + (i % 2 ? 180 : 0)));
    setCurves(r, grow(0.4, 0.3, 1.2), fadeOut(1, 0.4));
    paint(r, colours[0] as Rgb, colours[1] as Rgb, colours[2] as Rgb);
    kit.add(`sweep${layer}${i}`, r);
    sweeps.push(`sweep${layer}${i}`);
  }
}
const user = [
  ...sweeps,
  ...sparks(kit, "goldDust", { pos: USER, radius: 2.0, speed: 0.04, count: 1, bursts: DANCE / 3, gap: 3, life: 12, scale: 0.3, pal: [YELLOW, WHITE, GOLD], shape: "sphere", tex: kit.tex(T.sparkle4) }),
  // --- 2. the blaze ---
  ...sparks(kit, "finish", { pos: USER, at: DANCE, radius: 1.0, speed: 0.2, count: 8, life: 14, scale: 0.32, pal: [WHITE, YELLOW, GOLD], shape: "circle", tex: kit.tex(T.sparkle4) }),
  ...risers(kit, "motes", { pos: USER_FLOOR, at: DANCE, frames: BLAZE - 8, radius: 1.5, speed: 0.1, scale: 0.16, life: 16, every: 2, pal: [YELLOW, WHITE, GOLD] }),
  ...ring(kit, "halo", { pos: USER, at: DANCE, life: 14, scale: 1.4, pal: [YELLOW, WHITE, GOLD], to: 2.2 }),
  ...glow(kit, "blaze", { pos: USER, at: DANCE - 2, life: BLAZE, scale: 3.2, pal: [YELLOW, PALE, GOLD], level: 0.9 }),
  ...glow(kit, "warmth", { pos: USER, life: DANCE, scale: 2.8, pal: [GOLD, AMBER, YELLOW], level: 0.45 }),
];

const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1862, 0, { vol: 120 }),
  snd(1820, 14, { ch: "SE2", vol: 100 }),
  snd(1820, 26, { ch: "SE2", pitch: 200, vol: 100 }),
  snd(1452, DANCE, { vol: 115 }),
  snd(1784, DANCE + 2, { ch: "SE2", pitch: 200, vol: 105 }),
)}
${circleEmits(kit, ribbons, "ATTACKER")}
${emits(kit, user, "ATTACKER")}
MoveSprite ATTACKER, ROUNDTRIP, 2, 2px, 2px, 40960, 0, 12288, 0
Wait 12
${squash("ATTACKER", 819, -819, 5)}
Wait 12
${squash("ATTACKER", -819, 819, 5)}
Wait ${DANCE - 24}
${tint("ATTACKER", 0, 12, 4, [31, 30, 14])}
${squash("ATTACKER", -1229, 1229, 6)}
Wait ${BLAZE - 10}
${tint("ATTACKER", 12, 0, 8, [31, 30, 14])}
Wait 10
${outro({ unfreeze: "NONE" })}`;

await kit.finish({
  script,
  donorMoveIds: [542, 483, 427, 63, 605, 240, 129],
  references: ["reference/Victory_Dance_LA.png", "reference/Victory_Dance_IX.png", "reference/Victory_Dance_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `EmitCircle ${SPA}, ${kit.idx("ribbonsInner")}, ATTACKER_LEFT`, `Emit ${SPA}, ${kit.idx("sweep0")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("blaze")}, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  dance f${CAMERA_IN}-${CAMERA_IN + DANCE}, blaze until f${CAMERA_IN + DANCE + BLAZE}`);
