import { aimed, createKit, setCurves, T, twinkle, type Rgb } from "../tools/anim-kit";
import { arena, audio, beam, emits, FOE, FRONT, glow, hit, intro, outro, pan, puffs, shake, snd, sparks, tint, WHITE, type Pal } from "../tools/phrases";

// Strange Steam (move 790) - from the Bulbapedia stills (reference/sheet.png).
//   1. Night. The user breathes out a wide, soft stream of pastel steam -
//      pink, lilac and mint - with glitter in it, pale green puffs rolling
//      off its mouth.
//   2. It washes over the foe in a glittering pastel cloud.

const SPA = 970;
const kit = await createKit({ workDir: import.meta.dirname, slug: "strange-steam", moveId: 790, spaId: SPA, donors: [228, 465, 321, 298, 407] });

const CAMERA_IN = 10;
const INHALE = 12;
const TRAVEL = 10;
const POUR = 26;
const AFTER = 20;

const PINK: Rgb = [1.0, 0.7, 0.92];
const LILAC: Rgb = [0.82, 0.7, 1.0];
const MINT: Rgb = [0.72, 1.0, 0.85];
const PALE: Rgb = [0.97, 0.94, 1.0];
const GREEN: Rgb = [0.8, 0.92, 0.5];
const PASTEL: Pal = [PINK, MINT, LILAC];

const user = [
  ...puffs(kit, "mouthPuffs", { pos: FRONT, at: INHALE - 4, radius: 0.9, count: 1, bursts: (POUR + 4) / 3, gap: 3, life: 14, scale: 0.6, pal: [GREEN, [0.9, 1.0, 0.7], [0.65, 0.8, 0.4]], speed: 0.07, level: 0.9 }),
  ...glow(kit, "mouthGlow", { pos: FRONT, at: INHALE - 2, life: POUR + 4, scale: 1.4, pal: [PALE, WHITE, MINT], level: 0.85 }),
];
const stream = [
  ...beam(kit, "steam", { at: INHALE, pour: POUR, travel: TRAVEL, width: 1.35, pal: [LILAC, PINK, PINK], core: MINT, tex: kit.tex(T.softDisc) }),
];
// Glitter carried along in the stream.
const glitter = kit.spray([333, 1], kit.tex(T.dot), FRONT, { radius: 0.9, speed: 0.01, count: 1, bursts: POUR / 2, gap: 2, life: TRAVEL + 2, scale: 0.12, shape: "ball" });
glitter.startDelayFrames = INHALE;
aimed(glitter, 16 / TRAVEL, TRAVEL + 2);
glitter.airResistance = 1.0;
glitter.variance.lifeTime = 0;
setCurves(glitter, undefined, twinkle());
kit.prism(glitter, [WHITE, [1.0, 0.95, 0.5], MINT]);
kit.add("glitter", glitter);
stream.push("glitter");

const foe = [
  ...sparks(kit, "twinkles", { pos: [0, 0.5, 1.0], radius: 1.7, speed: 0, count: 1, bursts: POUR / 3, gap: 3, life: 9, scale: 0.36, pal: [WHITE, [1.0, 0.95, 0.6], MINT], shape: "ball", tex: kit.tex(T.sparkle4) }),
  ...puffs(kit, "cloudPink", { pos: FOE, radius: 1.1, count: 1, bursts: POUR / 4, gap: 4, life: 16, scale: 1.2, pal: [PINK, PALE, LILAC], speed: 0.07, level: 0.75, to: 1.6 }),
  ...puffs(kit, "cloudMint", { pos: [0.3, 0.5, 0.7], at: 2, radius: 1.1, count: 1, bursts: POUR / 4, gap: 4, life: 16, scale: 1.0, pal: [MINT, PALE, GREEN], speed: 0.07, level: 0.7, to: 1.6 }),
  ...glow(kit, "wash", { pos: FOE, life: POUR + 8, scale: 3.0, pal: [LILAC, PINK, MINT], level: 0.6 }),
  ...sparks(kit, "specks", { radius: 1.2, speed: 0.12, count: 2, bursts: POUR / 3, gap: 3, life: 12, scale: 0.12, pal: PASTEL, fall: -0.006 }),
];

const landAt = INHALE + TRAVEL;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1445, INHALE - 4, { pitch: 900, vol: 100 }),
  snd(1474, INHALE, { ch: "SE2", vol: 85 }),
  `SwitchAudioSide SE1, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0`,
  snd(1463, landAt, { ch: "SE2", side: "D", pitch: 400, vol: 105 }),
  snd(1784, landAt + 4, { side: "D", pitch: 300, vol: 100 }),
  snd(1420, landAt + 2, { ch: "SE2", side: "D", pitch: 300, vol: 100 }),
)}
${arena(0, 10, 8, [2, 4, 12])}
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, ${INHALE - 2}, 0, 1
${emits(kit, user, "ATTACKER")}
${emits(kit, stream, "ATTACKER", "DEFENDER")}
Wait ${INHALE}
${tint("ATTACKER", 0, 6, 3, [28, 24, 31])}
${shake("ATTACKER", 819, POUR / 2)}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [29, 26, 31], power: 2 })}
${shake("DEFENDER", 819, POUR / 2 - 4)}
Wait ${POUR - 8}
${tint("ATTACKER", 6, 0, 4, [28, 24, 31])}
${arena(10, 0, 8, [2, 4, 12])}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 153, 129, 236],
  references: ["reference/Strange_Steam_VIII.png", "reference/Strange_Steam_VIII_2.png", "reference/Strange_Steam_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("steamJet")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("cloudPink")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  breath f${CAMERA_IN + INHALE}-${CAMERA_IN + INHALE + POUR}, reaches foe f${CAMERA_IN + landAt}`);
