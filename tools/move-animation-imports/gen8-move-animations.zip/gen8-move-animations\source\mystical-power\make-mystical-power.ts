import { createKit, grow, T, type Rgb } from "../tools/anim-kit";
import { audio, emits, FOE, gather, glow, hit, impact, intro, outro, pan, ring, snd, sparks, streaks, tint, USER, WHITE } from "../tools/phrases";

// Mystical Power (move 832) - from the Bulbapedia stills (reference/sheet.png).
//   1. A pink light gathers on the user, rings of it pulsing out, sparkling.
//   2. A sphere of the same pink force closes round the foe: a bright rim,
//      pale rings turning inside it, arcs of magenta and cyan sweeping round.
//   3. It bursts in streaks and sparkles.
// The Sp. Atk boost is the engine's.

const SPA = 1012;
const kit = await createKit({ workDir: import.meta.dirname, slug: "mystical-power", moveId: 832, spaId: SPA, donors: [228, 465, 579, 411, 298, 560] });

const CAMERA_IN = 10;
const CHARGE = 20;
const PAN = 10;
const SPHERE = 22;
const AFTER = 18;

const PINK: Rgb = [1.0, 0.45, 0.8];
const PALE: Rgb = [1.0, 0.86, 0.95];
const MAGENTA: Rgb = [0.95, 0.2, 0.65];
const CYAN: Rgb = [0.6, 0.92, 1.0];
const VIOLET: Rgb = [0.68, 0.45, 1.0];

const user = [
  ...gather(kit, "charge", { frames: CHARGE, pal: [PINK, PALE, MAGENTA], radius: 2.2 }),
  ...ring(kit, "pulse0", { pos: USER, at: 3, life: 10, scale: 1.3, pal: [PINK, WHITE, MAGENTA], to: 1.9 }),
  ...ring(kit, "pulse1", { pos: USER, at: 10, life: 10, scale: 1.3, pal: [PALE, WHITE, PINK], to: 1.9 }),
  ...sparks(kit, "twinkles", { pos: USER, radius: 1.9, speed: 0, count: 1, bursts: CHARGE / 4, gap: 4, life: 9, scale: 0.3, pal: [WHITE, PALE, PINK], shape: "sphere", tex: kit.tex(T.sparkle4) }),
];

const foe = [
  // The arcs sweeping round it, drawn over the sphere.
  ...glow(kit, "arcs", { pos: FOE, life: SPHERE, scale: 2.5, pal: [MAGENTA, PALE, VIOLET], tex: kit.tex(T.crescent), spin: 0.5, level: 0.9, scaleCurve: grow(0.4, 0.3, 1.05) }),
  ...glow(kit, "arcsBack", { pos: FOE, at: 2, life: SPHERE - 2, scale: 2.1, pal: [CYAN, WHITE, VIOLET], tex: kit.tex(T.crescent), spin: -0.4, angle: 3.14, level: 0.8, scaleCurve: grow(0.4, 0.3, 1.05) }),
  ...glow(kit, "bands", { pos: FOE, life: SPHERE, scale: 2.0, pal: [PALE, WHITE, PINK], tex: kit.tex(T.thinRings), spin: 0.22, level: 0.75, scaleCurve: grow(0.3, 0.3, 1.05) }),
  ...ring(kit, "rim", { life: SPHERE, scale: 2.3, pal: [PINK, PALE, MAGENTA], to: 1.05, level: 0.95 }),
  ...glow(kit, "body", { pos: FOE, life: SPHERE, scale: 2.3, pal: [PINK, PALE, MAGENTA], tex: kit.tex(T.softDisc), level: 0.5, scaleCurve: grow(0.3, 0.3, 1.05) }),
  ...sparks(kit, "glints", { at: 2, radius: 2.0, speed: 0, count: 1, bursts: SPHERE / 3, gap: 3, life: 8, scale: 0.32, pal: [WHITE, PALE, CYAN], shape: "sphere", tex: kit.tex(T.sparkle4) }),
  // --- 3. the burst ---
  ...impact(kit, "burst", { at: SPHERE - 4, pal: [PALE, WHITE, PINK], size: 1.5, rays: 8, flecks: 0 }),
  ...ring(kit, "burstRing", { at: SPHERE - 4, life: 12, scale: 1.6, pal: [PINK, WHITE, MAGENTA], to: 2.2 }),
  ...streaks(kit, "lances", { at: SPHERE - 4, radius: 0.8, speed: 0.44, count: 9, life: 10, scale: 0.9, pal: [PINK, CYAN, VIOLET] }),
  ...sparks(kit, "afterglow", { at: SPHERE - 2, radius: 1.4, speed: 0.12, count: 6, life: 14, scale: 0.28, pal: [WHITE, PALE, PINK], shape: "circle", tex: kit.tex(T.sparkle4) }),
];

const sphereAt = CHARGE + PAN;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1510, 0, { pitch: 300, vol: 105 }),
  snd(1474, 3, { ch: "SE2", vol: 95 }),
  snd(1474, 10, { ch: "SE2", pitch: 200, vol: 95 }),
  snd(1505, sphereAt, { side: "D", vol: 115 }),
  snd(1455, sphereAt + 2, { ch: "SE2", side: "D", pitch: 300, vol: 105 }),
  snd(1475, sphereAt + SPHERE - 4, { side: "D", pitch: 200, vol: 120 }),
  snd(1784, sphereAt + SPHERE - 2, { ch: "SE2", side: "D", vol: 100 }),
)}
${tint("ATTACKER", 0, 9, 6, [31, 18, 27])}
${emits(kit, user, "ATTACKER")}
Wait ${CHARGE}
${tint("ATTACKER", 9, 0, 4, [31, 18, 27])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
Wait 2
${hit({ rgb: [31, 20, 28], power: 1 })}
Wait ${SPHERE - 4 - 2}
${hit({ rgb: [31, 26, 30], power: 2, freeze: false })}
Wait ${4 + AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 381],
  references: ["reference/Mystical_Power_LA.png", "reference/Mystical_Power_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("chargeGlow")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("rim")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("burstFlash")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  charge f${CAMERA_IN}, sphere f${CAMERA_IN + sphereAt}-${CAMERA_IN + sphereAt + SPHERE}, burst f${CAMERA_IN + sphereAt + SPHERE - 4}`);
