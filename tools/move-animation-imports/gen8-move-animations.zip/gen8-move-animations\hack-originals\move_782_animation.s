MoveCamera INTERPOLATION, ATTACKER, 10, 0, 6
LoadBackground 159
AudioContainer CONTINUE
PlaySound 1736, SE2, 14, 0, 2000, 30, 0, 0, 0
AdjustSound SE2, 0, 1, 30, 0, 80, 10, 0, 0
PlaySound 1376, SE2, 14, 90, 0, 0, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 16, 0, 90, 0, 0
AudioContainer SUSPEND
ApplyBackground 2, 0
ChangeBackgroundColor 4, 0, 13, 0, 0, 0, 0
LetCMDsFinish ALL
ChangeBackgroundColor 3, 13, 0, 1, 0, 0, 0
MoveBackground INTERPOLATION_DIRECT, 36, 0, 120, 0, 0
ApplyBackground OFF, 1
ApplyBackground ON, 1
ToggleSpriteShadow ATTACKER, ON
ToggleSpriteShadow DEFENDER, ON
AudioContainer CONTINUE
PlaySound 1848, SE1, 16, 0, 0, 70, 0, 0, 0
PlaySound 1819, SE1, 16, 0, 800, 120, 0, 0, 0
PlaySound 1376, SE1, 16, 65, 0, 0, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 16, 0, 30, 0, 0
AudioContainer SUSPEND
AudioContainer CONTINUE
PlaySound 1424, SE1, 16, 30, 0, 127, 0, 0, 0
PlaySound 1424, SE1, 16, 45, 0, 30, 0, 0, 0
AudioContainer SUSPEND
LoadSPA 826
ToggleSpriteVisibility ATTACKER, 3
Emit 826, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 18
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 6
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 2, 30, 0, 0
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 8
Emit 826, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
LetCMDsFinish PARTICLE
ChangeBackgroundColor 3, 0, 13, 1, 0, 0, 0
LetCMDsFinish PARTICLE
ToggleSpriteVisibility ATTACKER, 4
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor DEFENDER, 12, 0, 2, 30, 0, 0
ToggleSpriteShadow ATTACKER, OFF
ToggleSpriteShadow DEFENDER, OFF
ChangeBackgroundColor 2, 13, 0, 0, 0, 0, 0
ApplyBackground OFF, 0
ApplyBackground ON, 0
ApplyBackground 2, 1
ChangeBackgroundColor 3, 13, 0, 0, 0, 0, 0
ChangeBackgroundColor 4, 13, 0, 0, 0, 0, 0
MoveCamera INTERPOLATION, INIT, 10, 0, 6
LetCMDsFinish ALL
TerminateMoveScript
