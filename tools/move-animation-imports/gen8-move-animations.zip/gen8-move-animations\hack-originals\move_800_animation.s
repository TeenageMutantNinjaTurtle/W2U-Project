.include "B2W2_MOVSCRCMD.s"
.align 4

.word 2 @ Count
.word SCRIPT_116
.word SCRIPT_116
.word SCRIPT_116
.word SCRIPT_116
.word SCRIPT_116
.word SCRIPT_116
.word SCRIPT_116
.word SCRIPT_116
.word SCRIPT_116
.word SCRIPT_116
.word SCRIPT_116
.word SCRIPT_116
.word SCRIPT_116
.word SCRIPT_116
.word SCRIPT_902
.word SCRIPT_902
.word SCRIPT_902
.word SCRIPT_902
.word SCRIPT_902
.word SCRIPT_902
.word SCRIPT_902
.word SCRIPT_902
.word SCRIPT_902
.word SCRIPT_902
.word SCRIPT_902
.word SCRIPT_902
.word SCRIPT_902
.word SCRIPT_902

SCRIPT_116:
     LoadBackground 126
     ApplyBackground 2, 0
     ChangeBackgroundColor 4, 0, 13, 2, 0, 0, 0
     MoveCamera INTERPOLATION, ZOOM_OUT_ATTACKER, 16, 0, 8
     LetCMDsFinish ALL
     ApplyBackground OFF, 1
     ApplyBackground ON, 1
     ChangeBackgroundColor 3, 13, 0, 2, 0, 0, 0
     ToggleSpriteShadow ATTACKER, ON
     ToggleSpriteShadow DEFENDER, ON
     AudioContainer CONTINUE
     PlaySound 1434, SE1, 14, 0, -800, 120, 0, 0, 0
     PlaySound 1425, SE2, 14, 0, 0, 100, 0, 0, 0
     PlaySound 1376, SE2, 14, 50, 0, 0, 0, 0, 0
     AudioContainer SUSPEND
     MoveBackground INTERPOLATION_DIRECT, 0, 1, 100, 0, 0
     LoadSPA 417
     Emit 417, 3, ATTACKER, NONE, 0, 0, 0, 1x, 1x, 1x, 1x
     Wait 20
     LoadSPA 560
     Emit 560, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
     Emit 560, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
     AudioContainer CONTINUE
     PlaySound 1474, SE1, 14, 0, 0, 80, 0, 0, 0
     PlaySound 1784, SE2, 14, 0, 0, 110, 0, 0, 0
     PlaySound 1509, SE1, 14, 40, -50, 70, 0, 0, 0
     AudioContainer SUSPEND
     ChangeBackgroundColor 3, 0, 13, 1, 0, 0, 0
     ChangeSpriteColor ATTACKER, 0, 12, 0, 31, 31, 31
     LetCMDsFinish ALL
     Wait 20
     ToggleSpriteShadow ATTACKER, OFF
     ToggleSpriteShadow DEFENDER, OFF
     ApplyBackground OFF, 0
     ApplyBackground ON, 0
     MoveCamera INTERPOLATION, INIT, 16, 0, 8
     ChangeBackgroundColor 2, 13, 0, 1, 0, 0, 0
     ChangeSpriteColor ATTACKER, 12, 0, 0, 31, 31, 31
     LetCMDsFinish ALL
     ApplyBackground 2, 1
     ChangeBackgroundColor 4, 13, 0, 0, 0, 0, 0
     ChangeBackgroundColor 3, 13, 0, 0, 0, 0, 0
     TerminateMoveScript

SCRIPT_902:
     ChangeSpriteColor DEFENDER, 0, 13, 2, 0, 0, 0
     ChangeBackgroundColor 4, 0, 13, 2, 0, 0, 0
     MoveCamera INTERPOLATION, ATTACKER, 16, 0, 8
     LetCMDsFinish ALL
     ChangeBackgroundColor 3, 13, 0, 2, 0, 0, 0
     ToggleSpriteShadow ATTACKER, ON
     ToggleSpriteShadow DEFENDER, ON
     AudioContainer CONTINUE
     PlaySound 1416, SE1, 14, 0, 0, 127, 0, 0, 0
     PlaySound 1376, SE1, 14, 70, 0, 0, 0, 0, 0
     AdjustSound SE1, 0, 0, -1000, 2000, 0, 70, 0, 0
     AdjustSound SE1, 0, 1, 120, 0, 60, 10, 0, 0
     SwitchAudioSide SE2, INTERPOLATION, 14, 14, 0, 70, 0, 0
     AudioContainer SUSPEND
     LoadSPA 618
     Emit 618, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
     Emit 618, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
     Wait 50
     AudioContainer CONTINUE
     PlaySound 1721, SE2, 14, 0, 200, 75, 0, 0, 0
     SwitchAudioSide SE1, INTERPOLATION, 14, 14, 0, 60, 0, 0
     AudioContainer SUSPEND
     LoadSPA 272
     Emit 272, 0, ATTACKER, NONE, 0.5px, 0, 0, 1x, 1x, 1x, 1x
     ChangeSpriteColor DEFENDER, 13, 0, 2, 0, 0, 0
     ApplyBackground OFF, 0
     LetCMDsFinish ALL
     AudioContainer CONTINUE
     PlaySound 1975, SE1, 14, 0, 0, 127, 0, 0, 0
     AudioContainer SUSPEND
     ChangeBackgroundColor 2, 0, 16, 0, 0, 0, 0
     LetCMDsFinish ALL
     ChangeBackgroundColor 3, 16, 0, 0, 0, 0, 0
     MoveCamera INTERPOLATION, ATTACKER, 16, 0, 12
     LoadBackground 126
     ApplyBackground OFF, 1
     ApplyBackground ON, 1
     ApplyBackground 2, 0
     MoveBackground INTERPOLATION_DIRECT, 0, 5, 140, 1, 0
     Wait 6
     ToggleFreezeSprite ATTACKER, START
     Wait 20
     MoveCamera INTERPOLATION, DEFENDER, 58, 0, 50
     AudioContainer CONTINUE
     PlaySound 1424, SE1, 14, 0, -300, 120, 0, 0, 0
     PlaySound 1376, SE1, 14, 100, 0, 0, 0, 0, 0
     PlaySound 1962, SE2, 14, 0, 0, 100, 0, 0, 0
     PlaySound 1475, SE2, 16, 50, 0, 127, 0, 0, 0
     PlaySound 1475, SE2, 16, 58, 0, 127, 0, 0, 0
     PlaySound 1475, SE2, 16, 66, 0, 127, 0, 0, 0
     PlaySound 1475, SE2, 16, 74, 0, 127, 0, 0, 0
     AdjustSound SE1, 0, 0, 0, 2000, 0, 50, 0, 0
     AdjustSound SE1, 0, 1, 120, 0, 80, 20, 0, 0
     AdjustSound SE2, 0, 1, 125, 0, 60, 40, 0, 0
     SwitchAudioSide SE1, INTERPOLATION, 14, 16, 0, 50, 0, 0
     SwitchAudioSide SE2, INTERPOLATION, 14, 16, 0, 50, 0, 0
     AudioContainer SUSPEND
     LoadSPA 228
     Emit 228, 0, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
     Emit 228, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
     Emit 228, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
     Emit 228, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
     Wait 14
     ShakeSprite DEFENDER, 2, 1229, 0, 1, 2, 8
     Emit 618, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
     Emit 618, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
     LoadSPA 419
     Emit 419, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
     Emit 419, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
     Wait 58
     ChangeBackgroundColor 3, 0, 16, 1, 0, 0, 0
     LetCMDsFinish ALL
     ChangeBackgroundColor 2, 16, 0, 0, 0, 0, 0
     ApplyBackground OFF, 0
     ApplyBackground ON, 0
     ApplyBackground 2, 1
     ToggleFreezeSprite ATTACKER, STOP
     MoveCamera INTERPOLATION, INIT, 16, 0, 12
     LetCMDsFinish ALL
     ChangeBackgroundColor 4, 13, 0, 0, 0, 0, 0
     ChangeBackgroundColor 3, 16, 0, 0, 0, 0, 0
     ToggleSpriteShadow ATTACKER, OFF
     ToggleSpriteShadow DEFENDER, OFF
     TerminateMoveScript
