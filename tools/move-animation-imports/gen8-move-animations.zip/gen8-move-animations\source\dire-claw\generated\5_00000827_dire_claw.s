MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1007
AudioContainer CONTINUE
PlaySound 1407, SE1, 14, 7, 300, 115, 0, 0, 0
PlaySound 1514, SE1, 16, 16, 200, 127, 0, 0, 0
PlaySound 1514, SE2, 16, 18, 500, 115, 0, 0, 0
PlaySound 1727, SE1, 16, 21, 400, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 7, 0, 20, 10, 31
Emit 1007, 11, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 4, 0, 1
Wait 9
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 4px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 7, 0, 0, 20, 10, 31
MoveCamera INTERPOLATION, DEFENDER, 7, 0, 8
Wait 7
Emit 1007, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1007, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1007, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1007, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1007, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1007, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1007, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1007, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1007, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1007, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1007, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 2
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 22, 31, 26
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 22, 31, 26
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 24
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
