MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 971
AudioContainer CONTINUE
PlaySound 1509, SE1, 14, 6, 1000, 90, 0, 0, 0
PlaySound 1445, SE2, 14, 15, 1600, 85, 0, 0, 0
PlaySound 1511, SE1, 14, 18, 900, 105, 0, 0, 0
PlaySound 1427, SE2, 14, 22, 0, 115, 0, 0, 0
PlaySound 1784, SE1, 14, 34, 300, 95, 0, 0, 0
AudioContainer SUSPEND
Emit 971, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 971, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 971, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 971, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 971, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 971, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 971, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 971, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 971, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 971, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 971, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 971, 11, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 18
ChangeSpriteColor ATTACKER, 0, 10, 0, 18, 31, 22
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 4, 0, 1
Wait 30
ChangeSpriteColor ATTACKER, 10, 0, 0, 18, 31, 22
Wait 10
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
