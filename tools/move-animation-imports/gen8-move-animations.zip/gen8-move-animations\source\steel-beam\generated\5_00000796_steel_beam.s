MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 976
AudioContainer CONTINUE
PlaySound 1487, SE1, 14, 0, 0, 110, 0, 0, 0
PlaySound 1435, SE2, 14, 8, -300, 105, 0, 0, 0
PlaySound 1437, SE2, 14, 35, -1000, 127, 0, 0, 0
PlaySound 1975, SE1, 14, 35, 300, 115, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 8, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 43, -300, 127, 0, 0, 0
PlaySound 1435, SE2, 16, 45, -500, 120, 0, 0, 0
PlaySound 1420, SE1, 16, 55, 0, 120, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 9, 0, 4, 6, 14
ChangeSpriteColor ATTACKER, 0, 8, 0, 20, 24, 31
Emit 976, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 976, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 976, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 976, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 976, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 976, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 976, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 976, 7, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 976, 8, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 976, 9, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 11
Wait 35
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -2px, 49152, 0, 4096, 0
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 12
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 976, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 976, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 976, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 976, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 976, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 976, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 976, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeBackgroundColor 4, 13, 13, 0, 26, 29, 31
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 26, 29, 31
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 26, 29, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 13, 9, 0, 4, 6, 14
Wait 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 8
ChangeSpriteColor ATTACKER, 8, 0, 0, 20, 24, 31
ChangeBackgroundColor 4, 9, 0, 0, 4, 6, 14
Wait 26
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
