MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 950
AudioContainer CONTINUE
PlaySound 1474, SE1, 14, 0, 0, 85, 0, 0, 0
PlaySound 1523, SE2, 14, 4, 300, 105, 0, 0, 0
PlaySound 1445, SE1, 14, 14, 1500, 75, 0, 0, 0
PlaySound 1784, SE2, FLAT, 34, 0, 105, 0, 0, 0
PlaySound 1779, SE1, FLAT, 46, 300, 110, 0, 0, 0
PlaySound 1509, SE2, FLAT, 50, 500, 85, 0, 0, 0
AudioContainer SUSPEND
Emit 950, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 950, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 950, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 950, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 950, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 950, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 950, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 950, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 950, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 24
MoveCamera INTERPOLATION, INIT, 10, 0, 8
Wait 10
Emit 950, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 950, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 950, 11, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 950, 12, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 950, 13, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 950, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 950, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 950, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 950, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 950, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 12
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 4, 0, 1
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 4, 0, 1
Wait 8
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 4, 0, 1
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 4, 0, 1
Wait 8
LetCMDsFinish PARTICLE
LetCMDsFinish ALL
TerminateMoveScript
