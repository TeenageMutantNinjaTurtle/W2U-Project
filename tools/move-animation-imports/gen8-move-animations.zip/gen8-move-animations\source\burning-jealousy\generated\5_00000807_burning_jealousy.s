MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 987
AudioContainer CONTINUE
PlaySound 1426, SE1, 14, 0, 0, 115, 0, 0, 0
PlaySound 1425, SE2, 14, 4, -300, 100, 0, 0, 0
PlaySound 1376, SE2, 14, 28, 0, 0, 0, 0, 0
PlaySound 1425, SE1, 14, 28, 200, 120, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 9, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 37, -200, 120, 0, 0, 0
PlaySound 1426, SE2, 16, 37, 0, 120, 0, 0, 0
PlaySound 1426, SE2, 16, 49, -200, 100, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 11, 0, 18, 2, 4
ChangeSpriteColor ATTACKER, 0, 8, 0, 31, 20, 8
Emit 987, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 9, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 10, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 10
Wait 28
ChangeSpriteColor ATTACKER, 8, 0, 0, 31, 20, 8
MoveCamera INTERPOLATION, DEFENDER, 9, 0, 8
Wait 9
Emit 987, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 987, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 27, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 27, 12
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 4
Wait 8
ChangeBackgroundColor 4, 11, 0, 0, 18, 2, 4
Wait 18
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
