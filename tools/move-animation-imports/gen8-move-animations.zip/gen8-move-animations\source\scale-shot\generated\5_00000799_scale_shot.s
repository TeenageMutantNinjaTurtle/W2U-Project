LoadSPA 979
AudioContainer CONTINUE
PlaySound 1539, SE1, 14, 4, 300, 110, 0, 0, 0
PlaySound 1539, SE2, 14, 6, 420, 110, 0, 0, 0
PlaySound 1539, SE1, 14, 8, 540, 110, 0, 0, 0
PlaySound 1423, SE2, 16, 11, 400, 105, 0, 0, 0
PlaySound 1423, SE1, 16, 13, 500, 105, 0, 0, 0
PlaySound 1423, SE2, 16, 15, 600, 105, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 6, 0, 26, 27, 31
Emit 979, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 979, 0, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 4
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 2px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 6, 0, 0, 26, 27, 31
Wait 7
Emit 979, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 979, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 979, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 979, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 979, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 10, 10, 0, 27, 22, 31
Wait 2
ChangeSpriteColor DEFENDER, 10, 0, 0, 27, 22, 31
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 2, 0, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 6
Wait 16
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
