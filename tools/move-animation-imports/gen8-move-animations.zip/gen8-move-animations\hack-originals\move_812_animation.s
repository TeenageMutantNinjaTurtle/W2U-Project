MoveCamera INTERPOLATION, ATTACKER, 10, 0, 6
LetCMDsFinish ALL
AudioContainer CONTINUE
PlaySound 1505, SE1, 14, 0, 0, 115, 0, 0, 0
AudioContainer SUSPEND
AudioContainer CONTINUE
PlaySound 1510, SE2, 16, 10, 0, 115, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 16, 5, 30, 0, 0
AudioContainer SUSPEND
AudioContainer CONTINUE
PlaySound 1543, SE1, 14, 45, 0, 120, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 16, 14, 40, 40, 0, 0
AudioContainer SUSPEND
AudioContainer CONTINUE
PlaySound 1420, SE2, 16, 35, 0, 100, 0, 0, 0
AudioContainer SUSPEND
AudioContainer CONTINUE
PlaySound 1452, SE2, 14, 85, 0, 115, 0, 0, 0
AudioContainer SUSPEND
LoadSPA 821
LoadSPA 632
Emit 821, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
EmitProjectile 821, 1, STRAIGHT, ATTACKER, DEFENDER, 2px, 30f, 0, 1x, 1x, 0
ToggleSpriteVisibility ATTACKER, 3
Wait 1
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 6
Wait 19
Emit 821, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
EmitProjectile 821, 2, CURVE, DEFENDER, ATTACKER, 2px, 50f, 6px, 1x, 1x, 0
Emit 632, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 632, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 632, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 821, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
MoveSprite DEFENDER, ROUNDTRIP, 2, 0, 2px, 24576, 8192, 4096, 0
Wait 16
MoveCamera INTERPOLATION, ATTACKER, 10, 0, 6
Emit 821, 0, ATTACKER, NONE, 3px, 0, 0, 1x, 1x, 1x, 1x
Wait 50
ToggleSpriteVisibility ATTACKER, 4
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
