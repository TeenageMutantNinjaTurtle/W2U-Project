MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1012
AudioContainer CONTINUE
PlaySound 1510, SE1, 14, 0, 300, 105, 0, 0, 0
PlaySound 1474, SE2, 14, 3, 0, 95, 0, 0, 0
PlaySound 1474, SE2, 14, 10, 200, 95, 0, 0, 0
PlaySound 1505, SE1, 16, 30, 0, 115, 0, 0, 0
PlaySound 1455, SE2, 16, 32, 300, 105, 0, 0, 0
PlaySound 1475, SE1, 16, 48, 200, 120, 0, 0, 0
PlaySound 1784, SE2, 16, 50, 0, 100, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 9, 0, 31, 18, 27
Emit 1012, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1012, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1012, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1012, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1012, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 20
ChangeSpriteColor ATTACKER, 9, 0, 0, 31, 18, 27
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
Emit 1012, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1012, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1012, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1012, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1012, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1012, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1012, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1012, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1012, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1012, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1012, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1012, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 2
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 10, 10, 0, 31, 20, 28
Wait 2
ChangeSpriteColor DEFENDER, 10, 0, 0, 31, 20, 28
ScaleSprite DEFENDER, ROUNDTRIP, 819, -819, 2, 0, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 6
Wait 16
ChangeSpriteColor DEFENDER, 13, 13, 0, 31, 26, 30
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 31, 26, 30
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 22
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
