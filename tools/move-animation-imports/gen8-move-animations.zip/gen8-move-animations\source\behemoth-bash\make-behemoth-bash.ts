import { createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, FOE, glow, hit, impact, intro, outro, pan, quake, ring, risers, shake, shot, snd, sparks, streaks, tint, USER, WHITE, type Pal } from "../tools/phrases";

// Behemoth Bash (move 782) - from the Bulbapedia stills (reference/sheet.png).
//   1. The arena darkens; the user burns red and a huge red shield of light
//      spreads in front of it, red motes rising.
//   2. It charges behind the shield, red and magenta speed lines streaming
//      past.
//   3. It slams into the foe: a white-hot burst edged in orange and red.
// The shield is drawn (generated/texture-shield.png). The user is hidden
// while it charges (ToggleSpriteVisibility 3/4).

const SPA = 962;
const kit = await createKit({ workDir: import.meta.dirname, slug: "behemoth-bash", moveId: 782, spaId: SPA, donors: [228, 465, 579, 411, 298] });

const CAMERA_IN = 12;
const RAISE = 28; // the shield forms
const BRACE = 8; // speed lines, braced to charge
const TRAVEL = 6;
const AFTER = 30;

const RED: Rgb = [1.0, 0.18, 0.15];
const CRIMSON: Rgb = [0.75, 0.05, 0.1];
const ORANGE: Rgb = [1.0, 0.6, 0.2];
const PALE: Rgb = [1.0, 0.95, 0.8];
const MAGENTA: Rgb = [1.0, 0.25, 0.75];
const SHIELD_AT: Vec3 = [0.2, 0.6, 0.5];

// --- the drawn shield: a broad heater shield of red light with a bright rim and a boss ---
const shieldTex = await kit.drawn("shield", 32, 32, "a3i5", (x, y) => {
  const px = (x + 0.5 - 16) / 15, py = (y + 0.5) / 32; // px -1..1, py 0..1 from the top
  // Wide at the shoulders, flaring into wings, tapering to a point.
  const half = py < 0.12 ? 0.55 + py * 3.5 : py < 0.5 ? 0.97 - (py - 0.12) * 0.35 : 0.84 * Math.max(0, 1 - (py - 0.5) / 0.48) ** 0.8;
  const d = Math.abs(px);
  if (d > half || py > 0.985) return undefined;
  const rim = half - d < 0.1 || py < 0.05;
  if (rim) return [255, 150, 110, 255];
  const boss = Math.hypot(px, (py - 0.38) * 2.1);
  if (boss < 0.2) return [255, 220, 170, 255];
  if (boss < 0.27 || (d < 0.05 && py > 0.1)) return [170, 10, 25, 240];
  const light = Math.max(0, 1 - boss / 1.1);
  return [Math.round(225 + 30 * light), Math.round(15 + 45 * light), Math.round(25 + 30 * light), 215];
});

const shieldUp = kit.parked(shieldTex, SHIELD_AT, 2.6, RAISE + BRACE);
shieldUp.startDelayFrames = 6;
setCurves(shieldUp, { start: 0.2, mid: 1, end: 1.08, curveIn: 0.45, curveOut: 0.9 }, fadeInOut(0.9, 0.2, 0.95));
paint(shieldUp, WHITE);
kit.add("shieldUp", shieldUp);

const user = [
  "shieldUp",
  ...glow(kit, "aura", { pos: USER, life: RAISE + BRACE, scale: 3.2, pal: [RED, CRIMSON, ORANGE], level: 0.7 }),
  ...risers(kit, "motes", { frames: RAISE, radius: 1.8, speed: 0.14, scale: 0.17, life: 16, every: 3, pal: [RED, PALE, ORANGE] }),
  // Speed lines streaming past as it braces to charge.
  ...streaks(kit, "speedLines", { pos: [0, 0.6, 0.4], at: RAISE, radius: 2.6, speed: 0.6, count: 4, bursts: BRACE / 2, gap: 2, life: 6, scale: 1.2, pal: [MAGENTA, RED, PALE] }),
];
// The charge: the shield flies to the foe.
shot(kit, "shieldCharge", shieldTex, { from: SHIELD_AT, at: RAISE + BRACE, travel: TRAVEL, scale: 2.6, pal: [WHITE, WHITE, WHITE], scaleCurve: hold(1.08), alpha: hold(0.9) });
shot(kit, "chargeGlow", kit.tex(T.fuzzyGlow), { from: SHIELD_AT, at: RAISE + BRACE, travel: TRAVEL, scale: 2.6, pal: [RED, ORANGE, CRIMSON], count: 3, gap: 1, alpha: fadeOut(0.7, 0.4) });

const foe = [
  ...impact(kit, "slam", { pal: [ORANGE, PALE, RED], size: 1.9, rays: 11, flecks: 0 }),
  ...glow(kit, "whiteout", { pos: FOE, life: 13, scale: 3.8, pal: [PALE, WHITE, ORANGE], level: 1, scaleCurve: grow(0.4, 0.2, 1.2), alpha: fadeOut(1, 0.45) }),
  ...ring(kit, "shock", { at: 1, scale: 2.2, pal: [RED, ORANGE, CRIMSON], to: 2.4, life: 13 }),
  ...streaks(kit, "shards", { at: 1, radius: 0.8, speed: 0.5, count: 9, life: 10, scale: 0.9, pal: [RED, ORANGE, PALE], tex: kit.tex(T.shard) }),
  ...sparks(kit, "embers", { at: 6, radius: 1.5, speed: 0.14, count: 3, bursts: 4, gap: 4, life: 14, scale: 0.15, pal: [RED, PALE, ORANGE], fall: -0.006 }),
];

const chargeAt = RAISE + BRACE;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1497, 0, { vol: 105 }),
  snd(1435, 8, { ch: "SE2", pitch: -400, vol: 110 }),
  snd(1376, chargeAt, { vol: 0 }),
  snd(1688, chargeAt, { ch: "SE2", pitch: 200, vol: 125 }),
  snd(1475, chargeAt + TRAVEL, { side: "D", pitch: -400, vol: 127 }),
  snd(1413, chargeAt + TRAVEL, { ch: "SE2", side: "D", pitch: -300, vol: 127 }),
  snd(1505, chargeAt + TRAVEL + 2, { side: "D", vol: 120 }),
)}
${arena(0, 13, 8, [9, 0, 1])}
${tint("ATTACKER", 0, 11, 6, [31, 8, 6])}
${emits(kit, user, "ATTACKER")}
${emits(kit, ["shieldCharge", "chargeGlow"], "ATTACKER", "DEFENDER")}
${shake("ATTACKER", 819, RAISE / 2 - 4)}
Wait ${RAISE}
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, ${BRACE}, 0, 1
${shake("ATTACKER", 1229, BRACE / 2)}
Wait ${BRACE}
ToggleSpriteVisibility ATTACKER, 3
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${arena(13, 15, 0, [31, 28, 22])}
${hit({ rgb: [31, 26, 20], power: 3 })}
${arena(15, 13, 4, [9, 0, 1])}
Wait 10
${quake("1x", 8)}
${arena(13, 0, 10, [9, 0, 1])}
Wait ${AFTER - 10}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
${tint("ATTACKER", 11, 0, 0, [31, 8, 6])}
ToggleSpriteVisibility ATTACKER, 4
${pan("INIT", 12)}
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129],
  references: ["reference/Behemoth_Bash_VIII.png", "reference/Behemoth_Bash_VIII_2.png", "reference/Behemoth_Bash_IX.png", "reference/Behemoth_Bash_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("shieldUp")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("shieldCharge")}, ATTACKER, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 3", "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("slamFlash")}, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 4", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  shield f${CAMERA_IN}, charge f${CAMERA_IN + chargeAt}, slam f${CAMERA_IN + chargeAt + TRAVEL}`);
