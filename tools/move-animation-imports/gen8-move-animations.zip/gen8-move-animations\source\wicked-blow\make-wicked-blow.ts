import { createKit, fadeOut, grow, setCurves, T, type Rgb } from "../tools/anim-kit";
import { arena, audio, emits, FOE, glow, hit, impact, intro, lunge, outro, pan, quake, ring, risers, shake, snd, sparks, streaks, tint, USER, WHITE, type Pal } from "../tools/phrases";

// Wicked Blow (move 817) - from the Bulbapedia stills (reference/sheet.png).
//   1. The world bleaches white. The user sets itself, red and black shards
//      lifting off the ground round it.
//   2. One blow: bands of red and black shock burst out over the foe in an
//      arch, one inside another.
// The move always lands a critical hit, so the hit-stop is long.

const SPA = 997;
const kit = await createKit({ workDir: import.meta.dirname, slug: "wicked-blow", moveId: 817, spaId: SPA, donors: [228, 465, 579, 411, 298, 560] });

const CAMERA_IN = 12;
const SET = 28;
const HOLD = 6;
const PAN = 6;
const AFTER = 30;

const RED: Rgb = [0.95, 0.08, 0.12];
const DARK_RED: Rgb = [0.5, 0.02, 0.06];
const HOT: Rgb = [1.0, 0.4, 0.45];
const BLACK: Rgb = [0, 0, 0];
const PAL: Pal = [RED, HOT, DARK_RED];

const user = [
  ...risers(kit, "redShards", { frames: SET, radius: 1.5, speed: 0.26, scale: 0.8, life: 10, every: 3, pal: [RED, HOT, DARK_RED], streak: true, tex: kit.tex(T.shard) }),
  ...risers(kit, "blackShards", { at: 2, frames: SET, radius: 1.8, speed: 0.22, scale: 0.7, life: 10, every: 3, pal: [BLACK, DARK_RED, BLACK], streak: true, tex: kit.tex(T.shard) }),
  ...glow(kit, "menace", { pos: USER, life: SET + HOLD, scale: 2.7, pal: [RED, DARK_RED, HOT], level: 0.55 }),
  ...ring(kit, "focus", { pos: USER, at: SET - 2, scale: 2.4, pal: [BLACK, DARK_RED, BLACK], to: 0.3, life: HOLD + 4, level: 0.9 }),
];
setCurves(kit.resources[kit.idx("focus")]!, { start: 1, mid: 0.5, end: 0.1, curveIn: 0.5, curveOut: 0.6 }, { start: 0, mid: 0.9, end: 0.9, curveIn: 0.3, curveOut: 1 });

// The blow: bands of shock, alternating red and black, one inside another.
const BANDS: Array<[string, number, Rgb, Rgb, number]> = [["bandA", 0, RED, HOT, 2.6], ["bandB", 2, BLACK, DARK_RED, 2.3], ["bandC", 4, RED, HOT, 2.0], ["bandD", 6, BLACK, DARK_RED, 1.7]];
const bands = BANDS.flatMap(([name, at, colour, start, to]) => ring(kit, name, { pos: [0, 0.1, 0.9], at, scale: 1.5, pal: [colour, start, colour], tex: kit.tex(T.hoop), to, life: 14, level: 1 }));
const foe = [
  ...impact(kit, "blow", { pal: [WHITE, WHITE, HOT], size: 1.5, rays: 0, flecks: 0, spiky: false }),
  ...bands,
  ...streaks(kit, "redJags", { radius: 0.6, speed: 0.5, count: 9, life: 11, scale: 1.1, pal: [RED, HOT, DARK_RED], tex: kit.tex(T.shard) }),
  ...streaks(kit, "blackJags", { at: 1, radius: 0.6, speed: 0.42, count: 7, life: 11, scale: 1.0, pal: [BLACK, DARK_RED, BLACK], tex: kit.tex(T.shard) }),
  ...sparks(kit, "after", { at: 8, radius: 1.5, speed: 0.12, count: 3, bursts: 3, gap: 4, life: 12, scale: 0.15, pal: [RED, HOT, BLACK], fall: 0.008 }),
];

const blowAt = SET + HOLD + PAN;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1497, 0, { pitch: -500, vol: 95 }),
  snd(1452, SET - 6, { ch: "SE2", pitch: -400, vol: 110 }),
  snd(1376, SET + HOLD, { vol: 0 }),
  snd(1407, SET + HOLD, { ch: "SE2", pitch: 100, vol: 125 }),
  snd(1475, blowAt, { side: "D", pitch: -500, vol: 127 }),
  snd(1413, blowAt, { ch: "SE2", side: "D", pitch: -500, vol: 127 }),
  snd(1423, blowAt + 1, { side: "D", pitch: -300, vol: 127 }),
)}
${arena(0, 15, 10, [31, 31, 31])}
${tint("ATTACKER", 0, 6, 8, [28, 4, 6])}
${emits(kit, user, "ATTACKER")}
ScaleSprite ATTACKER, ROUNDTRIP, 410, -819, ${SET - 4}, 0, 1
Wait ${SET}
${shake("ATTACKER", 1229, HOLD / 2)}
Wait ${HOLD}
${lunge("ATTACKER", 5)}
${tint("ATTACKER", 6, 0, 4, [28, 4, 6])}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
${hit({ rgb: [31, 10, 10], power: 3, stop: 8 })}
Wait 8
${quake("2458", 8)}
Wait ${AFTER - 18}
${arena(15, 0, 10, [31, 31, 31])}
Wait 10
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 381],
  references: ["reference/SwShIoA_Prerelease_Wicked_Blow_2.png", "reference/Wicked_Blow_IX.png", "reference/Wicked_Blow_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("redShards")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("bandA")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("bandD")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  sets f${CAMERA_IN}, blow f${CAMERA_IN + blowAt}`);
