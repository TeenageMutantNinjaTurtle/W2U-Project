import { createKit, fadeOut, grow, hold, paint, setCurves, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, emits, FOE, FOE_FLOOR, glow, hit, impact, intro, outro, pan, ring, risers, shake, snd, sparks, streaks, tint, USER, WHITE, type Pal } from "../tools/phrases";

// Poltergeist (move 809) - from the Scarlet/Violet screenshot Logan sent on
// 2026-10-03 (and his description), in place of my first version:
//   1. A dark aura gathers on the user, violet sparks spitting off it.
//   2. A black hole opens in the ground beneath the foe, rimmed in magenta,
//      purple orbs and sparks rising out of it.
//   3. Little ghosts come up and circle the foe...
//   4. ...then close in on it all at once and strike: a jagged magenta burst
//      round a black star.
// The ghost is drawn (generated/texture-ghost.png). The ghosts ride the
// engine's "spin" behaviour, which turns a particle round its emitter - so
// they circle the foe - and "convergence", which pulls them in to it.

const SPA = 989;
const kit = await createKit({ workDir: import.meta.dirname, slug: "poltergeist", moveId: 809, spaId: SPA, donors: [228, 465, 579, 411, 298, 407] });

const CAMERA_IN = 10;
const POSSESS = 16;
const PAN = 10;
const HOLE = 8; // the hole opens before the ghosts come
const CIRCLE = 30;
const CLOSE_IN = 6;
const AFTER = 26;
const HIT = HOLE + CIRCLE + CLOSE_IN;

const MAGENTA: Rgb = [1.0, 0.2, 0.85];
const PINK: Rgb = [1.0, 0.65, 0.95];
const VIOLET: Rgb = [0.6, 0.3, 1.0];
const PURPLE: Rgb = [0.5, 0.15, 0.8];
const INK: Rgb = [0.02, 0.01, 0.04];
const BLACK: Rgb = [0, 0, 0];
const PAL: Pal = [MAGENTA, PINK, VIOLET];

const user = [
  ...streaks(kit, "sparks", { pos: USER, radius: 0.9, speed: 0.3, count: 3, bursts: POSSESS / 3, gap: 3, life: 8, scale: 0.6, pal: [MAGENTA, VIOLET, PINK] }),
  ...sparks(kit, "motes", { pos: USER, radius: 1.6, speed: 0.05, count: 1, bursts: POSSESS / 2, gap: 2, life: 12, scale: 0.18, pal: [VIOLET, MAGENTA, [0.4, 0.1, 0.8]], shape: "ball", tex: kit.tex(T.softDisc) }),
  ...glow(kit, "darkAura", { pos: USER, life: POSSESS + 4, scale: 2.8, pal: [[0.12, 0.02, 0.2], VIOLET, BLACK], level: 0.8 }),
];

// --- a little ghost: a round dark head on a tail that tapers and curls,
// outlined in violet so it shows against the dark, with two slanted amber eyes ---
const ghostTex = await kit.drawn("ghost", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5 - 16, py = y + 0.5;
  const head = Math.hypot(px, py - 11) - 8.5; // negative inside
  const t = (py - 11) / 19; // 0 at the middle of the head, 1 at the tip of the tail
  const tail = t >= 0 && t <= 1 ? Math.abs(px - 4.5 * t * Math.sin(t * Math.PI * 0.9)) - 8.5 * Math.pow(1 - t, 0.9) : 99; // (a small number here drew violet boxes above and below the ghost)
  const d = Math.min(head, tail);
  if (d > 1.4) return undefined;
  if (d > 0) return [150, 40, 210, 255];
  for (const side of [-1, 1]) {
    const ex = px - side * 3.4, ey = py - 10.5 + side * 0.4 * ex; // outer corners raised
    if ((ex * ex) / 4.4 + (ey * ey) / 1.7 < 1) return [255, 185, 40, 255];
  }
  return [16, 6, 26, 255];
});

// The ghosts: four of them, evenly spaced on a ring round the foe.
const GHOSTS = 4;
const RING = 1.9;
const TURNS = 1.25; // a quarter-turn over, so four ghosts end where four began
const TURN_RATE = (TURNS * 2 * Math.PI) / CIRCLE;
const HAUNT: Vec3 = [0, 0.5, 0.8];
function ghosts(name: string, at: number, life: number, pull: number): string {
  const r = kit.parked(ghostTex, HAUNT, 0.5, life);
  Object.assign(r, { startDelayFrames: at, emissionType: 3, emissionAxis: 1, emissionCount: GHOSTS, radius: RING });
  r.behaviors = [{ type: "spin", axis: 1, angle: TURN_RATE }, ...(pull ? [{ type: "convergence" as const, target: [0, 0, 0] as Vec3, force: pull }] : [])];
  paint(r, WHITE);
  kit.add(name, r);
  return name;
}
const circling = ghosts("ghosts", HOLE, CIRCLE, 0);
setCurves(kit.resources[kit.idx("ghosts")]!, { start: 0.3, mid: 1, end: 1, curveIn: 0.2, curveOut: 1 }, { start: 0, mid: 1, end: 1, curveIn: 0.15, curveOut: 1 });
// They close in: the same four, pulled to the foe while still turning.
const closing = ghosts("ghostsIn", HOLE + CIRCLE, CLOSE_IN + 1, 0.42);
setCurves(kit.resources[kit.idx("ghostsIn")]!, hold(1), hold(1));

const HOLE_AT: Vec3 = [0, FOE_FLOOR[1] - 0.1, -0.7];
const foe = [
  // --- 4. the strike ---
  ...glow(kit, "blackStar", { pos: [0, 0.3, 1.0], at: HIT, life: 10, scale: 1.3, pal: [BLACK, BLACK, BLACK], tex: kit.tex(T.spiky), spin: 0.1, level: 1, scaleCurve: grow(0.4, 0.3, 1.2), alpha: fadeOut(1, 0.5) }),
  ...streaks(kit, "jags", { at: HIT, radius: 0.6, speed: 0.46, count: 9, life: 12, scale: 1.2, pal: [MAGENTA, PINK, [0.8, 0.1, 0.6]], tex: kit.tex(T.shard) }),
  ...impact(kit, "burst", { at: HIT, pal: PAL, size: 1.6, rays: 8, flecks: 0, spiky: false }),
  // --- 3. the ghosts ---
  closing,
  circling,
  // --- 2. what rises out of the hole ---
  ...risers(kit, "orbs", { pos: FOE_FLOOR, at: 4, frames: HIT - 6, radius: 1.5, speed: 0.1, scale: 0.2, life: 16, every: 3, pal: [PURPLE, VIOLET, MAGENTA], tex: kit.tex(T.softDisc) }),
  ...risers(kit, "holeSparks", { pos: FOE_FLOOR, at: 4, frames: HIT - 6, radius: 1.4, speed: 0.3, scale: 0.6, life: 8, every: 3, pal: [MAGENTA, PINK, VIOLET], streak: true }),
  ...sparks(kit, "after", { at: HIT + 6, radius: 1.4, speed: 0.1, count: 3, bursts: 3, gap: 4, life: 12, scale: 0.15, pal: [MAGENTA, PINK, VIOLET], fall: 0.006 }),
  // The hole itself: black, flat on the ground under the foe, with a magenta
  // rim. It sits behind the foe in depth (negative z is away from the camera
  // on the foe's side), so the foe's sprite covers it and stands in it.
  ...ring(kit, "holeRim", { pos: HOLE_AT, life: HIT + 14, scale: 0.95, pal: [MAGENTA, PINK, PURPLE], to: 1.05, aspect: 2.6, level: 0.95 }),
  ...glow(kit, "hole", { pos: HOLE_AT, life: HIT + 14, scale: 0.9, pal: [INK, INK, INK], tex: kit.tex(T.softDisc), aspect: 2.6, level: 1 }),
  ...glow(kit, "gloom", { pos: FOE, at: HOLE, life: CIRCLE + CLOSE_IN + 8, scale: 3.2, pal: [[0.12, 0.02, 0.2], PURPLE, BLACK], level: 0.4 }),
];
// The hole opens out from nothing, holds, and shuts.
for (const n of ["holeRim", "hole"]) setCurves(kit.resources[kit.idx(n)]!, { start: 0.1, mid: 1, end: 0.2, curveIn: HOLE / (HIT + 14), curveOut: 0.9 }, { start: 0.6, mid: n === "hole" ? 1 : 0.95, end: 0, curveIn: 0.08, curveOut: 0.92 });

const foeAt = POSSESS + PAN;
const hitAt = foeAt + HIT;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1434, 0, { pitch: -600, vol: 110 }),
  snd(1815, foeAt, { side: "D", pitch: -500, vol: 115 }),
  snd(1510, foeAt + HOLE, { ch: "SE2", side: "D", pitch: -200, vol: 100 }),
  snd(1815, foeAt + HOLE + CIRCLE / 2, { side: "D", pitch: 300, vol: 100 }),
  snd(1407, hitAt - CLOSE_IN, { ch: "SE2", side: "D", pitch: 300, vol: 115 }),
  snd(1475, hitAt, { side: "D", pitch: -300, vol: 127 }),
  snd(1815, hitAt, { ch: "SE2", side: "D", pitch: 500, vol: 120 }),
)}
${arena(0, 10, 8, [6, 2, 12])}
${tint("ATTACKER", 0, 10, 6, [10, 2, 16])}
${emits(kit, user, "ATTACKER")}
${shake("ATTACKER", 819, POSSESS / 2 - 2)}
Wait ${POSSESS}
${pan("DEFENDER", PAN)}
Wait ${PAN}
${emits(kit, foe, "DEFENDER")}
Wait ${HOLE}
ShakeSprite DEFENDER, 2, 410, 0, 2, 0, ${Math.round(CIRCLE / 3)}
Wait ${CIRCLE + CLOSE_IN}
${arena(10, 13, 0, [31, 14, 28])}
${hit({ rgb: [31, 16, 29], power: 3 })}
${arena(13, 10, 4, [6, 2, 12])}
${tint("ATTACKER", 10, 0, 4, [10, 2, 16])}
Wait ${AFTER - 10}
${arena(10, 0, 8, [6, 2, 12])}
Wait 10
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 236, 247],
  references: ["reference/Poltergeist_VIII.png", "reference/Poltergeist_VIII_2.png", "reference/Poltergeist_IX.png", "reference/Poltergeist_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("darkAura")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("hole")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("ghosts")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("ghostsIn")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  possession f${CAMERA_IN}, hole f${CAMERA_IN + foeAt}, ghosts circle f${CAMERA_IN + foeAt + HOLE}-${CAMERA_IN + foeAt + HOLE + CIRCLE}, strike f${CAMERA_IN + hitAt}`);
