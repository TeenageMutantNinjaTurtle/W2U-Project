MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 966
AudioContainer CONTINUE
PlaySound 1869, SE1, 14, 0, -600, 100, 0, 0, 0
PlaySound 1458, SE2, 14, 4, 0, 105, 0, 0, 0
PlaySound 1869, SE1, 14, 12, -300, 105, 0, 0, 0
PlaySound 1522, SE2, 16, 38, 0, 120, 0, 0, 0
PlaySound 1869, SE1, 16, 38, -800, 127, 0, 0, 0
PlaySound 1475, SE2, 16, 38, 200, 115, 0, 0, 0
PlaySound 1458, SE1, 16, 50, 0, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 11, 0, 2, 3, 8
ChangeSpriteColor ATTACKER, 0, 7, 0, 28, 31, 12
Emit 966, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 966, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 966, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 966, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 966, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 966, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 4, 0, 1
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 11
Wait 26
ChangeSpriteColor ATTACKER, 7, 0, 0, 28, 31, 12
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
Emit 966, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 966, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 966, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 966, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 966, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 966, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 966, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 966, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 966, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 966, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 2
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 30, 31, 14
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 30, 31, 14
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 11
Wait 20
ChangeBackgroundColor 4, 11, 0, 0, 2, 3, 8
Wait 12
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
