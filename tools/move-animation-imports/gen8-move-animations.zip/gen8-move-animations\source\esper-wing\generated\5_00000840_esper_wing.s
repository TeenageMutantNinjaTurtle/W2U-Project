MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1020
AudioContainer CONTINUE
PlaySound 1510, SE1, 14, 0, 200, 105, 0, 0, 0
PlaySound 1425, SE2, 14, 2, 500, 100, 0, 0, 0
PlaySound 1407, SE1, 14, 21, 300, 118, 0, 0, 0
PlaySound 1514, SE1, 16, 29, 100, 127, 0, 0, 0
PlaySound 1514, SE2, 16, 34, 300, 127, 0, 0, 0
PlaySound 1455, SE2, 16, 35, 300, 115, 0, 0, 0
PlaySound 1475, SE1, 16, 35, 200, 120, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 9, 0, 26, 14, 31
EmitCircle 1020, 0, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 1020, 1, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
Emit 1020, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1020, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1020, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 22
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 6px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 9, 0, 0, 26, 14, 31
MoveCamera INTERPOLATION, DEFENDER, 7, 0, 8
Wait 7
Emit 1020, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1020, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1020, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1020, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1020, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1020, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1020, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1020, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1020, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1020, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1020, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1020, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 1
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 10, 10, 0, 29, 20, 31
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 3
Wait 1
ChangeSpriteColor DEFENDER, 10, 0, 0, 29, 20, 31
Wait 4
ChangeSpriteColor DEFENDER, 15, 15, 0, 29, 20, 31
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 29, 20, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 26
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
