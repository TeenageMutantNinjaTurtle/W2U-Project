MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 969
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, 500, 95, 0, 0, 0
PlaySound 1509, SE2, 14, 6, 400, 90, 0, 0, 0
PlaySound 1376, SE1, 14, 22, 0, 0, 0, 0, 0
PlaySound 1407, SE2, 14, 22, 200, 115, 0, 0, 0
PlaySound 1475, SE1, 16, 30, 200, 127, 0, 0, 0
PlaySound 1423, SE2, 16, 30, 500, 120, 0, 0, 0
PlaySound 1509, SE1, 16, 34, 900, 95, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 0, 8, 4, 16
ChangeSpriteColor ATTACKER, 0, 9, 0, 31, 16, 27
Emit 969, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 969, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 969, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 969, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 9
Wait 22
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 4px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 9, 0, 0, 31, 16, 27
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 969, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 969, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 969, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 969, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 969, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 969, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 969, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 969, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeBackgroundColor 4, 14, 14, 0, 31, 20, 28
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 22, 29
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 22, 29
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 14, 10, 0, 8, 4, 16
Wait 18
ChangeBackgroundColor 4, 10, 0, 0, 8, 4, 16
Wait 10
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
