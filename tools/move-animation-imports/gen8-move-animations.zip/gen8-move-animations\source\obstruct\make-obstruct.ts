import { createKit, deg, fadeInOut, grow, paint, setCurves, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { audio, emits, glow, intro, outro, ring, shake, snd, sparks, squash, streaks, tint, USER, WHITE } from "../tools/phrases";

// Obstruct (move 792) - from the Bulbapedia stills (reference/sheet.png).
//   1. The user bellows: a shock of red and black bursts off it.
//   2. It throws its arms across: a huge white X edged in black stands in
//      front of it, red motes hanging in the air.
// A protecting move: it stays on the user.

const SPA = 972;
const kit = await createKit({ workDir: import.meta.dirname, slug: "obstruct", moveId: 792, spaId: SPA, donors: [228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const ROAR = 12;
const CROSS = 32;

const RED: Rgb = [1.0, 0.15, 0.2];
const DARK_RED: Rgb = [0.6, 0.03, 0.1];
const BLACK: Rgb = [0, 0, 0];
const X_AT: Vec3 = [0.1, 0.5, 0.7];

// One bar of the X: Slash's streak, turned 45 degrees, held.
function bar(name: string, angle: number, scale: number, aspect: number, colour: Rgb): string {
  const r = kit.parked(kit.tex(T.streak), X_AT, scale, CROSS);
  r.startDelayFrames = ROAR;
  r.aspectRatio = aspect;
  r.initAngle = deg(90 + angle);
  setCurves(r, grow(0.2, 0.12, 1.03), fadeInOut(1, 0.04, 0.88));
  paint(r, colour);
  kit.add(name, r);
  return name;
}

const user = [
  // The white X first, so it draws over its black edge.
  bar("xWhiteA", 40, 3.3, 0.3, WHITE), bar("xWhiteB", -40, 3.3, 0.3, WHITE),
  bar("xBlackA", 40, 3.6, 0.5, BLACK), bar("xBlackB", -40, 3.6, 0.5, BLACK),
  ...sparks(kit, "redMotes", { pos: [0, 0.6, 0.5], at: ROAR, radius: 2.4, speed: 0.03, count: 2, bursts: 6, gap: 4, life: 14, scale: 0.2, pal: [RED, [1.0, 0.45, 0.45], DARK_RED], shape: "ball", tex: kit.tex(T.softDisc) }),
  ...streaks(kit, "blackFlecks", { pos: X_AT, at: ROAR, radius: 0.8, speed: 0.4, count: 8, life: 9, scale: 0.5, pal: [BLACK, BLACK, DARK_RED], tex: kit.tex(T.shard) }),
  ...ring(kit, "xShock", { pos: X_AT, at: ROAR, scale: 1.6, pal: [WHITE, WHITE, RED], to: 2.2, life: 10 }),
  // --- 1. the bellow ---
  ...streaks(kit, "roarRed", { pos: USER, radius: 0.5, speed: 0.5, count: 5, bursts: 3, gap: 3, life: 8, scale: 1.0, pal: [RED, [1.0, 0.5, 0.5], DARK_RED] }),
  ...streaks(kit, "roarBlack", { pos: USER, at: 1, radius: 0.5, speed: 0.45, count: 4, bursts: 3, gap: 3, life: 8, scale: 0.9, pal: [BLACK, DARK_RED, BLACK] }),
  ...ring(kit, "roarRing", { pos: USER, scale: 1.4, pal: [RED, WHITE, DARK_RED], to: 2.4, life: 10 }),
  ...glow(kit, "menace", { pos: USER, life: ROAR + CROSS, scale: 2.8, pal: [RED, DARK_RED, [1.0, 0.4, 0.4]], level: 0.5 }),
];

const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1869, 0, { pitch: -1200, vol: 110 }),
  snd(1505, 2, { ch: "SE2", pitch: -300, vol: 110 }),
  snd(1514, ROAR, { pitch: -300, vol: 120 }),
  snd(1435, ROAR + 1, { ch: "SE2", pitch: -200, vol: 120 }),
)}
${tint("ATTACKER", 0, 8, 2, [31, 6, 8])}
${emits(kit, user, "ATTACKER")}
${squash("ATTACKER", -1229, 1229, 4)}
${shake("ATTACKER", 1229, ROAR / 2)}
Wait ${ROAR}
${tint("ATTACKER", 8, 0, 4, [31, 6, 8])}
${squash("ATTACKER", 819, -819, 3)}
Wait ${CROSS}
${outro({ unfreeze: "NONE" })}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 163],
  references: ["reference/Obstruct_VIII.png", "reference/Obstruct_VIII_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("xWhiteA")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("roarRed")}, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  bellow f${CAMERA_IN}, X f${CAMERA_IN + ROAR}-${CAMERA_IN + ROAR + CROSS}`);
