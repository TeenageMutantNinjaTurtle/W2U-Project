MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 1005
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -800, 115, 0, 0, 0
PlaySound 1815, SE2, 14, 8, -300, 100, 0, 0, 0
PlaySound 1815, SE2, 14, 30, 0, 95, 0, 0, 0
PlaySound 1815, SE2, 14, 48, 200, 95, 0, 0, 0
PlaySound 1407, SE1, 14, 60, 500, 115, 0, 0, 0
PlaySound 1425, SE1, 16, 80, -500, 115, 0, 0, 0
PlaySound 1420, SE2, 16, 87, -200, 112, 0, 0, 0
PlaySound 1420, SE1, 16, 91, -200, 112, 0, 0, 0
PlaySound 1420, SE2, 16, 95, -200, 112, 0, 0, 0
PlaySound 1475, SE1, 16, 98, -500, 127, 0, 0, 0
PlaySound 1815, SE2, 16, 98, 300, 122, 0, 0, 0
PlaySound 1475, SE1, 16, 106, -700, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 13, 0, 3, 0, 8
ChangeSpriteColor ATTACKER, 0, 8, 0, 18, 8, 31
Emit 1005, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 1, 6
Wait 60
ChangeSpriteColor ATTACKER, 8, 0, 0, 18, 8, 31
Wait 10
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
Emit 1005, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 1005, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 7
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 9, 0, 20, 10, 31
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 6
Wait 11
ChangeSpriteColor DEFENDER, 0, 0, 0, 20, 10, 31
ChangeBackgroundColor 4, 15, 15, 0, 24, 6, 28
ChangeSpriteColor DEFENDER, 15, 15, 0, 28, 18, 31
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 0, 28, 18, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
ChangeBackgroundColor 4, 15, 13, 1, 3, 0, 8
Wait 8
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 4
ChangeBackgroundColor 4, 13, 0, 0, 3, 0, 8
Wait 10
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
