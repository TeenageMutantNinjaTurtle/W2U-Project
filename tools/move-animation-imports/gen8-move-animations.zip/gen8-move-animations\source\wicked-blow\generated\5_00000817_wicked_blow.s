MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 997
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, -500, 95, 0, 0, 0
PlaySound 1452, SE2, 14, 22, -400, 110, 0, 0, 0
PlaySound 1376, SE1, 14, 34, 0, 0, 0, 0, 0
PlaySound 1407, SE2, 14, 34, 100, 125, 0, 0, 0
PlaySound 1475, SE1, 16, 40, -500, 127, 0, 0, 0
PlaySound 1413, SE2, 16, 40, -500, 127, 0, 0, 0
PlaySound 1423, SE1, 16, 41, -300, 127, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 15, 0, 31, 31, 31
ChangeSpriteColor ATTACKER, 0, 6, 0, 28, 4, 6
Emit 997, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 997, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 997, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 997, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, 410, -819, 24, 0, 1
Wait 28
ShakeSprite ATTACKER, 2, 1229, 0, 2, 1, 3
Wait 6
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 5px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 6, 0, 0, 28, 4, 6
MoveCamera INTERPOLATION, DEFENDER, 6, 0, 8
Wait 6
Emit 997, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 997, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 997, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 997, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 997, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 997, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 997, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 997, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 15, 15, 0, 31, 10, 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 8
ChangeSpriteColor DEFENDER, 15, 0, 0, 31, 10, 10
ScaleSprite DEFENDER, ROUNDTRIP, 1638, -1638, 4, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 8
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 12
ChangeBackgroundColor 4, 15, 0, 0, 31, 31, 31
Wait 10
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
