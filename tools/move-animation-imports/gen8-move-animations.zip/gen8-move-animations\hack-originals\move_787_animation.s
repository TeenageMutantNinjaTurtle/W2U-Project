MoveCamera INTERPOLATION, ATTACKER, 16, 0, 8
ToggleSpriteShadow ALL, ON
LetCMDsFinish ALL
LoadSPA 823
Emit 823, 2, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 3277, 1x
Wait 10
MoveCamera INTERPOLATION, DEFENDER, 16, 0, 8
AudioContainer CONTINUE
PlaySound 1856, SE1, 14, 0, 0, 127, 0, 0, 0
PlaySound 1718, SE1, 14, 35, 0, 127, 0, 0, 0
PlaySound 1718, SE2, 16, 50, -1000, 127, 0, 0, 0
PlaySound 1718, SE1, 16, 70, 0, 127, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 16, 0, 40, 0, 0
AudioContainer SUSPEND
Wait 10
Emit 823, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 0.5x, 1x
Wait 40
Emit 823, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 0.5x, 1x
Wait 10
Emit 823, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1229, 1x
ChangeSpriteColor DEFENDER, 0, 8, 2, 31, 0, 0
ToggleFreezeSprite DEFENDER, START
Wait 10
Emit 823, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1229, 1x
LetCMDsFinish ALL
ChangeSpriteColor DEFENDER, 8, 0, 2, 31, 0, 0
ToggleFreezeSprite DEFENDER, STOP
ToggleSpriteShadow ALL, OFF
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
