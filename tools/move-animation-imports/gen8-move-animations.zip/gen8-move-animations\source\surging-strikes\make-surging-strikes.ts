import { assert, createKit, deg, fadeOut, grow, paint, setCurves, spin, T, type Rgb } from "../tools/anim-kit";
import { audio, emits, FOE, hit, impact, introStill, lunge, outro, snd, sparks, streaks, tint, WHITE, type Pal } from "../tools/phrases";

// Surging Strikes (move 818) - from the Bulbapedia stills (reference/sheet.png).
// A flowing strike that trails a broad ribbon of blue-white water, landing
// in a burst of white spray.
// Three hits (each a critical hit): Gen 5 replays the animation per hit, so
// the camera stays still and one hit is under a second.
// Psycho Cut's blade arc is the ribbon of water.

const SPA = 998;
const kit = await createKit({ workDir: import.meta.dirname, slug: "surging-strikes", moveId: 818, spaId: SPA, donors: [228, 465, 579, 411, 321, 298] });

const WINDUP = 6;
const AFTER = 14;

const BLUE: Rgb = [0.25, 0.6, 1.0];
const CYAN: Rgb = [0.5, 0.9, 1.0];
const PALE: Rgb = [0.88, 0.97, 1.0];
const PAL: Pal = [CYAN, PALE, BLUE];

function ribbon(name: string, pos: [number, number, number], angle: number, scale: number, colours: [Rgb, Rgb, Rgb], at: number): string {
  const r = kit.parked(kit.tex(T.bladeArc), pos, scale, 9);
  r.startDelayFrames = at;
  r.aspectRatio = 2.0;
  spin(r, 0, 0, deg(angle));
  setCurves(r, grow(0.4, 0.3, 1.2), fadeOut(1, 0.45));
  paint(r, colours[0], colours[1], colours[2]);
  kit.add(name, r);
  return name;
}
// (No ribbon on the user: Logan had the slash that trailed it at the start removed, 2026-10-03.)
const user = [
  ...sparks(kit, "trailDrops", { pos: [0.2, 0.4, 0.4], radius: 1.0, speed: 0.14, count: 5, life: 10, scale: 0.12, pal: [PALE, WHITE, CYAN], fall: 0.01, twinkle: false }),
];
const foe = [
  ribbon("strike", [0, 0.4, 1.0], -24, 1.6, [WHITE, WHITE, PALE], 0),
  ribbon("strikeWater", [0, 0.4, 0.95], -24, 1.9, [CYAN, PALE, BLUE], 0),
  ...impact(kit, "splash", { at: 1, pal: PAL, size: 1.1, rays: 0, flecks: 0 }),
  ...streaks(kit, "spray", { at: 1, radius: 0.5, speed: 0.4, count: 8, life: 10, scale: 0.7, pal: [WHITE, PALE, CYAN], tex: kit.tex(T.spike) }),
  ...sparks(kit, "droplets", { at: 2, radius: 0.6, speed: 0.28, count: 7, life: 14, scale: 0.13, pal: [PALE, WHITE, CYAN], fall: 0.012, twinkle: false }),
];
setCurves(kit.resources[kit.idx("spray")]!, grow(1.1, 0.3, 0.6), fadeOut());

const script = `${introStill(SPA)}
${audio(
  snd(1445, 0, { pitch: 700, vol: 100 }),
  snd(1407, WINDUP - 2, { ch: "SE2", pitch: 500, vol: 115 }),
  snd(1511, WINDUP + 1, { side: "D", pitch: 600, vol: 120 }),
  snd(1423, WINDUP + 1, { ch: "SE2", side: "D", pitch: 200, vol: 120 }),
)}
${tint("ATTACKER", 0, 6, 2, [16, 26, 31])}
${emits(kit, user, "ATTACKER")}
Wait ${WINDUP - 3}
${lunge("ATTACKER", 3)}
Wait 3
${tint("ATTACKER", 6, 0, 3, [16, 26, 31])}
${emits(kit, foe, "DEFENDER")}
Wait 1
${hit({ rgb: [24, 30, 31], power: 2, stop: 4 })}
Wait ${AFTER}
${outro({ camera: false })}`;

await kit.finish({
  script,
  donorMoveIds: [427, 63, 605, 400, 240, 153, 129],
  references: ["reference/SwShIoA_Prerelease_Surging_Strikes_2.png", "reference/Surging_Strikes_IX.png", "reference/Surging_Strikes_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("trailDrops")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("strike")}, DEFENDER`],
});
assert.ok(!script.includes("MoveCamera"), "Multi-hit animation moves the camera");
console.log(`  strike f${WINDUP}, one hit ~${WINDUP + 1 + 4 + AFTER} frames`);
