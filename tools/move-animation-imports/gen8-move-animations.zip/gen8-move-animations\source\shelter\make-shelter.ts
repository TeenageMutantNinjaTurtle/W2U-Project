import { createKit, grow, T, type Rgb } from "../tools/anim-kit";
import { audio, emits, glow, intro, outro, ring, snd, sparks, squash, tint, USER, WHITE } from "../tools/phrases";

// Shelter (move 842) - from the Bulbapedia stills (reference/sheet.png).
//   1. A glossy shell of pale blue slime closes over the user, a highlight
//      shining on it.
//   2. White rings sweep round it, beads of slime and sparkles hanging in
//      the air.
//   3. The shell sets hard with a white gleam.
// Stays on the user; the Defense boost is the engine's.

const SPA = 1022;
const kit = await createKit({ workDir: import.meta.dirname, slug: "shelter", moveId: 842, spaId: SPA, donors: [228, 465, 579, 411, 298] });

const CAMERA_IN = 10;
const COAT = 14;
const SWEEP = 26;
const SET = 18;
const TOTAL = COAT + SWEEP + SET;

const SLIME: Rgb = [0.7, 0.85, 1.0];
const PALE: Rgb = [0.92, 0.96, 1.0];
const LILAC: Rgb = [0.75, 0.75, 1.0];
const BLUE: Rgb = [0.45, 0.6, 1.0];

const user = [
  // The highlight on the shell.
  ...glow(kit, "shine", { pos: [-0.8, 1.3, 0.1], at: 4, life: TOTAL - 8, scale: 0.6, pal: [WHITE, WHITE, PALE], tex: kit.tex(T.softDisc), aspect: 1.6, angle: 0.6, level: 0.9 }),
  // --- 2. the rings and beads ---
  ...ring(kit, "sweepA", { pos: [0, 0.6, 0.2], at: COAT, life: 14, scale: 0.9, pal: [WHITE, WHITE, SLIME], to: 1.5, aspect: 2.6, level: 0.9 }),
  ...ring(kit, "sweepB", { pos: [0, -0.1, 0.2], at: COAT + 10, life: 14, scale: 0.9, pal: [PALE, WHITE, LILAC], to: 1.5, aspect: 2.6, level: 0.9 }),
  ...sparks(kit, "beads", { pos: USER, at: 4, radius: 2.3, speed: 0.01, count: 1, bursts: (COAT + SWEEP) / 3, gap: 3, life: 12, scale: 0.16, pal: [WHITE, PALE, SLIME], shape: "sphere", tex: kit.tex(T.softDisc), twinkle: false }),
  ...sparks(kit, "sparkles", { pos: USER, at: COAT, radius: 2.2, speed: 0, count: 1, bursts: SWEEP / 4, gap: 4, life: 9, scale: 0.3, pal: [WHITE, PALE, SLIME], shape: "sphere", tex: kit.tex(T.sparkle4) }),
  // --- 3. it sets ---
  ...glow(kit, "gleam", { pos: [-0.8, 1.3, 0.1], at: COAT + SWEEP, life: 12, scale: 1.1, pal: [WHITE, WHITE, PALE], tex: kit.tex(T.star4Big), spin: 0.1, level: 1 }),
  ...ring(kit, "setRing", { pos: USER, at: COAT + SWEEP, life: 12, scale: 2.2, pal: [WHITE, PALE, SLIME], to: 1.25 }),
  // --- 1. the shell itself: a rim and a soft glossy body ---
  ...ring(kit, "shellRim", { pos: USER, life: TOTAL, scale: 2.25, pal: [PALE, WHITE, BLUE], to: 1.04, level: 0.9 }),
  ...glow(kit, "shell", { pos: USER, life: TOTAL, scale: 2.2, pal: [SLIME, PALE, LILAC], tex: kit.tex(T.softDisc), level: 0.6, scaleCurve: grow(0.3, 0.25, 1.04) }),
];

const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1727, 0, { pitch: 600, vol: 95 }),
  snd(1418, 2, { ch: "SE2", pitch: 500, vol: 85 }),
  snd(1474, COAT, { ch: "SE2", vol: 95 }),
  snd(1474, COAT + 10, { ch: "SE2", pitch: 200, vol: 95 }),
  snd(1452, COAT + SWEEP, { vol: 115 }),
  snd(1784, COAT + SWEEP + 2, { ch: "SE2", pitch: 300, vol: 105 }),
)}
${emits(kit, user, "ATTACKER")}
${tint("ATTACKER", 0, 8, COAT, [22, 26, 31])}
${squash("ATTACKER", 819, -819, COAT)}
Wait ${COAT + SWEEP}
${tint("ATTACKER", 8, 14, 2, [31, 31, 31])}
${squash("ATTACKER", -819, 819, 5)}
Wait 5
${tint("ATTACKER", 14, 0, 10, [31, 31, 31])}
Wait ${SET - 5}
${outro({ unfreeze: "NONE" })}`;

await kit.finish({
  script,
  donorMoveIds: [151, 110, 63, 605, 240, 129, 334],
  references: ["reference/Shelter_LA.png", "reference/Shelter_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("shell")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("sweepA")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("gleam")}, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  shell f${CAMERA_IN}, rings f${CAMERA_IN + COAT}, sets f${CAMERA_IN + COAT + SWEEP}`);
