import { createKit, deg, fadeInOut, fadeOut, grow, paint, setCurves, spin, T, type Rgb, type Vec3 } from "../tools/anim-kit";
import { arena, audio, beam, emits, FOE, FRONT, gather, glow, hit, impact, intro, lunge, outro, pan, quake, ring, shake, snd, sparks, streaks, tint, USER, WHITE, type Pal } from "../tools/phrases";

// Eternabeam (move 795) - from the Bulbapedia stills (reference/sheet.png).
//   1. Everything goes black. A violet vortex turns behind the user as red
//      and pink light streams in to its core.
//   2. It fires: a torrent of pink-white light.
//   3. Shafts of pink light lance down round the foe and the beam erupts in
//      a blinding pink-white blast.
// A 160-power move with a recharge turn: the longest build-up and the
// heaviest finish of the set.

const SPA = 975;
const kit = await createKit({ workDir: import.meta.dirname, slug: "eternabeam", moveId: 795, spaId: SPA, donors: [228, 465, 579, 411, 298] });

const CAMERA_IN = 12;
const CHARGE = 40;
const HOLD = 8;
const TRAVEL = 8;
const POUR = 34;
const AFTER = 30;

const PINK: Rgb = [1.0, 0.4, 0.7];
const HOT: Rgb = [1.0, 0.15, 0.45];
const PALE: Rgb = [1.0, 0.86, 0.94];
const VIOLET: Rgb = [0.55, 0.25, 1.0];
const DEEP: Rgb = [0.3, 0.1, 0.7];
const PAL: Pal = [PINK, PALE, HOT];
const BACK: Vec3 = [0, 0.8, -0.8];

const user = [
  ...gather(kit, "draw", { pos: FRONT, frames: CHARGE, pal: [HOT, PALE, PINK], radius: 3.2, scale: 1.3, streaks: true }),
  ...glow(kit, "core", { pos: FRONT, at: CHARGE - 8, life: HOLD + POUR + 12, scale: 1.7, pal: [PALE, WHITE, PINK], tex: kit.tex(T.spiky), spin: 0.2, level: 1, scaleCurve: grow(1.6, 0.12, 1.1), alpha: fadeInOut(1, 0.08, 0.88) }),
  ...Array.from({ length: 3 }, (_, i) => ring(kit, `muzzle${i}`, { pos: FRONT, at: CHARGE + HOLD + i * 9, life: 10, scale: 1.6, pal: [PALE, WHITE, PINK], to: 2.4 })).flat(),
  ...sparks(kit, "redMotes", { pos: [0, 0.8, 0.2], radius: 3.0, speed: 0.01, count: 1, bursts: CHARGE / 3, gap: 3, life: 14, scale: 0.16, pal: [HOT, PALE, PINK], shape: "ball" }),
];
// The vortex behind it: two violet swirls turning opposite ways.
for (const [name, scale, rate, colours, level] of [["vortexA", 3.6, 0.07, [VIOLET, PINK, DEEP], 0.8], ["vortexB", 2.6, -0.09, [DEEP, VIOLET, [0.15, 0.05, 0.4]], 0.7]] as const) {
  const r = kit.parked(kit.tex(T.swirlRings), BACK, scale, CHARGE + HOLD + POUR);
  spin(r, rate);
  setCurves(r, grow(0.4, 0.2, 1.1), fadeInOut(level, 0.15, 0.85));
  paint(r, colours[0] as Rgb, colours[1] as Rgb, colours[2] as Rgb);
  kit.add(name, r);
  user.push(name);
}
const shots = [
  ...beam(kit, "beam", { at: CHARGE + HOLD, pour: POUR, travel: TRAVEL, width: 2.0, pal: [PINK, PALE, HOT], tex: kit.tex(T.softDisc) }),
  ...streaks(kit, "dashes", { pos: FRONT, at: CHARGE + HOLD, radius: 0.9, speed: 0, count: 1, bursts: POUR / 2, gap: 2, life: TRAVEL + 1, scale: 0.8, pal: [WHITE, PALE, HOT] }),
];
Object.assign(kit.resources[kit.idx("dashes")]!, { axis: [1, 0, 0], initVelAxisAmplifier: (16 / TRAVEL) * 1.1, airResistance: 1.0 });

// Shafts of light lancing down round the foe.
function shaft(name: string, x: number, angle: number, at: number): string {
  const r = kit.parked(kit.tex(T.streak), [x, 2.4, 0.5], 4.0, 12);
  r.startDelayFrames = at;
  r.aspectRatio = 0.3;
  r.initAngle = deg(angle); // the streak texture is upright
  setCurves(r, grow(0.3, 0.2, 1.05), fadeOut(0.9, 0.4));
  paint(r, PALE, WHITE, PINK);
  kit.add(name, r);
  return name;
}
const foe = [
  ...impact(kit, "hit", { pal: PAL, size: 2.0, rays: 10, flecks: 0 }),
  ...glow(kit, "whiteout", { pos: FOE, life: POUR, scale: 4.2, pal: [PALE, WHITE, PINK], level: 1, scaleCurve: grow(0.4, 0.15, 1.15), alpha: fadeInOut(1, 0.05, 0.75) }),
  shaft("shaftL", -2.2, 16, 6), shaft("shaftR", 2.0, -14, 12), shaft("shaftM", -0.4, 4, 18),
  ...ring(kit, "shock", { at: 2, scale: 2.4, pal: [PALE, WHITE, PINK], to: 2.4, life: 14 }),
  ...ring(kit, "shock2", { at: 14, scale: 2.2, pal: [PINK, WHITE, HOT], to: 2.4, life: 14 }),
  ...impact(kit, "hit2", { at: 16, pal: [HOT, WHITE, VIOLET], size: 1.6, rays: 9, flecks: 0, spiky: false }),
  ...sparks(kit, "embers", { at: POUR - 6, radius: 1.6, speed: 0.1, count: 3, bursts: 4, gap: 4, life: 14, scale: 0.15, pal: [PINK, WHITE, VIOLET], fall: -0.006 }),
];

const fireAt = CHARGE + HOLD;
const script = `${intro(SPA, CAMERA_IN)}
${audio(
  snd(1497, 0, { pitch: -300, vol: 115 }),
  snd(1480, 0, { ch: "SE2", pitch: -500, vol: 105 }),
  snd(1975, fireAt, { vol: 127 }),
  snd(1424, fireAt, { ch: "SE2", pitch: -600, vol: 127 }),
  `SwitchAudioSide SE2, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0`,
  snd(1475, fireAt + TRAVEL, { side: "D", pitch: -500, vol: 127 }),
  snd(1420, fireAt + TRAVEL + 8, { ch: "SE2", side: "D", vol: 127 }),
  snd(1475, fireAt + TRAVEL + 16, { side: "D", pitch: -700, vol: 127 }),
  snd(1420, fireAt + TRAVEL + 24, { ch: "SE2", side: "D", vol: 127 }),
)}
${arena(0, 15, 10, [1, 0, 2])}
${tint("ATTACKER", 0, 9, 8, [31, 10, 20])}
${emits(kit, user, "ATTACKER")}
${emits(kit, shots, "ATTACKER", "DEFENDER")}
${shake("ATTACKER", 819, CHARGE / 2 - 4)}
Wait ${CHARGE}
${tint("ATTACKER", 9, 14, 3, [31, 22, 27])}
${shake("ATTACKER", 1229, HOLD / 2)}
Wait ${HOLD}
${lunge("ATTACKER", -2)}
${shake("ATTACKER", 1229, POUR / 2)}
${pan("DEFENDER", TRAVEL)}
Wait ${TRAVEL}
${emits(kit, foe, "DEFENDER")}
${arena(15, 16, 0, [31, 20, 26])}
${hit({ rgb: [31, 24, 28], power: 3, stop: 7 })}
${arena(16, 15, 5, [1, 0, 2])}
Wait 8
${quake("2458", 8)}
Wait 10
${quake("1x", 6)}
Wait ${POUR - 7 - 18}
${tint("ATTACKER", 14, 0, 6, [31, 22, 27])}
${arena(15, 0, 12, [1, 0, 2])}
Wait ${AFTER}
${outro()}`;

await kit.finish({
  script,
  donorMoveIds: [63, 605, 400, 240, 129, 163],
  references: ["reference/Eternabeam_VIII.png", "reference/Eternabeam_VIII_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("vortexA")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("beamJet")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("shaftL")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
const at = CAMERA_IN + fireAt;
console.log(`  charge f${CAMERA_IN}, fire f${at}, lands f${at + TRAVEL}, beam ends f${at + POUR}`);
