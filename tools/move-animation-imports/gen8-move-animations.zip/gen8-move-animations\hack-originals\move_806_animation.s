MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish ALL
AudioContainer CONTINUE
PlaySound 1446, SE1, 14, 0, 0, 120, 0, 0, 0
PlaySound 1417, SE2, 14, 0, 0, 115, 0, 0, 0
PlaySound 1376, SE2, 14, 110, 0, 0, 0, 0, 0
AdjustSound SE2, 0, 0, -2000, 1000, 0, 50, 0, 0
AdjustSound SE2, 0, 1, 115, 0, 80, 20, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 16, 0, 40, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 16, 0, 60, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 12, 2, 10, 10, 10
LoadSPA 820
EmitProjectile 820, 0, WAVE_HORIZONTAL, ATTACKER, DEFENDER, 2px, 100f, 1px, 1x, 1x, 12288
Wait 1
EmitProjectile 820, 0, WAVE_HORIZONTAL, ATTACKER, DEFENDER, 2px, 100f, 1px, 1x, 1x, 12288
Wait 1
EmitProjectile 820, 0, WAVE_HORIZONTAL, ATTACKER, DEFENDER, 2px, 100f, 1px, 1x, 1x, 12288
Wait 1
EmitProjectile 820, 0, WAVE_HORIZONTAL, ATTACKER, DEFENDER, 2px, 100f, 1px, 1x, 1x, 12288
Wait 1
EmitProjectile 820, 0, WAVE_HORIZONTAL, ATTACKER, DEFENDER, 2px, 100f, 1px, 1x, 1x, 12288
Wait 1
EmitProjectile 820, 0, WAVE_HORIZONTAL, ATTACKER, DEFENDER, 2px, 100f, 1px, 1x, 1x, 12288
Wait 1
EmitProjectile 820, 0, WAVE_HORIZONTAL, ATTACKER, DEFENDER, 2px, 100f, 1px, 1x, 1x, 12288
Wait 1
EmitProjectile 820, 0, WAVE_HORIZONTAL, ATTACKER, DEFENDER, 2px, 100f, 1px, 1x, 1x, 12288
Wait 1
EmitProjectile 820, 0, WAVE_HORIZONTAL, ATTACKER, DEFENDER, 2px, 100f, 1px, 1x, 1x, 12288
Wait 1
EmitProjectile 820, 0, WAVE_HORIZONTAL, ATTACKER, DEFENDER, 2px, 100f, 1px, 1x, 1x, 12288
Wait 20
MoveCamera INTERPOLATION, DEFENDER, 12, 0, 8
Wait 20
AudioContainer CONTINUE
PlaySound 1420, SE1, 16, 55, 0, 120, 0, 0, 0
AudioContainer SUSPEND
Emit 820, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 820, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 820, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
Wait 40
ShakeSprite DEFENDER, 2, 1229, 0, 3, 0, 7
ScaleSprite DEFENDER, ROUNDTRIP, -819, 819, 2, 1, 1
LetCMDsFinish ALL
ChangeBackgroundColor 4, 12, 0, 2, 10, 10, 10
MoveCamera INTERPOLATION, INIT, 16, 0, 8
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
