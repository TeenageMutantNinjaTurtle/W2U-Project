MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 968
AudioContainer CONTINUE
PlaySound 1509, SE1, 16, 24, 700, 95, 0, 0, 0
PlaySound 1407, SE2, 16, 36, -300, 115, 0, 0, 0
PlaySound 1705, SE1, 16, 40, 100, 127, 0, 0, 0
PlaySound 1423, SE2, 16, 40, 300, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 6, 0, 31, 14, 12
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 4, 0, 1
Wait 10
ChangeSpriteColor ATTACKER, 6, 0, 0, 31, 14, 12
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
Emit 968, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 968, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 968, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 968, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 968, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 968, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 968, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 968, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 968, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 968, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 20
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 13, 13, 0, 31, 28, 16
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 0, 31, 28, 16
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 0, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1638, 6, 0, 1
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 4
Wait 28
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
