# Gen 9 move animations for White 2 (White2Upgrade)

68 moves, #852-919, as installed in `work/moves-preview.nds` on 2026-10-01.
Tera Blast (#851) is not included: the hack has no Terastallization.

## What is here

- `moves.csv` - one line per move: id, name, folder, and its two files.
- `GEN9-PROGRESS.md` - what each animation does, with notes.
- `narc-files/` - the compiled files, ready to put in a ROM:
  - `a065-move-scripts/5_<moveId>.bin` is file number <moveId> of NARC `a/0/6/5` (the move's animation script).
  - `a006-particles/6_<spaId>.bin` is file number <spaId> of NARC `a/0/0/6` (the particle archive that script loads).
- `source/` - what built them, laid out as in `work/`:
  - `source/<folder>/make-<folder>.ts` is the generator, `moveanim.json` the install manifest, and `generated/` holds the script source (`.s`), the two compiled files and any drawn textures (`.png`).
  - `source/tools/` is the shared toolkit (`anim-kit.ts`, `ship.sh`, `verify.ts`, `installed.json`, ...).

## Putting them in a ROM

Each script loads its particle archive by number (`LoadSPA <spaId>`), so the particle files must sit at exactly
the numbers in `moves.csv` (845-941; the numbers not listed in between belong to superseded versions and can hold anything).

With the Pokeweb-Serverless tools, copy `source/`'s contents into `work/` and, from `Pokeweb-Serverless/`, run once per move:

```powershell
npm run moveanim:install -- --manifest ../work/<folder>/moveanim.json --preview-rom <rom-in.nds> --out <rom-out.nds>
```

## Not included

- No ROMs.
- The reference stills (`reference/` in each folder, about 160 MB of Bulbapedia screenshots). The manifests still name them.
- The retail donor dumps the generators read when they are re-run (`work/donor-pool`, plus `silk-trap-donors` and
  `armor-cannon-v2-donors` for those two moves). The compiled files above do not need them; only regenerating does.
- Superseded versions (the v1 folders).
