import { createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Salt Cure (move 864), v2 - from Logan's keyframes (shown in chat, not saved):
//   1. Salt rains on the foe: white flakes and little salt chips tumbling
//      down round it, a pale mist at its base, specks twinkling.
//   2. The foe is encased in salt: a mound of big translucent white salt
//      cubes piles up over it, cube on cube, spray puffing off the sides.
//   3. The salt breaks open: the cubes burst apart into rectangular salt
//      blocks flung up and out, a white spray burst at the foe's base, thin
//      white shards and twinkling specks.
// The damage over the following turns is handled by the engine.
// v1 (../salt-cure, from the Bulbapedia stills) is kept; reinstall its
// manifest to revert.
//
// Drawn here: the salt cube (32x32 a3i5: an isometric cube, translucent
// white top and blue-grey side faces, bright edges and a faint inner rim;
// generated/texture-cube.png).

const SPA = 921;
const kit = await createKit({ workDir: import.meta.dirname, slug: "salt-cure-v2", moveId: 864, spaId: SPA, donors: [321, 465, 228, 411, 298] });

// --- timing (30 fps) ---
const CAMERA_IN = 14;
const RAIN = 22;
const BUILD = 10; // the mound piles up
const ENCASED = 20; // held, encased
const BREAK = 26;

const FOE: Vec3 = [0, 0.3, 0.8];
const FOE_FLOOR: Vec3 = [0, -1.4, 0.9];

const SALT: Rgb = [0.96, 0.98, 1.0];
const PALE_BLUE: Rgb = [0.85, 0.92, 1.0];
const GREY_BLUE: Rgb = [0.75, 0.82, 0.92];
const WHITE: Rgb = [1, 1, 1];

// --- the drawn salt cube ---
type P = [number, number];
const inPoly = (x: number, y: number, poly: P[]) => {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i]!;
    const [xj, yj] = poly[j]!;
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
};
const faces: Array<{ poly: P[]; colour: number[]; rim: number[] }> = [
  { poly: [[16, 2], [30, 9.5], [16, 17], [2, 9.5]], colour: [246, 250, 255, 232], rim: [255, 255, 255, 250] },
  { poly: [[2, 9.5], [16, 17], [16, 30.5], [2, 23]], colour: [214, 226, 242, 212], rim: [238, 244, 255, 235] },
  { poly: [[30, 9.5], [16, 17], [16, 30.5], [30, 23]], colour: [184, 200, 224, 212], rim: [222, 232, 248, 235] },
];
const cubeTex = await kit.drawn("cube", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5;
  const py = y + 0.5;
  const face = faces.find((f) => inPoly(px, py, f.poly));
  if (!face) return undefined;
  const inside = (d: number) => [[-d, 0], [d, 0], [0, -d], [0, d]].every(([ox, oy]) => inPoly(px + ox!, py + oy!, face.poly));
  if (!inside(1)) return [255, 255, 255, 255];
  if (!inside(3.2) && inside(2.2)) return face.rim;
  return face.colour;
});

// --- 1. the salt rain ---
const flakes = kit.spray([333, 1], kit.tex(333, 0), [0, 3.4, 0.9], { radius: 1.9, speed: 0, count: 2, bursts: RAIN / 2, gap: 2, life: 18, scale: 0.13, shape: "ball" });
flakes.axis = [0, -1, 0];
flakes.initVelAxisAmplifier = 0.13;
flakes.behaviors = [{ type: "gravity", magnitude: [0, -0.006, 0] }];
setCurves(flakes, undefined, fadeInOut(1, 0.1, 0.7));
kit.prism(flakes, [WHITE, SALT, PALE_BLUE]);
kit.add("flakes", flakes);

const chips = kit.spray([333, 1], cubeTex, [0, 3.0, 0.9], { radius: 1.5, speed: 0, count: 1, bursts: RAIN / 3, gap: 3, life: 16, scale: 0.22, shape: "ball" });
chips.axis = [0, -1, 0];
chips.initVelAxisAmplifier = 0.18;
chips.behaviors = [{ type: "gravity", magnitude: [0, -0.01, 0] }];
spin(chips, -0.25, 0.25, 0, true);
setCurves(chips, hold(1), fadeInOut(1, 0.1, 0.75));
paint(chips, WHITE);
kit.add("chips", chips);

const mist = kit.spray([333, 1], kit.tex(321, 5), FOE_FLOOR, { radius: 1.3, speed: 0.03, count: 1, bursts: 5, gap: 4, life: 16, scale: 0.8, shape: "circle" });
mist.startDelayFrames = 6;
mist.emissionAxis = 1;
spin(mist, -0.05, 0.05, 0, true);
setCurves(mist, grow(0.4, 0.3, 1.4), fadeInOut(0.5, 0.2, 0.6));
paint(mist, PALE_BLUE, WHITE, GREY_BLUE);
kit.add("mist", mist);

const specks = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 1.8, speed: 0, count: 1, bursts: RAIN / 3, gap: 3, life: 10, scale: 0.16, shape: "ball" });
specks.startDelayFrames = 4;
setCurves(specks, undefined, twinkle(1));
paint(specks, WHITE);
kit.add("specks", specks);

// --- 2. the mound of salt cubes, piled bottom row first ---
const ENCASE = BUILD + ENCASED;
const pile: Array<[number, number, number]> = [
  // [x, y, z-offset] round the foe, mid-body anchor
  [-1.3, -1.05, 0.25], [-0.45, -1.15, 0.4], [0.45, -1.1, 0.35], [1.3, -1.0, 0.25],
  [-0.9, -0.2, 0.3], [0.05, -0.25, 0.45], [0.95, -0.15, 0.3],
  [-0.45, 0.65, 0.35], [0.5, 0.6, 0.3],
  [0.05, 1.35, 0.25],
];
pile.forEach(([x, y, dz], i) => {
  const row = y < -0.6 ? 0 : y < 0.2 ? 1 : y < 1 ? 2 : 3;
  const delay = row * 3 + (i % 2);
  const r = kit.parked(cubeTex, [x, y, FOE[2] + dz], 0.95 - row * 0.06, ENCASE - delay);
  r.startDelayFrames = delay;
  r.initAngle = deg(((i * 47) % 40) - 20);
  setCurves(r, { start: 0.2, mid: 1, end: 1, curveIn: 3 / (ENCASE - delay), curveOut: 1 }, hold(1));
  paint(r, WHITE);
  kit.add(`cube${i}`, r);
});

const glow = kit.parked(kit.tex(465, 1), [0, -0.1, FOE[2] + 0.1], 3.4, ENCASE);
setCurves(glow, grow(0.3, 0.3, 1.05), fadeInOut(0.55, 0.2, 0.9));
paint(glow, WHITE, PALE_BLUE, WHITE);
kit.add("glow", glow);

const puffs = kit.spray([333, 1], kit.tex(321, 5), [0, -0.3, 0.9], { radius: 1.7, speed: 0.06, count: 1, bursts: 6, gap: 4, life: 12, scale: 0.5, shape: "circle" });
puffs.startDelayFrames = BUILD;
spin(puffs, -0.08, 0.08, 0, true);
setCurves(puffs, grow(0.4, 0.3, 1.3), fadeInOut(0.7, 0.2, 0.5));
paint(puffs, WHITE, WHITE, PALE_BLUE);
kit.add("puffs", puffs);

// --- 3. the salt breaks open ---
const blocks = kit.spray([333, 1], cubeTex, [0, -0.1, 1.0], { radius: 1.0, speed: 0.34, count: 10, life: 20, scale: 0.6, shape: "ball" });
blocks.aspectRatio = 0.65; // rectangular salt blocks
blocks.axis = [0, 1, 0];
blocks.initVelAxisAmplifier = 0.16;
blocks.behaviors = [{ type: "gravity", magnitude: [0, -0.022, 0] }];
spin(blocks, -0.25, 0.25, 0, true);
setCurves(blocks, hold(1), fadeOut(1, 0.65));
paint(blocks, WHITE);
kit.add("blocks", blocks);

const flash = kit.parked(kit.tex(228, 1), FOE, 2.0, 12);
spin(flash, 0.05);
setCurves(flash, grow(0.4, 0.2, 2.2), fadeOut(1, 0.35));
paint(flash, WHITE, WHITE, PALE_BLUE);
kit.add("flash", flash);

const spray = kit.spray([333, 1], kit.tex(321, 5), FOE_FLOOR, { radius: 0.9, speed: 0.12, count: 5, life: 14, scale: 0.9, shape: "circle" });
spray.axis = [0, 1, 0];
spray.initVelAxisAmplifier = 0.08;
spin(spray, -0.08, 0.08, 0, true);
setCurves(spray, grow(0.4, 0.25, 1.6), fadeOut(0.9, 0.4));
paint(spray, WHITE, WHITE, PALE_BLUE);
kit.add("spray", spray);

const shards = kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.5, speed: 0.7, count: 7, life: 8, scale: 1.4, directional: true });
setCurves(shards, undefined, fadeOut());
kit.prism(shards, [WHITE, PALE_BLUE, WHITE]);
kit.add("shards", shards);

const twinkles = kit.spray([333, 1], kit.tex(298, 1), FOE, { radius: 2.0, speed: 0.02, count: 1, bursts: 5, gap: 3, life: 10, scale: 0.28, shape: "ball" });
setCurves(twinkles, twinkle(1), twinkle(1));
paint(twinkles, WHITE);
kit.add("twinkles", twinkles);

// --- script ---
const cubeEmits = pile.map((_, i) => kit.emit(`cube${i}`, "DEFENDER")).join("\n");
const script = `MoveCamera INTERPOLATION, DEFENDER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1445, SE1, 14, 0, 1500, 90, 0, 0, 0
PlaySound 1445, SE2, 14, 10, 1900, 80, 0, 0, 0
PlaySound 1504, SE1, 16, ${RAIN}, 600, 105, 0, 0, 0
PlaySound 1719, SE2, 16, ${RAIN + 3}, 300, 100, 0, 0, 0
PlaySound 1719, SE2, 16, ${RAIN + 7}, 700, 95, 0, 0, 0
PlaySound 1505, SE1, 16, ${RAIN + ENCASE}, 0, 125, 0, 0, 0
PlaySound 1719, SE2, 16, ${RAIN + ENCASE + 2}, 200, 115, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("flakes", "DEFENDER")}
${kit.emit("chips", "DEFENDER")}
${kit.emit("mist", "DEFENDER")}
${kit.emit("specks", "DEFENDER")}
Wait ${RAIN}
${kit.emit("glow", "DEFENDER")}
${cubeEmits}
${kit.emit("puffs", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 3, 28, 30, 31
Wait ${BUILD}
ShakeSprite DEFENDER, 2, 819, 0, 1, 1, ${ENCASED / 2}
Wait ${ENCASED}
${kit.emit("flash", "DEFENDER")}
${kit.emit("blocks", "DEFENDER")}
${kit.emit("spray", "DEFENDER")}
${kit.emit("shards", "DEFENDER")}
${kit.emit("twinkles", "DEFENDER")}
ChangeSpriteColor DEFENDER, 14, 0, 2, 28, 30, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 5
Wait ${BREAK}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [129, 360, 163, 605, 63, 240],
  references: ["reference/Salt_Cure_IX.png", "reference/Salt_Cure_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 0, DEFENDER`, `Emit ${SPA}, 4, DEFENDER`, `Emit ${SPA}, 13, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  rain f${CAMERA_IN}, encase f${CAMERA_IN + RAIN}, break f${CAMERA_IN + RAIN + ENCASE}`);
