MoveCamera INTERPOLATION, DEFENDER, 14, 0, 8
LetCMDsFinish CAMERA
LoadSPA 921
AudioContainer CONTINUE
PlaySound 1445, SE1, 14, 0, 1500, 90, 0, 0, 0
PlaySound 1445, SE2, 14, 10, 1900, 80, 0, 0, 0
PlaySound 1504, SE1, 16, 22, 600, 105, 0, 0, 0
PlaySound 1719, SE2, 16, 25, 300, 100, 0, 0, 0
PlaySound 1719, SE2, 16, 29, 700, 95, 0, 0, 0
PlaySound 1505, SE1, 16, 52, 0, 125, 0, 0, 0
PlaySound 1719, SE2, 16, 54, 200, 115, 0, 0, 0
AudioContainer SUSPEND
Emit 921, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 22
Emit 921, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 3, 28, 30, 31
Wait 10
ShakeSprite DEFENDER, 2, 819, 0, 1, 1, 10
Wait 20
Emit 921, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 921, 20, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor DEFENDER, 14, 0, 2, 28, 30, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 5
Wait 26
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
