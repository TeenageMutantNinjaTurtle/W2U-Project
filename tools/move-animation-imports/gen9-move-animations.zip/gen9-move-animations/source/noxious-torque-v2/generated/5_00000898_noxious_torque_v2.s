MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 891
AudioContainer CONTINUE
PlaySound 1487, SE1, 14, 0, 500, 70, 0, 0, 0
PlaySound 1487, SE1, 14, 12, 900, 80, 0, 0, 0
PlaySound 1446, SE2, 14, 4, 0, 100, 0, 0, 0
PlaySound 1536, SE2, 14, 24, 0, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 8, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 1, 4, 0, 6
ChangeSpriteColor ATTACKER, 0, 10, 2, 20, 8, 28
Emit 891, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 891, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 891, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 13
Wait 26
ChangeSpriteColor ATTACKER, 10, 0, 1, 20, 8, 28
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
AudioContainer CONTINUE
PlaySound 1420, SE1, 16, 0, -300, 125, 0, 0, 0
PlaySound 1446, SE2, 16, 0, 300, 120, 0, 0, 0
PlaySound 1875, SE1, 16, 4, -300, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 891, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 891, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 891, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 891, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 891, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 891, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 891, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 22, 8, 28
Wait 4
ChangeSpriteColor DEFENDER, 12, 0, 1, 22, 8, 28
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 18
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 8, 0, 1, 4, 0, 6
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
