import { buildTorque } from "../tools/torque-v2";

// Noxious Torque (move 898), v2 - from Bulbapedia's stills (reference/).
//   1. Violet poison flames pour up round the Starmobile.
//   2. A purple swirl on the ground round the foe, magenta spikes and dark
//      purple globs splattering up round a yellow spark.
// Shared structure in ../tools/torque-v2.ts. v1 is in ../noxious-torque.
const VIOLET: [number, number, number] = [0.65, 0.3, 1.0];
const MAGENTA: [number, number, number] = [1.0, 0.35, 0.9];
const DEEP: [number, number, number] = [0.35, 0.08, 0.55];
const PALE: [number, number, number] = [1.0, 0.75, 1.0];
const YELLOW: [number, number, number] = [1.0, 0.92, 0.35];
const WHITE: [number, number, number] = [1, 1, 1];

await buildTorque({
  workDir: import.meta.dirname, slug: "noxious-torque-v2", moveId: 898, spaId: 891,
  references: ["reference/Noxious_Torque_IX.png", "reference/Noxious_Torque_IX_2.png"],
  aura: [VIOLET, MAGENTA, DEEP], rising: "flame",
  vortex: [VIOLET, MAGENTA, DEEP],
  fan: [MAGENTA, VIOLET, PALE],
  core: [YELLOW, WHITE, YELLOW],
  extra: "blobs", extraColours: [DEEP, VIOLET, MAGENTA],
  userTint: [20, 8, 28], foeTint: [22, 8, 28], dim: [4, 0, 6],
  revSounds: ["PlaySound 1446, SE2, 14, 4, 0, 100, 0, 0, 0"],
  hitSounds: ["PlaySound 1446, SE2, 16, 0, 300, 120, 0, 0, 0", "PlaySound 1875, SE1, 16, 4, -300, 110, 0, 0, 0"],
});
