import { createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Order Up (move 856), v2 - from Logan's keyframes (reference/keyframe-*):
//   1. Start: a thin glowing gold ring with a four-point gold sparkle at its
//      centre appears in front of the user - the order bell.
//   2. Slam: a wooden plank lies under the foe and three nigiri (tamago,
//      salmon, tuna) drop out of the sky one after another and slam down on
//      it, a white flash and light rays bursting at the foe's base.
//   3. Hold: the three nigiri sit in a row on the foe for about a second in
//      front of a big yellow-orange comic burst, pink sparkles twinkling.
// v1 (../order-up, one drawn platter) is kept; reinstall its manifest to
// revert.
//
// Drawn here (a3i5, see generated/): each nigiri (32x32: rice oval, draped
// topping, dark outline; the tamago with a nori band, the salmon with fat
// stripes) and the plank (64x16: light top face, grained front face).

const SPA = 915;
const kit = await createKit({ workDir: import.meta.dirname, slug: "order-up-v2", moveId: 856, spaId: SPA, donors: [298, 407, 579, 228, 411, 465] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const DING = 20;
const PAN = 10;
const FALL = 6;
const STAGGER = 3;
const HOLD = 30; // after the last nigiri lands

// --- placement (defender-relative; "2px" anchor is mid-body) ---
const BELL: Vec3 = [0.7, 1.3, -1.3]; // in front of the user, at head height
const FOE_Z = 0.9;
const PLANK: Vec3 = [0, -1.55, FOE_Z];
const SEAT_Y = -0.7;
const DROP_HEIGHT = 5.2;
const SUSHI_SCALE = 1.1;
const SPACING = 1.7;

const GOLD: Rgb = [1.0, 0.82, 0.3];
const PALE_GOLD: Rgb = [1.0, 0.95, 0.65];
const YELLOW: Rgb = [1.0, 0.88, 0.3];
const ORANGE: Rgb = [1.0, 0.55, 0.15];
const PINK: Rgb = [1.0, 0.5, 0.75];
const WHITE: Rgb = [1, 1, 1];

// --- drawn textures ---
type Px = [number, number, number];
const OUTLINE: Px = [74, 48, 32];
function outlined(w: number, h: number, paintPx: (x: number, y: number) => Px | undefined): (x: number, y: number) => Px | undefined {
  const grid: (Px | undefined)[] = [];
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) grid.push(paintPx(x, y));
  const solid = (x: number, y: number) => x >= 0 && x < w && y >= 0 && y < h && grid[y * w + x] !== undefined;
  return (x, y) => grid[y * w + x] ?? ([[1, 0], [-1, 0], [0, 1], [0, -1]].some(([ox, oy]) => solid(x + ox!, y + oy!)) ? OUTLINE : undefined);
}

const RICE: Px = [248, 246, 236];
const RICE_SHADE: Px = [220, 216, 202];
const RICE_GRAIN: Px = [232, 228, 214];
const NORI: Px = [34, 50, 40];
interface Topping { base: Px; light: Px; dark: Px; stripe?: Px; nori?: boolean }
function nigiri(t: Topping): (x: number, y: number) => Px | undefined {
  return outlined(32, 32, (x, y) => {
    const px = x + 0.5;
    const py = y + 0.5;
    const u = (px - 16) / 13; // -1..1 across the topping
    const top = 10 + 3.2 * u * u;
    const bottom = 18 + 2.2 * (1 - u * u);
    const onTopping = Math.abs(u) <= 1 && py >= top && py <= bottom;
    if (t.nori && px >= 14 && px <= 18.5 && py >= top - 0.5 && py <= 25.5) return NORI;
    if (onTopping) {
      if (py < top + 2) return t.light;
      if (py > bottom - 1.2) return t.dark;
      if (t.stripe && Math.round(px - py * 0.8) % 6 === 0) return t.stripe;
      return t.base;
    }
    const rx = (px - 16) / 12;
    const ry = (py - 20.5) / 6;
    if (rx * rx + ry * ry <= 1) return py > 23.5 ? RICE_SHADE : (x * 7 + y * 3) % 9 === 0 ? RICE_GRAIN : RICE;
    return undefined;
  });
}
const tamagoTex = await kit.drawn("tamago", 32, 32, "a3i5", nigiri({ base: [250, 206, 70], light: [255, 232, 150], dark: [214, 160, 40], nori: true }));
const salmonTex = await kit.drawn("salmon", 32, 32, "a3i5", nigiri({ base: [250, 128, 64], light: [255, 172, 122], dark: [212, 92, 40], stripe: [255, 204, 170] }));
const tunaTex = await kit.drawn("tuna", 32, 32, "a3i5", nigiri({ base: [214, 44, 54], light: [240, 112, 112], dark: [160, 24, 36] }));

const WOOD: Px = [206, 160, 108];
const WOOD_LIGHT: Px = [238, 204, 152];
const WOOD_GRAIN: Px = [184, 138, 90];
const plankTex = await kit.drawn("plank", 64, 16, "a3i5", outlined(64, 16, (x, y) => {
  if (x < 2 || x > 61 || y < 4 || y > 11) return undefined;
  if (y <= 6) return WOOD_LIGHT;
  return (x * 5 + y * 13) % 17 < 2 ? WOOD_GRAIN : WOOD;
}));

// --- 1. the order bell ---
const ring = kit.parked(kit.tex(298, 2), BELL, 1.6, DING);
setCurves(ring, grow(0.2, 0.25, 1.1), fadeInOut(1, 0.1, 0.75));
paint(ring, GOLD, PALE_GOLD, GOLD);
kit.add("ring", ring);

const ringGlow = kit.parked(kit.tex(465, 1), BELL, 1.8, DING);
setCurves(ringGlow, grow(0.2, 0.25, 1.1), fadeInOut(0.35, 0.1, 0.75));
paint(ringGlow, PALE_GOLD, WHITE, GOLD);
kit.add("ringGlow", ringGlow);

const sparkle = kit.parked(kit.tex(407, 1), BELL, 0.8, DING - 2);
sparkle.startDelayFrames = 2;
spin(sparkle, 0.05, 0.05, deg(45));
setCurves(sparkle, { start: 0.2, mid: 1.25, end: 0.6, curveIn: 0.2, curveOut: 0.6 }, fadeInOut(1, 0.1, 0.7));
paint(sparkle, WHITE, WHITE, PALE_GOLD);
kit.add("sparkle", sparkle);

// --- 2. the slam ---
const SLAM_LIFE = 2 * STAGGER + FALL + HOLD;
const plank = kit.parked(plankTex, PLANK, 0.8, SLAM_LIFE + 4);
plank.aspectRatio = 4; // 64x16 texture
setCurves(plank, { start: 0.3, mid: 1, end: 1, curveIn: 0.08, curveOut: 1 }, fadeInOut(1, 0.05, 0.9));
paint(plank, WHITE);
kit.add("plank", plank);

const order: Array<{ name: string; tex: number; x: number; tilt: number }> = [
  { name: "tamago", tex: tamagoTex, x: -SPACING, tilt: 25 },
  { name: "salmon", tex: salmonTex, x: 0, tilt: -20 },
  { name: "tuna", tex: tunaTex, x: SPACING, tilt: 30 },
];
order.forEach((s, i) => {
  // Falling, tumbling to level just as it lands.
  const fall = kit.parked(s.tex, [s.x * 0.7, SEAT_Y + DROP_HEIGHT, FOE_Z + 0.05 * i], SUSHI_SCALE, FALL);
  fall.startDelayFrames = i * STAGGER;
  fall.axis = [(s.x * 0.3) / DROP_HEIGHT, -1, 0];
  fall.initVelAxisAmplifier = DROP_HEIGHT / FALL;
  spin(fall, -deg(s.tilt) / FALL, -deg(s.tilt) / FALL, deg(s.tilt));
  setCurves(fall, hold(1), hold(1));
  paint(fall, WHITE);
  kit.add(`${s.name}Fall`, fall);

  // Seated: a squash-and-settle bounce, then it stays.
  const seat = kit.parked(s.tex, [s.x, SEAT_Y, FOE_Z + 0.05 * i], SUSHI_SCALE, SLAM_LIFE - i * STAGGER - FALL);
  seat.startDelayFrames = i * STAGGER + FALL;
  setCurves(seat, { start: 1.2, mid: 0.95, end: 1, curveIn: 0.06, curveOut: 0.14 }, fadeInOut(1, 0.01, 0.88));
  paint(seat, WHITE);
  kit.add(`${s.name}Seat`, seat);

  // A small white pop where it lands.
  const pop = kit.spray([333, 1], kit.tex(333, 0), [s.x, SEAT_Y - 0.5, FOE_Z + 0.2], { radius: 0.4, speed: 0.18, count: 4, life: 8, scale: 0.14 });
  pop.startDelayFrames = i * STAGGER + FALL;
  setCurves(pop, undefined, fadeOut());
  paint(pop, WHITE, WHITE, PALE_GOLD);
  kit.add(`${s.name}Pop`, pop);
});

// The first landing: a white flash and light rays bursting at the foe's base.
const FIRST_LAND = FALL;
const BASE: Vec3 = [0, SEAT_Y - 0.3, FOE_Z + 0.1];
const flash = kit.parked(kit.tex(228, 1), BASE, 1.6, 10);
flash.startDelayFrames = FIRST_LAND;
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.2, 2.0), fadeOut(1, 0.35));
paint(flash, WHITE, WHITE, PALE_GOLD);
kit.add("flash", flash);

const rays = kit.spray([228, 3], kit.tex(411, 0), BASE, { radius: 0.3, speed: 0.4, count: 8, life: 9, scale: 2.0, directional: true });
rays.startDelayFrames = FIRST_LAND;
rays.axis = [0, 1, 0];
rays.initVelAxisAmplifier = 0.35;
setCurves(rays, undefined, fadeOut(1, 0.45));
paint(rays, WHITE, WHITE, PALE_GOLD);
kit.add("rays", rays);

// --- 3. the hold: comic burst behind the row, pink sparkles ---
const LAST_LAND = 2 * STAGGER + FALL;
const burst = (scale: number, colour: Rgb, start: Rgb, rate: number, z: number) => {
  const r = kit.parked(kit.tex(579, 2), [0, SEAT_Y + 0.5, z], scale, HOLD);
  r.startDelayFrames = LAST_LAND;
  spin(r, rate);
  setCurves(r, { start: 0.3, mid: 1, end: 1.05, curveIn: 0.12, curveOut: 1 }, fadeInOut(1, 0.05, 0.8));
  paint(r, colour, start, colour);
  return r;
};
kit.add("burstOuter", burst(3.4, ORANGE, YELLOW, 0.012, FOE_Z - 0.5));
kit.add("burstInner", burst(2.6, YELLOW, WHITE, -0.015, FOE_Z - 0.45));

const sparkles = kit.spray([333, 1], kit.tex(298, 1), [0, SEAT_Y + 0.4, FOE_Z + 0.3], { radius: 2.4, speed: 0.01, count: 1, bursts: 8, gap: 3, life: 10, scale: 0.3, shape: "ball" });
sparkles.startDelayFrames = LAST_LAND;
setCurves(sparkles, twinkle(1), twinkle(1));
kit.prism(sparkles, [PINK, WHITE, PALE_GOLD]);
kit.add("sparkles", sparkles);

// --- script ---
const slamEmits = ["plank", ...order.flatMap((s) => [`${s.name}Fall`, `${s.name}Seat`, `${s.name}Pop`]), "flash", "rays", "burstOuter", "burstInner", "sparkles"]
  .map((n) => kit.emit(n, "DEFENDER"))
  .join("\n");
const landSounds = order.map((_, i) => `PlaySound 1420, SE${i % 2 ? 2 : 1}, 16, ${i * STAGGER + FALL}, ${-200 + i * 150}, ${127 - i * 10}, 0, 0, 0`).join("\n");
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1509, SE1, 14, 0, 900, 115, 0, 0, 0
PlaySound 1509, SE2, 14, 5, 1300, 95, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("ringGlow", "ATTACKER")}
${kit.emit("ring", "ATTACKER")}
${kit.emit("sparkle", "ATTACKER")}
Wait ${DING}
MoveCamera INTERPOLATION, DEFENDER, ${PAN}, 0, 8
Wait ${PAN}
AudioContainer CONTINUE
PlaySound 1424, SE2, 14, 0, 700, 90, 0, 0, 0
${landSounds}
PlaySound 1475, SE2, 16, ${FIRST_LAND}, 200, 100, 0, 0, 0
PlaySound 1509, SE1, 14, ${LAST_LAND + 2}, 600, 100, 0, 0, 0
AudioContainer SUSPEND
${slamEmits}
Wait ${FIRST_LAND}
ToggleFreezeSprite DEFENDER, START
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 3
Wait ${STAGGER}
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 2
Wait ${STAGGER}
ShakeScreen VERTICAL, 1x, 0, 2, 0, 3
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 8
Wait ${HOLD}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [381, 236, 400, 63, 129, 605],
  references: ["reference/keyframe-1-start.png", "reference/keyframe-2-slam.png", "reference/keyframe-3-hold.png", "reference/Order_Up_IX.png", "reference/Order_Up_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 3, DEFENDER`, `Emit ${SPA}, 4, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
const landAt = CAMERA_IN + DING + PAN;
console.log(`  ding f${CAMERA_IN}, lands f${landAt + FALL}/${landAt + FALL + STAGGER}/${landAt + LAST_LAND}, hold to f${landAt + LAST_LAND + HOLD}`);
