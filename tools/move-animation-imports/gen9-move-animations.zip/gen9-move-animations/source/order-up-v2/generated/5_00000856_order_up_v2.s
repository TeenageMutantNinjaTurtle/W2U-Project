MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 915
AudioContainer CONTINUE
PlaySound 1509, SE1, 14, 0, 900, 115, 0, 0, 0
PlaySound 1509, SE2, 14, 5, 1300, 95, 0, 0, 0
AudioContainer SUSPEND
Emit 915, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 915, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 915, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 20
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
AudioContainer CONTINUE
PlaySound 1424, SE2, 14, 0, 700, 90, 0, 0, 0
PlaySound 1420, SE1, 16, 6, -200, 127, 0, 0, 0
PlaySound 1420, SE2, 16, 9, -50, 117, 0, 0, 0
PlaySound 1420, SE1, 16, 12, 100, 107, 0, 0, 0
PlaySound 1475, SE2, 16, 6, 200, 100, 0, 0, 0
PlaySound 1509, SE1, 14, 14, 600, 100, 0, 0, 0
AudioContainer SUSPEND
Emit 915, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 915, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 915, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 915, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 915, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 915, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 915, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 915, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 915, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 915, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 915, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 915, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 915, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 915, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 915, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 6
ToggleFreezeSprite DEFENDER, START
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 3
Wait 3
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 2
Wait 3
ShakeScreen VERTICAL, 1x, 0, 2, 0, 3
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 8
Wait 30
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
