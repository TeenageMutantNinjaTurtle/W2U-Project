import { aimed, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Electro Shot (move 905) - from Bulbapedia's stills (reference/). A two-turn
// move, so the script has two parts, as retail Solar Beam's does: header
// entries 0-13 play on the charging turn, 14-27 on the firing turn.
//   1. Charging: the user glows pale blue-white as white, blue and yellow
//      lightning crackles back and forth across it.
//   2. Firing: a yellow-white electric beam blasts into the foe: a white
//      flash, yellow bolts, blue sparks and streaks.
// The Sp. Atk rise and firing at once in rain are handled by the engine.

const SPA = 898;
const kit = await createKit({ workDir: import.meta.dirname, slug: "electro-shot", moveId: 905, spaId: SPA, donors: [697, 228, 465, 579, 411] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const CHARGE = 34;
const AIM = 8;
const BEAM_SPEED = 2.0;
const TRAVEL = 8;
const HIT_STOP = 5;
const HOLD = 24;

const USER: Vec3 = [0, 0.3, 0.2];
const MUZZLE: Vec3 = [0.4, 0.6, -1.0];
const FOE: Vec3 = [0, 0.3, 0.8];

const YELLOW: Rgb = [1.0, 0.92, 0.3];
const PALE_YELLOW: Rgb = [1.0, 0.98, 0.72];
const BLUE: Rgb = [0.45, 0.65, 1.0];
const PALE_BLUE: Rgb = [0.8, 0.9, 1.0];
const WHITE: Rgb = [1, 1, 1];

function bolts(pos: Vec3, opts: Parameters<typeof kit.spray>[3], colours: [Rgb, Rgb, Rgb]): ReturnType<typeof kit.spray> {
  const r = kit.spray([333, 1], kit.tex(697, 0), pos, opts);
  r.texAnim = structuredClone(kit.spa(697).resources[0]!.texAnim);
  r.texAnim!.textures = r.texAnim!.textures.map((t, i) => (i < r.texAnim!.textureCount ? kit.tex(697, t) : 0));
  spin(r, 0, 0, 0, true);
  setCurves(r, hold(1), fadeOut(1, 0.6));
  r.loopFrames = 7;
  kit.prism(r, colours);
  return r;
}

// --- turn 1: charging ---
const glow = kit.parked(kit.tex(465, 1), USER, 2.8, CHARGE + 2);
setCurves(glow, grow(0.5, 0.35, 1.15), fadeInOut(0.7, 0.25, 0.85));
paint(glow, PALE_BLUE, WHITE, BLUE);
kit.add("glow", glow);

kit.add("crackle", bolts(USER, { radius: 1.8, speed: 0, count: 1, bursts: 11, gap: 3, life: 6, scale: 0.85, shape: "ball" }, [WHITE, BLUE, YELLOW]));

const sparks = kit.spray([333, 1], kit.tex(333, 0), [0, -1.2, 0.2], { radius: 1.8, speed: 0, count: 1, bursts: 12, gap: 2, life: 14, scale: 0.14, shape: "circle" });
sparks.emissionAxis = 1;
sparks.axis = [0, 1, 0];
sparks.initVelAxisAmplifier = 0.15;
setCurves(sparks, undefined, twinkle());
kit.prism(sparks, [YELLOW, PALE_BLUE, WHITE]);
kit.add("sparks", sparks);

const arcs = kit.spray([228, 3], kit.tex(411, 0), USER, { radius: 1.2, speed: 0.25, count: 1, bursts: 8, gap: 4, life: 6, scale: 1.2, directional: true });
setCurves(arcs, undefined, fadeOut());
kit.prism(arcs, [WHITE, PALE_BLUE, YELLOW]);
kit.add("arcs", arcs);

// --- turn 2: firing ---
const muzzle = kit.parked(kit.tex(228, 1), MUZZLE, 1.0, AIM + TRAVEL + 4);
spin(muzzle, 0.15);
setCurves(muzzle, grow(0.3, 0.3, 1.3), fadeInOut(1, 0.2, 0.8));
paint(muzzle, PALE_YELLOW, WHITE, YELLOW);
kit.add("muzzle", muzzle);

function stream(scale: number, colour: Rgb, start: Rgb): ReturnType<typeof kit.shell> {
  const r = kit.shell(228, 0);
  r.textureIndex = kit.tex(228, 1);
  aimed(r, BEAM_SPEED, TRAVEL);
  Object.assign(r, { emitterBasePos: [...MUZZLE], baseScale: scale, emitterLifeFrames: 12, emissionIntervalFrames: 1, airResistance: 1.0 });
  setCurves(r, hold(1), hold(1));
  paint(r, colour, start, colour);
  return r;
}
kit.add("beam", stream(1.0, YELLOW, PALE_YELLOW));
kit.add("core", stream(0.45, WHITE, WHITE));

kit.add("beamBolts", bolts(MUZZLE, { radius: 0.6, speed: 0, count: 1, bursts: 6, gap: 2, life: 5, scale: 0.7, shape: "ball" }, [YELLOW, WHITE, BLUE]));

const flash = kit.parked(kit.tex(228, 1), FOE, 2.0, 14);
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.2, 2.2), fadeOut(1, 0.35));
paint(flash, WHITE, WHITE, PALE_YELLOW);
kit.add("flash", flash);

const spiky = kit.parked(kit.tex(579, 2), FOE, 1.6, 12);
spin(spiky, 0.12);
setCurves(spiky, grow(0.4, 0.25, 1.5), fadeOut(1, 0.35));
paint(spiky, YELLOW, WHITE, PALE_YELLOW);
kit.add("spiky", spiky);

kit.add("foeBolts", bolts(FOE, { radius: 1.3, speed: 0.1, count: 1, bursts: 5, gap: 3, life: 7, scale: 0.9, shape: "ball" }, [YELLOW, WHITE, BLUE]));

const streaks = kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.3, speed: 0.8, count: 6, life: 8, scale: 2.2, directional: true });
setCurves(streaks, undefined, fadeOut());
kit.prism(streaks, [WHITE, PALE_BLUE, YELLOW]);
kit.add("streaks", streaks);

const blueSparks = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.5, speed: 0.4, count: 7, life: 12, scale: 0.13 });
setCurves(blueSparks, undefined, twinkle());
kit.prism(blueSparks, [BLUE, WHITE, YELLOW]);
kit.add("blueSparks", blueSparks);

// --- script: two parts ---
const charge = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1759, PSG, 16, 0, 300, 60, 0, 0, 0
PlaySound 1418, SE1, 14, 4, 600, 100, 0, 0, 0
PlaySound 1710, SE2, 14, 14, 200, 90, 0, 0, 0
PlaySound 1710, SE2, 14, 26, 500, 90, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 1, 2, 3, 10
ChangeSpriteColor ATTACKER, 0, 12, 3, 22, 26, 31
${kit.emit("glow", "ATTACKER")}
${kit.emit("crackle", "ATTACKER")}
${kit.emit("sparks", "ATTACKER")}
${kit.emit("arcs", "ATTACKER")}
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 16
Wait ${CHARGE}
ChangeSpriteColor ATTACKER, 12, 0, 2, 22, 26, 31
LetCMDsFinish PARTICLE
ChangeBackgroundColor 4, 8, 0, 1, 2, 3, 10
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript`;

const fire = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1418, SE1, 14, 0, 900, 100, 0, 0, 0
PlaySound 1376, PSG, 14, ${AIM}, 0, 0, 0, 0, 0
AdjustSound PSG, 0, 0, 0, 3000, 0, 34, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 1, 2, 3, 10
ChangeSpriteColor ATTACKER, 0, 12, 0, 31, 30, 18
${kit.emit("muzzle", "ATTACKER")}
Wait ${AIM}
${kit.emit("beam", "ATTACKER", "DEFENDER")}
${kit.emit("core", "ATTACKER", "DEFENDER")}
${kit.emit("beamBolts", "ATTACKER")}
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -1px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, ${TRAVEL}, 0, 8
Wait ${TRAVEL}
AudioContainer CONTINUE
PlaySound 1710, SE1, 16, 0, 0, 127, 0, 0, 0
PlaySound 1475, SE2, 16, 0, -300, 125, 0, 0, 0
PlaySound 1514, SE1, 16, ${HIT_STOP + 4}, 200, 110, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("flash", "DEFENDER")}
${kit.emit("spiky", "DEFENDER")}
${kit.emit("foeBolts", "DEFENDER")}
${kit.emit("streaks", "DEFENDER")}
${kit.emit("blueSparks", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 31, 14
Wait ${HIT_STOP}
ChangeSpriteColor ATTACKER, 12, 0, 2, 31, 30, 18
ChangeSpriteColor DEFENDER, 14, 0, 1, 31, 31, 14
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 8
Wait ${HOLD - HIT_STOP}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 8, 0, 1, 2, 3, 10
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript`;

const header = (label: string) => Array.from({ length: 14 }, () => `.word ${label}`).join("\n");
const script = `.include "B2W2_MOVSCRCMD.s"
.align 4

.word 2 @ Count
${header("SCRIPT_CHARGE")}
${header("SCRIPT_FIRE")}

SCRIPT_CHARGE:
${charge}

SCRIPT_FIRE:
${fire}
`;

await kit.finish({
  script,
  donorMoveIds: [76, 527, 63, 87, 85],
  references: ["reference/Electro_Shot_IX.png", "reference/Electro_Shot_IX_2.png"],
  expectText: [".word 2 @ Count", `LoadSPA ${SPA}`, `Emit ${SPA}, 1, ATTACKER`, `Emit ${SPA}, 5, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 8, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  charge turn ~${CAMERA_IN + CHARGE + 12}f; fire turn: beam f${CAMERA_IN + AIM}, hit f${CAMERA_IN + AIM + TRAVEL}`);
