.include "B2W2_MOVSCRCMD.s"
.align 4

.word 2 @ Count
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_CHARGE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE
.word SCRIPT_FIRE

SCRIPT_CHARGE:
MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 898
AudioContainer CONTINUE
PlaySound 1759, PSG, 16, 0, 300, 60, 0, 0, 0
PlaySound 1418, SE1, 14, 4, 600, 100, 0, 0, 0
PlaySound 1710, SE2, 14, 14, 200, 90, 0, 0, 0
PlaySound 1710, SE2, 14, 26, 500, 90, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 1, 2, 3, 10
ChangeSpriteColor ATTACKER, 0, 12, 3, 22, 26, 31
Emit 898, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 898, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 898, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 898, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 16
Wait 34
ChangeSpriteColor ATTACKER, 12, 0, 2, 22, 26, 31
LetCMDsFinish PARTICLE
ChangeBackgroundColor 4, 8, 0, 1, 2, 3, 10
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript

SCRIPT_FIRE:
MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 898
AudioContainer CONTINUE
PlaySound 1418, SE1, 14, 0, 900, 100, 0, 0, 0
PlaySound 1376, PSG, 14, 8, 0, 0, 0, 0, 0
AdjustSound PSG, 0, 0, 0, 3000, 0, 34, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 1, 2, 3, 10
ChangeSpriteColor ATTACKER, 0, 12, 0, 31, 30, 18
Emit 898, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 8
Emit 898, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 898, 6, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 898, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -1px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
AudioContainer CONTINUE
PlaySound 1710, SE1, 16, 0, 0, 127, 0, 0, 0
PlaySound 1475, SE2, 16, 0, -300, 125, 0, 0, 0
PlaySound 1514, SE1, 16, 9, 200, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 898, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 898, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 898, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 898, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 898, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 31, 14
Wait 5
ChangeSpriteColor ATTACKER, 12, 0, 2, 31, 30, 18
ChangeSpriteColor DEFENDER, 14, 0, 1, 31, 31, 14
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 8
Wait 19
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 8, 0, 1, 2, 3, 10
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
