import { aimed, createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Glaive Rush (move 862), v2 - from Logan's keyframes (reference/keyframe-1..6):
//   1. Startup: the user's colour shifts to purple.
//   2. It is enveloped in a bright magenta glow.
//   3-4. It launches at the foe, a blue-cyan and violet aura streaming off its
//      glaive like flame, white spray kicking up from the ground.
//   5. Contact: violet light streaks erupt upward, white spray, pink sparkles.
//   6. A huge colourful explosion: a magenta slash cutting across the ground,
//      violet streaks bursting out, dark purple smoke, magenta arcs and a
//      flash of cyan.
// 120 power: a long hit-stop and a heavy shake. The defence drop afterwards
// is handled by the engine.
// v1 (../glaive-rush) is kept; reinstall its manifest to revert.

const SPA = 920;
const kit = await createKit({ workDir: import.meta.dirname, slug: "glaive-rush-v2", moveId: 862, spaId: SPA, donors: [465, 321, 228, 411, 333, 606, 579, 298] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const STARTUP = 10;
const ENVELOP = 16;
const LAUNCH = 9;
const BLOW = 3; // contact to the big explosion
const HIT_STOP = 6;
const HOLD = 28;

const USER: Vec3 = [0, 0.3, 0.2];
const FEET: Vec3 = [0, -1.5, 0.2];
const CREST: Vec3 = [0.2, 1.0, -0.6];
const FOE: Vec3 = [0, 0.3, 0.8];
const FOE_FLOOR: Vec3 = [0, -1.4, 1.0];

const PURPLE: Rgb = [0.6, 0.25, 0.95];
const MAGENTA: Rgb = [1.0, 0.3, 0.85];
const PINK: Rgb = [1.0, 0.6, 0.9];
const VIOLET: Rgb = [0.55, 0.3, 1.0];
const BLUE: Rgb = [0.35, 0.55, 1.0];
const CYAN: Rgb = [0.4, 0.9, 1.0];
const SMOKE: Rgb = [0.3, 0.08, 0.45];
const WHITE: Rgb = [1, 1, 1];

// --- 1-2. startup and envelope ---
const aura = kit.parked(kit.tex(465, 1), USER, 3.2, ENVELOP + 4);
aura.startDelayFrames = STARTUP - 2;
setCurves(aura, grow(0.4, 0.35, 1.15), fadeInOut(0.75, 0.3, 0.85));
paint(aura, MAGENTA, PINK, PURPLE);
kit.add("aura", aura);

const flames = kit.spray([228, 3], kit.tex(321, 6), FEET, { radius: 1.8, speed: 0, count: 2, bursts: ENVELOP / 2, gap: 2, life: 11, scale: 0.85, shape: "circle", directional: true });
flames.startDelayFrames = STARTUP;
flames.emissionAxis = 1;
flames.axis = [0, 1, 0];
flames.initVelAxisAmplifier = 0.24;
setCurves(flames, grow(0.4, 0.3, 1.3), fadeInOut(0.9, 0.2, 0.55));
kit.prism(flames, [MAGENTA, PINK, VIOLET]);
kit.add("flames", flames);

const glints = kit.spray([333, 1], kit.tex(333, 0), USER, { radius: 2.0, speed: 0, count: 1, bursts: ENVELOP / 2, gap: 2, life: 10, scale: 0.13, shape: "ball" });
glints.startDelayFrames = STARTUP + 2;
glints.axis = [0, 1, 0];
glints.initVelAxisAmplifier = 0.05;
setCurves(glints, undefined, twinkle());
kit.prism(glints, [PINK, WHITE, MAGENTA]);
kit.add("glints", glints);

// --- 3-4. the launch ---
const comet = kit.parked(kit.tex(465, 1), CREST, 2.4, LAUNCH + 1);
aimed(comet, 1.9, LAUNCH + 1);
setCurves(comet, grow(0.6, 0.3, 1.1), hold(0.85));
paint(comet, BLUE, CYAN, VIOLET);
kit.add("comet", comet);

const wisps = kit.spray([333, 1], kit.tex(321, 5), CREST, { radius: 0.7, speed: 0.03, count: 1, bursts: LAUNCH, gap: 1, life: 7, scale: 1.1 });
aimed(wisps, 1.5, 7);
spin(wisps, -0.15, 0.15, 0, true);
setCurves(wisps, grow(0.7, 0.3, 1.4), fadeInOut(0.9, 0.1, 0.5));
kit.prism(wisps, [CYAN, BLUE, VIOLET]);
kit.add("wisps", wisps);

const trail = kit.spray([228, 3], kit.tex(411, 0), USER, { radius: 0.9, speed: 0, count: 1, bursts: LAUNCH, gap: 1, life: 6, scale: 2.2, directional: true });
aimed(trail, 2.1, 6);
setCurves(trail, undefined, fadeInOut(1, 0.2, 0.6));
kit.prism(trail, [MAGENTA, VIOLET, CYAN]);
kit.add("trail", trail);

const skid = kit.spray([333, 1], kit.tex(321, 5), FEET, { radius: 0.5, speed: 0.04, count: 1, bursts: Math.ceil(LAUNCH / 2), gap: 2, life: 10, scale: 0.7 });
aimed(skid, 1.3, 10);
spin(skid, -0.08, 0.08, 0, true);
setCurves(skid, grow(0.4, 0.3, 1.4), fadeInOut(0.75, 0.15, 0.5));
paint(skid, WHITE, WHITE, CYAN);
kit.add("skid", skid);

// --- 5. contact ---
const erupt = kit.spray([228, 3], kit.tex(411, 0), [0, -0.6, 0.9], { radius: 0.6, speed: 0.3, count: 3, bursts: 3, gap: 2, life: 9, scale: 2.0, directional: true });
erupt.axis = [0, 1, 0];
erupt.initVelAxisAmplifier = 0.45;
setCurves(erupt, undefined, fadeOut(1, 0.45));
kit.prism(erupt, [VIOLET, MAGENTA, PINK]);
kit.add("erupt", erupt);

const spray = kit.spray([333, 1], kit.tex(321, 5), FOE_FLOOR, { radius: 1.0, speed: 0.1, count: 3, life: 14, scale: 0.9, shape: "circle" });
spray.emissionAxis = 1;
spin(spray, -0.08, 0.08, 0, true);
setCurves(spray, grow(0.4, 0.3, 1.5), fadeOut(0.8, 0.4));
paint(spray, WHITE, WHITE, CYAN);
kit.add("spray", spray);

const sparkles = kit.spray([333, 1], kit.tex(298, 1), FOE, { radius: 1.6, speed: 0.03, count: 1, bursts: 6, gap: 3, life: 10, scale: 0.28, shape: "ball" });
setCurves(sparkles, twinkle(1), twinkle(1));
kit.prism(sparkles, [PINK, WHITE, MAGENTA]);
kit.add("sparkles", sparkles);

// --- 6. the explosion ---
const blowAt = <T extends { startDelayFrames: number }>(r: T): T => { r.startDelayFrames = BLOW; return r; };

const flash = blowAt(kit.parked(kit.tex(228, 1), FOE, 2.4, 14));
spin(flash, 0.05);
setCurves(flash, grow(0.4, 0.2, 2.4), fadeOut(1, 0.35));
paint(flash, PINK, WHITE, MAGENTA);
kit.add("flash", flash);

const spiky = blowAt(kit.parked(kit.tex(579, 2), FOE, 2.2, 14));
spin(spiky, 0.1);
setCurves(spiky, grow(0.4, 0.25, 1.6), fadeOut(1, 0.4));
paint(spiky, MAGENTA, WHITE, VIOLET);
kit.add("spiky", spiky);

const slash = blowAt(kit.parked(kit.tex(333, 2), [0, -1.1, 1.1], 5.0, 16));
slash.aspectRatio = 0.16;
slash.initAngle = deg(-88);
setCurves(slash, grow(0.1, 0.15, 1.05), fadeOut(1, 0.55));
paint(slash, MAGENTA, WHITE, MAGENTA);
kit.add("slash", slash);

const burst = blowAt(kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.4, speed: 0.85, count: 10, life: 10, scale: 2.4, directional: true }));
setCurves(burst, undefined, fadeOut(1, 0.45));
kit.prism(burst, [VIOLET, MAGENTA, CYAN]);
kit.add("burst", burst);

const smoke = blowAt(kit.spray([333, 1], kit.tex(321, 5), FOE, { radius: 0.8, speed: 0.12, count: 4, life: 20, scale: 1.2, shape: "ball" }));
spin(smoke, -0.06, 0.06, 0, true);
setCurves(smoke, grow(0.5, 0.25, 1.5), fadeOut(0.85, 0.5));
kit.prism(smoke, [SMOKE, PURPLE, SMOKE]);
kit.add("smoke", smoke);

const arcs = blowAt(kit.spray([333, 1], kit.tex(606, 3), FOE, { radius: 0.8, speed: 0.3, count: 4, life: 12, scale: 1.4 }));
spin(arcs, -0.25, 0.25, 0, true);
setCurves(arcs, grow(0.5, 0.3, 1.2), fadeOut(1, 0.45));
kit.prism(arcs, [MAGENTA, PINK, VIOLET]);
kit.add("arcs", arcs);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -600, 120, 0, 0, 0
PlaySound 1418, PSG, 14, ${STARTUP}, 300, 110, 0, 0, 0
PlaySound 1421, SE2, 14, ${STARTUP + ENVELOP}, 0, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${LAUNCH}, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 9, 2, 18, 8, 28
${kit.emit("aura", "ATTACKER")}
${kit.emit("flames", "ATTACKER")}
${kit.emit("glints", "ATTACKER")}
Wait ${STARTUP}
ChangeSpriteColor ATTACKER, 9, 15, 1, 31, 10, 28
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 10
Wait ${ENVELOP}
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 4px, 49152, 0, 4096, 0
${kit.emit("comet", "ATTACKER", "DEFENDER")}
${kit.emit("wisps", "ATTACKER", "DEFENDER")}
${kit.emit("trail", "ATTACKER", "DEFENDER")}
${kit.emit("skid", "ATTACKER", "DEFENDER")}
MoveCamera INTERPOLATION, DEFENDER, ${LAUNCH}, 0, 8
Wait ${LAUNCH}
AudioContainer CONTINUE
PlaySound 1420, SE2, 16, 0, -300, 120, 0, 0, 0
PlaySound 1475, SE1, 16, ${BLOW}, -500, 127, 0, 0, 0
PlaySound 1423, SE2, 16, ${BLOW}, -400, 125, 0, 0, 0
PlaySound 1475, SE1, 16, ${BLOW + HIT_STOP + 4}, -700, 110, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("erupt", "DEFENDER")}
${kit.emit("spray", "DEFENDER")}
${kit.emit("sparkles", "DEFENDER")}
${kit.emit("flash", "DEFENDER")}
${kit.emit("spiky", "DEFENDER")}
${kit.emit("slash", "DEFENDER")}
${kit.emit("burst", "DEFENDER")}
${kit.emit("smoke", "DEFENDER")}
${kit.emit("arcs", "DEFENDER")}
ChangeSpriteColor ATTACKER, 15, 0, 2, 31, 10, 28
Wait ${BLOW}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 10, 28
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 3
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 14, 0, 2, 31, 10, 28
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 4, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 14
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait ${HOLD - HIT_STOP - BLOW}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [337, 434, 63, 153, 427, 400, 605],
  references: ["reference/keyframe-1.png", "reference/keyframe-2.png", "reference/keyframe-3.webp", "reference/keyframe-4.png", "reference/keyframe-5.png", "reference/keyframe-6.png", "reference/Glaive_Rush_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, `Emit ${SPA}, 3, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 12, DEFENDER`, "ShakeScreen VERTICAL, 2458", "MoveCamera INTERPOLATION, INIT"],
});
const launchAt = CAMERA_IN + STARTUP + ENVELOP;
console.log(`  envelop f${CAMERA_IN + STARTUP}, launch f${launchAt}, contact f${launchAt + LAUNCH}, explosion f${launchAt + LAUNCH + BLOW}`);
