MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 920
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -600, 120, 0, 0, 0
PlaySound 1418, PSG, 14, 10, 300, 110, 0, 0, 0
PlaySound 1421, SE2, 14, 26, 0, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 9, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 9, 2, 18, 8, 28
Emit 920, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 920, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 920, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 10
ChangeSpriteColor ATTACKER, 9, 15, 1, 31, 10, 28
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 10
Wait 16
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 4px, 49152, 0, 4096, 0
Emit 920, 3, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 920, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 920, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 920, 6, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveCamera INTERPOLATION, DEFENDER, 9, 0, 8
Wait 9
AudioContainer CONTINUE
PlaySound 1420, SE2, 16, 0, -300, 120, 0, 0, 0
PlaySound 1475, SE1, 16, 3, -500, 127, 0, 0, 0
PlaySound 1423, SE2, 16, 3, -400, 125, 0, 0, 0
PlaySound 1475, SE1, 16, 13, -700, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 920, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 920, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 920, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 920, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 920, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 920, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 920, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 920, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 920, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor ATTACKER, 15, 0, 2, 31, 10, 28
Wait 3
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 10, 28
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 3
Wait 6
ChangeSpriteColor DEFENDER, 14, 0, 2, 31, 10, 28
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 4, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 14
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 19
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
