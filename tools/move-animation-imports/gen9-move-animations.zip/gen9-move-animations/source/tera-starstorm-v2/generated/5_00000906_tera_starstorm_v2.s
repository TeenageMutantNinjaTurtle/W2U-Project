MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 934
AudioContainer CONTINUE
PlaySound 1783, SE1, 14, 0, 0, 110, 0, 0, 0
PlaySound 1509, SE2, 14, 15, 200, 90, 0, 0, 0
PlaySound 1509, SE2, 14, 30, 500, 95, 0, 0, 0
PlaySound 1509, SE2, 14, 45, 800, 100, 0, 0, 0
PlaySound 1816, SE2, 14, 52, 600, 110, 0, 0, 0
PlaySound 1418, PSG, 14, 60, 400, 115, 0, 0, 0
PlaySound 1376, PSG, 14, 120, 0, 0, 0, 0, 0
PlaySound 1509, SE1, 16, 130, 300, 105, 0, 0, 0
PlaySound 1509, SE2, 16, 137, 450, 108, 0, 0, 0
PlaySound 1509, SE1, 16, 144, 600, 111, 0, 0, 0
PlaySound 1509, SE2, 16, 151, 750, 114, 0, 0, 0
PlaySound 1509, SE1, 16, 158, 900, 117, 0, 0, 0
PlaySound 1509, SE2, 16, 165, 1050, 120, 0, 0, 0
PlaySound 1475, SE1, 16, 165, -300, 125, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 11, 2, 1, 4, 6
ChangeSpriteColor ATTACKER, 0, 8, 6, 18, 31, 31
Emit 934, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 11, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 52
ChangeSpriteColor ATTACKER, 8, 15, 2, 26, 31, 31
Wait 8
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 5
Wait 30
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 4
Wait 30
ChangeSpriteColor ATTACKER, 15, 0, 3, 26, 31, 31
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 3
Emit 934, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 20, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 21, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 934, 22, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 7
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 9, 2, 22, 31, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 12
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 3
Wait 35
ChangeSpriteColor DEFENDER, 9, 15, 0, 28, 31, 31
Wait 5
ChangeSpriteColor DEFENDER, 15, 0, 2, 28, 31, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 8
Wait 22
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 11, 0, 2, 1, 4, 6
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
