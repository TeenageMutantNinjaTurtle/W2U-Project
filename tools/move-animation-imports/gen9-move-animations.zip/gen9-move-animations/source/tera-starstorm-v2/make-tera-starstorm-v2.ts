import { createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Tera Starstorm (move 906), v2 - from Logan's keyframes (shown in chat, not
// saved) and brief: "startup makes the user glow -> then emit a large beam to
// the sky -> call down stars that rain down on the target -> dealing damage".
//   1. Glow: the user sits in a pale translucent bubble, green-white light
//      trails circling it; it flares cyan-white and four long white rays
//      cross through it in an X.
//   2. Beam: a great white-cyan pillar of light shoots up into the sky, cyan
//      flames licking at its base and a wide ring of prismatic sparks circling
//      it.
//   3. Stars: yellow stars rain down out of the sky onto the foe among
//      streaks of green-white light, each landing in a burst of cyan-white
//      crystal shards and prismatic sparks; coloured light spots drift.
//   4. The last star lands hardest: a white flash, a tall thin green beam, a
//      hit-stop and a firm shake.
// Second pass (Logan, 2026-10-01): slowed down - the glow takes about two
// seconds, the beam keeps firing for about two more, and every star that
// lands erupts in coloured particles.
// The hack has no Terastallization, so this is the Normal-type look.
// v1 (../tera-starstorm, from the Bulbapedia stills) is kept; reinstall its
// manifest to revert.

const SPA = 934;
const kit = await createKit({ workDir: import.meta.dirname, slug: "tera-starstorm-v2", moveId: 906, spaId: SPA, donors: [228, 298, 560, 465, 411, 579, 321, 333] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const GLOW = 60; // two seconds
const PILLAR = 60; // two more
const PAN = 10;
const FALL = 7; // a star's fall from the sky to the foe
const STARS = 6;
const STAR_GAP = 7;
const HIT_STOP = 5;
const HOLD = 22;

const USER: Vec3 = [0, 0.3, 0.2];
const USER_TOP: Vec3 = [0, 0.8, 0.2];
const USER_FLOOR: Vec3 = [0, -1.3, 0.2];
const FOE: Vec3 = [0, 0.3, 0.8];
const SKY: Vec3 = [-3.2, 6.6, 0.8]; // where the stars come from, relative to the foe

const CYAN: Rgb = [0.3, 0.95, 1.0];
const PALE_CYAN: Rgb = [0.8, 1.0, 1.0];
const MINT: Rgb = [0.45, 1.0, 0.7];
const GREEN: Rgb = [0.4, 1.0, 0.45];
const YELLOW: Rgb = [1.0, 0.95, 0.4];
const GOLD: Rgb = [1.0, 0.8, 0.3];
const ORANGE: Rgb = [1.0, 0.6, 0.25];
const BUBBLE: Rgb = [0.82, 0.86, 0.9];
const WHITE: Rgb = [1, 1, 1];

// --- 1. the glow ---
const bubble = kit.parked(kit.tex(298, 0), USER, 2.9, GLOW + 2);
setCurves(bubble, grow(0.5, 0.25, 1.05), fadeInOut(0.4, 0.15, 0.85));
paint(bubble, BUBBLE, WHITE, PALE_CYAN);
kit.add("bubble", bubble);

const bubbleRim = kit.parked(kit.tex(560, 1), USER, 3.1, GLOW + 2);
setCurves(bubbleRim, grow(0.5, 0.25, 1.05), fadeInOut(0.6, 0.15, 0.85));
paint(bubbleRim, BUBBLE, WHITE, PALE_CYAN);
kit.add("bubbleRim", bubbleRim);

const trails = kit.spray([333, 1], kit.tex(333, 0), [0, -0.4, 0.2], { radius: 2.8, speed: 0, count: 2, bursts: GLOW / 3, gap: 3, life: 10, scale: 0.14, shape: "circle" });
trails.emissionAxis = 1;
trails.behaviors = [{ type: "spin", axis: 1, angle: 0.3 }];
setCurves(trails, undefined, twinkle());
kit.prism(trails, [GREEN, WHITE, MINT]);
kit.add("trails", trails);

const innerGlow = kit.parked(kit.tex(465, 1), USER, 2.6, GLOW + 4);
setCurves(innerGlow, { start: 0.3, mid: 0.7, end: 1.3, curveIn: 0.4, curveOut: 0.6 }, { start: 0, mid: 0.5, end: 1, curveIn: 0.3, curveOut: 0.6 });
paint(innerGlow, PALE_CYAN, CYAN, WHITE);
kit.add("innerGlow", innerGlow);

// Light drawn in to the user, faster as the glow builds.
const gather = kit.spray([333, 1], kit.tex(333, 0), USER, { radius: 3.0, speed: 0, count: 1, bursts: (GLOW - 12) / 3, gap: 3, life: 12, scale: 0.14, shape: "sphere" });
gather.startDelayFrames = 6;
gather.variance.lifeTime = 0;
gather.behaviors = [{ type: "convergence", target: [0, 0, 0], force: 0.09 }];
setCurves(gather, undefined, twinkle());
kit.prism(gather, [CYAN, WHITE, MINT]);
kit.add("gather", gather);

// The bubble's rim pulses outward every half second.
const rimPulse = kit.spray([333, 1], kit.tex(560, 1), USER, { radius: 0, speed: 0, count: 1, bursts: GLOW / 15, gap: 15, life: 14, scale: 3.1, shape: "point" });
rimPulse.variance.lifeTime = 0;
setCurves(rimPulse, grow(0.8, 0.8, 1.25), fadeOut(0.6, 0.2));
paint(rimPulse, PALE_CYAN, WHITE, CYAN);
kit.add("rimPulse", rimPulse);

// Four long white rays crossing through the user in an X.
const xRay = (angle: number) => {
  const r = kit.parked(kit.tex(333, 2), USER, 6.5, 9);
  r.startDelayFrames = GLOW - 8;
  r.aspectRatio = 0.12;
  r.initAngle = deg(angle);
  setCurves(r, grow(0.2, 0.3, 1.05), fadeOut(1, 0.5));
  paint(r, WHITE, WHITE, PALE_CYAN);
  return r;
};
kit.add("xRayA", xRay(42));
kit.add("xRayB", xRay(-42));

// --- 2. the beam to the sky ---
function pillarStream(scale: number, colour: Rgb, start: Rgb): ReturnType<typeof kit.shell> {
  const r = kit.shell(228, 0);
  r.textureIndex = kit.tex(228, 1);
  Object.assign(r, {
    emitterBasePos: [...USER_TOP], axis: [0, 1, 0], initVelAxisAmplifier: 1.5, particleLifeFrames: 8,
    followEmitter: false, baseScale: scale, emitterLifeFrames: PILLAR - 2, emissionIntervalFrames: 1, airResistance: 1.0, startDelayFrames: GLOW,
  });
  setCurves(r, hold(1), fadeOut(1, 0.8));
  paint(r, colour, start, colour);
  return r;
}
kit.add("pillar", pillarStream(1.35, CYAN, PALE_CYAN));
kit.add("pillarCore", pillarStream(0.65, WHITE, WHITE));

const baseFlames = kit.spray([228, 3], kit.tex(321, 6), USER_FLOOR, { radius: 1.2, speed: 0.06, count: 2, bursts: PILLAR / 4, gap: 4, life: 9, scale: 1.0, shape: "circle", directional: true });
baseFlames.startDelayFrames = GLOW;
baseFlames.emissionAxis = 1;
baseFlames.axis = [0, 1, 0];
baseFlames.initVelAxisAmplifier = 0.3;
setCurves(baseFlames, grow(0.5, 0.3, 1.2), fadeOut(1, 0.45));
kit.prism(baseFlames, [CYAN, MINT, PALE_CYAN]);
kit.add("baseFlames", baseFlames);

// A wide ring of prismatic sparks circling the pillar.
const sparkRing = kit.spray([228, 3], kit.tex(411, 0), [0, 2.4, 0.2], { radius: 3.2, speed: 0, count: 2, bursts: PILLAR / 2 - 2, gap: 2, life: 8, scale: 1.0, shape: "circle", directional: true });
sparkRing.startDelayFrames = GLOW + 3;
sparkRing.emissionAxis = 1;
sparkRing.behaviors = [{ type: "spin", axis: 1, angle: 0.4 }];
setCurves(sparkRing, undefined, fadeInOut(1, 0.2, 0.6));
kit.prism(sparkRing, [ORANGE, YELLOW, CYAN]);
kit.add("sparkRing", sparkRing);

// --- 3. the stars rain down on the foe ---
const fallDir: Vec3 = [FOE[0] - SKY[0], FOE[1] - SKY[1], 0];
const fallDist = Math.hypot(...fallDir);
const fallAxis = fallDir.map((v) => v / fallDist) as Vec3;
const RAIN = (STARS - 1) * STAR_GAP;

const stars = kit.spray([333, 1], kit.tex(298, 3), SKY, { radius: 0.9, speed: 0, count: 1, bursts: STARS, gap: STAR_GAP, life: FALL + 1, scale: 0.8, shape: "ball" });
stars.axis = [...fallAxis];
stars.initVelAxisAmplifier = fallDist / FALL;
stars.airResistance = 1.0; // the spray shell's drag would stop them short
spin(stars, 0.2, 0.3, 0, true);
setCurves(stars, hold(1), hold(1));
kit.prism(stars, [YELLOW, GOLD, YELLOW]);
kit.add("stars", stars);

const lightRain = kit.spray([228, 3], kit.tex(411, 0), SKY, { radius: 1.3, speed: 0, count: 2, bursts: RAIN / 2 + 2, gap: 2, life: FALL + 1, scale: 2.2, shape: "ball", directional: true });
lightRain.axis = [...fallAxis];
lightRain.initVelAxisAmplifier = fallDist / FALL;
lightRain.airResistance = 1.0;
setCurves(lightRain, undefined, fadeInOut(0.9, 0.2, 0.8));
kit.prism(lightRain, [MINT, WHITE, GREEN]);
kit.add("lightRain", lightRain);

// Each landing.
const landAt = <T extends { startDelayFrames: number }>(r: T): T => { r.startDelayFrames = FALL; return r; };
const pops = landAt(kit.spray([333, 1], kit.tex(579, 2), FOE, { radius: 0.8, speed: 0, count: 1, bursts: STARS, gap: STAR_GAP, life: 8, scale: 1.2, shape: "ball" }));
spin(pops, -0.1, 0.1, 0, true);
setCurves(pops, { start: 0.3, mid: 1.1, end: 1.3, curveIn: 0.25, curveOut: 0.5 }, fadeOut(1, 0.45));
kit.prism(pops, [CYAN, WHITE, PALE_CYAN]);
kit.add("pops", pops);

const shards = landAt(kit.spray([228, 3], kit.tex(465, 3), FOE, { radius: 0.5, speed: 0.45, count: 2, bursts: STARS, gap: STAR_GAP, life: 9, scale: 0.7, directional: true }));
setCurves(shards, grow(1, 0.3, 0.6), fadeOut());
kit.prism(shards, [PALE_CYAN, CYAN, WHITE]);
kit.add("shards", shards);

// Each landing erupts in colour: streaks in six colours and floating dots.
function eruption(colours: [Rgb, Rgb, Rgb], speed: number): ReturnType<typeof kit.spray> {
  const r = landAt(kit.spray([228, 3], kit.tex(333, 0), FOE, { radius: 0.5, speed, count: 3, bursts: STARS, gap: STAR_GAP, life: 10, scale: 0.7, directional: true }));
  r.aspectRatio = 0.45;
  setCurves(r, undefined, fadeOut(1, 0.5));
  kit.prism(r, colours);
  return r;
}
kit.add("eruptWarm", eruption([[1.0, 0.35, 0.4], YELLOW, [1.0, 0.55, 0.2]], 0.55));
kit.add("eruptCool", eruption([[0.4, 0.6, 1.0], [0.5, 1.0, 0.5], [1.0, 0.45, 0.95]], 0.45));

const colourDots = landAt(kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.6, speed: 0.22, count: 2, bursts: STARS, gap: STAR_GAP, life: 12, scale: 0.16 }));
colourDots.variance.lifeTime = 0;
colourDots.axis = [0, 1, 0];
colourDots.initVelAxisAmplifier = 0.08;
setCurves(colourDots, undefined, twinkle());
kit.prism(colourDots, [[1.0, 0.5, 0.85], YELLOW, CYAN]);
kit.add("colourDots", colourDots);

const bokeh = landAt(kit.spray([333, 1], kit.tex(298, 0), FOE, { radius: 2.2, speed: 0.01, count: 1, bursts: 6, gap: STAR_GAP, life: 12, scale: 0.4, shape: "ball" }));
setCurves(bokeh, grow(0.5, 0.3, 1.1), fadeInOut(0.7, 0.2, 0.6));
kit.prism(bokeh, [CYAN, YELLOW, GREEN]);
kit.add("bokeh", bokeh);

// --- 4. the last star ---
const LAST = FALL + RAIN;
const finale = <T extends { startDelayFrames: number }>(r: T): T => { r.startDelayFrames = LAST; return r; };
const flash = finale(kit.parked(kit.tex(228, 1), FOE, 2.4, 14));
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.2, 2.3), fadeOut(1, 0.35));
paint(flash, PALE_CYAN, WHITE, CYAN);
kit.add("flash", flash);

const beamLine = finale(kit.parked(kit.tex(333, 2), [0, 2.6, 0.8], 5.5, 10));
beamLine.aspectRatio = 0.1;
setCurves(beamLine, grow(0.3, 0.2, 1.05), fadeOut(1, 0.5));
paint(beamLine, MINT, WHITE, GREEN);
kit.add("beamLine", beamLine);

const burst = finale(kit.spray([228, 3], kit.tex(321, 6), FOE, { radius: 0.4, speed: 0.6, count: 9, life: 10, scale: 0.8, directional: true }));
setCurves(burst, grow(1.2, 0.3, 0.6), fadeOut());
kit.prism(burst, [CYAN, WHITE, MINT]);
kit.add("burst", burst);

// --- script ---
const emits = (names: string[], who: "ATTACKER" | "DEFENDER") => names.map((n) => kit.emit(n, who)).join("\n");
const rainAt = GLOW + PILLAR + PAN - FALL;
const landSounds = Array.from({ length: STARS }, (_, i) => `PlaySound 1509, SE${i % 2 ? 2 : 1}, 16, ${rainAt + FALL + i * STAR_GAP}, ${300 + i * 150}, ${105 + i * 3}, 0, 0, 0`).join("\n");
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1783, SE1, 14, 0, 0, 110, 0, 0, 0
PlaySound 1509, SE2, 14, 15, 200, 90, 0, 0, 0
PlaySound 1509, SE2, 14, 30, 500, 95, 0, 0, 0
PlaySound 1509, SE2, 14, 45, 800, 100, 0, 0, 0
PlaySound 1816, SE2, 14, ${GLOW - 8}, 600, 110, 0, 0, 0
PlaySound 1418, PSG, 14, ${GLOW}, 400, 115, 0, 0, 0
PlaySound 1376, PSG, 14, ${GLOW + PILLAR}, 0, 0, 0, 0, 0
${landSounds}
PlaySound 1475, SE1, 16, ${rainAt + LAST}, -300, 125, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 11, 2, 1, 4, 6
ChangeSpriteColor ATTACKER, 0, 8, 6, 18, 31, 31
${emits(["bubble", "bubbleRim", "rimPulse", "trails", "gather", "innerGlow", "xRayA", "xRayB", "pillar", "pillarCore", "baseFlames", "sparkRing"], "ATTACKER")}
Wait ${GLOW - 8}
ChangeSpriteColor ATTACKER, 8, 15, 2, 26, 31, 31
Wait 8
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 5
Wait ${PILLAR / 2}
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 4
Wait ${PILLAR / 2}
ChangeSpriteColor ATTACKER, 15, 0, 3, 26, 31, 31
MoveCamera INTERPOLATION, DEFENDER, ${PAN}, 0, 8
Wait ${PAN - FALL}
${emits(["stars", "lightRain", "pops", "shards", "eruptWarm", "eruptCool", "colourDots", "bokeh", "flash", "beamLine", "burst"], "DEFENDER")}
Wait ${FALL}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 9, 2, 22, 31, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, ${Math.round(RAIN / 3)}
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 3
Wait ${RAIN}
ChangeSpriteColor DEFENDER, 9, 15, 0, 28, 31, 31
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 15, 0, 2, 28, 31, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 8
Wait ${HOLD}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 11, 0, 2, 1, 4, 6
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [63, 129, 381, 605, 240],
  references: ["reference/Tera_Starstorm_IX.png", "reference/Tera_Starstorm_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("pillar")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("sparkRing")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("stars")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("burst")}, DEFENDER`, "ShakeScreen VERTICAL, 1x", "MoveCamera INTERPOLATION, INIT"],
});
const base = CAMERA_IN + rainAt;
console.log(`  glow f${CAMERA_IN}, pillar f${CAMERA_IN + GLOW}-${CAMERA_IN + GLOW + PILLAR}, stars land f${base + FALL}-${base + LAST} (${STARS}, ${STAR_GAP}f apart), last f${base + LAST}`);
