import { assert, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Ice Spinner (move 861), v2 - from Logan's keyframes (reference/keyframe-1..7):
//   1. Startup: a vertical tornado starts to rise round the user (Logan:
//      "like Hurricane, a vertical up-down tornado round the user").
//   2-3. It begins spinning: the tornado widens, ice spray and streaks
//      spiralling up it.
//   4. It turns itself into a spinning block of blue ice, streaked with frost.
//   5-6. It launches at the foe, gliding along the floor in a whirl of spray,
//      throwing up foam and ice chips.
//   7. Contact: the ice breaks apart - white-cyan swirls burst round the foe,
//      ice shards scatter across the ground.
// The user is hidden while it is the ice (ToggleSpriteVisibility 3/4), and
// the block rides an EmitProjectile STRAIGHT path along the ground.
// v1 (../ice-spinner, a spinning ice top) is kept; reinstall its manifest to
// revert.
//
// Drawn here: the ice block in three frames (64x64 a3i5: a faceted blue
// boulder with frost specks and frost streaks that shift sideways from frame
// to frame, so cycling them on a texture-animation track spins it while it
// stays upright; generated/texture-ice0..2.png).

const SPA = 919;
const kit = await createKit({ workDir: import.meta.dirname, slug: "ice-spinner-v2", moveId: 861, spaId: SPA, donors: [410, 471, 605, 228, 321, 465, 606, 333] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const STARTUP = 8;
const SPIN = 16;
const ENCASE = 10;
const GLIDE = 14;
const HIT_STOP = 4;
const HOLD = 24;

const USER: Vec3 = [0, 0.0, 0.3];
const FOE: Vec3 = [0, 0.3, 0.8];
const BLOCK_SCALE = 1.7;
const BLOCK_HUB = 1.35; // above the ground on the "0" anchor

const ICE: Rgb = [0.55, 0.85, 1.0];
const PALE_ICE: Rgb = [0.85, 0.96, 1.0];
const BLUE: Rgb = [0.35, 0.6, 1.0];
const FOAM: Rgb = [0.92, 0.97, 1.0];
const WHITE: Rgb = [1, 1, 1];

// --- the drawn ice block ---
type P = [number, number];
const outline: P[] = [[4, 34], [10, 18], [24, 8], [42, 7], [56, 16], [61, 32], [55, 48], [38, 56], [18, 55], [7, 46]];
const inPoly = (x: number, y: number, poly: P[]) => {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i]!;
    const [xj, yj] = poly[j]!;
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
};
const facetShade = (px: number, py: number) => {
  // Which centroid wedge the pixel is in decides its facet; lit from the upper left.
  for (let i = 0; i < outline.length; i++) {
    const a = outline[i]!;
    const b = outline[(i + 1) % outline.length]!;
    if (inPoly(px, py, [a, b, [32, 31]])) {
      const mx = (a[0] + b[0]) / 2 - 32;
      const my = (a[1] + b[1]) / 2 - 31;
      return (-mx - my) / Math.hypot(mx, my); // -1.4 .. 1.4
    }
  }
  return 0;
};
const iceFrames: number[] = [];
for (let frame = 0; frame < 3; frame++) {
  iceFrames.push(await kit.drawn(`ice${frame}`, 64, 64, "a3i5", (x, y) => {
    const px = x + 0.5;
    const py = y + 0.5;
    if (!inPoly(px, py, outline)) return undefined;
    if (!inPoly(px - 1.3, py, outline) || !inPoly(px + 1.3, py, outline) || !inPoly(px, py - 1.3, outline) || !inPoly(px, py + 1.3, outline)) return [36, 92, 186];
    // Frost streaks: meridians round a vertical axis, slanted, shifting each frame.
    const u = Math.max(-1, Math.min(1, (px - 32) / 29));
    const m = (Math.asin(u) * 6) / Math.PI + (py - 32) / 26 + frame / 3;
    const f = m - Math.floor(m);
    if (Math.abs(f - 0.5) < 0.07 && Math.abs(u) < 0.92) return [226, 244, 255];
    if (((x * 73856093) ^ (y * 19349663)) % 37 === 0) return [240, 250, 255];
    const s = facetShade(px, py);
    return s > 0.6 ? [170, 226, 255] : s > -0.2 ? [104, 178, 246] : s > -0.9 ? [70, 138, 226] : [46, 104, 204];
  }));
}
function iceSpinning(r: ReturnType<typeof kit.shell>): void {
  const track = structuredClone(kit.spa(471).resources[1]!.texAnim);
  assert.ok(track, "Ice Ball lost its texture animation");
  r.texAnim = { ...track, textures: [iceFrames[0]!, iceFrames[1]!, iceFrames[2]!, 0, 0, 0, 0, 0], textureCount: 3, step: 1 / 3, loop: true, randomizeInit: false };
  r.textureIndex = iceFrames[0]!;
}

// --- 1-3. startup and spin: a vertical tornado round the user ---
// Twister's funnel (SPA 410 res 1): flat rings drawn from a quarter-arc
// texture, rising up a narrow cylinder and pinching in the middle - the
// retail vertical tornado. Emitted at ground level ("0" anchor), as Twister
// does. Its child ring trail is dropped (the kit keeps no children), so two
// funnels of different widths stand in for its density.
const TORNADO = STARTUP + SPIN + 4;
function funnel(scale: number, delay: number, rise: number, colour: Rgb, start: Rgb): ReturnType<typeof kit.shell> {
  const r = kit.shell(410, 1);
  r.textureIndex = kit.tex(410, 1);
  Object.assign(r, { emitterBasePos: [0, -0.8, 0.2], baseScale: scale, emitterLifeFrames: TORNADO - delay, startDelayFrames: delay, initVelAxisAmplifier: rise });
  paint(r, colour, start, colour);
  return r;
}
kit.add("funnel", funnel(1.6, 0, 0.3, PALE_ICE, WHITE));
kit.add("funnelOuter", funnel(2.3, STARTUP, 0.34, ICE, PALE_ICE));

// Ice spray spiralling up the tornado.
const spray = kit.spray([333, 1], kit.tex(333, 0), [0, 0.2, 0.2], { radius: 1.5, speed: 0.04, count: 1, bursts: (STARTUP + SPIN) / 2, gap: 2, life: 12, scale: 0.15, shape: "circle" });
spray.emissionAxis = 1;
spray.axis = [0, 1, 0];
spray.initVelAxisAmplifier = 0.24;
spray.behaviors = [{ type: "spin", axis: 1, angle: 0.45 }];
setCurves(spray, undefined, twinkle());
kit.prism(spray, [WHITE, PALE_ICE, ICE]);
kit.add("spray", spray);

const flurry = kit.spray([228, 3], kit.tex(333, 2), [0, 0.6, 0.2], { radius: 1.8, speed: 0, count: 1, bursts: SPIN / 2, gap: 2, life: 7, scale: 1.0, shape: "circle", directional: true });
flurry.startDelayFrames = STARTUP;
flurry.emissionAxis = 1;
flurry.axis = [0, 1, 0];
flurry.initVelAxisAmplifier = 0.28;
flurry.behaviors = [{ type: "spin", axis: 1, angle: 0.55 }];
setCurves(flurry, undefined, fadeInOut(1, 0.15, 0.6));
kit.prism(flurry, [WHITE, PALE_ICE, ICE]);
kit.add("flurry", flurry);

// --- 4. encased: the ice block forms round the user ---
const encase = kit.parked(iceFrames[0]!, USER, BLOCK_SCALE, ENCASE + 1);
iceSpinning(encase);
encase.loopFrames = 6;
setCurves(encase, { start: 0.4, mid: 1, end: 1, curveIn: 0.5, curveOut: 1 }, { start: 0, mid: 1, end: 1, curveIn: 0.4, curveOut: 1 });
encase.loopFrames = 6; // setCurves leaves a looping track's pace alone; set it again to be sure
paint(encase, WHITE);
kit.add("encase", encase);

const frost = kit.parked(kit.tex(228, 1), USER, 2.2, 8);
spin(frost, 0.05);
setCurves(frost, grow(0.4, 0.3, 1.4), fadeOut(1, 0.4));
paint(frost, WHITE, WHITE, PALE_ICE);
kit.add("frost", frost);

// --- 5-6. the glide (riding an EmitProjectile STRAIGHT emitter on the ground) ---
function rider(texIndex: number, scale: number, hub: number): ReturnType<typeof kit.shell> {
  const r = kit.shell(605, 0);
  assert.ok(r.followEmitter, "Mud Bomb's ball no longer follows its emitter");
  r.textureIndex = texIndex;
  Object.assign(r, { particleLifeFrames: GLIDE + 1, baseScale: scale, emitterBasePos: [0, hub, 0] });
  setCurves(r, hold(1), undefined); // Mud Bomb's rider has no alpha curve
  paint(r, WHITE);
  return r;
}
const block = rider(iceFrames[0]!, BLOCK_SCALE, BLOCK_HUB);
iceSpinning(block);
block.loopFrames = 6;
kit.add("block", block);

const blockSwirl = rider(kit.tex(228, 3), 2.4, BLOCK_HUB - 0.3);
blockSwirl.aspectRatio = 2.6;
spin(blockSwirl, -0.4);
paint(blockSwirl, PALE_ICE, WHITE, PALE_ICE);
kit.add("blockSwirl", blockSwirl);

const foam = kit.spray([333, 1], kit.tex(321, 5), [0, 0.3, 0], { radius: 0.6, speed: 0.06, count: 1, bursts: GLIDE, gap: 1, life: 12, scale: 0.6 });
spin(foam, -0.08, 0.08, 0, true);
setCurves(foam, grow(0.4, 0.3, 1.5), fadeInOut(0.8, 0.1, 0.5));
paint(foam, FOAM, WHITE, PALE_ICE);
kit.add("foam", foam);

const chips = kit.spray([333, 1], kit.tex(471, 2), [0, 0.3, 0], { radius: 0.6, speed: 0.12, count: 1, bursts: GLIDE / 2, gap: 2, life: 12, scale: 0.22 });
chips.axis = [0, 1, 0];
chips.initVelAxisAmplifier = 0.16;
chips.behaviors = [{ type: "gravity", magnitude: [0, -0.03, 0] }];
spin(chips, -0.3, 0.3, 0, true);
setCurves(chips, hold(1), fadeOut(1, 0.5));
kit.prism(chips, [WHITE, PALE_ICE, ICE]);
kit.add("chips", chips);

// --- 7. contact: the ice breaks apart ---
const flash = kit.parked(kit.tex(228, 1), FOE, 1.8, 10);
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.2, 2.0), fadeOut(1, 0.35));
paint(flash, WHITE, WHITE, PALE_ICE);
kit.add("flash", flash);

const burstSwirl = kit.parked(kit.tex(228, 3), FOE, 3.0, 14);
burstSwirl.aspectRatio = 1.8;
spin(burstSwirl, 0.3);
setCurves(burstSwirl, grow(0.4, 0.25, 1.4), fadeOut(1, 0.4));
paint(burstSwirl, WHITE, WHITE, ICE);
kit.add("burstSwirl", burstSwirl);

const arcs = kit.spray([333, 1], kit.tex(606, 3), FOE, { radius: 0.6, speed: 0.35, count: 5, life: 10, scale: 1.0 });
spin(arcs, -0.3, 0.3, 0, true);
setCurves(arcs, grow(0.6, 0.3, 1.2), fadeOut(1, 0.4));
kit.prism(arcs, [WHITE, PALE_ICE, ICE]);
kit.add("arcs", arcs);

const shards = kit.spray([228, 3], kit.tex(465, 3), FOE, { radius: 0.4, speed: 0.5, count: 8, life: 10, scale: 0.6, directional: true });
setCurves(shards, grow(1.0, 0.3, 0.6), fadeOut());
kit.prism(shards, [PALE_ICE, ICE, WHITE]);
kit.add("shards", shards);

const scatter = kit.spray([333, 1], kit.tex(471, 2), FOE, { radius: 0.6, speed: 0.3, count: 8, life: 18, scale: 0.28 });
scatter.axis = [0, 1, 0];
scatter.initVelAxisAmplifier = 0.12;
scatter.behaviors = [{ type: "gravity", magnitude: [0, -0.025, 0] }];
spin(scatter, -0.3, 0.3, 0, true);
setCurves(scatter, hold(1), fadeOut(1, 0.6));
kit.prism(scatter, [WHITE, PALE_ICE, BLUE]);
kit.add("scatter", scatter);

// --- script ---
const glide = (name: string) => `EmitProjectile ${SPA}, ${kit.idx(name)}, STRAIGHT, ATTACKER, DEFENDER, 0, ${GLIDE}f, 0, 1x, 1x, 0`;
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1875, SE2, 14, 0, 300, 100, 0, 0, 0
PlaySound 1875, SE2, 14, ${STARTUP + 6}, 700, 110, 0, 0, 0
PlaySound 1457, SE1, 14, ${STARTUP + SPIN}, 0, 100, 0, 0, 0
PlaySound 1875, SE2, 14, ${STARTUP + SPIN + ENCASE}, 300, 115, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${GLIDE}, 0, 50, 0, 0
AudioContainer SUSPEND
${kit.emit("funnel", "ATTACKER", "NONE", "0")}
${kit.emit("funnelOuter", "ATTACKER", "NONE", "0")}
${kit.emit("spray", "ATTACKER")}
${kit.emit("flurry", "ATTACKER")}
Wait ${STARTUP}
ChangeSpriteColor ATTACKER, 0, 10, 2, 20, 28, 31
ScaleSprite ATTACKER, ROUNDTRIP, -2458, 0, 2, 0, 4
Wait ${SPIN}
${kit.emit("frost", "ATTACKER")}
${kit.emit("encase", "ATTACKER")}
Wait 5
ToggleSpriteVisibility ATTACKER, 3
Wait ${ENCASE - 5}
${glide("block")}
${glide("blockSwirl")}
${glide("foam")}
${glide("chips")}
MoveCamera INTERPOLATION, DEFENDER, ${GLIDE}, 0, 8
Wait ${GLIDE}
AudioContainer CONTINUE
PlaySound 1505, SE1, 16, 0, 0, 125, 0, 0, 0
PlaySound 1719, SE2, 16, 1, 500, 115, 0, 0, 0
PlaySound 1719, SE2, 16, 8, 100, 110, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("flash", "DEFENDER")}
${kit.emit("burstSwirl", "DEFENDER")}
${kit.emit("arcs", "DEFENDER")}
${kit.emit("shards", "DEFENDER")}
${kit.emit("scatter", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 13, 0, 22, 28, 31
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 13, 0, 2, 22, 28, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait ${HOLD - HIT_STOP}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 10, 0, 0, 20, 28, 31
ToggleSpriteVisibility ATTACKER, 4
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

const { built } = await kit.finish({
  script,
  donorMoveIds: [301, 605, 63, 153, 427, 400, 291],
  references: ["reference/keyframe-1.webp", "reference/keyframe-2.png", "reference/keyframe-3.png", "reference/keyframe-4.png", "reference/keyframe-5.png", "reference/keyframe-6.png", "reference/keyframe-7.png", "reference/Ice_Spinner_IX.png", "reference/Ice_Spinner_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, "ToggleSpriteVisibility ATTACKER, 3", `EmitProjectile ${SPA}, 6, STRAIGHT, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 10, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 4", "MoveCamera INTERPOLATION, INIT"],
});
for (const name of ["encase", "block"]) {
  const t = built(name).texAnim!;
  assert.ok(t && t.loop && t.textureCount === 3 && built(name).loopFrames === 6, `${name} lost its spin track`);
}
const glideAt = CAMERA_IN + STARTUP + SPIN + ENCASE;
console.log(`  spin f${CAMERA_IN + STARTUP}, encase f${CAMERA_IN + STARTUP + SPIN}, glide f${glideAt}-${glideAt + GLIDE}, break f${glideAt + GLIDE}`);
