MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 919
AudioContainer CONTINUE
PlaySound 1875, SE2, 14, 0, 300, 100, 0, 0, 0
PlaySound 1875, SE2, 14, 14, 700, 110, 0, 0, 0
PlaySound 1457, SE1, 14, 24, 0, 100, 0, 0, 0
PlaySound 1875, SE2, 14, 34, 300, 115, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 14, 0, 50, 0, 0
AudioContainer SUSPEND
Emit 919, 0, ATTACKER, NONE, 0, 0, 0, 1x, 1x, 1x, 1x
Emit 919, 1, ATTACKER, NONE, 0, 0, 0, 1x, 1x, 1x, 1x
Emit 919, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 919, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 8
ChangeSpriteColor ATTACKER, 0, 10, 2, 20, 28, 31
ScaleSprite ATTACKER, ROUNDTRIP, -2458, 0, 2, 0, 4
Wait 16
Emit 919, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 919, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 5
ToggleSpriteVisibility ATTACKER, 3
Wait 5
EmitProjectile 919, 6, STRAIGHT, ATTACKER, DEFENDER, 0, 14f, 0, 1x, 1x, 0
EmitProjectile 919, 7, STRAIGHT, ATTACKER, DEFENDER, 0, 14f, 0, 1x, 1x, 0
EmitProjectile 919, 8, STRAIGHT, ATTACKER, DEFENDER, 0, 14f, 0, 1x, 1x, 0
EmitProjectile 919, 9, STRAIGHT, ATTACKER, DEFENDER, 0, 14f, 0, 1x, 1x, 0
MoveCamera INTERPOLATION, DEFENDER, 14, 0, 8
Wait 14
AudioContainer CONTINUE
PlaySound 1505, SE1, 16, 0, 0, 125, 0, 0, 0
PlaySound 1719, SE2, 16, 1, 500, 115, 0, 0, 0
PlaySound 1719, SE2, 16, 8, 100, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 919, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 919, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 919, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 919, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 919, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 13, 0, 22, 28, 31
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 2, 22, 28, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 20
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 10, 0, 0, 20, 28, 31
ToggleSpriteVisibility ATTACKER, 4
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
