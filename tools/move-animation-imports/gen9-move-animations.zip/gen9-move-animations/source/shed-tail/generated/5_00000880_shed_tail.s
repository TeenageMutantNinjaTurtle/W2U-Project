MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 874
AudioContainer CONTINUE
PlaySound 1436, SE1, 14, 0, 0, 110, 0, 0, 0
PlaySound 1509, SE2, 14, 8, 600, 80, 0, 0, 0
AudioContainer SUSPEND
Emit 874, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 874, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 874, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ChangeSpriteColor ATTACKER, 0, 12, 0, 31, 31, 31
Wait 4
ChangeSpriteColor ATTACKER, 12, 0, 2, 31, 31, 31
Wait 22
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
