import { createKit, fadeInOut, fadeOut, grow, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Shed Tail (move 880) - from Bulbapedia's still (reference/).
// The user's tail pops off in a poof of white smoke puffs.
// The Gen 5 engine draws the substitute doll itself when Shed Tail sets one
// up, so this is only the poof: a white smoke burst round the user, a few
// puffs rolling along the ground, a quick pop of the sprite.

const SPA = 874;
const kit = await createKit({ workDir: import.meta.dirname, slug: "shed-tail", moveId: 880, spaId: SPA, donors: [321, 298] });

const CAMERA_IN = 12;
const POOF = 26;

const BODY: Vec3 = [0, 0, 0.3];
const GROUND: Vec3 = [0, -1.8, 0.2];

const WHITE: Rgb = [1, 1, 1];
const SMOKE: Rgb = [0.92, 0.93, 0.95];

const puffTex = kit.tex(321, 5);

const poof = kit.spray([333, 1], puffTex, BODY, { radius: 0.5, speed: 0.18, count: 7, life: 22, scale: 0.9, shape: "ball" });
poof.airResistance = 0.9;
spin(poof, -0.06, 0.06, 0, true);
setCurves(poof, grow(0.4, 0.2, 1.4), fadeInOut(0.95, 0.1, 0.55));
paint(poof, WHITE, WHITE, SMOKE);
kit.add("poof", poof);

const rolling = kit.spray([333, 1], puffTex, GROUND, { radius: 0.6, speed: 0.14, count: 4, life: 22, scale: 0.7, shape: "circle" });
rolling.emissionAxis = 1;
rolling.airResistance = 0.92;
rolling.startDelayFrames = 3;
spin(rolling, -0.05, 0.05, 0, true);
setCurves(rolling, grow(0.4, 0.25, 1.3), fadeInOut(0.85, 0.15, 0.5));
paint(rolling, SMOKE, WHITE, SMOKE);
kit.add("rolling", rolling);

const glint = kit.parked(kit.tex(298, 1), [0.6, 0.6, 0.6], 0.5, 12);
glint.startDelayFrames = 8;
setCurves(glint, twinkle(1.2), twinkle(1));
paint(glint, WHITE);
kit.add("glint", glint);

const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1436, SE1, 14, 0, 0, 110, 0, 0, 0
PlaySound 1509, SE2, 14, 8, 600, 80, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("poof", "ATTACKER")}
${kit.emit("rolling", "ATTACKER")}
${kit.emit("glint", "ATTACKER")}
ScaleSprite ATTACKER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ChangeSpriteColor ATTACKER, 0, 12, 0, 31, 31, 31
Wait 4
ChangeSpriteColor ATTACKER, 12, 0, 2, 31, 31, 31
Wait ${POOF - 4}
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [153, 129],
  references: ["reference/Shed_Tail_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, "ScaleSprite ATTACKER, ROUNDTRIP", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  poof f${CAMERA_IN}-${CAMERA_IN + POOF}`);
