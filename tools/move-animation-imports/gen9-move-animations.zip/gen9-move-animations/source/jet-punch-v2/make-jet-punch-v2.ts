import { aimed, createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Curve3, type Rgb, type Vec3 } from "../tools/anim-kit";

// Jet Punch (move 857), v2 - from Logan's keyframes (reference/keyframe-1..6):
//   1. Startup: a deep blue water orb forms at the user's fist, cyan
//      caustic lines rippling over it round a white-hot spark.
//   2. Windup: the orb swells, its core blazing, bubbles round it.
//   3. Climax: the orb bursts open into a flower of blue water petals edged
//      with white foam, a white star at its heart, white swoosh rings round it.
//   4. Fire: a blue water fist shoots at the foe trailing white foam, white
//      swoosh arcs spiralling round it.
//   5. Hit: the fist crashes in, foam and blue water spraying, white arcs.
//   6. Contact: a yellow-white spiky burst, yellow streaks, blue ring bubbles
//      and droplets.
// v1 (../jet-punch, Aqua Jet's dash) is kept; reinstall its manifest to revert.
//
// Drawn here (see generated/): the orb (64x64 a3i5, a deep blue sphere with a
// cyan caustic web and a glowing rim), the splash flower (64x64 a3i5, seven
// blue petals edged with white foam) and a foam splat (32x32 a5i3).
// Mega Punch's fist (SPA 169) is the water fist.

const SPA = 916;
const kit = await createKit({ workDir: import.meta.dirname, slug: "jet-punch-v2", moveId: 857, spaId: SPA, donors: [169, 580, 228, 465, 579, 407, 606, 411, 298] });

// --- timing (30 fps) ---
const CAMERA_IN = 10;
const STARTUP = 10;
const WINDUP = 14;
const CLIMAX = 6;
const FIRE = 8;
const CONTACT_DELAY = 2;
const HIT_STOP = 4;
const HOLD = 22;

const FIST: Vec3 = [0.6, 0.0, -1.0]; // in front of the user, at its fist
const FOE: Vec3 = [0, 0.3, 0.8];

const DEEP_BLUE: Rgb = [0.15, 0.4, 1.0];
const WATER: Rgb = [0.3, 0.62, 1.0];
const CYAN: Rgb = [0.45, 0.9, 1.0];
const PALE_CYAN: Rgb = [0.82, 0.96, 1.0];
const YELLOW: Rgb = [1.0, 0.9, 0.35];
const PALE_YELLOW: Rgb = [1.0, 0.97, 0.75];
const WHITE: Rgb = [1, 1, 1];

// --- drawn textures ---
let seed = 7;
const rand = () => ((seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648);
const cells: Array<[number, number]> = Array.from({ length: 16 }, () => {
  const a = rand() * Math.PI * 2;
  const r = Math.sqrt(rand()) * 27;
  return [32 + r * Math.cos(a), 32 + r * Math.sin(a)];
});
const orbTex = await kit.drawn("orb", 64, 64, "a3i5", (x, y) => {
  const px = x + 0.5;
  const py = y + 0.5;
  const r = Math.hypot(px - 32, py - 32);
  if (r > 29) return undefined;
  if (r > 27) return [110, 190, 255];
  const ds = cells.map(([cx, cy]) => Math.hypot(px - cx, py - cy)).sort((a, b) => a - b);
  if (ds[1]! - ds[0]! < 1.3) return r < 14 ? [190, 240, 255] : [110, 210, 255];
  const t = 1 - r / 27;
  return [Math.round(20 + 30 * t), Math.round(55 + 70 * t), Math.round(165 + 70 * t)];
});

const PETALS = 7;
const inPetal = (px: number, py: number) => {
  const dx = px - 32;
  const dy = py - 32;
  if (Math.hypot(dx, dy) < 9) return true;
  for (let i = 0; i < PETALS; i++) {
    const a = (i / PETALS) * Math.PI * 2 + 0.2;
    const u = dx * Math.cos(a) + dy * Math.sin(a) - 16; // along the petal
    const v = -dx * Math.sin(a) + dy * Math.cos(a); // across it
    if ((u / 15) ** 2 + (v / 10.5) ** 2 <= 1) return true;
  }
  return false;
};
const flowerTex = await kit.drawn("flower", 64, 64, "a3i5", (x, y) => {
  const px = x + 0.5;
  const py = y + 0.5;
  if (!inPetal(px, py)) return undefined;
  let edge = false;
  for (let oy = -2; oy <= 2 && !edge; oy++) for (let ox = -2; ox <= 2; ox++) if (!inPetal(px + ox, py + oy)) { edge = true; break; }
  if (edge) return [236, 246, 255];
  const r = Math.hypot(px - 32, py - 32);
  if (r < 5) return [255, 255, 255];
  if (((x * 73856093) ^ (y * 19349663)) % 31 === 0) return [220, 240, 255];
  return r < 12 ? [90, 170, 250] : r < 22 ? [52, 125, 236] : [30, 90, 210];
});

const lumps = [{ x: 16, y: 16, r: 7.5 }, { x: 11, y: 13, r: 5 }, { x: 21, y: 12, r: 4.5 }, { x: 20, y: 21, r: 5 }, { x: 11, y: 21, r: 4 }, { x: 4, y: 9, r: 2 }, { x: 27, y: 6, r: 1.6 }, { x: 28, y: 24, r: 2.2 }, { x: 6, y: 27, r: 1.5 }];
const foamTex = await kit.drawn("foam", 32, 32, "a5i3", (x, y) => {
  const px = x + 0.5;
  const py = y + 0.5;
  if (!lumps.some((c) => Math.hypot(px - c.x, py - c.y) < c.r)) return undefined;
  const edge = lumps.every((c) => Math.hypot(px - c.x, py - c.y) > c.r - 1.2);
  return [255, 255, 255, edge ? 170 : 245];
});

// --- 1-2. startup and windup: the orb ---
const CHARGE = STARTUP + WINDUP;
const orbGrowth: Curve3 = { start: 0.15, mid: 0.55, end: 1.0, curveIn: STARTUP / CHARGE, curveOut: STARTUP / CHARGE };
const orb = kit.parked(orbTex, FIST, 1.25, CHARGE + 1);
setCurves(orb, orbGrowth, fadeInOut(1, 0.12, 1));
paint(orb, WHITE);
kit.add("orb", orb);

const halo = kit.parked(kit.tex(465, 1), FIST, 1.9, CHARGE + 1);
setCurves(halo, orbGrowth, fadeInOut(0.55, 0.15, 1));
paint(halo, CYAN, PALE_CYAN, WATER);
kit.add("halo", halo);

const core = kit.parked(kit.tex(465, 1), [FIST[0], FIST[1], FIST[2] - 0.1], 0.75, CHARGE + 1);
setCurves(core, { start: 0.3, mid: 0.7, end: 1.2, curveIn: STARTUP / CHARGE, curveOut: STARTUP / CHARGE }, fadeInOut(1, 0.12, 1));
paint(core, WHITE, PALE_CYAN, WHITE);
kit.add("core", core);

const spark = kit.parked(kit.tex(579, 2), [FIST[0], FIST[1], FIST[2] - 0.15], 0.45, CHARGE + 1);
spin(spark, 0.2);
setCurves(spark, orbGrowth, fadeInOut(1, 0.12, 1));
paint(spark, WHITE);
kit.add("spark", spark);

const bubbles = kit.spray([333, 1], kit.tex(580, 2), FIST, { radius: 1.6, speed: 0, count: 1, bursts: WINDUP / 2, gap: 2, life: 10, scale: 0.22, shape: "ball" });
bubbles.startDelayFrames = STARTUP;
bubbles.axis = [0, 1, 0];
bubbles.initVelAxisAmplifier = 0.05;
setCurves(bubbles, grow(0.5, 0.3, 1.1), fadeInOut(1, 0.2, 0.6));
kit.prism(bubbles, [CYAN, PALE_CYAN, WHITE]);
kit.add("bubbles", bubbles);

// --- 3. climax: the burst flower ---
const flower = kit.parked(flowerTex, FIST, 1.5, CLIMAX + 4);
spin(flower, 0.04);
setCurves(flower, { start: 0.5, mid: 1.1, end: 1.25, curveIn: 0.3, curveOut: 0.6 }, fadeOut(1, 0.6));
paint(flower, WHITE);
kit.add("flower", flower);

const star = kit.parked(kit.tex(407, 1), [FIST[0], FIST[1], FIST[2] - 0.15], 1.1, CLIMAX + 4);
spin(star, 0.05, 0.05, deg(45));
setCurves(star, { start: 0.3, mid: 1.3, end: 0.6, curveIn: 0.25, curveOut: 0.6 }, fadeOut(1, 0.6));
paint(star, WHITE);
kit.add("star", star);

const rings = kit.parked(kit.tex(228, 3), FIST, 2.6, CLIMAX + FIRE);
spin(rings, -0.3);
setCurves(rings, grow(0.5, 0.25, 1.3), fadeOut(0.9, 0.4));
paint(rings, WHITE, WHITE, PALE_CYAN);
kit.add("rings", rings);

// --- 4. fire: the water fist ---
const fist = kit.parked(kit.tex(169, 3), FIST, 1.0, FIRE + 1);
aimed(fist, 2.0, FIRE + 1);
setCurves(fist, grow(0.7, 0.25, 1.15), hold(1));
paint(fist, WATER, CYAN, DEEP_BLUE);
kit.add("fist", fist);

const fistGlow = kit.parked(kit.tex(465, 1), FIST, 1.6, FIRE + 1);
aimed(fistGlow, 2.0, FIRE + 1);
setCurves(fistGlow, hold(1), hold(0.6));
paint(fistGlow, CYAN, PALE_CYAN, CYAN);
kit.add("fistGlow", fistGlow);

const trail = kit.spray([333, 1], foamTex, FIST, { radius: 0.5, speed: 0.04, count: 1, bursts: FIRE, gap: 1, life: 8, scale: 0.5 });
aimed(trail, 1.5, 8);
trail.behaviors = [{ type: "gravity", magnitude: [0, -0.015, 0] }];
spin(trail, -0.15, 0.15, 0, true);
setCurves(trail, grow(0.6, 0.3, 1.1), fadeOut(1, 0.4));
kit.prism(trail, [WHITE, PALE_CYAN, CYAN]);
kit.add("trail", trail);

const swooshes = kit.spray([333, 1], kit.tex(606, 3), FIST, { radius: 0.7, speed: 0, count: 1, bursts: FIRE / 2, gap: 2, life: FIRE, scale: 1.4, shape: "circle" });
aimed(swooshes, 1.9, FIRE);
spin(swooshes, -0.35, -0.25, 0, true);
setCurves(swooshes, grow(0.6, 0.3, 1.15), fadeInOut(1, 0.15, 0.7));
paint(swooshes, WHITE, WHITE, PALE_CYAN);
kit.add("swooshes", swooshes);

// --- 5. hit: foam and water ---
const foamBurst = kit.spray([333, 1], foamTex, FOE, { radius: 0.5, speed: 0.35, count: 7, life: 14, scale: 0.55 });
foamBurst.behaviors = [{ type: "gravity", magnitude: [0, -0.018, 0] }];
spin(foamBurst, -0.15, 0.15, 0, true);
setCurves(foamBurst, grow(0.5, 0.2, 1.1), fadeOut(1, 0.55));
kit.prism(foamBurst, [WHITE, PALE_CYAN, CYAN]);
kit.add("foamBurst", foamBurst);

const arcs = kit.parked(kit.tex(228, 3), FOE, 2.4, 12);
spin(arcs, 0.28);
setCurves(arcs, grow(0.4, 0.25, 1.35), fadeOut(0.9, 0.4));
paint(arcs, WHITE, WHITE, PALE_CYAN);
kit.add("arcs", arcs);

const water = kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.4, speed: 0.6, count: 6, life: 9, scale: 1.8, directional: true });
setCurves(water, undefined, fadeOut());
kit.prism(water, [WATER, CYAN, DEEP_BLUE]);
kit.add("water", water);

// --- 6. contact ---
const contactAt = (r: ReturnType<typeof kit.parked>) => { r.startDelayFrames = CONTACT_DELAY; return r; };
const spiky = contactAt(kit.parked(kit.tex(579, 2), FOE, 1.8, 12));
spin(spiky, 0.1);
setCurves(spiky, grow(0.4, 0.25, 1.6), fadeOut(1, 0.35));
paint(spiky, PALE_YELLOW, WHITE, YELLOW);
kit.add("spiky", spiky);

const flash = contactAt(kit.parked(kit.tex(228, 1), FOE, 1.6, 10));
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.2, 2.0), fadeOut(1, 0.35));
paint(flash, WHITE, WHITE, PALE_YELLOW);
kit.add("flash", flash);

const yellowStreaks = contactAt(kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.3, speed: 0.8, count: 9, life: 8, scale: 2.0, directional: true }));
setCurves(yellowStreaks, undefined, fadeOut());
kit.prism(yellowStreaks, [YELLOW, PALE_YELLOW, WHITE]);
kit.add("yellowStreaks", yellowStreaks);

const ringBubbles = contactAt(kit.spray([333, 1], kit.tex(298, 2), FOE, { radius: 0.6, speed: 0.3, count: 6, life: 14, scale: 0.22 }));
ringBubbles.behaviors = [{ type: "gravity", magnitude: [0, -0.01, 0] }];
setCurves(ringBubbles, grow(0.5, 0.3, 1), fadeOut(1, 0.5));
kit.prism(ringBubbles, [CYAN, WATER, PALE_CYAN]);
kit.add("ringBubbles", ringBubbles);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1762, SE1, 14, 0, -300, 110, 0, 0, 0
PlaySound 1452, SE2, 14, ${STARTUP}, -200, 110, 0, 0, 0
PlaySound 1511, SE1, 14, ${CHARGE}, 400, 115, 0, 0, 0
PlaySound 1421, SE2, 14, ${CHARGE + CLIMAX}, 0, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${FIRE}, 0, 50, 0, 0
AudioContainer SUSPEND
${kit.emit("halo", "ATTACKER")}
${kit.emit("orb", "ATTACKER")}
${kit.emit("core", "ATTACKER")}
${kit.emit("spark", "ATTACKER")}
${kit.emit("bubbles", "ATTACKER")}
Wait ${STARTUP}
ChangeSpriteColor ATTACKER, 0, 9, 2, 12, 20, 31
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 7
Wait ${WINDUP}
${kit.emit("flower", "ATTACKER")}
${kit.emit("star", "ATTACKER")}
${kit.emit("rings", "ATTACKER")}
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 3
Wait ${CLIMAX}
ChangeSpriteColor ATTACKER, 9, 0, 1, 12, 20, 31
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
${kit.emit("fistGlow", "ATTACKER", "DEFENDER")}
${kit.emit("fist", "ATTACKER", "DEFENDER")}
${kit.emit("trail", "ATTACKER", "DEFENDER")}
${kit.emit("swooshes", "ATTACKER", "DEFENDER")}
MoveCamera INTERPOLATION, DEFENDER, ${FIRE}, 0, 8
Wait ${FIRE}
AudioContainer CONTINUE
PlaySound 1511, SE1, 16, 0, 0, 125, 0, 0, 0
PlaySound 1420, SE2, 16, ${CONTACT_DELAY}, -300, 127, 0, 0, 0
PlaySound 1424, SE1, 16, ${CONTACT_DELAY + 2}, 0, 115, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("foamBurst", "DEFENDER")}
${kit.emit("arcs", "DEFENDER")}
${kit.emit("water", "DEFENDER")}
${kit.emit("spiky", "DEFENDER")}
${kit.emit("flash", "DEFENDER")}
${kit.emit("yellowStreaks", "DEFENDER")}
${kit.emit("ringBubbles", "DEFENDER")}
Wait ${CONTACT_DELAY}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 13, 0, 18, 26, 31
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 13, 0, 1, 18, 26, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait ${HOLD - HIT_STOP - CONTACT_DELAY}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [5, 401, 63, 605, 400, 129, 427, 240],
  references: ["reference/keyframe-1.png", "reference/keyframe-2.png", "reference/keyframe-3.png", "reference/keyframe-4.png", "reference/keyframe-5.png", "reference/keyframe-6.png", "reference/Jet_Punch_IX.png", "reference/Jet_Punch_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, `Emit ${SPA}, 5, ATTACKER`, `Emit ${SPA}, 8, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 12, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
const fireAt = CAMERA_IN + CHARGE + CLIMAX;
console.log(`  orb f${CAMERA_IN}, swell f${CAMERA_IN + STARTUP}, burst f${CAMERA_IN + CHARGE}, fire f${fireAt}, hit f${fireAt + FIRE}, contact f${fireAt + FIRE + CONTACT_DELAY}`);
