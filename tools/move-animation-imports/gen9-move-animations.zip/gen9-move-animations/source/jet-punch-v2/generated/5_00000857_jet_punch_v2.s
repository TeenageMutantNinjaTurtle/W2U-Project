MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 916
AudioContainer CONTINUE
PlaySound 1762, SE1, 14, 0, -300, 110, 0, 0, 0
PlaySound 1452, SE2, 14, 10, -200, 110, 0, 0, 0
PlaySound 1511, SE1, 14, 24, 400, 115, 0, 0, 0
PlaySound 1421, SE2, 14, 30, 0, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 8, 0, 50, 0, 0
AudioContainer SUSPEND
Emit 916, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 916, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 916, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 916, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 916, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 10
ChangeSpriteColor ATTACKER, 0, 9, 2, 12, 20, 31
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 7
Wait 14
Emit 916, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 916, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 916, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 3
Wait 6
ChangeSpriteColor ATTACKER, 9, 0, 1, 12, 20, 31
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
Emit 916, 9, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 916, 8, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 916, 10, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 916, 11, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
AudioContainer CONTINUE
PlaySound 1511, SE1, 16, 0, 0, 125, 0, 0, 0
PlaySound 1420, SE2, 16, 2, -300, 127, 0, 0, 0
PlaySound 1424, SE1, 16, 4, 0, 115, 0, 0, 0
AudioContainer SUSPEND
Emit 916, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 916, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 916, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 916, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 916, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 916, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 916, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 2
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 13, 0, 18, 26, 31
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 1, 18, 26, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 16
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
