MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 926
AudioContainer CONTINUE
PlaySound 1514, SE1, 14, 0, 500, 110, 0, 0, 0
PlaySound 1762, SE1, 14, 10, 0, 105, 0, 0, 0
PlaySound 1407, SE2, 14, 10, 100, 105, 0, 0, 0
PlaySound 1407, SE2, 14, 18, 350, 110, 0, 0, 0
PlaySound 1407, SE2, 14, 26, 600, 115, 0, 0, 0
PlaySound 1421, SE1, 14, 34, 0, 120, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 8, 0, 50, 0, 0
AudioContainer SUSPEND
Emit 926, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 10
Emit 926, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 2, 0, 12
Wait 24
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
AudioContainer CONTINUE
PlaySound 1420, SE1, 16, 0, -200, 110, 0, 0, 0
PlaySound 1420, SE2, 16, 4, -50, 114, 0, 0, 0
PlaySound 1420, SE1, 16, 8, 100, 118, 0, 0, 0
PlaySound 1420, SE2, 16, 12, 250, 122, 0, 0, 0
PlaySound 1511, SE1, 16, 12, 800, 120, 0, 0, 0
AudioContainer SUSPEND
Emit 926, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 926, 20, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 11, 1, 18, 28, 31
ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 8
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
Wait 4
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
Wait 4
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
Wait 4
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 4
Wait 4
ChangeSpriteColor DEFENDER, 11, 0, 2, 18, 28, 31
Wait 12
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
