import { createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Aqua Step (move 872), v3 - from Logan's keyframes (reference/keyframe-1..5)
// and brief: "a short wind up of a single slash upward -> into a few spinning
// slashes around the user -> then a flurry of water attacks on the target".
//   1. Windup: one long thin cyan water slash sweeps upward in front of the
//      user, bubbles rising along it.
//   2-3. Spinning slashes: wide cyan water arcs whirl flat round the user, one
//      after another, inside rings of glowing teardrop feathers fanned out
//      on the ground, white spray glittering.
//   4-5. Flurry: quick white-cyan star bursts pop on the foe one after
//      another with jagged water splashes, a long white spike flashing
//      through.
// Second pass (Logan: "a bit less all over the place"): both the upward
// slash and the circling slashes are smaller, and the dash trail is gone.
// v2 (../aqua-step-v2, from the Bulbapedia still) and v1 (../aqua-step) are
// kept; reinstall a manifest to revert.
//
// The teardrop feather is v2's drawn texture (32x32 a5i3: a bright outline
// round a faint fill, point at the bottom; generated/texture-teardrop.png).

const SPA = 926;
const kit = await createKit({ workDir: import.meta.dirname, slug: "aqua-step-v3", moveId: 872, spaId: SPA, donors: [580, 632, 321, 228, 579, 333, 411] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const WINDUP = 10;
const SPINS = 3;
const SPIN_GAP = 8;
const DASH = 8;
const HITS = 4;
const HIT_GAP = 4;
const HOLD = 16;

const USER: Vec3 = [0, 0.1, 0.3];
const FRONT: Vec3 = [0.8, 0.5, -0.9];
const GROUND_Y = -1.3;
const FOE: Vec3 = [0, 0.3, 0.8];

const CYAN: Rgb = [0.45, 0.9, 1.0];
const PALE_CYAN: Rgb = [0.85, 0.98, 1.0];
const WATER: Rgb = [0.3, 0.65, 1.0];
const WHITE: Rgb = [1, 1, 1];

// --- the drawn teardrop (v2's) ---
const dropTex = await kit.drawn("teardrop", 32, 32, "a5i3", (x, y) => {
  // Round end at the top, point at the bottom.
  const nx = (x - 15.5) / 15.5;
  const ny = (y - 12) / 12; // round part centred high
  const inside = (r: number) => {
    if (y <= 12) return nx * nx + ny * ny <= r * r;
    const t = (y - 12) / 19; // 0 at the widest, 1 at the point
    return Math.abs(nx) <= r * (1 - t) && y <= 31;
  };
  if (!inside(1)) return undefined;
  const ring = !inside(0.62);
  return ring ? [255, 255, 255, 255] : [255, 255, 255, 110];
});

// --- 1. windup: the upward slash ---
function upSlash(scale: number, aspect: number, colour: Rgb, start: Rgb): ReturnType<typeof kit.parked> {
  const r = kit.parked(kit.tex(333, 2), FRONT, scale, WINDUP);
  r.aspectRatio = aspect;
  r.initAngle = deg(12);
  r.axis = [0, 1, 0];
  r.initVelAxisAmplifier = 0.08; // it sweeps upward as it grows
  setCurves(r, grow(0.1, 0.35, 1.1), fadeOut(1, 0.55));
  paint(r, colour, start, colour);
  return r;
}
kit.add("upSlash", upSlash(2.6, 0.3, CYAN, WHITE));
kit.add("upSlashCore", upSlash(2.3, 0.12, WHITE, WHITE));

const bubbles = kit.spray([333, 1], kit.tex(580, 2), FRONT, { radius: 0.8, speed: 0, count: 1, bursts: 5, gap: 2, life: 10, scale: 0.2, shape: "ball" });
bubbles.axis = [0, 1, 0];
bubbles.initVelAxisAmplifier = 0.12;
setCurves(bubbles, grow(0.5, 0.3, 1.1), fadeInOut(1, 0.2, 0.6));
kit.prism(bubbles, [CYAN, PALE_CYAN, WHITE]);
kit.add("bubbles", bubbles);

// --- 2-3. the spinning slashes ---
const DANCE = SPINS * SPIN_GAP;
for (let i = 0; i < SPINS; i++) {
  const r = kit.parked(kit.tex(228, 3), [0, GROUND_Y + 0.5 + i * 0.35, 0.3], 1.1 + i * 0.2, SPIN_GAP + 4); // kept inside the feather rings
  r.startDelayFrames = i * SPIN_GAP;
  r.aspectRatio = 3.2;
  spin(r, i % 2 ? -0.55 : 0.55);
  setCurves(r, grow(0.4, 0.3, 1.25), fadeOut(0.95, 0.45));
  paint(r, CYAN, WHITE, WATER);
  kit.add(`spin${i}`, r);
}

const whirl = kit.spray([333, 1], kit.tex(333, 2), [0, GROUND_Y + 0.8, 0.3], { radius: 1.6, speed: 0, count: 2, bursts: DANCE / 2, gap: 2, life: 7, scale: 0.8, shape: "circle", directional: true });
whirl.emissionAxis = 1;
whirl.behaviors = [{ type: "spin", axis: 1, angle: 0.6 }];
setCurves(whirl, undefined, fadeOut(1, 0.4));
kit.prism(whirl, [WHITE, PALE_CYAN, CYAN]);
kit.add("whirl", whirl);

// Teardrop feathers fanned out in rings lying on the ground, pointing outward.
function fan(radius: number, count: number, delay: number, scale: number): ReturnType<typeof kit.spray> {
  const r = kit.spray([228, 3], dropTex, [0, GROUND_Y, 0.3], { radius, speed: 0.03, count, life: DANCE - delay + 2, scale, shape: "circle", directional: true });
  r.emissionType = 3; // evenly spaced ring
  r.emissionAxis = 1; // lying flat
  r.startDelayFrames = delay;
  r.airResistance = 0.95;
  setCurves(r, grow(0.2, 0.25, 1.1), fadeInOut(1, 0.15, 0.8));
  paint(r, CYAN, WHITE, CYAN);
  return r;
}
kit.add("fanInner", fan(1.4, 8, 0, 0.45));
kit.add("fanOuter", fan(2.4, 10, SPIN_GAP, 0.55));

const spray = kit.spray([333, 1], kit.tex(333, 0), [0, GROUND_Y + 0.2, 0.3], { radius: 2.4, speed: 0.04, count: 1, bursts: DANCE / 2, gap: 2, life: 9, scale: 0.12, shape: "circle" });
spray.emissionAxis = 1;
spray.axis = [0, 1, 0];
spray.initVelAxisAmplifier = 0.06;
setCurves(spray, undefined, twinkle());
paint(spray, WHITE, WHITE, PALE_CYAN);
kit.add("spray", spray);

// (The dash's white streak trail was removed at Logan's request: seen end-on
// during the camera pan it read as stray white sparkles in the top right.)

// --- 4-5. the flurry on the foe ---
const spots: Vec3[] = [[-0.7, 0.6, 1.0], [0.6, 0.1, 1.0], [-0.3, -0.5, 1.0], [0.4, 0.8, 1.0]];
spots.forEach((s, i) => {
  const delay = i * HIT_GAP;
  const pop = kit.parked(kit.tex(579, 2), s, i === HITS - 1 ? 1.4 : 1.1, 9);
  pop.startDelayFrames = delay;
  spin(pop, 0.12, 0.12, i * 0.7);
  setCurves(pop, grow(0.3, 0.25, 1.4), fadeOut(1, 0.4));
  paint(pop, PALE_CYAN, WHITE, CYAN);
  kit.add(`pop${i}`, pop);

  const splash = kit.spray([228, 3], kit.tex(321, 6), s, { radius: 0.3, speed: 0.4, count: 4, life: 9, scale: 0.55, directional: true });
  splash.startDelayFrames = delay;
  setCurves(splash, grow(1.2, 0.3, 0.6), fadeOut());
  kit.prism(splash, [CYAN, WHITE, WATER]);
  kit.add(`splash${i}`, splash);
});

const spike = kit.parked(kit.tex(333, 2), [0.3, 0.2, 1.05], 4.0, 8);
spike.startDelayFrames = HIT_GAP;
spike.aspectRatio = 0.14;
spike.initAngle = deg(-25);
setCurves(spike, grow(0.2, 0.25, 1.05), fadeOut(1, 0.45));
paint(spike, WHITE);
kit.add("spike", spike);

const ring = kit.parked(kit.tex(632, 2), FOE, 1.3, 10);
ring.startDelayFrames = (HITS - 1) * HIT_GAP;
setCurves(ring, grow(0.5, 0.3, 1.8), fadeOut(1, 0.3));
paint(ring, PALE_CYAN, WHITE, CYAN);
kit.add("ring", ring);

const finalSpray = kit.shell(580, 2);
finalSpray.textureIndex = kit.tex(580, 3);
Object.assign(finalSpray, { emitterBasePos: [...FOE], emissionCount: 3, startDelayFrames: (HITS - 1) * HIT_GAP });
paint(finalSpray, PALE_CYAN, WHITE, WATER);
kit.add("finalSpray", finalSpray);

// --- script ---
const emits = (names: string[], who: "ATTACKER" | "DEFENDER", toward = "NONE") => names.map((n) => kit.emit(n, who, toward)).join("\n");
const spinNames = Array.from({ length: SPINS }, (_, i) => `spin${i}`);
const flurryNames = [...spots.flatMap((_, i) => [`pop${i}`, `splash${i}`]), "spike", "ring", "finalSpray"];
const spinSounds = spinNames.map((_, i) => `PlaySound 1407, SE2, 14, ${WINDUP + i * SPIN_GAP}, ${100 + i * 250}, ${105 + i * 5}, 0, 0, 0`).join("\n");
const hitSounds = spots.map((_, i) => `PlaySound 1420, SE${i % 2 ? 2 : 1}, 16, ${i * HIT_GAP}, ${-200 + i * 150}, ${110 + i * 4}, 0, 0, 0`).join("\n");
const hitSteps = spots.map((_, i) => `${i === 0 ? "" : `Wait ${HIT_GAP}\n`}ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1`).join("\n");
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1514, SE1, 14, 0, 500, 110, 0, 0, 0
PlaySound 1762, SE1, 14, ${WINDUP}, 0, 105, 0, 0, 0
${spinSounds}
PlaySound 1421, SE1, 14, ${WINDUP + DANCE}, 0, 120, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, ${DASH}, 0, 50, 0, 0
AudioContainer SUSPEND
${emits(["upSlash", "upSlashCore", "bubbles"], "ATTACKER")}
Wait ${WINDUP}
${emits([...spinNames, "whirl", "fanInner", "fanOuter", "spray"], "ATTACKER")}
ShakeSprite ATTACKER, 2, 819, 0, 2, 0, ${DANCE / 2}
Wait ${DANCE}
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, ${DASH}, 0, 8
Wait ${DASH}
AudioContainer CONTINUE
${hitSounds}
PlaySound 1511, SE1, 16, ${(HITS - 1) * HIT_GAP}, 800, 120, 0, 0, 0
AudioContainer SUSPEND
${emits(flurryNames, "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 11, 1, 18, 28, 31
ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, ${HITS * 2}
${hitSteps}
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 4
Wait 4
ChangeSpriteColor DEFENDER, 11, 0, 2, 18, 28, 31
Wait ${HOLD - 4}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [401, 453, 163, 63, 400, 153],
  references: ["reference/keyframe-1.png", "reference/keyframe-2.webp", "reference/keyframe-3.webp", "reference/keyframe-4.png", "reference/keyframe-5.png", "reference/Aqua_Step_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, `Emit ${SPA}, ${kit.idx("spin2")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("fanOuter")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("pop3")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
const flurryAt = CAMERA_IN + WINDUP + DANCE + DASH;
console.log(`  up-slash f${CAMERA_IN}, spins f${CAMERA_IN + WINDUP}/+${SPIN_GAP}/+${2 * SPIN_GAP}, flurry f${flurryAt}-${flurryAt + (HITS - 1) * HIT_GAP}`);
