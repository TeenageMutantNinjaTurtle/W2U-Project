import { aimed, createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Aqua Cutter (move 895), v2 - from Bulbapedia's still (reference/).
//   A thin, bright cyan-white water blade slices across the foe in a shallow
//   diagonal, throwing a spiky blue splash and a spray of droplets.
// The user whips a water crescent and flings it; it crosses as the long
// slash on the foe. Psycho Cut's crescent (606) is the blade, Slash's streak
// (333) the cut line, Aqua Tail's (580) bubbles and spray the splash.
// v1 (../aqua-cutter) is kept; reinstall its manifest to revert.

const SPA = 888;
const kit = await createKit({ workDir: import.meta.dirname, slug: "aqua-cutter-v2", moveId: 895, spaId: SPA, donors: [580, 632, 579, 321, 228, 411] });

// --- timing (30 fps) ---
const CAMERA_IN = 10;
const WHIP = 14;
const FLIGHT = 8;
const HOLD = 18;

const USER: Vec3 = [0, 0.3, 0.2];
const ARM: Vec3 = [0.6, 0.4, -0.6];
const FOE: Vec3 = [0, 0.3, 0.8];

const WATER: Rgb = [0.2, 0.55, 1.0];
const CYAN: Rgb = [0.45, 0.85, 1.0];
const PALE_CYAN: Rgb = [0.8, 0.96, 1.0];
const WHITE: Rgb = [1, 1, 1];

// --- the whip ---
const swirl = kit.parked(kit.tex(580, 4), USER, 2.0, WHIP + 2);
swirl.emissionCount = 2;
spin(swirl, -0.32, -0.24, 0, true);
setCurves(swirl, grow(0.5, 0.3, 1.1), fadeInOut(0.8, 0.2, 0.7));
kit.prism(swirl, [CYAN, PALE_CYAN, WATER]);
kit.add("swirl", swirl);

const gather = kit.spray([333, 1], kit.tex(333, 0), ARM, { radius: 0.8, speed: 0.04, count: 2, bursts: 5, gap: 2, life: 10, scale: 0.12, shape: "ball" });
gather.behaviors = [{ type: "gravity", magnitude: [0, -0.01, 0] }];
setCurves(gather, undefined, twinkle());
kit.prism(gather, [WHITE, PALE_CYAN, CYAN]);
kit.add("gather", gather);

// --- the blade in flight ---
function blade(scale: number, aspect: number, colour: Rgb, start: Rgb): ReturnType<typeof kit.parked> {
  const r = kit.parked(kit.tex(606, 3), ARM, scale, FLIGHT + 1);
  aimed(r, 2.0, FLIGHT + 1);
  r.aspectRatio = aspect;
  r.flipTextureS = true; // bulge forward, toward the foe
  setCurves(r, grow(0.6, 0.3, 1.05), hold(1));
  paint(r, colour, start, colour);
  return r;
}
kit.add("blade", blade(1.6, 0.7, CYAN, PALE_CYAN));
kit.add("bladeCore", blade(1.0, 0.45, WHITE, WHITE));

const wake = kit.spray([333, 1], kit.tex(333, 0), ARM, { radius: 0.3, speed: 0.05, count: 1, bursts: FLIGHT, gap: 1, life: 8, scale: 0.14 });
aimed(wake, 1.6, 8);
wake.behaviors = [{ type: "gravity", magnitude: [0, -0.012, 0] }];
setCurves(wake, undefined, fadeOut());
kit.prism(wake, [WHITE, PALE_CYAN, CYAN]);
kit.add("wake", wake);

// --- the cut ---
function cut(scale: number, aspect: number, colour: Rgb, start: Rgb, level: number): ReturnType<typeof kit.parked> {
  const r = kit.parked(kit.tex(333, 2), FOE, scale, 12);
  r.aspectRatio = aspect;
  r.initAngle = deg(-68);
  setCurves(r, grow(0.15, 0.2, 1.05), fadeOut(level, 0.45));
  paint(r, colour, start, colour);
  return r;
}
kit.add("cut", cut(3.4, 0.4, CYAN, WHITE, 1));
kit.add("cutCore", cut(3.0, 0.18, WHITE, WHITE, 1));

const spiky = kit.parked(kit.tex(579, 2), FOE, 1.2, 10);
spin(spiky, 0.1);
setCurves(spiky, grow(0.4, 0.25, 1.4), fadeOut(1, 0.35));
paint(spiky, CYAN, WHITE, WATER);
kit.add("spiky", spiky);

const spikes = kit.spray([228, 3], kit.tex(321, 6), FOE, { radius: 0.3, speed: 0.45, count: 8, life: 9, scale: 0.5, directional: true });
setCurves(spikes, grow(1.2, 0.3, 0.6), fadeOut());
kit.prism(spikes, [WATER, CYAN, WHITE]);
kit.add("spikes", spikes);

const bubbles = kit.shell(580, 1);
bubbles.textureIndex = kit.tex(580, 2);
Object.assign(bubbles, { emitterBasePos: [...FOE], emissionCount: 4 });
paint(bubbles, PALE_CYAN, WHITE, CYAN);
kit.add("bubbles", bubbles);

const spray = kit.shell(580, 2);
spray.textureIndex = kit.tex(580, 3);
Object.assign(spray, { emitterBasePos: [...FOE], emissionCount: 3 });
paint(spray, PALE_CYAN, WHITE, WATER);
kit.add("spray", spray);

const droplets = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.5, speed: 0.3, count: 6, life: 14, scale: 0.13 });
droplets.behaviors = [{ type: "gravity", magnitude: [0, -0.015, 0] }];
setCurves(droplets, undefined, fadeOut(1, 0.5));
kit.prism(droplets, [WHITE, PALE_CYAN, CYAN]);
kit.add("droplets", droplets);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1452, SE1, 14, 0, 0, 110, 0, 0, 0
PlaySound 1407, SE2, 14, ${WHIP - 4}, 100, 115, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${FLIGHT}, 0, 50, 0, 0
AudioContainer SUSPEND
${kit.emit("swirl", "ATTACKER")}
${kit.emit("gather", "ATTACKER")}
Wait ${WHIP}
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 2px, 49152, 0, 4096, 0
${kit.emit("blade", "ATTACKER", "DEFENDER")}
${kit.emit("bladeCore", "ATTACKER", "DEFENDER")}
${kit.emit("wake", "ATTACKER", "DEFENDER")}
MoveCamera INTERPOLATION, DEFENDER, ${FLIGHT}, 0, 8
Wait ${FLIGHT}
AudioContainer CONTINUE
PlaySound 1514, SE1, 16, 0, 200, 120, 0, 0, 0
PlaySound 1511, SE2, 16, 1, -60, 120, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("cut", "DEFENDER")}
${kit.emit("cutCore", "DEFENDER")}
${kit.emit("spiky", "DEFENDER")}
${kit.emit("spikes", "DEFENDER")}
${kit.emit("bubbles", "DEFENDER")}
${kit.emit("spray", "DEFENDER")}
${kit.emit("droplets", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 10, 0, 10, 20, 31
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 8
Wait 4
ChangeSpriteColor DEFENDER, 10, 0, 1, 10, 20, 31
Wait ${HOLD - 4}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [401, 453, 400, 153, 63, 427],
  references: ["reference/Aqua_Cutter_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 2, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 5, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  whip f${CAMERA_IN}-${CAMERA_IN + WHIP}, cut f${CAMERA_IN + WHIP + FLIGHT}`);
