MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 888
AudioContainer CONTINUE
PlaySound 1452, SE1, 14, 0, 0, 110, 0, 0, 0
PlaySound 1407, SE2, 14, 10, 100, 115, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 8, 0, 50, 0, 0
AudioContainer SUSPEND
Emit 888, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 888, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 14
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 2px, 49152, 0, 4096, 0
Emit 888, 2, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 888, 3, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 888, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
AudioContainer CONTINUE
PlaySound 1514, SE1, 16, 0, 200, 120, 0, 0, 0
PlaySound 1511, SE2, 16, 1, -60, 120, 0, 0, 0
AudioContainer SUSPEND
Emit 888, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 888, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 888, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 888, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 888, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 888, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 888, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 10, 0, 10, 20, 31
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 8
Wait 4
ChangeSpriteColor DEFENDER, 10, 0, 1, 10, 20, 31
Wait 14
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
