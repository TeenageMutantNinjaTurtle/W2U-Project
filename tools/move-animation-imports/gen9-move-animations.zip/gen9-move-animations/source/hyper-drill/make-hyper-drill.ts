import { aimed, assert, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Hyper Drill (move 887) - from Bulbapedia's stills (reference/).
//   1. A giant segmented silver drill spins forward through big white swirl
//      rings, with gold spiral streaks.
//   2. Its tip smashes the foe in a shower of cyan, gold and orange sparks,
//      little lightning zigzags and grey debris.
//
// The drill is drawn here: three 64x64 a3i5 frames of a tip-up cone with
// spiral silver bands shifted per frame (generated/texture-drill*.png),
// cycled so it spins. As a directional billboard it points where it flies.

const SPA = 881;
const kit = await createKit({ workDir: import.meta.dirname, slug: "hyper-drill", moveId: 887, spaId: SPA, donors: [770, 606, 228, 321, 697, 471, 471] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const SPIN_UP = 16;
const FLIGHT = 10;
const HOLD = 24;

const FRONT: Vec3 = [0, 0.2, -1.2];
const FOE: Vec3 = [0, 0.3, 0.8];

const WHITE: Rgb = [1, 1, 1];
const PALE: Rgb = [0.9, 0.93, 1.0];
const GOLD: Rgb = [1.0, 0.82, 0.3];
const CYAN: Rgb = [0.4, 0.9, 1.0];
const ORANGE: Rgb = [1.0, 0.55, 0.3];
const YELLOW_GREEN: Rgb = [0.85, 1.0, 0.4];
const GREY: Rgb = [0.55, 0.55, 0.6];

// --- the drawn drill, three frames ---
const drillFrames: number[] = [];
for (let frame = 0; frame < 3; frame++) {
  const phase = (frame / 3) * 8;
  drillFrames.push(await kit.drawn(`drill${frame}`, 64, 64, "a3i5", (x, y) => {
    const tipY = 2;
    const baseY = 61;
    if (y < tipY || y > baseY) return undefined;
    const half = 1 + 25 * ((y - tipY) / (baseY - tipY));
    const rel = (x - 31.5) / half;
    if (Math.abs(rel) > 1) return undefined;
    if (Math.abs(rel) > 0.9 || y > baseY - 1) return [52, 54, 62];
    // Spiral bands: slanted stripes that slide with the phase.
    const band = Math.floor((y + rel * 6 + phase) / 8) % 2 === 0;
    const shade = 1.05 - 0.4 * (rel + 1) / 2; // lit from the left
    const base = band ? 225 : 150;
    const v = Math.max(40, Math.min(255, Math.round(base * shade)));
    return [v, v + 2, v + 10 > 255 ? 255 : v + 10];
  }));
}

function drill(scale: number, life: number): ReturnType<typeof kit.parked> {
  const r = kit.parked(drillFrames[0]!, FRONT, scale, life);
  r.texAnim = structuredClone(kit.spa(471).resources[1]!.texAnim);
  assert.ok(r.texAnim, "Ice Ball lost its texture-animation track");
  r.texAnim.textures = [drillFrames[0]!, drillFrames[1]!, drillFrames[2]!, 0, 0, 0, 0, 0];
  r.texAnim.textureCount = 3;
  r.texAnim.step = 1 / 3;
  r.texAnim.loop = true;
  r.texAnim.randomizeInit = false;
  paint(r, WHITE);
  return r;
}

// --- spin-up at the user: the drill points at the foe already ---
const revving = drill(1.6, SPIN_UP + 1);
revving.drawType = 1;
revving.axis = [1, 0, 0];
revving.initVelAxisAmplifier = 0.02; // a crawl, just to point it at the foe
setCurves(revving, grow(0.3, 0.35), fadeInOut(1, 0.1, 1));
revving.loopFrames = 3;
kit.add("revving", revving);

const rings = kit.spray([333, 1], kit.tex(770, 2), FRONT, { radius: 0.2, speed: 0, count: 1, bursts: 5, gap: 3, life: 10, scale: 1.5 });
aimed(rings, -0.25, 10); // drift back past the user as the drill bores forward
rings.aspectRatio = 0.5;
setCurves(rings, grow(0.4, 0.3, 1.4), fadeInOut(0.9, 0.2, 0.6));
paint(rings, WHITE, WHITE, PALE);
kit.add("rings", rings);

const spiral = kit.parked(kit.tex(606, 3), FRONT, 1.7, SPIN_UP + FLIGHT);
spiral.emissionCount = 2;
spin(spiral, -0.45, -0.35, 0, true);
setCurves(spiral, grow(0.5, 0.3, 1.1), fadeInOut(0.85, 0.2, 0.6));
paint(spiral, GOLD, WHITE, GOLD);
kit.add("spiral", spiral);

// --- the drive ---
const flying = drill(1.6, FLIGHT + 1);
flying.drawType = 1;
aimed(flying, 1.5, FLIGHT + 1);
setCurves(flying, hold(1), hold(1));
flying.loopFrames = 3;
kit.add("flying", flying);

const wakeRings = kit.spray([333, 1], kit.tex(770, 2), FRONT, { radius: 0.2, speed: 0, count: 1, bursts: 5, gap: 2, life: 9, scale: 1.4 });
aimed(wakeRings, 0.9, 9);
wakeRings.aspectRatio = 0.5;
setCurves(wakeRings, grow(0.5, 0.3, 1.5), fadeOut(0.8, 0.3));
paint(wakeRings, WHITE, WHITE, PALE);
kit.add("wakeRings", wakeRings);

// --- impact ---
const flash = kit.parked(kit.tex(228, 1), FOE, 1.5, 12);
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.25, 2.0), fadeOut(1, 0.35));
paint(flash, WHITE, WHITE, PALE);
kit.add("flash", flash);

const sparks = kit.spray([228, 3], kit.tex(321, 6), FOE, { radius: 0.3, speed: 0.55, count: 6, bursts: 3, gap: 4, life: 10, scale: 0.5, directional: true });
setCurves(sparks, grow(1.2, 0.3, 0.6), fadeOut());
kit.prism(sparks, [CYAN, GOLD, ORANGE]);
kit.add("sparks", sparks);

const zigzags = kit.spray([333, 1], kit.tex(697, 0), FOE, { radius: 1.0, speed: 0.1, count: 1, bursts: 5, gap: 3, life: 6, scale: 0.6, shape: "ball" });
zigzags.texAnim = structuredClone(kit.spa(697).resources[0]!.texAnim);
zigzags.texAnim!.textures = zigzags.texAnim!.textures.map((t, i) => (i < zigzags.texAnim!.textureCount ? kit.tex(697, t) : 0));
spin(zigzags, 0, 0, 0, true);
setCurves(zigzags, hold(1), fadeOut(1, 0.6));
zigzags.loopFrames = 7;
kit.prism(zigzags, [YELLOW_GREEN, GOLD, WHITE]);
kit.add("zigzags", zigzags);

const debris = kit.spray([333, 1], kit.tex(471, 2), FOE, { radius: 0.4, speed: 0.35, count: 5, life: 16, scale: 0.25 });
debris.behaviors = [{ type: "gravity", magnitude: [0, -0.015, 0] }];
spin(debris, -0.25, 0.25, 0, true);
setCurves(debris, hold(1), fadeOut());
paint(debris, GREY, PALE, GREY);
kit.add("debris", debris);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1875, SE1, 14, 0, -500, 120, 0, 0, 0
PlaySound 1421, SE2, 14, ${SPIN_UP}, 0, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${FLIGHT}, 0, 50, 0, 0
AudioContainer SUSPEND
${kit.emit("revving", "ATTACKER", "DEFENDER")}
${kit.emit("rings", "ATTACKER", "DEFENDER")}
${kit.emit("spiral", "ATTACKER")}
Wait ${SPIN_UP}
${kit.emit("flying", "ATTACKER", "DEFENDER")}
${kit.emit("wakeRings", "ATTACKER", "DEFENDER")}
MoveCamera INTERPOLATION, DEFENDER, ${FLIGHT}, 0, 8
Wait ${FLIGHT}
AudioContainer CONTINUE
PlaySound 1686, SE1, 16, 0, 0, 125, 0, 0, 0
PlaySound 1475, SE2, 16, 0, -300, 120, 0, 0, 0
PlaySound 1686, SE1, 16, 8, 300, 100, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("flash", "DEFENDER")}
${kit.emit("sparks", "DEFENDER")}
${kit.emit("zigzags", "DEFENDER")}
${kit.emit("debris", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 31, 31, 31
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 4, 0, 6
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 5
ChangeSpriteColor DEFENDER, 12, 0, 1, 31, 31, 31
Wait ${HOLD - 5}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

const { built } = await kit.finish({
  script,
  donorMoveIds: [564, 427, 63, 153, 527, 301],
  references: ["reference/Hyper_Drill_IX.png", "reference/Hyper_Drill_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER, DEFENDER`, `Emit ${SPA}, 3, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 5, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
for (const name of ["revving", "flying"]) {
  assert.ok(built(name).drawType === 1 && built(name).texAnim?.textureCount === 3, `${name} drill does not point and spin`);
}
console.log(`  spin-up f${CAMERA_IN}-${CAMERA_IN + SPIN_UP}, drive ${FLIGHT}f, impact f${CAMERA_IN + SPIN_UP + FLIGHT}`);
