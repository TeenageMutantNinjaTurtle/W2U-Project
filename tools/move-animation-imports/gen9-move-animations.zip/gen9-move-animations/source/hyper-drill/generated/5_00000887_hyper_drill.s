MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 881
AudioContainer CONTINUE
PlaySound 1875, SE1, 14, 0, -500, 120, 0, 0, 0
PlaySound 1421, SE2, 14, 16, 0, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 10, 0, 50, 0, 0
AudioContainer SUSPEND
Emit 881, 0, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 881, 1, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 881, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 16
Emit 881, 3, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 881, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
AudioContainer CONTINUE
PlaySound 1686, SE1, 16, 0, 0, 125, 0, 0, 0
PlaySound 1475, SE2, 16, 0, -300, 120, 0, 0, 0
PlaySound 1686, SE1, 16, 8, 300, 100, 0, 0, 0
AudioContainer SUSPEND
Emit 881, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 881, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 881, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 881, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 31, 31, 31
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 4, 0, 6
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 5
ChangeSpriteColor DEFENDER, 12, 0, 1, 31, 31, 31
Wait 19
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
