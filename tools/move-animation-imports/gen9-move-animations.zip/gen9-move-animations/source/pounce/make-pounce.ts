import { aimed, createKit, fadeInOut, fadeOut, grow, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Pounce (move 884) - from Bulbapedia's stills (reference/).
//   1. The user crouches low with thin white swirl lines round it, like a
//      spring winding up.
//   2. It springs across, trailing white streak lines, and lands with a small
//      yellow-green star burst and a white ring.
// A quick 50-power move: short crouch, leap, hit.

const SPA = 878;
const kit = await createKit({ workDir: import.meta.dirname, slug: "pounce", moveId: 884, spaId: SPA, donors: [606, 411, 579, 560] });

const CAMERA_IN = 10;
const COIL = 14;
const LEAP = 8;
const HOLD = 16;

const USER: Vec3 = [0, -0.4, 0.2];
const FOE: Vec3 = [0, 0.3, 0.8];

const WHITE: Rgb = [1, 1, 1];
const YELLOW_GREEN: Rgb = [0.85, 1.0, 0.3];
const GREEN: Rgb = [0.4, 1.0, 0.55];
const YELLOW: Rgb = [1.0, 0.92, 0.3];

// Coil: thin white swirl lines round the crouching user.
const coil = kit.parked(kit.tex(606, 3), USER, 1.6, COIL + 2);
coil.emissionCount = 2;
coil.aspectRatio = 1.6;
spin(coil, -0.35, -0.25, 0, true);
setCurves(coil, grow(1.2, 0.6, 0.8), fadeInOut(0.85, 0.2, 0.8));
paint(coil, WHITE);
kit.add("coil", coil);

// Leap: white streak lines arcing up and across toward the foe.
const trail = kit.spray([228, 3], kit.tex(411, 0), [0, 0.3, -0.6], { radius: 0.7, speed: 0, count: 1, bursts: LEAP, gap: 1, life: 7, scale: 1.6, directional: true });
aimed(trail, 2.0, 7, -0.25);
setCurves(trail, undefined, fadeInOut(0.9, 0.2, 0.5));
paint(trail, WHITE);
kit.add("trail", trail);

// Hit: a yellow-green spiky star, a white ring, green sparks.
const star = kit.parked(kit.tex(579, 2), FOE, 1.0, 10);
spin(star, 0.1);
setCurves(star, grow(0.4, 0.25, 1.4), fadeOut(1, 0.35));
paint(star, YELLOW_GREEN, YELLOW, GREEN);
kit.add("star", star);

const ring = kit.parked(kit.tex(560, 1), FOE, 0.9, 9);
setCurves(ring, grow(0.4, 0.3, 1.7), fadeOut(0.9, 0.3));
paint(ring, WHITE);
kit.add("ring", ring);

const sparks = kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.2, speed: 0.4, count: 6, life: 7, scale: 0.7, directional: true });
setCurves(sparks, undefined, fadeOut());
kit.prism(sparks, [GREEN, YELLOW_GREEN, WHITE]);
kit.add("sparks", sparks);

const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1497, SE2, 14, 0, 900, 80, 0, 0, 0
PlaySound 1421, SE1, 14, ${COIL}, 0, 115, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, ${LEAP}, 0, 50, 0, 0
AudioContainer SUSPEND
ScaleSprite ATTACKER, ROUNDTRIP, 819, -1229, 6, 6, 1
${kit.emit("coil", "ATTACKER")}
Wait ${COIL}
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
${kit.emit("trail", "ATTACKER", "DEFENDER")}
MoveCamera INTERPOLATION, DEFENDER, ${LEAP}, 0, 8
Wait ${LEAP}
AudioContainer CONTINUE
PlaySound 1420, SE1, 16, 0, 0, 115, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("star", "DEFENDER")}
${kit.emit("ring", "DEFENDER")}
${kit.emit("sparks", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 3, 0, 4
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 6
Wait ${HOLD}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [427, 240, 400, 381],
  references: ["reference/Pounce_IX.png", "reference/Pounce_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, `Emit ${SPA}, 1, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 2, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  coil f${CAMERA_IN}-${CAMERA_IN + COIL}, hit f${CAMERA_IN + COIL + LEAP}`);
