MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 878
AudioContainer CONTINUE
PlaySound 1497, SE2, 14, 0, 900, 80, 0, 0, 0
PlaySound 1421, SE1, 14, 14, 0, 115, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 8, 0, 50, 0, 0
AudioContainer SUSPEND
ScaleSprite ATTACKER, ROUNDTRIP, 819, -1229, 6, 6, 1
Emit 878, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 14
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
Emit 878, 1, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
AudioContainer CONTINUE
PlaySound 1420, SE1, 16, 0, 0, 115, 0, 0, 0
AudioContainer SUSPEND
Emit 878, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 878, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 878, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 3, 0, 4
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 6
Wait 16
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
