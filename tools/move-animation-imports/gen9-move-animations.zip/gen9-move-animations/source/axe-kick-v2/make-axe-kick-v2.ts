import { assert, createKit, deg, fadeInOut, fadeOut, grow, hold, lighten, paint, setCurves, spin, type Rgb, type Vec3 } from "../tools/anim-kit";

// Axe Kick (move 853), v2 - from Bulbapedia's stills (reference/).
//   1. The user flips up while a big orange-to-yellow arc trail swings over
//      its head: the heel coming up and over.
//   2. A giant orange foot slams straight down onto the foe, a yellow flame
//      trail above it, and a white/orange starburst of spikes where it lands.
//      The frame is motion-blurred.
// v1 (../axe-kick) is kept; reinstall its manifest to revert.
//
// Donors: SPA 190 Double Kick - texture 2 is the footprint (white with a dark
// outline, toes up), res 2 the spiky-ring impact burst. Psycho Cut's crescent
// and blade arc make the heel trail; Explosion's tapered spike the impact
// spikes; Hyper Beam's sunburst the flash.

const kit = await createKit({ workDir: import.meta.dirname, slug: "axe-kick-v2", moveId: 853, spaId: 847, donors: [190] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const ARC = 12; // heel arc swing at the user
const PAN = 8;
const FALL = 7; // foot drop onto the foe
const HOLD = 22;

// --- placement (defender-relative unless noted) ---
const OVER_USER: Vec3 = [0, 1.4, -0.6]; // attacker-relative
const FOE: Vec3 = [0, 0.2, 0.8]; // camera side of the foe
const FOOT_TOP = 5.5;
const FOOT_LAND = 0.4;
const FOOT_SPEED = (FOOT_TOP - FOOT_LAND) / FALL;
const FOOT_SCALE = 2.0;

const ORANGE: Rgb = [1.0, 0.5, 0.08];
const DEEP_ORANGE: Rgb = [0.95, 0.38, 0.04];
const YELLOW: Rgb = [1.0, 0.86, 0.25];
const WHITE: Rgb = [1, 1, 1];

const footTex = kit.tex(190, 2);

// Heel arc: a big crescent sweeping over the user, a thinner blade arc behind it.
function arc(tex: number, scale: number, rate: number, delay: number, colour: Rgb): ReturnType<typeof kit.parked> {
  const r = kit.parked(tex, OVER_USER, scale, ARC);
  spin(r, rate, rate, deg(150));
  r.startDelayFrames = delay;
  setCurves(r, grow(0.7, 0.4, 1.1), fadeInOut(1, 0.2, 0.5));
  paint(r, colour, YELLOW, ORANGE);
  return r;
}
kit.add("arc", arc(kit.tex(606, 3), 2.3, -0.42, 0, ORANGE));
kit.add("arcBlade", arc(kit.tex(606, 4), 2.0, -0.42, 2, YELLOW));

// The foot: falls straight down from above the foe and dies as it lands.
function foot(delay: number, alpha: number, colour: Rgb): ReturnType<typeof kit.parked> {
  const r = kit.parked(footTex, [0, FOOT_TOP, FOE[2]], FOOT_SCALE, FALL + 1);
  r.axis = [0, -1, 0];
  r.initVelAxisAmplifier = FOOT_SPEED;
  r.startDelayFrames = delay;
  setCurves(r, hold(1), hold(alpha));
  paint(r, colour);
  return r;
}
kit.add("foot", foot(0, 1, ORANGE));
// Motion-blur ghosts one and two frames behind it.
kit.add("ghost1", foot(1, 0.55, lighten(ORANGE, 0.3)));
kit.add("ghost2", foot(2, 0.3, YELLOW));

// Flame trail: a tall yellow streak over the landing spot as the foot arrives.
const trail = kit.parked(kit.tex(298, 0), [0, 3.0, FOE[2] - 0.2], 2.6, 10);
trail.aspectRatio = 0.3;
trail.startDelayFrames = FALL - 3;
setCurves(trail, grow(0.6, 0.3, 1.1), fadeOut(0.8, 0.3));
paint(trail, YELLOW, WHITE, ORANGE);
kit.add("trail", trail);

// The stamped foot: holds on the foe a moment after landing, then fades.
const stamp = kit.parked(footTex, [0, FOOT_LAND, FOE[2]], FOOT_SCALE, 14);
stamp.aspectRatio = 1.1;
setCurves(stamp, grow(1.08, 0.15, 0.96), fadeOut(1, 0.4));
paint(stamp, ORANGE, YELLOW, DEEP_ORANGE);
kit.add("stamp", stamp);

// Impact: white flash, radial spikes, Double Kick's spiky ring, embers.
const flash = kit.parked(kit.tex(228, 1), FOE, 1.2, 9);
setCurves(flash, grow(0.4, 0.25, 2.2), fadeOut(1, 0.3));
paint(flash, WHITE, WHITE, YELLOW);
kit.add("flash", flash);

const spikes = kit.spray([228, 3], kit.tex(321, 6), FOE, { radius: 0.3, speed: 0.5, count: 12, life: 10, scale: 0.55, directional: true });
setCurves(spikes, grow(1.2, 0.3, 0.6), fadeOut());
paint(spikes, WHITE, WHITE, ORANGE, 0.35);
kit.add("spikes", spikes);

const ring = kit.shell(190, 2);
ring.textureIndex = kit.tex(190, 4);
Object.assign(ring, { emitterBasePos: [...FOE], startDelayFrames: 0, baseScale: 1.6 });
paint(ring, YELLOW, WHITE, ORANGE);
kit.add("ring", ring);

const embers = kit.shell(190, 0);
embers.textureIndex = kit.tex(190, 1);
Object.assign(embers, { emitterBasePos: [...FOE], emissionCount: 5 });
paint(embers, ORANGE, YELLOW, DEEP_ORANGE);
kit.add("embers", embers);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA 847
AudioContainer CONTINUE
PlaySound 1421, SE2, 14, 0, 0, 120, 0, 0, 0
AudioContainer SUSPEND
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 2px, 40960, 8192, 4096, 0
${kit.emit("arc", "ATTACKER")}
${kit.emit("arcBlade", "ATTACKER")}
Wait ${ARC}
MoveCamera INTERPOLATION, DEFENDER, ${PAN}, 0, 8
Wait ${PAN}
AudioContainer CONTINUE
PlaySound 1424, SE1, 16, 0, 400, 100, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("foot", "DEFENDER")}
${kit.emit("ghost1", "DEFENDER")}
${kit.emit("ghost2", "DEFENDER")}
${kit.emit("trail", "DEFENDER")}
Wait ${FALL}
AudioContainer CONTINUE
PlaySound 1420, SE1, 16, 0, -300, 120, 0, 0, 0
PlaySound 1475, SE2, 16, 0, -500, 120, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("stamp", "DEFENDER")}
${kit.emit("flash", "DEFENDER")}
${kit.emit("spikes", "DEFENDER")}
${kit.emit("ring", "DEFENDER")}
${kit.emit("embers", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 31, 31, 31
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 4, 0, 6
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 4
ChangeSpriteColor DEFENDER, 12, 0, 1, 31, 31, 31
Wait ${HOLD - 4}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

const { built } = await kit.finish({
  script,
  donorMoveIds: [24, 427, 63, 153, 453],
  references: ["reference/Axe_Kick_IX.png", "reference/Axe_Kick_IX_2.png"],
  expectText: ["LoadSPA 847", "MoveSprite ATTACKER, ROUNDTRIP", "Emit 847, 0, ATTACKER", "MoveCamera INTERPOLATION, DEFENDER", "Emit 847, 2, DEFENDER", "Emit 847, 7, DEFENDER", "ShakeScreen VERTICAL, 1x", "MoveCamera INTERPOLATION, INIT"],
});
assert.ok(built("foot").axis[1] < -0.9 && Math.abs(built("foot").initVelAxisAmplifier - FOOT_SPEED) < 0.01, "Foot does not fall straight down at speed");
assert.ok(built("foot").emitterBasePos[1] > 5, "Foot does not start high above the foe");
assert.equal(built("ghost2").startDelayFrames, 2, "Second ghost is not two frames behind");
assert.ok(built("arc").minRotation < 0, "Heel arc does not swing");
console.log(`  arc f${CAMERA_IN}-${CAMERA_IN + ARC}, foot falls f${CAMERA_IN + ARC + PAN} for ${FALL}f at ${FOOT_SPEED.toFixed(2)}/f, impact f${CAMERA_IN + ARC + PAN + FALL}`);
