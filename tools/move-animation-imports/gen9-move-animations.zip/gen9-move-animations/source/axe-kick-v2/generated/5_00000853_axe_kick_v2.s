MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 847
AudioContainer CONTINUE
PlaySound 1421, SE2, 14, 0, 0, 120, 0, 0, 0
AudioContainer SUSPEND
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 2px, 40960, 8192, 4096, 0
Emit 847, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 847, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 12
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
AudioContainer CONTINUE
PlaySound 1424, SE1, 16, 0, 400, 100, 0, 0, 0
AudioContainer SUSPEND
Emit 847, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 847, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 847, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 847, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 7
AudioContainer CONTINUE
PlaySound 1420, SE1, 16, 0, -300, 120, 0, 0, 0
PlaySound 1475, SE2, 16, 0, -500, 120, 0, 0, 0
AudioContainer SUSPEND
Emit 847, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 847, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 847, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 847, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 847, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 31, 31, 31
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 4, 0, 6
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 4
ChangeSpriteColor DEFENDER, 12, 0, 1, 31, 31, 31
Wait 18
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
