import { aimed, assert, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Malignant Chain (move 919), v2 - from Logan's keyframes (shown in chat, not
// saved) and brief: "fires two small poison beams that extend out in front of
// the user -> then a vortex (similar to Mortal Spin's) begins around the
// target -> a large appendage appears and constricts the target dealing
// damage".
//   1. Two thin magenta poison beams shoot from the user, one above the
//      other, in a puff of magenta poison.
//   2. A purple vortex spins up round the foe: Hurricane's tornado, tinted
//      as in Mortal Spin, at retail width.
//   3. A chain of big purple links appears round the foe, coiled in wide
//      loops.
//   4. The coils pull tight: a magenta burst, white streaks and a black
//      spark as the foe is squeezed.
// Second pass (Logan, 2026-10-01: "a bit slower"): a second's wait after the
// shot before the camera pans; the vortex spins for about a second on its
// own; then the chain constricts for about two seconds, squeezing three
// times.
// Third pass (Logan, 2026-10-01): the chain no longer shoots across from the
// user ("the speed looks weird, sudden") - its coils simply appear round the
// foe - and the constriction lasts about 3.5 seconds, squeezing five times.
// The bad poisoning is handled by the engine.
// v1 (../malignant-chain) is kept; reinstall its manifest to revert.
//
// The link is v1's drawn texture (32x32 a3i5: a shaded purple torus with a
// see-through hole; generated/texture-link.png).

const SPA = 941;
const kit = await createKit({ workDir: import.meta.dirname, slug: "malignant-chain-v2", moveId: 919, spaId: SPA, donors: [711, 228, 465, 579, 333, 411] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const FIRE = 30; // a second after the shot before the camera leaves
const PAN = 12;
const TRAVEL = 9; // a beam's crossing
const VORTEX = 30; // the vortex spins on its own for a second
const COILED = 26; // loose coils appear and turn
const SQUEEZES = 5;
const SQUEEZE_GAP = 16;
const TIGHT = 82; // the tight coils: with COILED, about 3.5 seconds of constriction

const MUZZLE: Vec3 = [0.4, 0.5, -0.9];
const FOE: Vec3 = [0, 0.3, 0.8];
const SPEED = 15 / TRAVEL;

const PURPLE: Rgb = [0.55, 0.14, 0.82];
const VIOLET: Rgb = [0.68, 0.3, 1.0];
const MAGENTA: Rgb = [1.0, 0.25, 0.9];
const PINK: Rgb = [1.0, 0.6, 0.95];
const LAVENDER: Rgb = [0.92, 0.8, 1.0];
const BLACK: Rgb = [0.06, 0.03, 0.08];
const WHITE: Rgb = [1, 1, 1];

// --- the drawn link (v1's) ---
const linkTex = await kit.drawn("link", 32, 32, "a3i5", (x, y) => {
  const dx = x + 0.5 - 16;
  const dy = y + 0.5 - 16;
  const r = Math.hypot(dx, dy);
  const R = 9.5; // tube centre radius
  const t = 5.5; // tube half-thickness
  const d = Math.abs(r - R);
  if (d > t) return undefined;
  // Tube normal: radial in-plane component plus out-of-plane bulge.
  const radial = (r - R) / t;
  const nz = Math.sqrt(Math.max(0, 1 - radial * radial));
  const nx = (dx / (r || 1)) * radial;
  const ny = (dy / (r || 1)) * radial;
  const light = Math.max(0, -0.5 * nx - 0.5 * ny + 0.7 * nz);
  const shade = 0.35 + 0.65 * light;
  if (d > t - 0.9) return [70, 18, 80];
  return [Math.round(110 + 120 * shade), Math.round(30 + 60 * shade * shade), Math.round(130 + 100 * shade)];
});

// --- 1. the two beams ---
function beam(dy: number): ReturnType<typeof kit.shell> {
  const r = kit.shell(228, 0);
  r.textureIndex = kit.tex(228, 1);
  aimed(r, SPEED, TRAVEL + 2);
  Object.assign(r, { emitterBasePos: [MUZZLE[0], MUZZLE[1] + dy, MUZZLE[2]], baseScale: 0.3, emitterLifeFrames: 6, emissionIntervalFrames: 1, airResistance: 1.0 });
  setCurves(r, { start: 1, mid: 0.9, end: 0.5, curveIn: 0.3, curveOut: 0.6 }, hold(1));
  paint(r, MAGENTA, WHITE, MAGENTA, 0.25);
  return r;
}
kit.add("beamHigh", beam(0.45));
kit.add("beamLow", beam(-0.45));

const poison = kit.spray([333, 1], kit.tex(579, 2), MUZZLE, { radius: 0.7, speed: 0.05, count: 1, bursts: 8, gap: 3, life: 9, scale: 0.7, shape: "ball" }); // lingers through the wait before the pan
spin(poison, -0.1, 0.1, 0, true);
setCurves(poison, grow(0.4, 0.3, 1.2), fadeOut(1, 0.4));
kit.prism(poison, [MAGENTA, PINK, PURPLE]);
kit.add("poison", poison);

// --- 2. the vortex (Hurricane's tornado, as Mortal Spin's) ---
function swooshes(index: number, opts: { delay: number; emitFor: number; every: number; life: number; colour: Rgb; start: Rgb; end: Rgb }): ReturnType<typeof kit.shell> {
  const r = kit.shell(711, index);
  assert.ok(r.followEmitter, `Hurricane res ${index} no longer follows its emitter`);
  r.textureIndex = kit.tex(711, r.textureIndex);
  Object.assign(r, { baseScale: r.baseScale * 1.5, startDelayFrames: opts.delay, emitterLifeFrames: opts.emitFor, emissionIntervalFrames: opts.every, particleLifeFrames: opts.life });
  paint(r, opts.colour, opts.start, opts.end, 0.5);
  return r;
}
kit.add("inner", swooshes(2, { delay: 0, emitFor: VORTEX, every: 4, life: 20, colour: VIOLET, start: LAVENDER, end: PURPLE }));
kit.add("outer", swooshes(4, { delay: 4, emitFor: VORTEX - 4, every: 5, life: 22, colour: MAGENTA, start: LAVENDER, end: VIOLET }));

// --- 3. the chain ---
// The chain's coils appear round the foe: evenly spaced links on flat rings, turning.
function coil(y: number, radius: number, count: number, scale: number, rate: number, delay: number, life: number): ReturnType<typeof kit.spray> {
  const r = kit.spray([333, 1], linkTex, [FOE[0], FOE[1] + y, FOE[2] - 0.2], { radius, speed: 0, count, life, scale, shape: "circle" });
  r.emissionType = 3; // evenly spaced ring
  r.emissionAxis = 1;
  r.startDelayFrames = delay;
  r.variance.lifeTime = 0;
  r.behaviors = [{ type: "spin", axis: 1, angle: rate }];
  spin(r, 0, 0, 0, true);
  setCurves(r, { start: 0.2, mid: 1, end: 1, curveIn: 0.2, curveOut: 1 }, { start: 0, mid: 1, end: 1, curveIn: 0.15, curveOut: 1 });
  paint(r, WHITE);
  return r;
}
kit.add("looseHigh", coil(1.0, 2.3, 8, 0.6, 0.1, 0, COILED + 1));
kit.add("looseLow", coil(-0.5, 2.5, 8, 0.6, -0.09, 3, COILED - 2));

// --- 4. the coils pull tight and squeeze, SQUEEZES times ---
const tight = (y: number, radius: number, count: number, rate: number) => {
  const r = coil(y, radius, count, 0.65, rate, COILED, TIGHT);
  setCurves(r, hold(1), fadeOut(1, 0.85));
  return r;
};
kit.add("tightHigh", tight(1.1, 1.25, 6, 0.06));
kit.add("tightMid", tight(0.2, 1.4, 6, -0.05));
kit.add("tightLow", tight(-0.7, 1.25, 6, 0.06));

const glow = kit.parked(kit.tex(465, 1), FOE, 2.6, TIGHT);
glow.startDelayFrames = COILED;
setCurves(glow, grow(0.5, 0.1, 1.1), fadeInOut(0.7, 0.08, 0.8));
paint(glow, MAGENTA, PINK, PURPLE);
kit.add("glow", glow);

// One of each per squeeze.
function perSqueeze<T extends ReturnType<typeof kit.spray>>(r: T): T {
  r.startDelayFrames = COILED;
  r.variance.lifeTime = 0;
  return r;
}
const squeezeOpts = { bursts: SQUEEZES, gap: SQUEEZE_GAP };
const burst = perSqueeze(kit.spray([333, 1], kit.tex(579, 2), FOE, { radius: 0, speed: 0, count: 1, ...squeezeOpts, life: 10, scale: 1.8, shape: "point" }));
spin(burst, 0.1, 0.1, 0, true);
setCurves(burst, grow(0.4, 0.25, 1.5), fadeOut(1, 0.4));
paint(burst, MAGENTA, WHITE, PURPLE);
kit.add("burst", burst);

const whiteStreaks = perSqueeze(kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.4, speed: 0.45, count: 5, ...squeezeOpts, life: 8, scale: 1.3, directional: true }));
setCurves(whiteStreaks, undefined, fadeOut());
paint(whiteStreaks, WHITE, WHITE, PINK);
kit.add("whiteStreaks", whiteStreaks);

const blackSpark = perSqueeze(kit.spray([333, 1], kit.tex(333, 1), [FOE[0], FOE[1] + 0.2, FOE[2] + 0.3], { radius: 0.3, speed: 0, count: 1, ...squeezeOpts, life: 8, scale: 0.9, shape: "ball" }));
spin(blackSpark, 0.12, 0.12, 0, true);
setCurves(blackSpark, grow(0.4, 0.3, 1.3), fadeOut(1, 0.45));
paint(blackSpark, BLACK);
kit.add("blackSpark", blackSpark);

const flecks = perSqueeze(kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.6, speed: 0.25, count: 3, ...squeezeOpts, life: 12, scale: 0.14 }));
flecks.behaviors = [{ type: "gravity", magnitude: [0, -0.012, 0] }];
setCurves(flecks, undefined, twinkle());
kit.prism(flecks, [MAGENTA, PINK, VIOLET]);
kit.add("flecks", flecks);

// --- script ---
const emits = (names: string[], who: "ATTACKER" | "DEFENDER", toward = "NONE") => names.map((n) => kit.emit(n, who, toward)).join("\n");
const vortex = ["inner", "outer"].map((n) => `EmitCircle ${SPA}, ${kit.idx(n)}, DEFENDER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0`).join("\n");
const squeezeFrame = FIRE + PAN + VORTEX + COILED;
const squeezeSounds = Array.from({ length: SQUEEZES }, (_, i) => [
  `PlaySound 1475, SE2, 16, ${squeezeFrame + i * SQUEEZE_GAP}, ${-400 - i * 100}, ${115 + i * 5}, 0, 0, 0`,
  `PlaySound 1446, SE1, 16, ${squeezeFrame + i * SQUEEZE_GAP + 2}, -600, 110, 0, 0, 0`,
]).flat().join("\n");
const squeezes = Array.from({ length: SQUEEZES }, (_, i) => [
  "ChangeSpriteColor DEFENDER, 9, 14, 0, 31, 12, 30",
  "ScaleSprite DEFENDER, ROUNDTRIP, -1638, 410, 5, 0, 1",
  `ShakeScreen HORIZON, ${i === SQUEEZES - 1 ? "1x" : "0.5x"}, 0, 1, 0, 3`,
  "Wait 4",
  "ChangeSpriteColor DEFENDER, 14, 9, 2, 24, 6, 26",
  "ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 3",
  `Wait ${SQUEEZE_GAP - 4}`,
]).flat().join("\n");
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1446, SE1, 14, 0, -400, 110, 0, 0, 0
PlaySound 1407, SE2, 14, 0, 500, 110, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0
PlaySound 1919, SE1, 16, ${FIRE + PAN}, 0, 105, 70, 20, 0
PlaySound 1442, SE2, 16, ${FIRE + PAN + VORTEX}, 300, 105, 0, 0, 0
PlaySound 1376, SE1, 16, ${squeezeFrame + SQUEEZE_GAP}, 0, 0, 100, 20, 0
${squeezeSounds}
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 2, 24, 8, 26
${emits(["beamHigh", "beamLow"], "ATTACKER", "DEFENDER")}
${kit.emit("poison", "ATTACKER")}
Wait ${TRAVEL}
ChangeSpriteColor ATTACKER, 10, 0, 3, 24, 8, 26
Wait ${FIRE - TRAVEL}
MoveCamera INTERPOLATION, DEFENDER, ${PAN}, 0, 8
Wait ${PAN}
${vortex}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 9, 3, 24, 6, 26
ShakeSprite DEFENDER, 2, 819, 0, 2, 0, ${Math.round((VORTEX + COILED) / 4)}
Wait ${VORTEX}
${emits(["looseHigh", "looseLow", "tightHigh", "tightMid", "tightLow", "glow", "burst", "whiteStreaks", "blackSpark", "flecks"], "DEFENDER")}
Wait ${COILED}
${squeezes}
ChangeSpriteColor DEFENDER, 9, 0, 3, 24, 6, 26
Wait ${TIGHT - SQUEEZES * SQUEEZE_GAP + 4}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [542, 92, 188, 400, 605, 63],
  references: ["reference/Malignant_Chain_IX.png", "reference/Malignant_Chain_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `EmitCircle ${SPA}, ${kit.idx("inner")}, DEFENDER_LEFT`, `Emit ${SPA}, ${kit.idx("looseHigh")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("tightMid")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
const at = CAMERA_IN + FIRE + PAN;
console.log(`  beams f${CAMERA_IN}, vortex f${at}, coils f${at + VORTEX}, ${SQUEEZES} squeezes from f${at + VORTEX + COILED}, ${SQUEEZE_GAP}f apart, ends f${at + VORTEX + COILED + TIGHT}`);
