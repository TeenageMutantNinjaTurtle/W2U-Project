MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 941
AudioContainer CONTINUE
PlaySound 1446, SE1, 14, 0, -400, 110, 0, 0, 0
PlaySound 1407, SE2, 14, 0, 500, 110, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 9, 0, 50, 0, 0
PlaySound 1919, SE1, 16, 42, 0, 105, 70, 20, 0
PlaySound 1442, SE2, 16, 72, 300, 105, 0, 0, 0
PlaySound 1376, SE1, 16, 114, 0, 0, 100, 20, 0
PlaySound 1475, SE2, 16, 98, -400, 115, 0, 0, 0
PlaySound 1446, SE1, 16, 100, -600, 110, 0, 0, 0
PlaySound 1475, SE2, 16, 114, -500, 120, 0, 0, 0
PlaySound 1446, SE1, 16, 116, -600, 110, 0, 0, 0
PlaySound 1475, SE2, 16, 130, -600, 125, 0, 0, 0
PlaySound 1446, SE1, 16, 132, -600, 110, 0, 0, 0
PlaySound 1475, SE2, 16, 146, -700, 130, 0, 0, 0
PlaySound 1446, SE1, 16, 148, -600, 110, 0, 0, 0
PlaySound 1475, SE2, 16, 162, -800, 135, 0, 0, 0
PlaySound 1446, SE1, 16, 164, -600, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 2, 24, 8, 26
Emit 941, 0, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 941, 1, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 941, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 9
ChangeSpriteColor ATTACKER, 10, 0, 3, 24, 8, 26
Wait 21
MoveCamera INTERPOLATION, DEFENDER, 12, 0, 8
Wait 12
EmitCircle 941, 3, DEFENDER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 941, 4, DEFENDER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 9, 3, 24, 6, 26
ShakeSprite DEFENDER, 2, 819, 0, 2, 0, 14
Wait 30
Emit 941, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 941, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 941, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 941, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 941, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 941, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 941, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 941, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 941, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 941, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 26
ChangeSpriteColor DEFENDER, 9, 14, 0, 31, 12, 30
ScaleSprite DEFENDER, ROUNDTRIP, -1638, 410, 5, 0, 1
ShakeScreen HORIZON, 0.5x, 0, 1, 0, 3
Wait 4
ChangeSpriteColor DEFENDER, 14, 9, 2, 24, 6, 26
ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 3
Wait 12
ChangeSpriteColor DEFENDER, 9, 14, 0, 31, 12, 30
ScaleSprite DEFENDER, ROUNDTRIP, -1638, 410, 5, 0, 1
ShakeScreen HORIZON, 0.5x, 0, 1, 0, 3
Wait 4
ChangeSpriteColor DEFENDER, 14, 9, 2, 24, 6, 26
ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 3
Wait 12
ChangeSpriteColor DEFENDER, 9, 14, 0, 31, 12, 30
ScaleSprite DEFENDER, ROUNDTRIP, -1638, 410, 5, 0, 1
ShakeScreen HORIZON, 0.5x, 0, 1, 0, 3
Wait 4
ChangeSpriteColor DEFENDER, 14, 9, 2, 24, 6, 26
ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 3
Wait 12
ChangeSpriteColor DEFENDER, 9, 14, 0, 31, 12, 30
ScaleSprite DEFENDER, ROUNDTRIP, -1638, 410, 5, 0, 1
ShakeScreen HORIZON, 0.5x, 0, 1, 0, 3
Wait 4
ChangeSpriteColor DEFENDER, 14, 9, 2, 24, 6, 26
ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 3
Wait 12
ChangeSpriteColor DEFENDER, 9, 14, 0, 31, 12, 30
ScaleSprite DEFENDER, ROUNDTRIP, -1638, 410, 5, 0, 1
ShakeScreen HORIZON, 1x, 0, 1, 0, 3
Wait 4
ChangeSpriteColor DEFENDER, 14, 9, 2, 24, 6, 26
ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 3
Wait 12
ChangeSpriteColor DEFENDER, 9, 0, 3, 24, 6, 26
Wait 6
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
