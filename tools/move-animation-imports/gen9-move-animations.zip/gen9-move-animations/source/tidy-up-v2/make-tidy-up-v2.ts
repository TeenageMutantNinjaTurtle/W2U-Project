import { assert, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";
import { compileMoveAnimation } from "../../Pokeweb-Serverless/src/pokeweb/moveAnimationModel";

// Tidy Up (move 882), v2 - from Logan's keyframes (reference/keyframe-1..2)
// and brief: "the brooms appear over the other Pokemon (even though the move
// selects the user) -> once the brooms are done cleaning, a 'cleansing' aura
// appears over the battlefield for a short second".
//   1. Big brooms sweep round the OPPOSING Pokemon, kicking up tan dust
//      clouds.
//   2. A cleansing aura pulses at the centre of the battlefield: two white
//      rings on the ground, the last dust settling, sparkles and soft
//      pale-blue light spots.
//
// The move targets its user, so DEFENDER can't be used for the opposing side.
// Retail Spikes and Stealth Rock solve the same problem with a side branch,
// copied here:
//     CheckMoveuser ATTACKER_POKEMON_VANISH, EQUAL, 1, <skip to the AA block>
//     ...block using BB (the enemy-side slot)...
//     CheckMoveUserElse <skip the AA block>
//     ...block using AA (the player-side slot)...
// Jump distances are in bytes from the end of the jump command; a command is
// 2 bytes plus 4 per parameter (Spikes: its 264-byte block, jumps 270/264).
// The web preview does not follow branches: it plays BOTH blocks one after
// the other. In game only one plays.
// The aura is emitted at the field's centre with EmitFromCoordinates, as
// retail Rain Dance and Perish Song do, so it is the same from either side.
// v1 (../tidy-up) is kept; reinstall its manifest to revert.
//
// The broom is v1's drawn texture (64x64 a3i5: a wooden handle, a bound
// collar and a pink-tan bristle fan; generated/texture-broom.png).

const SPA = 930;
const kit = await createKit({ workDir: import.meta.dirname, slug: "tidy-up-v2", moveId: 882, spaId: SPA, donors: [321, 560, 298, 228, 465] });

// --- timing (30 fps) ---
const WIDE = 18;
const SWEEP = 36;
const AURA = 34;

const WHITE: Rgb = [1, 1, 1];
const TAN: Rgb = [0.9, 0.8, 0.62];
const CREAM: Rgb = [1.0, 0.95, 0.82];
const BROWN: Rgb = [0.62, 0.5, 0.36];
const GOLD: Rgb = [1.0, 0.92, 0.6];
const PALE_BLUE: Rgb = [0.75, 0.88, 1.0];
const HAZE: Rgb = [0.86, 0.88, 0.92];

// --- the drawn broom (v1's) ---
type P = [number, number];
const inPoly = (x: number, y: number, poly: P[]) => {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i]!;
    const [xj, yj] = poly[j]!;
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
};
const bristles: P[] = [[17, 37], [31, 43], [22, 62], [4, 55]];
const broomTex = await kit.drawn("broom", 64, 64, "a3i5", (x, y) => {
  const px = x + 0.5;
  const py = y + 0.5;
  // Handle: a line from (52,4) to (25,40), 2.6 px thick.
  const hx = 25 - 52;
  const hy = 40 - 4;
  const t = Math.max(0, Math.min(1, ((px - 52) * hx + (py - 4) * hy) / (hx * hx + hy * hy)));
  const d = Math.hypot(px - (52 + hx * t), py - (4 + hy * t));
  if (inPoly(px, py, bristles)) {
    const stripe = Math.round((px - py * 0.45) / 3) % 2 === 0;
    return stripe ? [214, 158, 140] : [190, 132, 118];
  }
  if (Math.hypot(px - 24, py - 40) < 4.2) return [196, 118, 106]; // collar
  if (d < 1.4) return [172, 116, 82];
  if (d < 2.3) return [120, 78, 54];
  return undefined;
});

// --- 1. the sweep (positions relative to the opposing Pokemon's slot) ---
const brooms: Array<{ pos: Vec3; delay: number; dir: 1 | -1; flip: boolean }> = [
  { pos: [-2.3, 0.7, 0.3], delay: 0, dir: 1, flip: false },
  { pos: [2.3, 0.9, 0.1], delay: 4, dir: -1, flip: true },
  { pos: [0.2, 0.4, 1.3], delay: 8, dir: 1, flip: false },
];
brooms.forEach((b, i) => {
  const r = kit.parked(broomTex, b.pos, 2.0, SWEEP - b.delay);
  r.startDelayFrames = b.delay;
  r.flipTextureS = b.flip;
  r.axis = [1, 0, 0];
  r.initVelAxisAmplifier = 0.035 * b.dir;
  spin(r, 0.03 * b.dir, 0.03 * b.dir, -0.3 * b.dir);
  setCurves(r, grow(0.4, 0.15), fadeInOut(1, 0.1, 0.85));
  paint(r, WHITE);
  kit.add(`broom${i}`, r);

  const dust = kit.spray([333, 1], kit.tex(321, 5), [b.pos[0] - 0.5 * b.dir, b.pos[1] - 1.5, b.pos[2] + 0.2], { radius: 0.6, speed: 0.06, count: 1, bursts: 6, gap: 4, life: 16, scale: 0.8, shape: "ball" });
  dust.startDelayFrames = b.delay + 3;
  spin(dust, -0.05, 0.05, 0, true);
  setCurves(dust, grow(0.4, 0.3, 1.5), fadeInOut(0.95, 0.15, 0.55));
  kit.prism(dust, [TAN, CREAM, BROWN]);
  kit.add(`dust${i}`, dust);
});
const sweepNames = brooms.flatMap((_, i) => [`broom${i}`, `dust${i}`]);

// --- 2. the cleansing aura (positions relative to the field's centre) ---
function ring(scale: number, delay: number, level: number): ReturnType<typeof kit.parked> {
  const r = kit.parked(kit.tex(560, 1), [0, -0.4, -1.0], scale, AURA - delay);
  r.startDelayFrames = delay;
  r.aspectRatio = 3.0;
  setCurves(r, grow(0.15, 0.35, 1.25), fadeInOut(level, 0.12, 0.7));
  paint(r, WHITE);
  return r;
}
kit.add("ringOuter", ring(2.2, 0, 1)); // half the first pass, at Logan's request
kit.add("ringInner", ring(1.3, 4, 1));

// (A spinning pale swirl and orbiting dust were removed at Logan's request:
// "no spinning emitter around the screen".)
const lastDust = kit.spray([333, 1], kit.tex(321, 5), [0, 0.2, -1.0], { radius: 1.2, speed: 0.03, count: 4, life: AURA - 12, scale: 0.7, shape: "circle" });
lastDust.emissionAxis = 1;
spin(lastDust, -0.06, 0.06, 0, true);
setCurves(lastDust, { start: 1, mid: 0.7, end: 0.15, curveIn: 0.3, curveOut: 0.4 }, fadeOut(0.75, 0.25));
kit.prism(lastDust, [TAN, CREAM, BROWN]);
kit.add("lastDust", lastDust);

const sparkles = kit.spray([333, 1], kit.tex(298, 1), [0, 1.2, -1.0], { radius: 2.6, speed: 0.01, count: 2, bursts: (AURA - 10) / 3, gap: 3, life: 10, scale: 0.3, shape: "ball" });
sparkles.startDelayFrames = 4;
setCurves(sparkles, twinkle(1), twinkle(1));
kit.prism(sparkles, [WHITE, GOLD, WHITE]);
kit.add("sparkles", sparkles);

const bokeh = kit.spray([333, 1], kit.tex(298, 0), [0, 0.8, -1.0], { radius: 1.8, speed: 0.01, count: 1, bursts: 5, gap: 4, life: 16, scale: 0.6, shape: "ball" });
bokeh.startDelayFrames = 6;
setCurves(bokeh, grow(0.6, 0.3, 1.1), fadeInOut(0.45, 0.25, 0.6));
paint(bokeh, PALE_BLUE, WHITE, PALE_BLUE);
kit.add("bokeh", bokeh);
const auraNames = ["ringOuter", "ringInner", "lastDust", "sparkles", "bokeh"];

// --- script ---
const sweepBlock = (slot: "AA" | "BB") => [...sweepNames.map((n) => `Emit ${SPA}, ${kit.idx(n)}, ${slot}, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x`), `Wait ${SWEEP}`].join("\n");
// Compiled size of a run of commands, in bytes.
const empty = compileMoveAnimation(undefined as never, 0, "TerminateMoveScript").length;
const bytesOf = (text: string) => compileMoveAnimation(undefined as never, 0, `${text}\nTerminateMoveScript`).length - empty;
// The compiler must agree with retail: Spikes' enemy-side block is 264 bytes and its "else" jump command 6.
const spikesBlock = `MoveCamera INTERPOLATION, BB, 32, 0, 12
EmitProjectile 361, 0, CURVE, ATTACKER, BB, 1px, 20f, 2px, 1x, 1x, 0
Wait 10
EmitProjectile 361, 0, CURVE, ATTACKER, BB, 1px, 20f, 2px, 1x, 1x, 0
Wait 10
EmitProjectile 361, 0, CURVE, ATTACKER, BB, 1px, 20f, 2px, 1x, 1x, 0
Emit 361, 1, BB, NONE, 1px, 0, 0, 1x, 1x, 1x, 1x
Emit 361, 2, BB, NONE, 1px, 0, 0, 1x, 1x, 1x, 1x`;
assert.equal(bytesOf(spikesBlock), 264, "Compiled block size disagrees with retail Spikes");
assert.equal(bytesOf("CheckMoveUserElse 264"), 6, "Jump command is not 6 bytes");
const blockBytes = bytesOf(sweepBlock("BB"));
assert.equal(blockBytes, bytesOf(sweepBlock("AA")), "The two side blocks differ in size");
const elseBytes = 6;

const field = (name: string) => `EmitFromCoordinates ${SPA}, ${kit.idx(name)}, 0, 1px, 0, 0, 0, 0, 0, 0, 0, 1x, 1x, 1x, 1x`;
const script = `MoveCamera INTERPOLATION, ZOOM_OUT_PERS, ${WIDE}, 0, 0
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, 500, 95, 0, 0, 0
PlaySound 1497, SE2, 14, 10, 900, 85, 0, 0, 0
PlaySound 1497, SE1, 14, 20, 600, 90, 0, 0, 0
AudioContainer SUSPEND
CheckMoveuser ATTACKER_POKEMON_VANISH, EQUAL, 1, ${blockBytes + elseBytes}
${sweepBlock("BB")}
CheckMoveUserElse ${blockBytes}
${sweepBlock("AA")}
AudioContainer CONTINUE
PlaySound 1875, SE1, 14, 0, 600, 95, 0, 0, 0
PlaySound 1509, SE2, 14, 4, 600, 110, 0, 0, 0
PlaySound 1784, SE1, 14, 12, 300, 95, 0, 0, 0
AudioContainer SUSPEND
${auraNames.map(field).join("\n")}
Wait ${AURA}
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [191, 446, 240, 195, 153, 564],
  references: ["reference/keyframe-1.png", "reference/keyframe-2.png", "reference/Tidy_Up_IX.png", "reference/Tidy_Up_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveCamera INTERPOLATION, ZOOM_OUT_PERS", `Emit ${SPA}, 0, BB`, `Emit ${SPA}, 0, AA`, `EmitFromCoordinates ${SPA}, ${kit.idx("ringOuter")}`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  side block ${blockBytes} bytes (jumps ${blockBytes + elseBytes} / ${blockBytes}); in game: sweep f${WIDE}-${WIDE + SWEEP}, aura f${WIDE + SWEEP}-${WIDE + SWEEP + AURA}; the preview plays the sweep twice`);
