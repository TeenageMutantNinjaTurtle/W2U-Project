MoveCamera INTERPOLATION, ZOOM_OUT_PERS, 18, 0, 0
LetCMDsFinish CAMERA
LoadSPA 930
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, 500, 95, 0, 0, 0
PlaySound 1497, SE2, 14, 10, 900, 85, 0, 0, 0
PlaySound 1497, SE1, 14, 20, 600, 90, 0, 0, 0
AudioContainer SUSPEND
CheckMoveuser ATTACKER_POKEMON_VANISH, EQUAL, 1, 288
Emit 930, 0, BB, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 930, 1, BB, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 930, 2, BB, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 930, 3, BB, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 930, 4, BB, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 930, 5, BB, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 36
CheckMoveUserElse 282
Emit 930, 0, AA, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 930, 1, AA, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 930, 2, AA, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 930, 3, AA, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 930, 4, AA, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 930, 5, AA, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 36
AudioContainer CONTINUE
PlaySound 1875, SE1, 14, 0, 600, 95, 0, 0, 0
PlaySound 1509, SE2, 14, 4, 600, 110, 0, 0, 0
PlaySound 1784, SE1, 14, 12, 300, 95, 0, 0, 0
AudioContainer SUSPEND
EmitFromCoordinates 930, 6, 0, 1px, 0, 0, 0, 0, 0, 0, 0, 1x, 1x, 1x, 1x
EmitFromCoordinates 930, 7, 0, 1px, 0, 0, 0, 0, 0, 0, 0, 1x, 1x, 1x, 1x
EmitFromCoordinates 930, 8, 0, 1px, 0, 0, 0, 0, 0, 0, 0, 1x, 1x, 1x, 1x
EmitFromCoordinates 930, 9, 0, 1px, 0, 0, 0, 0, 0, 0, 0, 1x, 1x, 1x, 1x
EmitFromCoordinates 930, 10, 0, 1px, 0, 0, 0, 0, 0, 0, 0, 1x, 1x, 1x, 1x
Wait 34
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
