import { aimed, assert, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Torch Song (move 871), v2 - from Logan's keyframes (shown in chat, not
// saved) and brief:
//   1. A short windup: yellow-orange fire gathers and flares at the user's
//      mouth, embers drifting round it.
//   2. It fires: the fire bird flies at the foe trailing embers.
//   3. The target takes the hit and explodes in white-yellow fire, orange
//      flame fragments flying.
// The fire bird (texture and flight) is v1's, unchanged: Logan called it
// perfect. A drawn sceptre-microphone stood in front of the user in the
// first pass of v2; Logan had it removed (2026-10-01).
// v1 (../torch-song) is kept; reinstall its manifest to revert.

const SPA = 925;
const kit = await createKit({ workDir: import.meta.dirname, slug: "torch-song-v2", moveId: 871, spaId: SPA, donors: [411, 465, 321, 228, 579] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const WINDUP = 14;
const FLIGHT = 12;
const HIT_STOP = 4;
const HOLD = 26;

const MOUTH: Vec3 = [0.3, 0.8, -0.8]; // as v1
const FOE: Vec3 = [0, 0.3, 0.8];
const FOE_GROUND: Vec3 = [0, -1.8, 0.6];

const ORANGE: Rgb = [1.0, 0.5, 0.1];
const YELLOW: Rgb = [1.0, 0.85, 0.3];
const RED_ORANGE: Rgb = [1.0, 0.32, 0.08];
const PINK_RED: Rgb = [1.0, 0.4, 0.45];
const PALE: Rgb = [1.0, 0.95, 0.75];
const WHITE: Rgb = [1, 1, 1];

// --- the drawn fire bird (v1's, unchanged) ---
const birdTex = await kit.drawn("firebird", 64, 64, "a3i5", (x, y) => {
  const nx = (x - 31.5) / 32;
  const ny = (y - 31.5) / 32;
  // Wings: sweep up from the shoulders to pointed tips, thick at the root
  // and tapering, with a scalloped (feathered) trailing edge.
  const ax = Math.abs(nx);
  const span = (ax - 0.12) / 0.85; // 0 at the shoulder, 1 at the tip
  const lead = 0.0 - 0.5 * span - 0.08 * span * span;
  const thick = 0.5 * Math.pow(Math.max(0, 1 - span), 0.7) + 0.03;
  const trail = lead + thick + 0.045 * Math.sin(span * 26);
  const inWing = span >= 0 && span <= 1 && ny >= lead && ny <= trail;
  // Body: an ellipse; tail: a tapering plume streaming down.
  const inBody = (nx / 0.17) ** 2 + ((ny - 0.08) / 0.3) ** 2 <= 1;
  const tailHalf = 0.14 * (1 - (ny - 0.3) / 0.65);
  const inTail = ny > 0.3 && ny < 0.95 && Math.abs(nx + 0.08 * Math.sin(ny * 9)) < tailHalf;
  const inHead = (nx / 0.12) ** 2 + ((ny + 0.28) / 0.12) ** 2 <= 1;
  if (!inWing && !inBody && !inTail && !inHead) return undefined;
  // Heat: hottest at the centre, cooling toward the tips.
  const heat = Math.max(0, 1 - Math.hypot(nx * 1.1, (ny - 0.05) * 1.4));
  if (heat > 0.75) return [255, 250, 220];
  if (heat > 0.5) return [255, 215, 80];
  if (heat > 0.25) return [255, 145, 30];
  return [235, 80, 25];
});

// --- 1. the windup: fire gathers and flares at the mouth ---
const embers = kit.spray([333, 1], kit.tex(333, 0), MOUTH, { radius: 1.3, speed: 0.04, count: 1, bursts: WINDUP / 2, gap: 2, life: 12, scale: 0.15, shape: "ball" });
embers.axis = [0, 1, 0];
embers.initVelAxisAmplifier = 0.04;
setCurves(embers, undefined, twinkle());
kit.prism(embers, [PINK_RED, ORANGE, PALE]);
kit.add("embers", embers);

const gather = kit.spray([333, 1], kit.tex(333, 0), MOUTH, { radius: 1.8, speed: 0, count: 2, bursts: WINDUP / 2, gap: 2, life: 9, scale: 0.14, shape: "sphere" });
gather.behaviors = [{ type: "convergence", target: [0, 0, 0], force: 0.13 }];
setCurves(gather, undefined, twinkle());
kit.prism(gather, [YELLOW, ORANGE, PALE]);
kit.add("gather", gather);

const charge = kit.parked(kit.tex(465, 1), MOUTH, 2.2, WINDUP + 2);
setCurves(charge, { start: 0.2, mid: 0.7, end: 1.2, curveIn: 0.5, curveOut: 0.5 }, fadeInOut(0.95, 0.2, 0.9));
paint(charge, YELLOW, PALE, ORANGE);
kit.add("charge", charge);

const flare = kit.parked(kit.tex(579, 2), MOUTH, 1.4, 8);
flare.startDelayFrames = WINDUP - 4;
spin(flare, 0.15);
setCurves(flare, grow(0.3, 0.4, 1.5), fadeOut(1, 0.5));
paint(flare, YELLOW, WHITE, ORANGE);
kit.add("flare", flare);

const tongues = kit.spray([228, 3], kit.tex(321, 6), MOUTH, { radius: 0.3, speed: 0.2, count: 2, bursts: WINDUP / 3, gap: 3, life: 9, scale: 0.6, directional: true });
tongues.startDelayFrames = 2;
tongues.axis = [0, 1, 0];
tongues.initVelAxisAmplifier = 0.22;
setCurves(tongues, grow(0.6, 0.3, 1.1), fadeOut(1, 0.45));
kit.prism(tongues, [ORANGE, YELLOW, RED_ORANGE]);
kit.add("tongues", tongues);

// --- 2. the fire bird (v1's resources, unchanged) ---
const bird = kit.parked(birdTex, MOUTH, 1.4, FLIGHT + 1);
aimed(bird, 1.3, FLIGHT + 1);
setCurves(bird, grow(0.6, 0.3, 1.1), hold(1));
paint(bird, WHITE);
kit.add("bird", bird);

const trail = kit.spray([333, 1], kit.tex(321, 5), MOUTH, { radius: 0.4, speed: 0.03, count: 1, bursts: FLIGHT, gap: 1, life: 10, scale: 0.6 });
aimed(trail, 0.8, 10);
spin(trail, -0.1, 0.1, 0, true);
setCurves(trail, grow(0.8, 0.3, 0.4), fadeOut(0.85, 0.3));
kit.prism(trail, [ORANGE, YELLOW, RED_ORANGE]);
kit.add("trail", trail);

const sparks = kit.spray([333, 1], kit.tex(333, 0), MOUTH, { radius: 0.6, speed: 0.06, count: 1, bursts: FLIGHT, gap: 1, life: 10, scale: 0.13 });
aimed(sparks, 1.0, 10);
sparks.behaviors = [{ type: "gravity", magnitude: [0, -0.01, 0] }];
setCurves(sparks, undefined, twinkle());
kit.prism(sparks, [YELLOW, PALE, ORANGE]);
kit.add("sparks", sparks);

// --- 3. the explosion ---
const flash = kit.parked(kit.tex(228, 1), FOE, 2.4, 14);
spin(flash, 0.05);
setCurves(flash, grow(0.4, 0.2, 2.3), fadeOut(1, 0.35));
paint(flash, PALE, WHITE, YELLOW);
kit.add("flash", flash);

const blast = kit.parked(kit.tex(579, 2), FOE, 2.2, 14);
spin(blast, 0.1);
setCurves(blast, grow(0.4, 0.25, 1.6), fadeOut(1, 0.4));
paint(blast, YELLOW, WHITE, ORANGE);
kit.add("blast", blast);

const fireball = kit.spray([333, 1], kit.tex(321, 5), FOE, { radius: 0.7, speed: 0.16, count: 7, life: 16, scale: 1.2, shape: "ball" });
spin(fireball, -0.08, 0.08, 0, true);
setCurves(fireball, grow(0.5, 0.25, 1.5), fadeOut(1, 0.4));
kit.prism(fireball, [YELLOW, ORANGE, PALE]);
kit.add("fireball", fireball);

const fragments = kit.spray([228, 3], kit.tex(321, 6), FOE, { radius: 0.4, speed: 0.6, count: 10, life: 11, scale: 0.7, directional: true });
setCurves(fragments, grow(1.2, 0.3, 0.6), fadeOut());
kit.prism(fragments, [ORANGE, YELLOW, RED_ORANGE]);
kit.add("fragments", fragments);

const smoulder = kit.spray([333, 1], kit.tex(465, 1), FOE_GROUND, { radius: 1.8, speed: 0, count: 1, bursts: 6, gap: 3, life: 14, scale: 0.3, shape: "circle" });
smoulder.startDelayFrames = 4;
smoulder.emissionAxis = 1;
setCurves(smoulder, undefined, twinkle());
kit.prism(smoulder, [ORANGE, RED_ORANGE, YELLOW]);
kit.add("smoulder", smoulder);

// --- script ---
const emits = (names: string[], who: "ATTACKER" | "DEFENDER", toward = "NONE") => names.map((n) => kit.emit(n, who, toward)).join("\n");
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1864, SE2, 16, 0, 200, 100, 0, 0, 0
PlaySound 1425, SE1, 16, ${WINDUP}, 0, 120, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, ${FLIGHT}, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 1, 4, 1, 0
${emits(["embers", "gather", "charge", "flare", "tongues"], "ATTACKER")}
ChangeSpriteColor ATTACKER, 0, 8, 2, 31, 18, 6
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, ${WINDUP / 2}
Wait ${WINDUP}
ChangeSpriteColor ATTACKER, 8, 0, 1, 31, 18, 6
${emits(["bird", "trail", "sparks"], "ATTACKER", "DEFENDER")}
MoveCamera INTERPOLATION, DEFENDER, ${FLIGHT}, 0, 8
Wait ${FLIGHT}
AudioContainer CONTINUE
PlaySound 1426, SE1, 16, 0, 0, 125, 0, 0, 0
PlaySound 1475, SE2, 16, 0, -300, 125, 0, 0, 0
PlaySound 1420, SE2, 16, ${HIT_STOP + 2}, -300, 110, 0, 0, 0
AudioContainer SUSPEND
${emits(["flash", "blast", "fireball", "fragments", "smoulder"], "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 22, 6
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 14, 0, 2, 31, 14, 2
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait ${HOLD - HIT_STOP}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 8, 0, 1, 4, 1, 0
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

const { built } = await kit.finish({
  script,
  donorMoveIds: [240, 605, 153, 63, 163, 304, 53],
  references: ["reference/Torch_Song_IX.png", "reference/Torch_Song_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, `Emit ${SPA}, ${kit.idx("bird")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("blast")}, DEFENDER`, "ShakeScreen VERTICAL, 1x", "MoveCamera INTERPOLATION, INIT"],
});
assert.equal(built("bird").textureIndex, birdTex, "Fire bird is not the drawn texture");
assert.ok(built("bird").color.every((c) => c > 0.99), "Fire bird is tinted");
assert.ok(Math.abs(built("bird").baseScale - 1.4) < 0.02 && Math.abs(built("bird").initVelAxisAmplifier - 1.3) < 0.02, "Fire bird's size or flight changed from v1");
console.log(`  windup f${CAMERA_IN}, fire f${CAMERA_IN + WINDUP}, explosion f${CAMERA_IN + WINDUP + FLIGHT}`);
