MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 925
AudioContainer CONTINUE
PlaySound 1864, SE2, 16, 0, 200, 100, 0, 0, 0
PlaySound 1425, SE1, 16, 14, 0, 120, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 12, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 1, 4, 1, 0
Emit 925, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 925, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 925, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 925, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 925, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor ATTACKER, 0, 8, 2, 31, 18, 6
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 7
Wait 14
ChangeSpriteColor ATTACKER, 8, 0, 1, 31, 18, 6
Emit 925, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 925, 6, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 925, 7, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveCamera INTERPOLATION, DEFENDER, 12, 0, 8
Wait 12
AudioContainer CONTINUE
PlaySound 1426, SE1, 16, 0, 0, 125, 0, 0, 0
PlaySound 1475, SE2, 16, 0, -300, 125, 0, 0, 0
PlaySound 1420, SE2, 16, 6, -300, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 925, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 925, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 925, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 925, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 925, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 22, 6
Wait 4
ChangeSpriteColor DEFENDER, 14, 0, 2, 31, 14, 2
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 22
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 8, 0, 1, 4, 1, 0
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
