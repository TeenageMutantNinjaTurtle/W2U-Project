MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 918
AudioContainer CONTINUE
PlaySound 1487, SE1, 14, 0, 500, 80, 0, 0, 0
PlaySound 1487, SE1, 14, 10, 1100, 95, 0, 0, 0
PlaySound 1421, SE2, 14, 14, 600, 100, 0, 0, 0
PlaySound 1536, SE2, 14, 26, 0, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 12, 0, 50, 0, 0
AudioContainer SUSPEND
Emit 918, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 918, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 918, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 918, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 918, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 10
Wait 10
ChangeSpriteColor ATTACKER, 0, 16, 1, 28, 29, 31
Wait 16
ToggleSpriteVisibility ATTACKER, 3
EmitProjectile 918, 5, STRAIGHT, ATTACKER, DEFENDER, 0, 12f, 0, 1x, 1x, 0
EmitProjectile 918, 6, STRAIGHT, ATTACKER, DEFENDER, 0, 12f, 0, 1x, 1x, 0
EmitProjectile 918, 7, STRAIGHT, ATTACKER, DEFENDER, 0, 12f, 0, 1x, 1x, 0
EmitProjectile 918, 8, STRAIGHT, ATTACKER, DEFENDER, 0, 12f, 0, 1x, 1x, 0
MoveCamera INTERPOLATION, DEFENDER, 12, 0, 8
Wait 12
AudioContainer CONTINUE
PlaySound 1420, SE1, 16, 0, -300, 125, 0, 0, 0
PlaySound 1442, SE2, 16, 0, 0, 115, 0, 0, 0
PlaySound 1442, SE2, 16, 6, 300, 100, 0, 0, 0
AudioContainer SUSPEND
Emit 918, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 918, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 918, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 918, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 918, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 30, 30, 31
Wait 4
ChangeSpriteColor DEFENDER, 12, 0, 1, 30, 30, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 18
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 16, 0, 0, 28, 29, 31
ToggleSpriteVisibility ATTACKER, 4
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
