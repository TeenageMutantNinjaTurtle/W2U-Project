import { assert, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Spin Out (move 859), v2 - from Logan's keyframes (reference/keyframe-1..7):
//   1. Startup: the user revs, dust stirring at its feet.
//   2. Winding: it whirls into a glowing silver blur, gold sparks and rock
//      chips flying off it.
//   3-5. Firing: it shoots itself at the foe as a spinning silver tyre,
//      dark streaks whirling round it, rolling across the ground and leaving
//      a trail of gold sparks, rock chips and dust.
//   6-7. Contact: the tyre rides up the foe, grinding - white spray and
//      streaks shooting up, chips flying - dealing the damage.
// The user is hidden while it is the tyre (ToggleSpriteVisibility 3/4, as
// retail Dive does). The Speed drop is handled by the engine.
// v1 (../spin-out, a drawn wheel in front of the user) is kept; reinstall its
// manifest to revert.
//
// Drawn here (see generated/): the tyre (64x64 a3i5: a silver torus with a
// hole and dark motion streaks) and a stone chip (32x32 a3i5).

const SPA = 918;
const kit = await createKit({ workDir: import.meta.dirname, slug: "spin-out-v2", moveId: 859, spaId: SPA, donors: [605, 465, 321, 228, 411, 333] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const STARTUP = 10;
const WIND = 16;
const ROLL = 12;
const RIDE = 12;
const HIT_STOP = 4;
const HOLD = 22;

// "0" anchors (ground level) for the roll; "2px" (mid-body) elsewhere.
const USER: Vec3 = [0, 0.3, 0.2];
const FEET: Vec3 = [0, -1.5, 0.2];
const FOE: Vec3 = [0, 0.3, 0.8];
const TYRE_SCALE = 1.5;
const TYRE_HUB = 1.4; // above the ground

const SILVER: Rgb = [0.88, 0.9, 0.96];
const PALE: Rgb = [0.95, 0.97, 1.0];
const GOLD: Rgb = [1.0, 0.82, 0.35];
const ORANGE: Rgb = [1.0, 0.6, 0.25];
const DUST: Rgb = [0.82, 0.84, 0.88];
const WHITE: Rgb = [1, 1, 1];

// --- drawn textures ---
const bandHash = (b: number) => {
  const s = Math.sin(b * 12.9898 + 4.1) * 43758.5453;
  return s - Math.floor(s);
};
const tyreTex = await kit.drawn("tyre", 64, 64, "a3i5", (x, y) => {
  const dx = x + 0.5 - 32;
  const dy = y + 0.5 - 32;
  const r = Math.hypot(dx, dy);
  if (r > 30.5 || r < 10) return undefined;
  if (r < 11.6) return [104, 106, 122]; // inner lip
  if (r > 29.2) return [150, 154, 172]; // outer edge
  const a = (Math.atan2(dy, dx) + Math.PI * 2) % (Math.PI * 2);
  // Two dark motion streaks per 3-pixel band, each an arc of its own length.
  const band = Math.floor(r / 3);
  for (let k = 0; k < 2; k++) {
    const start = bandHash(band * 2 + k) * Math.PI * 2;
    const len = 0.5 + bandHash(band * 2 + k + 50) * 0.9;
    const rel = (a - start + Math.PI * 2) % (Math.PI * 2);
    if (rel < len && r % 3 > 0.8 && r % 3 < 2.2) return rel < len * 0.3 ? [120, 122, 138] : [72, 74, 90];
  }
  const t = (r - 11.6) / 17.6; // 0 inner .. 1 outer
  return t < 0.25 ? [176, 180, 196] : t < 0.7 ? [222, 225, 236] : [246, 247, 252];
});

type P = [number, number];
const chip: P[] = [[6, 12], [15, 5], [26, 10], [27, 21], [16, 27], [5, 21]];
const inPoly = (x: number, y: number, poly: P[]) => {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i]!;
    const [xj, yj] = poly[j]!;
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
};
const chipTex = await kit.drawn("chip", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5;
  const py = y + 0.5;
  if (!inPoly(px, py, chip)) return undefined;
  if (!inPoly(px - 1.2, py, chip) || !inPoly(px + 1.2, py, chip) || !inPoly(px, py - 1.2, chip) || !inPoly(px, py + 1.2, chip)) return [70, 74, 92];
  if (inPoly(px, py, [chip[0]!, chip[1]!, chip[2]!, [16, 16]])) return [236, 238, 246];
  if (inPoly(px, py, [chip[2]!, chip[3]!, chip[4]!, [16, 16]])) return [140, 146, 168];
  return [190, 194, 210];
});

// --- 1. startup: revving ---
const revDust = kit.spray([333, 1], kit.tex(321, 5), FEET, { radius: 1.3, speed: 0.04, count: 1, bursts: 5, gap: 2, life: 12, scale: 0.5, shape: "circle" });
revDust.emissionAxis = 1;
spin(revDust, -0.08, 0.08, 0, true);
setCurves(revDust, grow(0.4, 0.3, 1.3), fadeInOut(0.7, 0.2, 0.5));
paint(revDust, DUST, WHITE, DUST);
kit.add("revDust", revDust);

// --- 2. winding: the silver blur ---
const blurGlow = kit.parked(kit.tex(465, 1), USER, 3.0, WIND + 2);
blurGlow.startDelayFrames = STARTUP;
blurGlow.aspectRatio = 0.8;
setCurves(blurGlow, grow(0.3, 0.4, 1.1), fadeInOut(0.85, 0.3, 0.9));
paint(blurGlow, PALE, WHITE, SILVER);
kit.add("blurGlow", blurGlow);

const blurTyre = kit.parked(tyreTex, USER, TYRE_SCALE, WIND + 2);
blurTyre.startDelayFrames = STARTUP + 4;
blurTyre.aspectRatio = 0.8;
spin(blurTyre, -0.55);
setCurves(blurTyre, grow(0.3, 0.4, 1), fadeInOut(0.9, 0.35, 1));
paint(blurTyre, WHITE);
kit.add("blurTyre", blurTyre);

const windSparks = kit.spray([333, 1], kit.tex(333, 0), USER, { radius: 1.2, speed: 0.22, count: 1, bursts: WIND / 2, gap: 2, life: 10, scale: 0.12 });
windSparks.startDelayFrames = STARTUP;
windSparks.behaviors = [{ type: "gravity", magnitude: [0, -0.015, 0] }];
setCurves(windSparks, undefined, twinkle());
kit.prism(windSparks, [GOLD, WHITE, ORANGE]);
kit.add("windSparks", windSparks);

const windChips = kit.spray([333, 1], chipTex, USER, { radius: 1.2, speed: 0.18, count: 1, bursts: WIND / 3, gap: 3, life: 12, scale: 0.22 });
windChips.startDelayFrames = STARTUP;
windChips.behaviors = [{ type: "gravity", magnitude: [0, -0.02, 0] }];
spin(windChips, -0.3, 0.3, 0, true);
setCurves(windChips, hold(1), fadeOut(1, 0.6));
paint(windChips, WHITE);
kit.add("windChips", windChips);

// --- 3-5. the roll (riding an EmitProjectile STRAIGHT emitter) ---
const tyre = kit.shell(605, 0);
assert.ok(tyre.followEmitter, "Mud Bomb's ball no longer follows its emitter");
tyre.textureIndex = tyreTex;
Object.assign(tyre, { particleLifeFrames: ROLL + 1, baseScale: TYRE_SCALE, aspectRatio: 0.8, emitterBasePos: [0, TYRE_HUB, 0] });
spin(tyre, -0.6);
setCurves(tyre, hold(1), undefined); // Mud Bomb's rider has no alpha curve
paint(tyre, WHITE);
kit.add("tyre", tyre);

const trailSparks = kit.spray([333, 1], kit.tex(333, 0), [0, 0.15, 0], { radius: 0.4, speed: 0.12, count: 1, bursts: ROLL, gap: 1, life: 9, scale: 0.12 });
trailSparks.axis = [0, 1, 0];
trailSparks.initVelAxisAmplifier = 0.15;
trailSparks.behaviors = [{ type: "gravity", magnitude: [0, -0.03, 0] }];
setCurves(trailSparks, undefined, fadeOut(1, 0.5));
kit.prism(trailSparks, [GOLD, ORANGE, WHITE]);
kit.add("trailSparks", trailSparks);

const trailChips = kit.spray([333, 1], chipTex, [0, 0.2, 0], { radius: 0.4, speed: 0.1, count: 1, bursts: ROLL / 2, gap: 2, life: 12, scale: 0.2 });
trailChips.axis = [0, 1, 0];
trailChips.initVelAxisAmplifier = 0.14;
trailChips.behaviors = [{ type: "gravity", magnitude: [0, -0.03, 0] }];
spin(trailChips, -0.3, 0.3, 0, true);
setCurves(trailChips, hold(1), fadeOut(1, 0.5));
paint(trailChips, WHITE);
kit.add("trailChips", trailChips);

const trailDust = kit.spray([333, 1], kit.tex(321, 5), [0, 0.3, 0], { radius: 0.3, speed: 0.03, count: 1, bursts: ROLL / 2, gap: 2, life: 14, scale: 0.7 });
spin(trailDust, -0.06, 0.06, 0, true);
setCurves(trailDust, grow(0.4, 0.3, 1.5), fadeInOut(0.6, 0.15, 0.5));
paint(trailDust, DUST, WHITE, DUST);
kit.add("trailDust", trailDust);

// --- 6-7. riding up the foe ---
const climb = kit.parked(tyreTex, [0, -0.6, FOE[2] + 0.3], TYRE_SCALE, RIDE);
climb.aspectRatio = 0.8;
climb.axis = [0, 1, 0];
climb.initVelAxisAmplifier = 0.28;
climb.airResistance = 0.94;
spin(climb, -0.6);
setCurves(climb, hold(1), fadeOut(1, 0.65));
paint(climb, WHITE);
kit.add("climb", climb);

const flash = kit.parked(kit.tex(228, 1), FOE, 1.6, 10);
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.2, 1.8), fadeOut(1, 0.35));
paint(flash, WHITE, WHITE, PALE);
kit.add("flash", flash);

const spray = kit.spray([228, 3], kit.tex(321, 6), [0, -0.5, FOE[2] + 0.2], { radius: 0.5, speed: 0.25, count: 4, bursts: RIDE / 3, gap: 3, life: 9, scale: 0.7, directional: true });
spray.axis = [0, 1, 0];
spray.initVelAxisAmplifier = 0.4;
setCurves(spray, grow(1.2, 0.3, 0.7), fadeOut(1, 0.45));
paint(spray, WHITE, WHITE, PALE);
kit.add("spray", spray);

const streaks = kit.spray([228, 3], kit.tex(411, 0), [0, -0.3, FOE[2] + 0.2], { radius: 0.4, speed: 0.4, count: 2, bursts: RIDE / 3, gap: 3, life: 7, scale: 1.6, directional: true });
streaks.axis = [0, 1, 0];
streaks.initVelAxisAmplifier = 0.45;
setCurves(streaks, undefined, fadeOut());
kit.prism(streaks, [WHITE, PALE, GOLD]);
kit.add("streaks", streaks);

const hitChips = kit.spray([333, 1], chipTex, FOE, { radius: 0.5, speed: 0.3, count: 5, life: 16, scale: 0.26 });
hitChips.axis = [0, 1, 0];
hitChips.initVelAxisAmplifier = 0.2;
hitChips.behaviors = [{ type: "gravity", magnitude: [0, -0.022, 0] }];
spin(hitChips, -0.3, 0.3, 0, true);
setCurves(hitChips, hold(1), fadeOut(1, 0.6));
paint(hitChips, WHITE);
kit.add("hitChips", hitChips);

// --- script ---
const roll = (name: string) => `EmitProjectile ${SPA}, ${kit.idx(name)}, STRAIGHT, ATTACKER, DEFENDER, 0, ${ROLL}f, 0, 1x, 1x, 0`;
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1487, SE1, 14, 0, 500, 80, 0, 0, 0
PlaySound 1487, SE1, 14, ${STARTUP}, 1100, 95, 0, 0, 0
PlaySound 1421, SE2, 14, ${STARTUP + 4}, 600, 100, 0, 0, 0
PlaySound 1536, SE2, 14, ${STARTUP + WIND}, 0, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${ROLL}, 0, 50, 0, 0
AudioContainer SUSPEND
${kit.emit("revDust", "ATTACKER")}
${kit.emit("blurGlow", "ATTACKER")}
${kit.emit("blurTyre", "ATTACKER")}
${kit.emit("windSparks", "ATTACKER")}
${kit.emit("windChips", "ATTACKER")}
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 10
Wait ${STARTUP}
ChangeSpriteColor ATTACKER, 0, 16, 1, 28, 29, 31
Wait ${WIND}
ToggleSpriteVisibility ATTACKER, 3
${roll("tyre")}
${roll("trailSparks")}
${roll("trailChips")}
${roll("trailDust")}
MoveCamera INTERPOLATION, DEFENDER, ${ROLL}, 0, 8
Wait ${ROLL}
AudioContainer CONTINUE
PlaySound 1420, SE1, 16, 0, -300, 125, 0, 0, 0
PlaySound 1442, SE2, 16, 0, 0, 115, 0, 0, 0
PlaySound 1442, SE2, 16, 6, 300, 100, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("climb", "DEFENDER")}
${kit.emit("flash", "DEFENDER")}
${kit.emit("spray", "DEFENDER")}
${kit.emit("streaks", "DEFENDER")}
${kit.emit("hitChips", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 30, 30, 31
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 12, 0, 1, 30, 30, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait ${HOLD - HIT_STOP}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 16, 0, 0, 28, 29, 31
ToggleSpriteVisibility ATTACKER, 4
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [205, 360, 605, 63, 400, 153, 291],
  references: ["reference/keyframe-1.png", "reference/keyframe-2.png", "reference/keyframe-3.png", "reference/keyframe-4.png", "reference/keyframe-5.png", "reference/keyframe-6.png", "reference/keyframe-7.webp", "reference/Spin_Out_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 1, ATTACKER`, "ToggleSpriteVisibility ATTACKER, 3", `EmitProjectile ${SPA}, 5, STRAIGHT, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 9, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 4", "MoveCamera INTERPOLATION, INIT"],
});
const rollAt = CAMERA_IN + STARTUP + WIND;
console.log(`  wind f${CAMERA_IN + STARTUP}, roll f${rollAt}-${rollAt + ROLL}, ride-up f${rollAt + ROLL}`);
