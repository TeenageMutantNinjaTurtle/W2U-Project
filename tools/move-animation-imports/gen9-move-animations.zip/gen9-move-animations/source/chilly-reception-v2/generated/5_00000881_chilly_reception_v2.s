MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 875
AudioContainer CONTINUE
PlaySound 1475, SE1, 14, 0, 600, 90, 0, 0, 0
PlaySound 1509, SE2, 14, 2, 900, 100, 0, 0, 0
PlaySound 1509, SE2, 14, 10, 400, 90, 0, 0, 0
PlaySound 1497, SE1, 14, 30, -400, 110, 0, 0, 0
PlaySound 1376, SE1, 14, 78, 0, 0, 0, 0, 0
AudioContainer SUSPEND
Emit 875, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 875, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 875, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 875, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 3, 1, 1
Wait 26
MoveCamera INTERPOLATION, ZOOM_OUT_PERS, 16, 0, 0
ChangeBackgroundColor 4, 0, 8, 2, 16, 24, 31
Wait 16
Emit 875, 4, ATTACKER, NONE, 0, 0, 0, 1x, 1x, 1x, 1x
Emit 875, 5, ATTACKER, NONE, 0, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor ATTACKER, 0, 6, 2, 20, 26, 31
Wait 36
ChangeSpriteColor ATTACKER, 6, 0, 1, 20, 26, 31
ChangeBackgroundColor 4, 8, 0, 1, 16, 24, 31
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
