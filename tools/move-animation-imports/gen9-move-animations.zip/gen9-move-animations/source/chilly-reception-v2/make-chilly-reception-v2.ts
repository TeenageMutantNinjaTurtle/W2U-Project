import { createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Chilly Reception (move 881), v2 - from Bulbapedia's stills (reference/).
// The user tells a bad joke:
//   1. A party-popper burst of pastel puff clouds (pink, mint, yellow, cyan),
//      confetti and sparkle streaks.
//   2. Silence: a wide shot as cold wind gusts across the sky and the first
//      snowflakes drift down.
// v1 (../chilly-reception) is kept; reinstall its manifest to revert. The
// snow weather and the switch-out are handled by the engine.

const SPA = 875;
const kit = await createKit({ workDir: import.meta.dirname, slug: "chilly-reception-v2", moveId: 881, spaId: SPA, donors: [321, 498, 228, 411] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const PARTY = 26;
const WIDE = 16;
const CHILL = 36;

const BODY: Vec3 = [0, 0.4, 0.3];

const PINK: Rgb = [1.0, 0.7, 0.85];
const MINT: Rgb = [0.65, 1.0, 0.85];
const LEMON: Rgb = [1.0, 0.97, 0.6];
const SKY: Rgb = [0.6, 0.9, 1.0];
const WHITE: Rgb = [1, 1, 1];

// --- the joke ---
const puffs = kit.spray([333, 1], kit.tex(321, 5), BODY, { radius: 0.6, speed: 0.16, count: 5, bursts: 2, gap: 5, life: 22, scale: 1.0, shape: "ball" });
puffs.airResistance = 0.9;
spin(puffs, -0.05, 0.05, 0, true);
setCurves(puffs, grow(0.4, 0.2, 1.4), fadeInOut(0.85, 0.1, 0.55));
kit.prism(puffs, [PINK, MINT, LEMON]);
kit.add("puffs", puffs);

const puffsBlue = kit.spray([333, 1], kit.tex(321, 5), BODY, { radius: 0.7, speed: 0.13, count: 3, life: 20, scale: 0.9, shape: "ball" });
puffsBlue.startDelayFrames = 3;
puffsBlue.airResistance = 0.9;
setCurves(puffsBlue, grow(0.4, 0.2, 1.4), fadeInOut(0.85, 0.1, 0.55));
paint(puffsBlue, SKY, WHITE, SKY);
kit.add("puffsBlue", puffsBlue);

// Confetti: small flat squares tumbling up and fluttering down.
const confetti = kit.spray([333, 1], kit.tex(498, 1), BODY, { radius: 0.4, speed: 0.3, count: 6, bursts: 3, gap: 4, life: 26, scale: 0.13 });
confetti.aspectRatio = 0.55;
confetti.axis = [0, 1, 0];
confetti.initVelAxisAmplifier = 0.12;
confetti.behaviors = [{ type: "gravity", magnitude: [0, -0.012, 0] }];
confetti.airResistance = 0.94;
spin(confetti, -0.3, 0.3, 0, true);
setCurves(confetti, hold(1), fadeOut(1, 0.75));
kit.prism(confetti, [PINK, SKY, LEMON]);
kit.add("confetti", confetti);

const streaks = kit.spray([228, 3], kit.tex(411, 0), BODY, { radius: 0.4, speed: 0.6, count: 6, life: 8, scale: 1.2, directional: true });
streaks.startDelayFrames = 1;
setCurves(streaks, undefined, fadeOut());
paint(streaks, WHITE, WHITE, LEMON);
kit.add("streaks", streaks);

// --- the chill ---
// Cold gusts sweeping across the field: long white streaks moving sideways.
const gusts = kit.spray([228, 3], kit.tex(411, 0), [-4.0, 4.0, 0], { radius: 3.0, speed: 0, count: 1, bursts: 12, gap: 3, life: 14, scale: 3.0, shape: "ball", directional: true });
gusts.axis = [1, -0.12, 0];
gusts.initVelAxisAmplifier = 0.9;
setCurves(gusts, undefined, fadeInOut(0.5, 0.25, 0.6));
paint(gusts, WHITE, WHITE, SKY);
kit.add("gusts", gusts);

const snow = kit.spray([333, 1], kit.tex(333, 0), [0, 6.0, 0], { radius: 5.0, speed: 0, count: 1, bursts: 16, gap: 2, life: 30, scale: 0.12, shape: "ball" });
snow.axis = [0.2, -1, 0];
snow.initVelAxisAmplifier = 0.12;
setCurves(snow, undefined, fadeInOut(1, 0.15, 0.7));
paint(snow, WHITE);
kit.add("snow", snow);

const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1475, SE1, 14, 0, 600, 90, 0, 0, 0
PlaySound 1509, SE2, 14, 2, 900, 100, 0, 0, 0
PlaySound 1509, SE2, 14, 10, 400, 90, 0, 0, 0
PlaySound 1497, SE1, 14, ${PARTY + 4}, -400, 110, 0, 0, 0
PlaySound 1376, SE1, 14, ${PARTY + WIDE + CHILL}, 0, 0, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("puffs", "ATTACKER")}
${kit.emit("puffsBlue", "ATTACKER")}
${kit.emit("confetti", "ATTACKER")}
${kit.emit("streaks", "ATTACKER")}
ScaleSprite ATTACKER, ROUNDTRIP, 819, -819, 3, 1, 1
Wait ${PARTY}
MoveCamera INTERPOLATION, ZOOM_OUT_PERS, ${WIDE}, 0, 0
ChangeBackgroundColor 4, 0, 8, 2, 16, 24, 31
Wait ${WIDE}
${kit.emit("gusts", "ATTACKER", "NONE", "0")}
${kit.emit("snow", "ATTACKER", "NONE", "0")}
ChangeSpriteColor ATTACKER, 0, 6, 2, 20, 26, 31
Wait ${CHILL}
ChangeSpriteColor ATTACKER, 6, 0, 1, 20, 26, 31
ChangeBackgroundColor 4, 8, 0, 1, 16, 24, 31
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [153, 324, 63, 240],
  references: ["reference/Chilly_Reception_IX.png", "reference/Chilly_Reception_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, "MoveCamera INTERPOLATION, ZOOM_OUT_PERS", `Emit ${SPA}, 4, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  party f${CAMERA_IN}-${CAMERA_IN + PARTY}, chill f${CAMERA_IN + PARTY + WIDE}-${CAMERA_IN + PARTY + WIDE + CHILL}`);
