MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 868
AudioContainer CONTINUE
PlaySound 1509, SE2, 14, 0, 300, 100, 0, 0, 0
PlaySound 1430, SE1, 14, 22, 0, 127, 0, 0, 0
PlaySound 1430, SE2, 14, 28, 400, 120, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 12, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 2, 31, 26, 8
Emit 868, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 868, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 868, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 22
Emit 868, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 868, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 868, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor ATTACKER, 10, 16, 0, 31, 28, 14
ShakeScreen VERTICAL, 0.5x, 0, 1, 1, 3
Wait 4
ChangeSpriteColor ATTACKER, 16, 0, 2, 31, 28, 14
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
AudioContainer CONTINUE
PlaySound 1431, SE1, 16, 0, 0, 120, 0, 0, 0
PlaySound 1431, SE2, 16, 8, 400, 110, 0, 0, 0
PlaySound 1431, SE1, 16, 16, -300, 110, 0, 0, 0
PlaySound 1420, SE2, 16, 0, -300, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 868, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 868, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 868, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 31, 28, 12
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 14
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 6
Wait 6
ChangeSpriteColor DEFENDER, 12, 0, 2, 31, 28, 12
Wait 18
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
