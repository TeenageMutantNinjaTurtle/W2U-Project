import { aimed, assert, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Make It Rain (move 874) - from Bulbapedia's stills (reference/).
//   1. The user glows inside a pale gold bubble with radial light rays and
//      gold sparkles.
//   2. It flashes brilliant gold and a torrent of gold coins sprays and
//      showers everywhere, hitting the foe in white-gold sparkle bursts.
// 120 power: a big release, then coins rain on the foe.
//
// Coins are Pay Day's (SPA 170): its resource 1 spins a coin through four
// frames (face, narrow, edge, narrow). Each frame is remapped into this SPA
// so the spin survives. Pay Day's eight-point star and sparkle make the
// bursts.

const SPA = 868;
const kit = await createKit({ workDir: import.meta.dirname, slug: "make-it-rain", moveId: 874, spaId: SPA, donors: [170, 228, 298] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const GLOW = 22;
const SPRAY = 16;
const TRAVEL = 12;
const RAIN = 24;

const USER: Vec3 = [0, 0.2, -0.3];
const FOE: Vec3 = [0, 0.3, 0.8];

const GOLD: Rgb = [1.0, 0.82, 0.2];
const PALE_GOLD: Rgb = [1.0, 0.95, 0.7];
const WHITE: Rgb = [1, 1, 1];

// A spinning coin: Pay Day's coin resource with its four frames remapped.
function coins(pos: Vec3): ReturnType<typeof kit.shell> {
  const r = kit.shell(170, 1); // Pay Day res 1 spins the coin (frames 3-6, 12-frame loop)
  assert.ok(r.texAnim, "Pay Day's coin lost its spin animation");
  const frames = r.texAnim.textures.slice(0, r.texAnim.textureCount).map((t) => kit.tex(170, t));
  r.texAnim.textures = [...frames, 0, 0, 0, 0, 0, 0, 0, 0].slice(0, 8);
  r.textureIndex = frames[0]!;
  Object.assign(r, { emitterBasePos: [...pos], followEmitter: false, behaviors: [] });
  return r;
}

// --- the glow ---
const bubble = kit.parked(kit.tex(298, 0), USER, 2.0, GLOW + 4);
setCurves(bubble, grow(0.3, 0.3, 1.15), fadeInOut(0.5, 0.2, 0.85));
paint(bubble, PALE_GOLD, WHITE, GOLD);
kit.add("bubble", bubble);

const rays = kit.parked(kit.tex(228, 1), USER, 1.6, GLOW + 4);
spin(rays, 0.04);
setCurves(rays, grow(0.3, 0.4, 1.4), fadeInOut(0.85, 0.25, 0.85));
paint(rays, PALE_GOLD, WHITE, GOLD);
kit.add("rays", rays);

const sparkles = kit.spray([333, 1], kit.tex(170, 2), USER, { radius: 1.8, speed: 0.01, count: 1, bursts: 8, gap: 3, life: 10, scale: 0.35, shape: "ball" });
setCurves(sparkles, twinkle(1), twinkle(1));
paint(sparkles, WHITE, WHITE, GOLD);
kit.add("sparkles", sparkles);

// --- the release ---
const flash = kit.parked(kit.tex(228, 1), USER, 2.0, 10);
setCurves(flash, grow(0.6, 0.2, 2.2), fadeOut(1, 0.3));
paint(flash, WHITE, WHITE, PALE_GOLD);
kit.add("flash", flash);

// Coins sprayed at the foe with a wide spread, spinning as they fly.
const spray = coins(USER);
Object.assign(spray, { emissionType: 1, radius: 0.5, initVelPosAmplifier: 0.12, emissionCount: 1, emitterLifeFrames: SPRAY, emissionIntervalFrames: 1, particleLifeFrames: TRAVEL + 2, baseScale: 0.32, airResistance: 1.0 });
aimed(spray, 1.25, TRAVEL + 2);
kit.add("spray", spray);

// Coins thrown up and showering round the user.
const fountain = coins(USER);
Object.assign(fountain, { emissionType: 1, radius: 0.6, initVelPosAmplifier: 0.25, axis: [0, 1, 0], initVelAxisAmplifier: 0.25, emissionCount: 1, emitterLifeFrames: 8, emissionIntervalFrames: 1, particleLifeFrames: 20, baseScale: 0.3, airResistance: 0.98 });
fountain.behaviors = [{ type: "gravity", magnitude: [0, -0.025, 0] }];
kit.add("fountain", fountain);

// --- the rain on the foe ---
const rain = coins([0, 4.2, 0.8]);
Object.assign(rain, { emissionType: 4, radius: 1.8, initVelPosAmplifier: 0, axis: [0, -1, 0], initVelAxisAmplifier: 0.15, emissionCount: 1, emitterLifeFrames: RAIN - 6, emissionIntervalFrames: 1, particleLifeFrames: 16, baseScale: 0.3 });
rain.behaviors = [{ type: "gravity", magnitude: [0, -0.02, 0] }];
kit.add("rain", rain);

const burst = kit.shell(170, 2);
burst.textureIndex = kit.tex(170, 1);
Object.assign(burst, { emitterBasePos: [...FOE], emitterLifeFrames: RAIN - 8, emissionIntervalFrames: 4, emissionType: 4, radius: 0.9 });
paint(burst, WHITE, WHITE, GOLD);
kit.add("burst", burst);

const glints = kit.spray([333, 1], kit.tex(170, 2), FOE, { radius: 1.0, speed: 0.15, count: 2, bursts: 5, gap: 4, life: 10, scale: 0.35 });
setCurves(glints, twinkle(1), twinkle(1));
paint(glints, WHITE, WHITE, PALE_GOLD);
kit.add("glints", glints);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1509, SE2, 14, 0, 300, 100, 0, 0, 0
PlaySound 1430, SE1, 14, ${GLOW}, 0, 127, 0, 0, 0
PlaySound 1430, SE2, 14, ${GLOW + 6}, 400, 120, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 2, 31, 26, 8
${kit.emit("bubble", "ATTACKER")}
${kit.emit("rays", "ATTACKER")}
${kit.emit("sparkles", "ATTACKER")}
Wait ${GLOW}
${kit.emit("flash", "ATTACKER")}
${kit.emit("spray", "ATTACKER", "DEFENDER")}
${kit.emit("fountain", "ATTACKER")}
ChangeSpriteColor ATTACKER, 10, 16, 0, 31, 28, 14
ShakeScreen VERTICAL, 0.5x, 0, 1, 1, 3
Wait 4
ChangeSpriteColor ATTACKER, 16, 0, 2, 31, 28, 14
MoveCamera INTERPOLATION, DEFENDER, ${TRAVEL - 4}, 0, 8
Wait ${TRAVEL - 4}
AudioContainer CONTINUE
PlaySound 1431, SE1, 16, 0, 0, 120, 0, 0, 0
PlaySound 1431, SE2, 16, 8, 400, 110, 0, 0, 0
PlaySound 1431, SE1, 16, 16, -300, 110, 0, 0, 0
PlaySound 1420, SE2, 16, 0, -300, 110, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("rain", "DEFENDER")}
${kit.emit("burst", "DEFENDER")}
${kit.emit("glints", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 31, 28, 12
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 14
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 6
Wait 6
ChangeSpriteColor DEFENDER, 12, 0, 2, 31, 28, 12
Wait ${RAIN - 6}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

const { built } = await kit.finish({
  script,
  donorMoveIds: [6, 63, 129, 163],
  references: ["reference/Make_It_Rain_IX.png", "reference/Make_It_Rain_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, `Emit ${SPA}, 4, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 6, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
for (const name of ["spray", "fountain", "rain"]) {
  const t = built(name).texAnim!;
  assert.ok(t && t.textureCount >= 3 && new Set(t.textures.slice(0, t.textureCount)).size >= 3, `${name} coins do not spin through their frames`);
}
console.log(`  glow f${CAMERA_IN}-${CAMERA_IN + GLOW}, coins land f${CAMERA_IN + GLOW + TRAVEL}`);
