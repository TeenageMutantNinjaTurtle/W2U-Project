import { aimed, assert, createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Fickle Beam (move 907), v2 - from Logan's keyframes (shown in chat, not
// saved): "startup -> firing -> dealing damage to target".
//   1. Startup: a small golden orb forms in front of the user, long white
//      sparkle rays flashing out of it in a star, little gold arcs curling
//      round it and a tall thin ring of light standing round it.
//   2. Firing: a gold beam with a blazing head shoots at the foe, gold arcs
//      wrapped round it like ribs along its length, orange flecks flying.
//   3. Damage: the beam bursts on the foe in a white flash with white spiky
//      sparks and gold flecks.
// One animation serves both the normal and the "all out" versions.
// v1 (../fickle-beam, from the Bulbapedia stills) is kept; reinstall its
// manifest to revert.

const SPA = 935;
const kit = await createKit({ workDir: import.meta.dirname, slug: "fickle-beam-v2", moveId: 907, spaId: SPA, donors: [228, 298, 407, 465, 606, 579, 411, 321] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const GATHER = 26;
const BEAM_SPEED = 1.65;
const TRAVEL = 9;
const POUR = 14; // frames the beam is fired
const HIT_STOP = 4;
const HOLD = 18;

const ORB: Vec3 = [0.5, 0.5, -1.5];
const FOE: Vec3 = [0, 0.3, 0.8];

const GOLD: Rgb = [1.0, 0.82, 0.25];
const YELLOW: Rgb = [1.0, 0.95, 0.45];
const PALE: Rgb = [1.0, 0.98, 0.8];
const ORANGE: Rgb = [1.0, 0.55, 0.15];
const WHITE: Rgb = [1, 1, 1];

// --- 1. the orb ---
const ORB_LIFE = GATHER + POUR;
const halo = kit.parked(kit.tex(465, 1), ORB, 1.8, ORB_LIFE);
setCurves(halo, grow(0.2, 0.4, 1.1), fadeInOut(0.75, 0.25, 0.9));
paint(halo, GOLD, PALE, ORANGE);
kit.add("halo", halo);

const orb = kit.parked(kit.tex(298, 0), ORB, 0.8, ORB_LIFE);
setCurves(orb, { start: 0.1, mid: 1, end: 0.9, curveIn: 0.45, curveOut: 1 }, fadeInOut(1, 0.15, 0.9));
paint(orb, YELLOW, WHITE, GOLD);
kit.add("orb", orb);

// The sparkle: two four-point stars, one turned 45 degrees, pulsing.
const sparkle = (angle: number, scale: number, delay: number) => {
  const r = kit.parked(kit.tex(407, 1), ORB, scale, GATHER - delay);
  r.startDelayFrames = delay;
  r.initAngle = deg(angle);
  setCurves(r, { start: 0.2, mid: 1.2, end: 0.9, curveIn: 0.3, curveOut: 0.7 }, fadeInOut(1, 0.15, 0.85));
  paint(r, WHITE, WHITE, YELLOW);
  return r;
};
kit.add("sparkleA", sparkle(0, 1.5, 4));
kit.add("sparkleB", sparkle(45, 1.0, 8));

// A tall thin ring of light standing round the orb.
const tallRing = kit.parked(kit.tex(298, 2), ORB, 3.4, GATHER + 2);
tallRing.aspectRatio = 0.5;
tallRing.initAngle = deg(-8);
setCurves(tallRing, grow(0.4, 0.3, 1.08), fadeInOut(0.85, 0.2, 0.8));
paint(tallRing, PALE, WHITE, GOLD);
kit.add("tallRing", tallRing);

// Little gold arcs curling round the orb.
const curls = kit.spray([333, 1], kit.tex(606, 3), ORB, { radius: 0.5, speed: 0, count: 1, bursts: GATHER / 4, gap: 4, life: 9, scale: 0.55, shape: "ball" });
spin(curls, 0.35, 0.5, 0, true);
setCurves(curls, grow(0.5, 0.3, 1.1), fadeInOut(1, 0.2, 0.6));
kit.prism(curls, [GOLD, YELLOW, ORANGE]);
kit.add("curls", curls);

const motes = kit.spray([333, 1], kit.tex(333, 0), ORB, { radius: 2.0, speed: 0, count: 1, bursts: GATHER / 3, gap: 3, life: 10, scale: 0.13, shape: "sphere" });
motes.behaviors = [{ type: "convergence", target: [0, 0, 0], force: 0.12 }];
setCurves(motes, undefined, twinkle());
kit.prism(motes, [GOLD, WHITE, ORANGE]);
kit.add("motes", motes);

// --- 2. the beam ---
function stream(scale: number, colour: Rgb, start: Rgb): ReturnType<typeof kit.shell> {
  const r = kit.shell(228, 0);
  r.textureIndex = kit.tex(228, 1);
  aimed(r, BEAM_SPEED, TRAVEL + 1);
  Object.assign(r, { emitterBasePos: [...ORB], baseScale: scale, emitterLifeFrames: POUR, emissionIntervalFrames: 1, airResistance: 1.0 });
  setCurves(r, hold(1), hold(1));
  paint(r, colour, start, colour);
  return r;
}
kit.add("beam", stream(0.9, GOLD, YELLOW));
kit.add("core", stream(0.4, PALE, WHITE));

// The blazing head leading the beam.
const head = kit.parked(kit.tex(579, 2), ORB, 1.1, TRAVEL + 1);
aimed(head, BEAM_SPEED, TRAVEL + 1);
spin(head, 0.3);
setCurves(head, hold(1), hold(1));
paint(head, YELLOW, WHITE, GOLD);
kit.add("head", head);

// Gold arcs wrapped round the beam like ribs, riding along it.
const ribs = kit.spray([333, 1], kit.tex(606, 3), ORB, { radius: 0.15, speed: 0, count: 1, bursts: POUR / 2, gap: 2, life: TRAVEL + 1, scale: 1.2, shape: "ball" });
aimed(ribs, BEAM_SPEED, TRAVEL + 1);
ribs.airResistance = 1.0; // the spray shell's drag would stall them part-way
ribs.aspectRatio = 0.45;
spin(ribs, 0, 0, 0, true);
setCurves(ribs, grow(0.5, 0.25, 1.15), fadeInOut(1, 0.1, 0.85));
kit.prism(ribs, [GOLD, ORANGE, YELLOW]);
kit.add("ribs", ribs);

const muzzle = kit.spray([228, 3], kit.tex(321, 6), ORB, { radius: 0.3, speed: 0.4, count: 2, bursts: 4, gap: 3, life: 8, scale: 0.5, directional: true });
setCurves(muzzle, grow(1, 0.3, 0.6), fadeOut());
kit.prism(muzzle, [ORANGE, GOLD, YELLOW]);
kit.add("muzzle", muzzle);

// --- 3. the hit ---
const flash = kit.parked(kit.tex(228, 1), FOE, 1.9, 12);
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.2, 2.0), fadeOut(1, 0.35));
paint(flash, WHITE, WHITE, PALE);
kit.add("flash", flash);

const splinters = kit.spray([333, 1], kit.tex(579, 2), FOE, { radius: 0.5, speed: 0, count: 1, bursts: POUR / 4, gap: 4, life: 8, scale: 1.3, shape: "ball" });
spin(splinters, -0.12, 0.12, 0, true);
setCurves(splinters, grow(0.4, 0.3, 1.4), fadeOut(1, 0.4));
paint(splinters, WHITE, WHITE, YELLOW);
kit.add("splinters", splinters);

const whiteSparks = kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.3, speed: 0.6, count: 3, bursts: POUR / 4, gap: 4, life: 8, scale: 1.4, directional: true });
whiteSparks.axis = [0, -1, 0];
whiteSparks.initVelAxisAmplifier = 0.2;
setCurves(whiteSparks, undefined, fadeOut());
paint(whiteSparks, WHITE, WHITE, PALE);
kit.add("whiteSparks", whiteSparks);

const flecks = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.5, speed: 0.35, count: 2, bursts: POUR / 4, gap: 4, life: 12, scale: 0.13 });
flecks.behaviors = [{ type: "gravity", magnitude: [0, -0.012, 0] }];
setCurves(flecks, undefined, twinkle());
kit.prism(flecks, [GOLD, ORANGE, WHITE]);
kit.add("flecks", flecks);

// --- script ---
const emits = (names: string[], who: "ATTACKER" | "DEFENDER", toward = "NONE") => names.map((n) => kit.emit(n, who, toward)).join("\n");
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1418, PSG, 14, 0, 0, 110, 0, 0, 0
PlaySound 1509, SE1, 14, 4, 500, 105, 0, 0, 0
PlaySound 1509, SE1, 14, 8, 900, 95, 0, 0, 0
PlaySound 1816, SE2, 14, ${GATHER - 8}, 0, 110, 0, 0, 0
PlaySound 1376, PSG, 14, ${GATHER}, 0, 0, 0, 0, 0
AdjustSound PSG, 0, 0, 0, 3000, 0, 34, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${GATHER + TRAVEL}, 0, 50, 0, 0
PlaySound 1475, SE1, 16, ${GATHER + TRAVEL}, -200, 125, 0, 0, 0
PlaySound 1514, SE2, 16, ${GATHER + TRAVEL}, 300, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 2, 31, 28, 10
${emits(["halo", "orb", "tallRing", "sparkleA", "sparkleB", "curls", "motes"], "ATTACKER")}
Wait ${GATHER}
ChangeSpriteColor ATTACKER, 8, 0, 1, 31, 28, 10
${emits(["beam", "core", "head", "ribs"], "ATTACKER", "DEFENDER")}
${kit.emit("muzzle", "ATTACKER")}
MoveCamera INTERPOLATION, DEFENDER, ${TRAVEL}, 0, 8
Wait ${TRAVEL}
${emits(["flash", "splinters", "whiteSparks", "flecks"], "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 13, 0, 31, 30, 16
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 13, 0, 2, 31, 28, 10
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 0, ${Math.round((POUR - HIT_STOP) / 4) + 2}
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait ${POUR - HIT_STOP + HOLD}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

const { built } = await kit.finish({
  script,
  donorMoveIds: [63, 129, 427, 381, 400, 240],
  references: ["reference/Fickle_Beam_IX.png", "reference/Fickle_Beam_IX_2.png", "reference/Fickle_Beam_IX_All-Out.png", "reference/Fickle_Beam_IX_All-Out_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("sparkleA")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("beam")}, ATTACKER, DEFENDER`, `Emit ${SPA}, ${kit.idx("ribs")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("flash")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
assert.ok(built("beam").initVelAxisAmplifier * TRAVEL > 14, "Beam does not reach the foe");
console.log(`  orb f${CAMERA_IN}-${CAMERA_IN + GATHER}, beam f${CAMERA_IN + GATHER}-${CAMERA_IN + GATHER + POUR}, hit f${CAMERA_IN + GATHER + TRAVEL}`);
