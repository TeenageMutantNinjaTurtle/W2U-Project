MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 935
AudioContainer CONTINUE
PlaySound 1418, PSG, 14, 0, 0, 110, 0, 0, 0
PlaySound 1509, SE1, 14, 4, 500, 105, 0, 0, 0
PlaySound 1509, SE1, 14, 8, 900, 95, 0, 0, 0
PlaySound 1816, SE2, 14, 18, 0, 110, 0, 0, 0
PlaySound 1376, PSG, 14, 26, 0, 0, 0, 0, 0
AdjustSound PSG, 0, 0, 0, 3000, 0, 34, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 35, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 35, -200, 125, 0, 0, 0
PlaySound 1514, SE2, 16, 35, 300, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 2, 31, 28, 10
Emit 935, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 935, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 935, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 935, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 935, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 935, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 935, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 26
ChangeSpriteColor ATTACKER, 8, 0, 1, 31, 28, 10
Emit 935, 7, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 935, 8, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 935, 9, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 935, 10, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 935, 11, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveCamera INTERPOLATION, DEFENDER, 9, 0, 8
Wait 9
Emit 935, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 935, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 935, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 935, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 13, 0, 31, 30, 16
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 2, 31, 28, 10
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 0, 5
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 28
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
