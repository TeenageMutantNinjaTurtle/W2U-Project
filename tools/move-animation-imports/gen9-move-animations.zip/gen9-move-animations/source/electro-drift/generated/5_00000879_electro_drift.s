MoveCamera INTERPOLATION, ATTACKER, 14, 0, 8
LetCMDsFinish CAMERA
LoadSPA 873
AudioContainer CONTINUE
PlaySound 1759, PSG, 16, 0, 500, 60, 0, 0, 0
PlaySound 1710, SE1, 16, 8, 0, 110, 0, 0, 0
PlaySound 1424, SE2, 14, 26, 0, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 10, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 13, 1, 0, 1, 8
AdjustCamera INTERPOLATION_RELATIVE, 0, 0, 0, 0, 2px, 0, 18, 0, 20
Emit 873, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 873, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 873, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 873, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 26
Emit 873, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 873, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 12
Wait 10
AudioContainer CONTINUE
PlaySound 1710, SE1, 16, 0, 0, 127, 0, 0, 0
PlaySound 1475, SE2, 16, 0, -300, 120, 0, 0, 0
PlaySound 1514, SE1, 16, 8, 200, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 873, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 873, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 873, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 873, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 26, 30, 31
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 7
Wait 6
ChangeSpriteColor DEFENDER, 14, 0, 1, 26, 30, 31
Wait 20
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 13, 0, 1, 0, 1, 8
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
