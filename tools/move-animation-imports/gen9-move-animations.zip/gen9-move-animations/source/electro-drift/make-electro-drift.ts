import { aimed, assert, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Electro Drift (move 879) - from Bulbapedia's stills (reference/).
//   1. A glowing blue-violet electric oval: pale blue core, yellow lightning
//      crackling inside, a white rim.
//   2. A big white-blue blast on the foe: cyan lightning bolts zigzagging
//      out, a white star flash, electric sparks.
// Miraidon's counterpart to Collision Course, built the same way: the oval
// forms at the user, dives at the foe and bursts.
//
// Textures: Swift's soft disc (core), Lucky Chant's hoop (rim), Magma Storm's
// spiral (inner swirl), Electroweb's lightning squiggles (SPA 697, cycling
// through their four frames) for bolts, Hyper Beam's sunburst, Moonlight's
// star, Slash's dot. Thunder's sounds.

const SPA = 873;
const kit = await createKit({ workDir: import.meta.dirname, slug: "electro-drift", moveId: 879, spaId: SPA, donors: [298, 560, 643, 697, 228, 407] });

// --- timing (30 fps) ---
const CAMERA_IN = 14;
const CHARGE = 26;
const DIVE = 10;
const HOLD = 26;

const OVAL_POS: Vec3 = [0, 1.4, -0.8];
const FOE: Vec3 = [0, 0.3, 0.8];

const PALE_BLUE: Rgb = [0.7, 0.85, 1.0];
const BLUE_VIOLET: Rgb = [0.45, 0.45, 1.0];
const CYAN: Rgb = [0.4, 0.9, 1.0];
const YELLOW: Rgb = [1.0, 0.92, 0.35];
const VIOLET: Rgb = [0.65, 0.45, 1.0];
const WHITE: Rgb = [1, 1, 1];

// Lightning: Electroweb's squiggle cycling through its four frames.
function bolts(pos: Vec3, opts: Parameters<typeof kit.spray>[3], colours: [Rgb, Rgb, Rgb]): ReturnType<typeof kit.spray> {
  const r = kit.spray([333, 1], kit.tex(697, 0), pos, opts);
  r.texAnim = structuredClone(kit.spa(697).resources[0]!.texAnim);
  r.texAnim!.textures = r.texAnim!.textures.map((t, i) => (i < r.texAnim!.textureCount ? kit.tex(697, t) : 0));
  spin(r, 0, 0, 0, true);
  setCurves(r, hold(1), fadeOut(1, 0.6));
  r.loopFrames = 7;
  kit.prism(r, colours);
  return r;
}

// --- the oval ---
const core = kit.parked(kit.tex(298, 0), OVAL_POS, 2.0, CHARGE + 2);
core.aspectRatio = 0.65;
setCurves(core, grow(0.2, 0.3, 1.1), fadeInOut(0.85, 0.15, 0.95));
paint(core, PALE_BLUE, WHITE, BLUE_VIOLET);
kit.add("core", core);

const swirl = kit.parked(kit.tex(643, 3), OVAL_POS, 1.9, CHARGE + 2);
swirl.aspectRatio = 0.62;
spin(swirl, 0.2);
setCurves(swirl, grow(0.2, 0.3, 1.1), fadeInOut(0.8, 0.2, 0.95));
paint(swirl, BLUE_VIOLET, VIOLET, BLUE_VIOLET);
kit.add("swirl", swirl);

const rim = kit.parked(kit.tex(560, 1), OVAL_POS, 2.05, CHARGE + 2);
rim.aspectRatio = 0.65;
setCurves(rim, grow(0.2, 0.3, 1.1), fadeInOut(0.9, 0.15, 0.95));
paint(rim, WHITE, WHITE, PALE_BLUE);
kit.add("rim", rim);

kit.add("innerBolts", bolts(OVAL_POS, { radius: 0.9, speed: 0, count: 1, bursts: 9, gap: 3, life: 6, scale: 0.7, shape: "ball" }, [YELLOW, WHITE, YELLOW]));

// --- the dive ---
const diving = kit.parked(kit.tex(298, 0), OVAL_POS, 1.6, DIVE + 1);
diving.aspectRatio = 0.65;
aimed(diving, 1.6, DIVE + 1, 0.12);
setCurves(diving, hold(1), hold(0.9));
paint(diving, PALE_BLUE, WHITE, CYAN);
kit.add("diving", diving);

const divingRim = kit.parked(kit.tex(560, 1), OVAL_POS, 1.65, DIVE + 1);
divingRim.aspectRatio = 0.65;
aimed(divingRim, 1.6, DIVE + 1, 0.12);
setCurves(divingRim, hold(1), hold(1));
paint(divingRim, WHITE);
kit.add("divingRim", divingRim);

// --- the blast ---
const flash = kit.parked(kit.tex(228, 1), FOE, 1.8, 12);
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.25, 2.1), fadeOut(1, 0.35));
paint(flash, WHITE, WHITE, PALE_BLUE);
kit.add("flash", flash);

const star = kit.parked(kit.tex(407, 1), FOE, 1.4, 10);
spin(star, 0.05, 0.05, 0.4);
setCurves(star, grow(0.4, 0.25, 1.5), fadeOut(1, 0.35));
paint(star, WHITE, WHITE, CYAN);
kit.add("star", star);

kit.add("blastBolts", bolts(FOE, { radius: 1.2, speed: 0.15, count: 2, bursts: 5, gap: 3, life: 8, scale: 1.0, shape: "ball" }, [CYAN, WHITE, PALE_BLUE]));

const sparks = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.5, speed: 0.45, count: 8, life: 14, scale: 0.13 });
setCurves(sparks, undefined, twinkle());
kit.prism(sparks, [CYAN, VIOLET, WHITE]);
kit.add("sparks", sparks);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1759, PSG, 16, 0, 500, 60, 0, 0, 0
PlaySound 1710, SE1, 16, 8, 0, 110, 0, 0, 0
PlaySound 1424, SE2, 14, ${CHARGE}, 0, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${DIVE}, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 13, 1, 0, 1, 8
AdjustCamera INTERPOLATION_RELATIVE, 0, 0, 0, 0, 2px, 0, 18, 0, 20
${kit.emit("core", "ATTACKER")}
${kit.emit("swirl", "ATTACKER")}
${kit.emit("rim", "ATTACKER")}
${kit.emit("innerBolts", "ATTACKER")}
Wait ${CHARGE}
${kit.emit("diving", "ATTACKER", "DEFENDER")}
${kit.emit("divingRim", "ATTACKER", "DEFENDER")}
MoveCamera INTERPOLATION, DEFENDER, ${DIVE}, 0, 12
Wait ${DIVE}
AudioContainer CONTINUE
PlaySound 1710, SE1, 16, 0, 0, 127, 0, 0, 0
PlaySound 1475, SE2, 16, 0, -300, 120, 0, 0, 0
PlaySound 1514, SE1, 16, 8, 200, 110, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("flash", "DEFENDER")}
${kit.emit("star", "DEFENDER")}
${kit.emit("blastBolts", "DEFENDER")}
${kit.emit("sparks", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 26, 30, 31
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 7
Wait 6
ChangeSpriteColor DEFENDER, 14, 0, 1, 26, 30, 31
Wait ${HOLD - 6}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 13, 0, 1, 0, 1, 8
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

const { built } = await kit.finish({
  script,
  donorMoveIds: [129, 381, 463, 527, 63, 236, 163, 87],
  references: ["reference/Electro_Drift_IX.png", "reference/Electro_Drift_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, "ChangeBackgroundColor 4, 0, 13, 1, 0, 1, 8", `Emit ${SPA}, 0, ATTACKER`, `Emit ${SPA}, 4, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 6, DEFENDER`, "ShakeScreen VERTICAL, 1x", "MoveCamera INTERPOLATION, INIT"],
});
for (const name of ["innerBolts", "blastBolts"]) {
  assert.ok(built(name).texAnim?.loop && built(name).loopFrames === 7, `${name} lightning does not flicker`);
}
console.log(`  charge f${CAMERA_IN}-${CAMERA_IN + CHARGE}, dive ${DIVE}f, blast f${CAMERA_IN + CHARGE + DIVE}`);
