import assert from "node:assert/strict";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import {
  parseSpaArchive,
  serializeSpaArchive,
  type SpaArchive,
  type SpaResource,
  type SpaTexture,
} from "../../Pokeweb-Serverless/src/pokeweb/nitroSpa";

// Silk Trap (move 852) - from Bulbapedia's still (reference/Silk_Trap_IX.png).
//
// What the still shows: a translucent mint-green protect bubble in front of
// the user, a dense white spider web spun across the middle of it, and loose
// white silk threads looping and swirling round the outside of the bubble.
// The order here: strands shoot out, the bubble rises, the threads wrap it,
// the web spins in, everything holds, then fades.
//
// Donors:
//   SPA 340 Spider Web   - texture: the spider web (a 4-colour palette
//                          texture, white lines, so a white tint keeps it white).
//   SPA 770 Sticky Web   - texture: thin concentric rings, squashed into tilted
//                          ellipses for the silk loops.
//   SPA 249 String Shot  - texture: the thin thread streak (shooting strands).
//   SPA 352 Protect      - res 0: Protect's own regular ring of twinkling dots,
//                          recoloured mint and parked on the bubble's rim.
//   SPA 298 Swift        - texture: soft disc (the bubble).
//   SPA 606 Psycho Cut   - res 0 (held disc): shell for every parked layer.
//   SPA 333 Slash        - res 1: particles thrown off a sphere (the strands).

const WORK_DIR = import.meta.dirname;
const OUT_DIR = path.join(WORK_DIR, "generated");
const DONOR_DIR = path.join(WORK_DIR, "../silk-trap-donors");

const MOVE_ID = 852;
const OUTPUT_SPA_ID = 846;

const OUT_SCRIPT = path.join(OUT_DIR, `5_${String(MOVE_ID).padStart(8, "0")}_silk_trap.s`);
const OUT_SPA = path.join(OUT_DIR, `6_${String(OUTPUT_SPA_ID).padStart(8, "0")}.bin`);

type Rgb = [number, number, number];
type Vec3 = [number, number, number];

// --- timing (30 fps) ---------------------------------------------------------
const CAMERA_IN = 16;
const STRANDS_TO_BUBBLE = 4; // strands shoot out first
const BUBBLE_TO_LOOPS = 2;
const LOOPS_TO_WEB = 4;
const SHIELD_LIFE = 54; // bubble on screen, rise to fade
const RISE = 8; // bubble / loops / web scale in over this many frames
const WEB_SPIN_IN = 12; // web spins in, then settles
const FADE = 10; // everything fades over its last frames
const WEB_LIFE = SHIELD_LIFE - BUBBLE_TO_LOOPS - LOOPS_TO_WEB;
const LOOP_LIFE = SHIELD_LIFE - BUBBLE_TO_LOOPS;
const WEB_DONE = STRANDS_TO_BUBBLE + BUBBLE_TO_LOOPS + LOOPS_TO_WEB + WEB_SPIN_IN; // from the first emit

// --- placement ---------------------------------------------------------------
// In front of the user, toward the foe, at mid-body: where Protect's shield sits.
const SHIELD: Vec3 = [0, 0.2, -1.4];
const BUBBLE_SCALE = 1.9;

// --- palette -----------------------------------------------------------------
const MINT: Rgb = [0.55, 1.0, 0.78];
const MINT_DEEP: Rgb = [0.3, 0.9, 0.62];
const PALE_MINT: Rgb = [0.85, 1.0, 0.92];
const WHITE: Rgb = [1, 1, 1];
const SILK: Rgb = [0.95, 1.0, 0.97];

await mkdir(OUT_DIR, { recursive: true });

const load = async (name: string) => parseSpaArchive(new Uint8Array(await readFile(path.join(DONOR_DIR, name))));
const spiderWeb = await load("spa_340.spa");
const stickyWeb = await load("spa_770.spa");
const stringShot = await load("spa_249.spa");
const protect = await load("spa_352.spa");
const swift = await load("spa_298.spa");
const psychoCut = await load("spa_606.spa");
const slash = await load("spa_333.spa");
assert.equal(spiderWeb.resources.length, 3, "Unexpected Spider Web SPA");
assert.equal(protect.resources.length, 2, "Unexpected Protect SPA");

// --- texture table -----------------------------------------------------------

const TEX = { disc: 0, rings: 1, web: 2, thread: 3, dot: 4 } as const;
const TEXTURE_SOURCES: Array<{ donor: SpaArchive; index: number; label: string; format: number }> = [
  { donor: swift, index: 0, label: "soft disc", format: 6 },
  { donor: stickyWeb, index: 2, label: "thin concentric rings", format: 6 },
  { donor: spiderWeb, index: 1, label: "spider web", format: 3 },
  { donor: stringShot, index: 1, label: "thread streak", format: 6 },
  { donor: protect, index: 0, label: "Protect's glow dot", format: 6 },
];
assert.equal(TEXTURE_SOURCES.length, Object.keys(TEX).length, "Texture table and index map disagree");
const textures: SpaTexture[] = TEXTURE_SOURCES.map((source, index) => {
  const texture = source.donor.textures[source.index];
  assert.ok(texture, `Donor texture ${source.index} (${source.label}) is missing`);
  assert.equal(texture.useSharedTexture, false, `Texture ${source.label} is shared`);
  assert.equal(texture.format, source.format, `Texture ${source.label} changed format`);
  const clone = structuredClone(texture);
  clone.index = index;
  return clone;
});

// --- builders ----------------------------------------------------------------

interface Curve3 { start: number; mid: number; end: number; curveIn: number; curveOut: number }

function retexture(resource: SpaResource, textureIndex: number): void {
  resource.textureIndex = textureIndex;
  if (resource.texAnim) resource.texAnim.textures = resource.texAnim.textures.map(() => textureIndex);
  delete resource.childResource;
}

function setCurves(resource: SpaResource, scale: Curve3 | undefined, alpha: Curve3): void {
  assert.ok(resource.alphaAnim, "Donor shell lost its alpha curve");
  if (scale) {
    assert.ok(resource.scaleAnim, "Donor shell lost its scale curve");
    Object.assign(resource.scaleAnim, scale, { loop: false });
  }
  Object.assign(resource.alphaAnim, alpha, { loop: false });
  resource.loopFrames = 1;
}

function paint(resource: SpaResource, base: Rgb, start: Rgb, end: Rgb, peak = 0.3): void {
  assert.ok(resource.colorAnim, "Donor shell lost its colour curve");
  resource.color = [...base];
  Object.assign(resource.colorAnim, { start: [...start], end: [...end], curveIn: 0, curvePeak: peak, curveOut: 1, interpolate: true, loop: false, randomStartColor: false });
}

function spin(resource: SpaResource, min: number, max = min, startAngle = 0, randomStart = false): void {
  resource.hasRotation = min !== 0 || max !== 0;
  resource.minRotation = min;
  resource.maxRotation = max;
  resource.randomInitAngle = randomStart;
  resource.initAngle = startAngle;
}

/** One parked billboard on Psycho Cut's held disc: no emission shape, no motion. */
function parked(textureIndex: number, pos: Vec3, scale: number, life: number): SpaResource {
  const resource = structuredClone(psychoCut.resources[0]!);
  retexture(resource, textureIndex);
  Object.assign(resource, {
    emissionType: 0, emissionAxis: 0, radius: 0, axis: [0, 1, 0],
    initVelAxisAmplifier: 0, initVelPosAmplifier: 0, airResistance: 1.0,
    followEmitter: false, behaviors: [], emitterBasePos: [...pos],
    baseScale: scale, aspectRatio: 1, particleLifeFrames: life,
    emitterLifeFrames: 1, emissionCount: 1, emissionIntervalFrames: 1, startDelayFrames: 0,
  });
  spin(resource, 0);
  return resource;
}

// Rise over RISE frames, hold, fade over the last FADE frames.
const rise = (life: number, from = 0.3, to = 1): Curve3 => ({ start: from, mid: to, end: to, curveIn: RISE / life, curveOut: 1 });
const holdThenFade = (life: number, level: number): Curve3 => ({ start: 0, mid: level, end: 0, curveIn: (RISE / life) * 0.6, curveOut: 1 - FADE / life });

// --- the strands -------------------------------------------------------------
// String Shot's thread streak shot out radially from the shield's centre to
// its rim: the web's spokes being spun, just before everything else appears.
const strands = structuredClone(slash.resources[1]!);
retexture(strands, TEX.thread);
Object.assign(strands, {
  drawType: 1, emissionType: 1, emissionAxis: 0, radius: 0.2, emitterBasePos: [...SHIELD], axis: [0, 1, 0],
  initVelAxisAmplifier: 0, initVelPosAmplifier: 0.3, airResistance: 0.9, followEmitter: false, behaviors: [],
  emissionCount: 8, emitterLifeFrames: 1, emissionIntervalFrames: 1, particleLifeFrames: 9, baseScale: 0.9, aspectRatio: 0.12, startDelayFrames: 0,
});
setCurves(strands, { start: 0.4, mid: 1, end: 1.2, curveIn: 0.4, curveOut: 0.6 }, { start: 1, mid: 1, end: 0, curveIn: 0, curveOut: 0.5 });
paint(strands, SILK, WHITE, PALE_MINT);

// --- the bubble --------------------------------------------------------------

// Translucent mint sphere: under half strength so the user shows through.
const bubble = parked(TEX.disc, SHIELD, BUBBLE_SCALE, SHIELD_LIFE);
setCurves(bubble, rise(SHIELD_LIFE), holdThenFade(SHIELD_LIFE, 0.42));
paint(bubble, MINT, PALE_MINT, MINT_DEEP);

// Its rim: faint concentric rings at the bubble's edge.
const rim = parked(TEX.rings, SHIELD, BUBBLE_SCALE * 1.05, SHIELD_LIFE);
setCurves(rim, rise(SHIELD_LIFE), holdThenFade(SHIELD_LIFE, 0.6));
paint(rim, PALE_MINT, WHITE, MINT);

// Protect's twinkling dots, parked on the rim and coloured mint. Protect lays
// them on an evenly spaced ring, which with two per emission puts every pair
// at the same top and bottom points; a random point on the circle instead
// scatters them all round the rim.
const sparkles = structuredClone(protect.resources[0]!);
retexture(sparkles, TEX.dot);
assert.equal(sparkles.emissionType, 3, "Protect's dots are no longer a regular ring");
Object.assign(sparkles, {
  emissionType: 2, emissionAxis: 0,
  emitterBasePos: [...SHIELD], radius: BUBBLE_SCALE * 0.92, axis: [0, 1, 0], initVelAxisAmplifier: 0, initVelPosAmplifier: 0.01,
  emitterLifeFrames: SHIELD_LIFE - FADE - 18, emissionCount: 2, emissionIntervalFrames: 3, particleLifeFrames: 18, baseScale: 0.45, startDelayFrames: RISE,
});
assert.ok(sparkles.colorAnim, "Protect's dots lost their colour curve");
sparkles.color = [...MINT];
Object.assign(sparkles.colorAnim, { start: [...WHITE], end: [...MINT_DEEP] });

// --- the silk loops ----------------------------------------------------------
// Thin rings squashed into ellipses at random tilts, slowly turning: loose
// silk threads wrapping round the bubble. Two widths so they don't all match.
function loops(aspect: number, scale: number, rates: [number, number]): SpaResource {
  const resource = parked(TEX.rings, SHIELD, scale, LOOP_LIFE);
  resource.aspectRatio = aspect;
  resource.emissionCount = 2;
  spin(resource, rates[0], rates[1], 0, true);
  setCurves(resource, rise(LOOP_LIFE, 0.4), holdThenFade(LOOP_LIFE, 0.9));
  paint(resource, SILK, WHITE, SILK);
  return resource;
}
const loopsNarrow = loops(0.38, BUBBLE_SCALE * 1.12, [-0.05, -0.02]);
const loopsWide = loops(0.62, BUBBLE_SCALE * 1.18, [0.02, 0.05]);

// --- the web -----------------------------------------------------------------
// Spider Web's web across the middle of the bubble: it spins in from nothing
// over WEB_SPIN_IN frames. The roll can't decelerate, so it turns slowly
// throughout, which reads as the web settling.
const web = parked(TEX.web, SHIELD, BUBBLE_SCALE * 0.68, WEB_LIFE);
spin(web, 0.025, 0.025, -Math.PI / 2);
setCurves(web, { start: 0, mid: 1, end: 1, curveIn: WEB_SPIN_IN / WEB_LIFE, curveOut: 1 }, holdThenFade(WEB_LIFE, 1));
paint(web, WHITE, WHITE, WHITE);

// --- archive -----------------------------------------------------------------

const RES = { strands: 0, bubble: 1, rim: 2, sparkles: 3, loopsNarrow: 4, loopsWide: 5, web: 6 } as const;
const resources = [strands, bubble, rim, sparkles, loopsNarrow, loopsWide, web];
assert.equal(resources.length, Object.keys(RES).length, "Resource table and index map disagree");
resources.forEach((resource, index) => {
  resource.index = index;
  assert.ok(resource.textureIndex < textures.length, `Resource ${index} texture index out of range`);
  assert.equal(resource.childResource, undefined, `Resource ${index} kept a donor child`);
});

const archive: SpaArchive = { resourceCount: resources.length, textureCount: textures.length, resources, textures, warnings: [], rawHeader: psychoCut.rawHeader?.slice() };
const spaBytes = serializeSpaArchive(archive);
await writeFile(OUT_SPA, spaBytes);

// --- round-trip checks -------------------------------------------------------

const reparsed = parseSpaArchive(spaBytes);
const built = (index: number) => reparsed.resources[index]!;
const close = (got: readonly number[], want: readonly number[], tol = 0.04) => got.every((v, i) => Math.abs(v - want[i]!) <= tol);
const show = (v: readonly number[]) => `[${v.map((c) => c.toFixed(2)).join(",")}]`;
assert.equal(reparsed.resources.length, resources.length, "Resource count changed on round-trip");
assert.equal(reparsed.textures[TEX.web]!.format, 3, "Web texture lost its palette format");
for (const [index, resource] of reparsed.resources.entries()) {
  assert.equal(resource.textureIndex, resources[index]!.textureIndex, `Resource ${index} texture index drifted`);
  assert.ok(close(resource.emitterBasePos, SHIELD), `Layer ${index} sits at ${show(resource.emitterBasePos)}, off the shield`);
}
assert.ok(built(RES.bubble).alphaAnim!.mid < 0.5, "Bubble is opaque; the user would not show through it");
assert.ok(built(RES.bubble).color[1] > 0.9 && built(RES.bubble).color[0] < 0.7, `Bubble is ${show(built(RES.bubble).color)}, not mint`);
assert.ok(built(RES.web).color.every((c) => c > 0.95), "Web is not white");
assert.ok(built(RES.web).scaleAnim!.start === 0 && built(RES.web).scaleAnim!.mid === 1, "Web does not spin in from nothing");
assert.ok(built(RES.web).baseScale < built(RES.bubble).baseScale, "Web is bigger than the bubble");
for (const index of [RES.loopsNarrow, RES.loopsWide]) {
  assert.ok(built(index).aspectRatio < 0.7 && built(index).randomInitAngle, `Loops ${index} are not tilted ellipses`);
  assert.ok(built(index).baseScale > built(RES.bubble).baseScale, `Loops ${index} sit inside the bubble`);
}
assert.ok(built(RES.loopsNarrow).maxRotation < 0 && built(RES.loopsWide).minRotation > 0, "Loops do not turn against each other");
assert.equal(built(RES.strands).drawType, 1, "Strands are not directional billboards");

// --- move script -------------------------------------------------------------

const emit = (res: number) => `Emit ${OUTPUT_SPA_ID}, ${res}, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x`;

const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${OUTPUT_SPA_ID}
AudioContainer CONTINUE
PlaySound 1410, SE1, 14, 0, 300, 110, 0, 0, 0
PlaySound 1471, SE2, 14, ${STRANDS_TO_BUBBLE}, 0, 115, 0, 0, 0
PlaySound 1358, SE2, 14, ${STRANDS_TO_BUBBLE + 20}, 0, 80, 0, 0, 0
PlaySound 1708, SE1, 14, ${WEB_DONE}, 0, 110, 0, 0, 0
AudioContainer SUSPEND
${emit(RES.strands)}
Wait ${STRANDS_TO_BUBBLE}
${emit(RES.bubble)}
${emit(RES.rim)}
${emit(RES.sparkles)}
Wait ${BUBBLE_TO_LOOPS}
${emit(RES.loopsNarrow)}
${emit(RES.loopsWide)}
Wait ${LOOPS_TO_WEB}
${emit(RES.web)}
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await writeFile(OUT_SCRIPT, script, "utf8");

const first = CAMERA_IN;
console.log(`Wrote ${OUT_SPA} (${spaBytes.length} bytes, ${resources.length} resources, ${textures.length} textures)`);
console.log(`  strands f${first}, bubble f${first + STRANDS_TO_BUBBLE}, loops f${first + STRANDS_TO_BUBBLE + BUBBLE_TO_LOOPS}, web f${first + STRANDS_TO_BUBBLE + BUBBLE_TO_LOOPS + LOOPS_TO_WEB} (set f${first + WEB_DONE}), shield gone f${first + STRANDS_TO_BUBBLE + SHIELD_LIFE}`);
console.log(`Wrote ${OUT_SCRIPT}`);
