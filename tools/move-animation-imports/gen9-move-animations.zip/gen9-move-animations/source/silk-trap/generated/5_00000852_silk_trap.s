MoveCamera INTERPOLATION, ATTACKER, 16, 0, 8
LetCMDsFinish CAMERA
LoadSPA 846
AudioContainer CONTINUE
PlaySound 1410, SE1, 14, 0, 300, 110, 0, 0, 0
PlaySound 1471, SE2, 14, 4, 0, 115, 0, 0, 0
PlaySound 1358, SE2, 14, 24, 0, 80, 0, 0, 0
PlaySound 1708, SE1, 14, 22, 0, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 846, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 4
Emit 846, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 846, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 846, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 2
Emit 846, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 846, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 4
Emit 846, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
