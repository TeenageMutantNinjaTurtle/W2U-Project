MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 887
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -900, 120, 0, 0, 0
PlaySound 1759, PSG, 14, 4, 900, 50, 0, 0, 0
PlaySound 1435, SE2, 14, 10, -300, 110, 0, 0, 0
PlaySound 1435, SE2, 14, 24, 200, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 8, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 1, 6, 0, 2
ChangeSpriteColor ATTACKER, 0, 10, 2, 20, 2, 6
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 10
Emit 887, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 887, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 887, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 887, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 24
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 10, 0, 1, 20, 2, 6
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
AudioContainer CONTINUE
PlaySound 1514, SE1, 16, 0, -300, 125, 0, 0, 0
PlaySound 1420, SE2, 16, 0, -400, 120, 0, 0, 0
PlaySound 1514, SE2, 16, 5, 200, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 887, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 887, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 887, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 887, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 887, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 887, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 887, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 31, 6, 8
Wait 5
ChangeSpriteColor DEFENDER, 12, 0, 1, 31, 6, 8
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 17
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 8, 0, 1, 6, 0, 2
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
