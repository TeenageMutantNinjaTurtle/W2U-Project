import { createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Comeuppance (move 894), v2 - from Bulbapedia's stills (reference/).
//   1. Crimson streaks whirl round the user, magenta-pink lightning crackling
//      and red and violet flecks flying.
//   2. On the foe, a dome of curved red-white streaks arches round a yellow
//      and orange burst with spiky yellow points.
// v1 (../comeuppance, Logan's slash design) is kept; reinstall its manifest
// to revert.
//
// Drawn here: a fan of concentric, slightly spiralling arcs (64x64 a5i3 white
// mask; generated/texture-arcs.png). It spins as the whirl on the user and
// sits as the dome on the foe. Electroweb's squiggles (SPA 697) are the
// crackles.

const SPA = 887;
const kit = await createKit({ workDir: import.meta.dirname, slug: "comeuppance-v2", moveId: 894, spaId: SPA, donors: [697, 228, 579, 465, 411] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const BRACE = 24;
const DASH = 8;
const HIT_STOP = 5;
const HOLD = 22;

const USER: Vec3 = [0, 0.3, 0.2];
const FOE: Vec3 = [0, 0.3, 0.8];
const DOME: Vec3 = [0, 0.1, 0.8];

const CRIMSON: Rgb = [1.0, 0.18, 0.3];
const RED: Rgb = [0.9, 0.08, 0.15];
const PINK: Rgb = [1.0, 0.55, 0.65];
const MAGENTA: Rgb = [1.0, 0.35, 0.95];
const VIOLET: Rgb = [0.65, 0.3, 1.0];
const ORANGE: Rgb = [1.0, 0.5, 0.15];
const YELLOW: Rgb = [1.0, 0.9, 0.3];
const WHITE: Rgb = [1, 1, 1];

// --- the drawn arcs ---
// Six arcs over the top half round (32, 40): each spans its own angle range,
// spirals outward a little along its length and tapers at both ends.
const arcs = [
  { r: 12, from: 0.35, to: 2.6 },
  { r: 16, from: 0.2, to: 2.9 },
  { r: 19.5, from: 0.5, to: 2.75 },
  { r: 23, from: 0.15, to: 2.5 },
  { r: 26.5, from: 0.4, to: 2.95 },
  { r: 29.5, from: 0.25, to: 2.7 },
];
const arcsTex = await kit.drawn("arcs", 64, 64, "a5i3", (x, y) => {
  const dx = x + 0.5 - 32;
  const dy = 40 - (y + 0.5);
  const rr = Math.hypot(dx, dy);
  const a = Math.atan2(dy, dx);
  let alpha = 0;
  for (const arc of arcs) {
    if (a < arc.from || a > arc.to) continue;
    const t = (a - arc.from) / (arc.to - arc.from);
    const target = arc.r + 2.2 * t;
    const width = 0.6 + 1.0 * Math.sin(Math.PI * t);
    const d = Math.abs(rr - target);
    if (d < width) alpha = Math.max(alpha, Math.min(1, (1 - d / width) * 1.6) * Math.min(1, Math.sin(Math.PI * t) * 2.5));
  }
  return alpha > 0.06 ? [255, 255, 255, Math.round(alpha * 255)] : undefined;
});

function crackles(pos: Vec3, opts: Parameters<typeof kit.spray>[3], colours: [Rgb, Rgb, Rgb]): ReturnType<typeof kit.spray> {
  const r = kit.spray([333, 1], kit.tex(697, 0), pos, opts);
  r.texAnim = structuredClone(kit.spa(697).resources[0]!.texAnim);
  r.texAnim!.textures = r.texAnim!.textures.map((t, i) => (i < r.texAnim!.textureCount ? kit.tex(697, t) : 0));
  spin(r, 0, 0, 0, true);
  setCurves(r, hold(1), fadeOut(1, 0.6));
  r.loopFrames = 7;
  kit.prism(r, colours);
  return r;
}

// --- the whirl on the user ---
function whirl(scale: number, rate: number, delay: number, colour: Rgb, start: Rgb, level: number): ReturnType<typeof kit.parked> {
  const r = kit.parked(arcsTex, USER, scale, BRACE - delay + 4);
  r.startDelayFrames = delay;
  spin(r, rate, rate, 0, true);
  setCurves(r, grow(0.5, 0.3, 1.15), fadeInOut(level, 0.15, 0.7));
  paint(r, colour, start, colour);
  return r;
}
kit.add("whirlA", whirl(3.0, 0.24, 0, CRIMSON, PINK, 1));
kit.add("whirlB", whirl(2.3, -0.3, 6, RED, CRIMSON, 0.85));

kit.add("userCrackles", crackles(USER, { radius: 1.7, speed: 0, count: 1, bursts: 7, gap: 3, life: 6, scale: 0.55, shape: "ball" }, [MAGENTA, PINK, VIOLET]));

const flecks = kit.spray([333, 1], kit.tex(333, 0), USER, { radius: 1.2, speed: 0.08, count: 2, bursts: 6, gap: 3, life: 12, scale: 0.14, shape: "ball" });
setCurves(flecks, undefined, twinkle());
kit.prism(flecks, [RED, CRIMSON, VIOLET]);
kit.add("flecks", flecks);

// --- the hit ---
function dome(scale: number, angle: number, colour: Rgb, start: Rgb, level: number, life: number): ReturnType<typeof kit.parked> {
  const r = kit.parked(arcsTex, DOME, scale, life);
  r.initAngle = angle;
  spin(r, 0.02, 0.02, angle);
  setCurves(r, grow(0.45, 0.25, 1.15), fadeOut(level, 0.4));
  paint(r, colour, start, colour);
  return r;
}
kit.add("domeOuter", dome(4.0, 0, CRIMSON, WHITE, 1, 16));
kit.add("domeInner", dome(3.0, 0.25, PINK, WHITE, 0.9, 14));

const sun = kit.parked(kit.tex(465, 1), FOE, 1.7, 14);
setCurves(sun, grow(0.4, 0.2, 1.4), fadeOut(1, 0.4));
paint(sun, ORANGE, YELLOW, RED);
kit.add("sun", sun);

const flash = kit.parked(kit.tex(228, 1), FOE, 1.5, 12);
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.2, 1.9), fadeOut(1, 0.35));
paint(flash, YELLOW, WHITE, ORANGE);
kit.add("flash", flash);

const points = kit.spray([333, 1], kit.tex(579, 2), FOE, { radius: 0.9, speed: 0.04, count: 5, life: 10, scale: 0.5 });
spin(points, 0, 0, 0, true);
setCurves(points, grow(0.4, 0.3, 1.2), fadeOut(1, 0.4));
kit.prism(points, [YELLOW, WHITE, ORANGE]);
kit.add("points", points);

const streaks = kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.5, speed: 0.6, count: 7, life: 9, scale: 2.0, directional: true });
setCurves(streaks, undefined, fadeOut());
kit.prism(streaks, [CRIMSON, PINK, RED]);
kit.add("streaks", streaks);

kit.add("foeCrackles", crackles(FOE, { radius: 1.4, speed: 0.08, count: 1, bursts: 4, gap: 3, life: 6, scale: 0.6, shape: "ball" }, [MAGENTA, PINK, VIOLET]));

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -900, 120, 0, 0, 0
PlaySound 1759, PSG, 14, 4, 900, 50, 0, 0, 0
PlaySound 1435, SE2, 14, 10, -300, 110, 0, 0, 0
PlaySound 1435, SE2, 14, ${BRACE}, 200, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${DASH}, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 1, 6, 0, 2
ChangeSpriteColor ATTACKER, 0, 10, 2, 20, 2, 6
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 10
${kit.emit("whirlA", "ATTACKER")}
${kit.emit("whirlB", "ATTACKER")}
${kit.emit("userCrackles", "ATTACKER")}
${kit.emit("flecks", "ATTACKER")}
Wait ${BRACE}
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 10, 0, 1, 20, 2, 6
MoveCamera INTERPOLATION, DEFENDER, ${DASH}, 0, 8
Wait ${DASH}
AudioContainer CONTINUE
PlaySound 1514, SE1, 16, 0, -300, 125, 0, 0, 0
PlaySound 1420, SE2, 16, 0, -400, 120, 0, 0, 0
PlaySound 1514, SE2, 16, ${HIT_STOP}, 200, 110, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("domeOuter", "DEFENDER")}
${kit.emit("domeInner", "DEFENDER")}
${kit.emit("sun", "DEFENDER")}
${kit.emit("flash", "DEFENDER")}
${kit.emit("points", "DEFENDER")}
${kit.emit("streaks", "DEFENDER")}
${kit.emit("foeCrackles", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 31, 6, 8
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 12, 0, 1, 31, 6, 8
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait ${HOLD - HIT_STOP}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 8, 0, 1, 6, 0, 2
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [400, 527, 63, 605],
  references: ["reference/Comeuppance_IX.png", "reference/Comeuppance_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 4, DEFENDER`, "ShakeScreen VERTICAL, 1x", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  brace f${CAMERA_IN}-${CAMERA_IN + BRACE}, hit f${CAMERA_IN + BRACE + DASH}`);
