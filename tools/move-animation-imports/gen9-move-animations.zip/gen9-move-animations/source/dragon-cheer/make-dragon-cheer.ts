import { assert, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Dragon Cheer (move 913) - from Bulbapedia's stills (reference/).
//   1. Dragon energy erupts round the user: violet spikes burst up at its
//      feet, a great purple vortex of rings whirls up behind it with violet
//      lightning crackling, shards flying.
//   2. Its ally is wrapped in a glowing white-gold sphere, streaks of light
//      rising through it.
// Second pass (Logan, 2026-10-01: "I want the animation to look more like
// the user is 'cheering' or making a noise that encourages the target"):
// after the vortex builds, the user hops three times and calls out; each
// call sends a ring of sound across to the ally with shout lines bursting
// from the user, and the ally's sphere pulses as each one arrives.
// It targets the ally, so the ally is the script's DEFENDER; a wide shot
// keeps both in view. (In a single battle the move fails before animating.)

const SPA = 906;
const kit = await createKit({ workDir: import.meta.dirname, slug: "dragon-cheer", moveId: 913, spaId: SPA, donors: [697, 228, 321, 465, 606, 560, 411, 298, 605, 212] });

// --- timing (30 fps) ---
const WIDE = 16;
const ROAR = 18; // the vortex builds
const CALLS = 3;
const CALL_GAP = 10;
const TRAVEL = CALL_GAP; // a call's crossing to the ally
const SHOUT = CALLS * CALL_GAP;
const CHEER = (CALLS - 1) * CALL_GAP + 26; // the ally's sphere, from the first call's arrival

const USER: Vec3 = [0, 0.3, 0.2];
const FEET: Vec3 = [0, -1.5, 0.2];
const VORTEX: Vec3 = [0.6, 1.6, 0.6];
const ALLY: Vec3 = [0, 0.3, 0.6];
const MOUTH: Vec3 = [0.3, 1.0, -0.4];

const VIOLET: Rgb = [0.65, 0.3, 1.0];
const MAGENTA: Rgb = [0.95, 0.4, 1.0];
const DEEP: Rgb = [0.35, 0.1, 0.65];
const PALE_VIOLET: Rgb = [0.9, 0.78, 1.0];
const GOLD: Rgb = [1.0, 0.88, 0.55];
const WARM_WHITE: Rgb = [1.0, 0.97, 0.88];
const WHITE: Rgb = [1, 1, 1];

// --- the roar ---
const spikes = kit.spray([228, 3], kit.tex(321, 6), FEET, { radius: 1.1, speed: 0.1, count: 3, bursts: 5, gap: 3, life: 10, scale: 0.85, shape: "circle", directional: true });
spikes.emissionAxis = 1;
spikes.axis = [0, 1, 0];
spikes.initVelAxisAmplifier = 0.24;
setCurves(spikes, grow(0.5, 0.3, 1.2), fadeOut(1, 0.45));
kit.prism(spikes, [VIOLET, MAGENTA, PALE_VIOLET]);
kit.add("spikes", spikes);

const vortex = (tex: number, scale: number, rate: number, delay: number, colour: Rgb, start: Rgb, level: number) => {
  const r = kit.parked(tex, VORTEX, scale, ROAR + SHOUT - delay + 4);
  r.startDelayFrames = delay;
  spin(r, rate);
  setCurves(r, grow(0.3, 0.35, 1.15), fadeInOut(level, 0.15, 0.75));
  paint(r, colour, start, colour);
  return r;
};
kit.add("vortexGlow", (() => {
  const r = kit.parked(kit.tex(465, 1), VORTEX, 3.6, ROAR + SHOUT + 4);
  setCurves(r, grow(0.3, 0.35, 1.1), fadeInOut(0.6, 0.2, 0.75));
  paint(r, DEEP, VIOLET, DEEP);
  return r;
})());
kit.add("vortexSwirl", vortex(kit.tex(228, 3), 2.8, -0.25, 2, MAGENTA, WHITE, 0.95));
kit.add("vortexRings", vortex(kit.tex(606, 0), 2.2, 0.18, 5, PALE_VIOLET, WHITE, 0.85));

const crackle = kit.spray([333, 1], kit.tex(697, 0), VORTEX, { radius: 1.6, speed: 0, count: 1, bursts: (ROAR + SHOUT) / 4, gap: 4, life: 6, scale: 0.7, shape: "ball" });
crackle.texAnim = structuredClone(kit.spa(697).resources[0]!.texAnim);
crackle.texAnim!.textures = crackle.texAnim!.textures.map((t, i) => (i < crackle.texAnim!.textureCount ? kit.tex(697, t) : 0));
spin(crackle, 0, 0, 0, true);
setCurves(crackle, hold(1), fadeOut(1, 0.6));
crackle.loopFrames = 7;
kit.prism(crackle, [VIOLET, WHITE, MAGENTA]);
kit.add("crackle", crackle);

const shards = kit.spray([228, 3], kit.tex(465, 3), USER, { radius: 0.8, speed: 0.35, count: 2, bursts: 5, gap: 4, life: 10, scale: 0.6, directional: true });
setCurves(shards, grow(0.8, 0.3, 0.6), fadeOut());
kit.prism(shards, [VIOLET, MAGENTA, PALE_VIOLET]);
kit.add("shards", shards);

// --- the calls ---
// Each call: a ring of sound riding across to the ally (an EmitProjectile
// emitter, so it arrives whatever the distance), swelling as it goes.
function callRing(texIndex: number, scale: number, colour: Rgb, start: Rgb): ReturnType<typeof kit.shell> {
  const r = kit.shell(605, 0);
  assert.ok(r.followEmitter, "Mud Bomb's ball no longer follows its emitter");
  r.textureIndex = texIndex;
  Object.assign(r, { particleLifeFrames: TRAVEL + 1, baseScale: scale });
  setCurves(r, { start: 0.35, mid: 0.8, end: 1.3, curveIn: 0.4, curveOut: 0.5 }, undefined); // Mud Bomb's rider has no alpha curve
  paint(r, colour, start, colour);
  return r;
}
kit.add("callRing", callRing(kit.tex(212, 0), 1.3, MAGENTA, WHITE));
kit.add("callRingGold", callRing(kit.tex(560, 1), 1.0, GOLD, WHITE));

// Shout lines bursting from the user's mouth on each call.
const shout = kit.spray([228, 3], kit.tex(411, 0), MOUTH, { radius: 0.4, speed: 0.5, count: 5, bursts: CALLS, gap: CALL_GAP, life: 6, scale: 1.3, shape: "circle", directional: true });
setCurves(shout, undefined, fadeOut(1, 0.4));
kit.prism(shout, [WHITE, PALE_VIOLET, GOLD]);
kit.add("shout", shout);

const mouthPulse = kit.spray([333, 1], kit.tex(212, 0), MOUTH, { radius: 0, speed: 0, count: 1, bursts: CALLS, gap: CALL_GAP, life: 8, scale: 1.0, shape: "point" });
setCurves(mouthPulse, grow(0.3, 0.5, 1.5), fadeOut(0.9, 0.3));
kit.prism(mouthPulse, [MAGENTA, PALE_VIOLET, WHITE]);
kit.add("mouthPulse", mouthPulse);

// The ally's sphere pulses as each call arrives.
const allyPulse = kit.spray([333, 1], kit.tex(560, 1), ALLY, { radius: 0, speed: 0, count: 1, bursts: CALLS, gap: CALL_GAP, life: 9, scale: 2.4, shape: "point" });
setCurves(allyPulse, grow(0.5, 0.6, 1.3), fadeOut(0.9, 0.3));
paint(allyPulse, GOLD, WHITE, WARM_WHITE);
kit.add("allyPulse", allyPulse);

// --- the cheer on the ally ---
const sphere = kit.parked(kit.tex(560, 1), ALLY, 2.6, CHEER);
setCurves(sphere, { start: 0.3, mid: 1, end: 1.05, curveIn: 0.25, curveOut: 1 }, fadeInOut(0.75, 0.15, 0.75));
paint(sphere, WARM_WHITE, WHITE, GOLD);
kit.add("sphere", sphere);

const inner = kit.parked(kit.tex(465, 1), ALLY, 3.0, CHEER);
setCurves(inner, { start: 0.3, mid: 1, end: 1.05, curveIn: 0.25, curveOut: 1 }, fadeInOut(0.55, 0.15, 0.75));
paint(inner, GOLD, WHITE, WARM_WHITE);
kit.add("inner", inner);

const rise = kit.spray([228, 3], kit.tex(411, 0), [0, -1.2, 0.6], { radius: 1.2, speed: 0, count: 1, bursts: CHEER / 3, gap: 3, life: 9, scale: 1.0, shape: "circle", directional: true });
rise.emissionAxis = 1;
rise.axis = [0, 1, 0];
rise.initVelAxisAmplifier = 0.3;
setCurves(rise, undefined, fadeInOut(1, 0.2, 0.6));
kit.prism(rise, [WHITE, GOLD, WARM_WHITE]);
kit.add("rise", rise);

const glints = kit.spray([333, 1], kit.tex(298, 1), ALLY, { radius: 1.4, speed: 0, count: 1, bursts: CHEER / 5, gap: 5, life: 10, scale: 0.3, shape: "ball" });
setCurves(glints, twinkle(1), twinkle(1));
kit.prism(glints, [WHITE, GOLD, PALE_VIOLET]);
kit.add("glints", glints);

// --- script ---
const ride = (name: string) => `EmitProjectile ${SPA}, ${kit.idx(name)}, STRAIGHT, ATTACKER, DEFENDER, 2px, ${TRAVEL}f, 0, 1x, 1x, 0`;
// One call: the user hops and a ring of sound sets off for the ally.
const call = ["ScaleSprite ATTACKER, ROUNDTRIP, -410, 819, 3, 0, 1", "ShakeSprite ATTACKER, 2, 0, 1229, 3, 0, 1", ride("callRing"), ride("callRingGold"), `Wait ${CALL_GAP}`];
// The ally's sphere appears as the first call arrives (a call takes CALL_GAP frames to cross).
const allyLights = [...["inner", "sphere", "allyPulse", "rise", "glints"].map((n) => kit.emit(n, "DEFENDER")), "ChangeSpriteColor DEFENDER, 0, 10, 2, 31, 29, 22"];
const calls = Array.from({ length: CALLS }, (_, i) => (i === 0 ? [...call, ...allyLights] : call)).flat().join("\n");
const callSounds = Array.from({ length: CALLS }, (_, i) => [
  `PlaySound 1864, SE${i % 2 ? 2 : 1}, 16, ${ROAR + i * CALL_GAP}, ${200 + i * 200}, ${100 + i * 8}, 0, 0, 0`,
  `PlaySound 1509, SE${i % 2 ? 1 : 2}, 14, ${ROAR + TRAVEL + i * CALL_GAP}, ${500 + i * 200}, 100, 0, 0, 0`,
]).flat().join("\n");
const script = `MoveCamera INTERPOLATION, ZOOM_OUT_PERS, ${WIDE}, 0, 0
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -300, 115, 0, 0, 0
PlaySound 1759, PSG, 14, 6, -200, 50, 0, 0, 0
PlaySound 1435, SE2, 14, 8, 300, 105, 0, 0, 0
${callSounds}
PlaySound 1784, SE2, 14, ${ROAR + SHOUT + 4}, 300, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 2, 20, 10, 31
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 3, 0, 1
${kit.emit("spikes", "ATTACKER")}
${kit.emit("vortexGlow", "ATTACKER")}
${kit.emit("vortexSwirl", "ATTACKER")}
${kit.emit("vortexRings", "ATTACKER")}
${kit.emit("crackle", "ATTACKER")}
${kit.emit("shards", "ATTACKER")}
Wait ${ROAR}
${kit.emit("shout", "ATTACKER")}
${kit.emit("mouthPulse", "ATTACKER")}
${calls}
ChangeSpriteColor ATTACKER, 10, 0, 2, 20, 10, 31
Wait ${CHEER - (CALLS - 1) * CALL_GAP - 10}
ChangeSpriteColor DEFENDER, 10, 0, 2, 31, 29, 22
Wait 10
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [349, 527, 63, 153, 427, 560, 400],
  references: ["reference/Dragon_Cheer_IX.png", "reference/Dragon_Cheer_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveCamera INTERPOLATION, ZOOM_OUT_PERS", `Emit ${SPA}, 0, ATTACKER`, `EmitProjectile ${SPA}, ${kit.idx("callRing")}, STRAIGHT, ATTACKER, DEFENDER`, `Emit ${SPA}, ${kit.idx("sphere")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  vortex f${WIDE}, calls f${WIDE + ROAR}/+${CALL_GAP}/+${2 * CALL_GAP} (arrive ${TRAVEL}f later), ally sphere f${WIDE + ROAR + TRAVEL}-${WIDE + ROAR + TRAVEL + CHEER}`);
