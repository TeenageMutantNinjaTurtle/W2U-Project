MoveCamera INTERPOLATION, ZOOM_OUT_PERS, 16, 0, 0
LetCMDsFinish CAMERA
LoadSPA 906
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -300, 115, 0, 0, 0
PlaySound 1759, PSG, 14, 6, -200, 50, 0, 0, 0
PlaySound 1435, SE2, 14, 8, 300, 105, 0, 0, 0
PlaySound 1864, SE1, 16, 18, 200, 100, 0, 0, 0
PlaySound 1509, SE2, 14, 28, 500, 100, 0, 0, 0
PlaySound 1864, SE2, 16, 28, 400, 108, 0, 0, 0
PlaySound 1509, SE1, 14, 38, 700, 100, 0, 0, 0
PlaySound 1864, SE1, 16, 38, 600, 116, 0, 0, 0
PlaySound 1509, SE2, 14, 48, 900, 100, 0, 0, 0
PlaySound 1784, SE2, 14, 52, 300, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 2, 20, 10, 31
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 3, 0, 1
Emit 906, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 906, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 906, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 906, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 906, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 906, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 18
Emit 906, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 906, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, -410, 819, 3, 0, 1
ShakeSprite ATTACKER, 2, 0, 1229, 3, 0, 1
EmitProjectile 906, 6, STRAIGHT, ATTACKER, DEFENDER, 2px, 10f, 0, 1x, 1x, 0
EmitProjectile 906, 7, STRAIGHT, ATTACKER, DEFENDER, 2px, 10f, 0, 1x, 1x, 0
Wait 10
Emit 906, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 906, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 906, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 906, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 906, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor DEFENDER, 0, 10, 2, 31, 29, 22
ScaleSprite ATTACKER, ROUNDTRIP, -410, 819, 3, 0, 1
ShakeSprite ATTACKER, 2, 0, 1229, 3, 0, 1
EmitProjectile 906, 6, STRAIGHT, ATTACKER, DEFENDER, 2px, 10f, 0, 1x, 1x, 0
EmitProjectile 906, 7, STRAIGHT, ATTACKER, DEFENDER, 2px, 10f, 0, 1x, 1x, 0
Wait 10
ScaleSprite ATTACKER, ROUNDTRIP, -410, 819, 3, 0, 1
ShakeSprite ATTACKER, 2, 0, 1229, 3, 0, 1
EmitProjectile 906, 6, STRAIGHT, ATTACKER, DEFENDER, 2px, 10f, 0, 1x, 1x, 0
EmitProjectile 906, 7, STRAIGHT, ATTACKER, DEFENDER, 2px, 10f, 0, 1x, 1x, 0
Wait 10
ChangeSpriteColor ATTACKER, 10, 0, 2, 20, 10, 31
Wait 16
ChangeSpriteColor DEFENDER, 10, 0, 2, 31, 29, 22
Wait 10
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
