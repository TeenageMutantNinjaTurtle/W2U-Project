import { buildTorque } from "../tools/torque-v2";

// Magical Torque (move 900), v2 - from Bulbapedia's stills (reference/).
//   1. Shimmering cyan, white and pink light streams up round the Starmobile.
//   2. A pink swirl on the ground round the foe, pink and yellow spikes
//      fanning up and little stars scattering.
// Shared structure in ../tools/torque-v2.ts. v1 is in ../magical-torque.
const CYAN: [number, number, number] = [0.45, 0.95, 1.0];
const PINK: [number, number, number] = [1.0, 0.5, 0.85];
const MAGENTA: [number, number, number] = [0.95, 0.3, 0.8];
const YELLOW: [number, number, number] = [1.0, 0.9, 0.35];
const WHITE: [number, number, number] = [1, 1, 1];

await buildTorque({
  workDir: import.meta.dirname, slug: "magical-torque-v2", moveId: 900, spaId: 893,
  references: ["reference/Magical_Torque_IX.png", "reference/Magical_Torque_IX_2.png"],
  aura: [CYAN, WHITE, PINK], rising: "flame",
  vortex: [PINK, WHITE, MAGENTA],
  fan: [PINK, YELLOW, WHITE],
  core: [YELLOW, WHITE, PINK],
  extra: "stars", extraColours: [PINK, CYAN, YELLOW],
  userTint: [20, 30, 31], foeTint: [31, 20, 28],
  revSounds: ["PlaySound 1783, SE2, 14, 4, 0, 100, 0, 0, 0"],
  hitSounds: ["PlaySound 1816, SE2, 16, 0, 300, 120, 0, 0, 0", "PlaySound 1509, SE1, 16, 4, 600, 100, 0, 0, 0"],
});
