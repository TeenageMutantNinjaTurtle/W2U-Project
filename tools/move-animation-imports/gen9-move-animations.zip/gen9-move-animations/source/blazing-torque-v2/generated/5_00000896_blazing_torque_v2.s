MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 889
AudioContainer CONTINUE
PlaySound 1487, SE1, 14, 0, 500, 70, 0, 0, 0
PlaySound 1487, SE1, 14, 12, 900, 80, 0, 0, 0
PlaySound 1425, SE2, 14, 6, 0, 110, 0, 0, 0
PlaySound 1536, SE2, 14, 24, 0, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 8, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 2, 31, 16, 4
Emit 889, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 889, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 889, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 13
Wait 26
ChangeSpriteColor ATTACKER, 10, 0, 1, 31, 16, 4
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
AudioContainer CONTINUE
PlaySound 1420, SE1, 16, 0, -300, 125, 0, 0, 0
PlaySound 1426, SE2, 16, 0, 0, 125, 0, 0, 0
PlaySound 1864, SE1, 16, 4, 200, 100, 0, 0, 0
AudioContainer SUSPEND
Emit 889, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 889, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 889, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 889, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 889, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 889, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 889, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 31, 14, 4
Wait 4
ChangeSpriteColor DEFENDER, 12, 0, 1, 31, 14, 4
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 18
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
