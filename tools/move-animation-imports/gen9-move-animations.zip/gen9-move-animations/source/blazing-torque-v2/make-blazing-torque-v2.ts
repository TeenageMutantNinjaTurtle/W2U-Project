import { buildTorque } from "../tools/torque-v2";

// Blazing Torque (move 896), v2 - from Bulbapedia's stills (reference/).
//   1. Flames lick up all round the Starmobile; yellow sparks skitter off the ground.
//   2. A flattened orange-yellow fire vortex on the ground round the foe, a
//      crown of flame spikes fanning up out of it.
// Shared structure in ../tools/torque-v2.ts. v1 is in ../blazing-torque.
const ORANGE: [number, number, number] = [1.0, 0.5, 0.1];
const YELLOW: [number, number, number] = [1.0, 0.88, 0.3];
const RED: [number, number, number] = [0.95, 0.25, 0.08];
const PALE: [number, number, number] = [1.0, 0.97, 0.75];

await buildTorque({
  workDir: import.meta.dirname, slug: "blazing-torque-v2", moveId: 896, spaId: 889,
  references: ["reference/Blazing_Torque_IX.png", "reference/Blazing_Torque_IX_2.png"],
  aura: [ORANGE, YELLOW, RED], rising: "flame",
  vortex: [ORANGE, YELLOW, RED],
  fan: [YELLOW, ORANGE, PALE],
  core: [YELLOW, PALE, ORANGE],
  extra: "flames", extraColours: [ORANGE, YELLOW, RED],
  userTint: [31, 16, 4], foeTint: [31, 14, 4],
  revSounds: ["PlaySound 1425, SE2, 14, 6, 0, 110, 0, 0, 0"],
  hitSounds: ["PlaySound 1426, SE2, 16, 0, 0, 125, 0, 0, 0", "PlaySound 1864, SE1, 16, 4, 200, 100, 0, 0, 0"],
});
