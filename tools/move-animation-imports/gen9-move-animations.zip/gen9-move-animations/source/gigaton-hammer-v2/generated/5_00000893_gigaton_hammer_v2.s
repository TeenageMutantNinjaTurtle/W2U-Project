MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 933
AudioContainer CONTINUE
PlaySound 1560, SE1, 14, 0, 0, 120, 0, 0, 0
PlaySound 1509, SE2, 14, 2, -300, 100, 0, 0, 0
PlaySound 1421, SE2, 14, 9, -300, 100, 0, 0, 0
PlaySound 1421, SE2, 14, 20, -100, 110, 0, 0, 0
PlaySound 1421, SE1, 16, 34, -600, 120, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 3, 26, 28, 31
Emit 933, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 933, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 933, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 933, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 933, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 933, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 933, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 26
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 3, 0, 1
Wait 6
ChangeSpriteColor ATTACKER, 10, 0, 1, 26, 28, 31
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 3
Emit 933, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 933, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 5
AudioContainer CONTINUE
PlaySound 1413, SE1, 16, 0, -300, 127, 0, 0, 0
PlaySound 1884, SE2, 16, 0, 0, 127, 0, 0, 0
PlaySound 1442, SE2, 16, 8, -400, 120, 0, 0, 0
PlaySound 1475, SE1, 16, 8, -700, 120, 0, 0, 0
AudioContainer SUSPEND
Emit 933, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 933, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 933, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 933, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 933, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 933, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 933, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 933, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeBackgroundColor 4, 0, 12, 0, 31, 31, 31
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 31, 31
ShakeScreen VERTICAL, 1x, 0, 1, 0, 4
Wait 8
ChangeBackgroundColor 4, 12, 0, 1, 31, 31, 31
ChangeSpriteColor DEFENDER, 14, 0, 1, 31, 31, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 4, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 14
ShakeScreen VERTICAL, 2458, 0, 2, 0, 10
Wait 32
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
