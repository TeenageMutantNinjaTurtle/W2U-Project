import { createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Gigaton Hammer (move 893), v2 - from Logan's keyframes (shown in chat, not
// saved) and brief: "the user gain a steel spirit radiate them -> where it
// brings down the large hammer, breaking apart the ground and causing chunks
// of rock to fly from the target".
//   1. A steel spirit radiates from the user: white wind bands whirl flat
//      round it, tall white light spikes shoot up all round, steel-white
//      rings pulse outward and it glows silver.
//   2. The great hammer comes down on the foe.
//   3. The ground breaks: a jagged dark fissure opens under the foe, slabs of
//      grey-blue rock jut up round it, big rock chunks fly out, orange-yellow
//      streaks shoot up, cyan shards and tan dust burst.
// 160 power: a long hit-stop, a white flash and the heaviest shake.
// v1 (../gigaton-hammer, from the Bulbapedia stills) is kept; reinstall its
// manifest to revert.
//
// Drawn here (a3i5, see generated/): the steel mallet (64x64, as v1) and a
// rock chunk (32x32: a faceted boulder, pale grey top, blue-grey side, navy
// shadow, dark outline).

const SPA = 933;
const kit = await createKit({ workDir: import.meta.dirname, slug: "gigaton-hammer-v2", moveId: 893, spaId: SPA, donors: [228, 321, 298, 411, 465, 579] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const SPIRIT = 32;
const SWING = 8; // camera to the foe while the hammer comes down
const DROP = 5;
const HIT_STOP = 8;
const HOLD = 32;

const USER: Vec3 = [0, 0.2, 0.2];
const USER_FLOOR: Vec3 = [0, -1.5, 0.2];
const FOE: Vec3 = [0, 0.3, 0.8];
const FOE_FLOOR: Vec3 = [0, -1.6, 0.8];
const DROP_HEIGHT = 4.2;

const WHITE: Rgb = [1, 1, 1];
const PALE_BLUE: Rgb = [0.85, 0.92, 1.0];
const STEEL: Rgb = [0.72, 0.8, 0.95];
const TAN: Rgb = [0.95, 0.85, 0.62];
const SAND: Rgb = [0.85, 0.72, 0.5];
const ORANGE: Rgb = [1.0, 0.55, 0.15];
const YELLOW: Rgb = [1.0, 0.85, 0.3];
const CYAN: Rgb = [0.35, 0.8, 1.0];
const FISSURE: Rgb = [0.12, 0.13, 0.24];

// --- drawn textures ---
type P = [number, number];
const inPoly = (x: number, y: number, poly: P[]) => {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i]!;
    const [xj, yj] = poly[j]!;
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
};

// The mallet (v1's): a drum head with rims on a short handle.
const hammerTex = await kit.drawn("hammer", 64, 64, "a3i5", (x, y) => {
  const px = x + 0.5;
  const py = y + 0.5;
  const R = 7;
  const cx = Math.max(6 + R, Math.min(58 - R, px));
  const cy = Math.max(6 + R, Math.min(40 - R, py));
  const inHead = px >= 6 && px <= 58 && py >= 6 && py <= 40 && Math.hypot(px - cx, py - cy) <= R;
  if (inHead) {
    const edge = px < 7.5 || px > 56.5 || py < 7.5 || py > 38.5 || Math.hypot(px - cx, py - cy) > R - 1.5;
    if (edge) return [70, 72, 104];
    const v = (py - 6) / 34; // 0 top .. 1 bottom
    const rim = px < 13 || px > 51;
    if (rim) return v < 0.25 ? [250, 250, 255] : v < 0.6 ? [208, 212, 232] : [140, 142, 176];
    if (v < 0.14) return [214, 218, 238];
    if (v < 0.3) return [252, 252, 255];
    if (v < 0.55) return [184, 186, 214];
    if (v < 0.8) return [146, 146, 182];
    return [110, 108, 146];
  }
  if (px >= 28.5 && px <= 35.5 && py > 40 && py <= 62) {
    if (px < 29.8 || px > 34.2) return [70, 66, 96];
    return px < 31.5 ? [196, 190, 220] : [140, 132, 170];
  }
  return undefined;
});

// A rock chunk: an angular boulder in three facets round an off-centre peak.
const rock: P[] = [[4, 13], [13, 3], [25, 5], [30, 17], [22, 29], [9, 27]];
const peak: P = [15, 13];
const rockFacets: Array<{ poly: P[]; colour: number[] }> = [
  { poly: [rock[0]!, rock[1]!, rock[2]!, peak], colour: [228, 234, 246] },
  { poly: [rock[2]!, rock[3]!, rock[4]!, peak], colour: [142, 154, 190] },
  { poly: [rock[4]!, rock[5]!, rock[0]!, peak], colour: [58, 64, 104] },
];
const rockTex = await kit.drawn("rock", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5;
  const py = y + 0.5;
  if (!inPoly(px, py, rock)) return undefined;
  const d = 1.2;
  if (!inPoly(px - d, py, rock) || !inPoly(px + d, py, rock) || !inPoly(px, py - d, rock) || !inPoly(px, py + d, rock)) return [30, 34, 64];
  return rockFacets.find((f) => inPoly(px, py, f.poly))?.colour ?? rockFacets[1]!.colour;
});

// --- 1. the steel spirit ---
const swirlRing = (scale: number, delay: number, level: number) => {
  const r = kit.parked(kit.tex(228, 3), USER_FLOOR, scale, SPIRIT - delay + 4);
  r.aspectRatio = 3.0;
  r.startDelayFrames = delay;
  setCurves(r, grow(0.3, 0.35, 1.15), fadeInOut(level, 0.15, 0.7));
  paint(r, WHITE, PALE_BLUE, WHITE);
  return r;
};
kit.add("swirlOuter", swirlRing(2.6, 0, 0.9));
kit.add("swirlInner", swirlRing(1.9, 6, 0.75));

const aura = kit.parked(kit.tex(465, 1), USER, 3.2, SPIRIT + 2);
setCurves(aura, grow(0.4, 0.3, 1.2), fadeInOut(0.7, 0.2, 0.85));
paint(aura, PALE_BLUE, WHITE, STEEL);
kit.add("aura", aura);

// Steel-white rings pulsing outward from its body.
const pulses = kit.spray([333, 1], kit.tex(298, 2), USER, { radius: 0, speed: 0, count: 1, bursts: 4, gap: 7, life: 13, scale: 2.6, shape: "point" });
setCurves(pulses, grow(0.25, 0.7, 1.2), fadeOut(0.9, 0.4));
paint(pulses, WHITE, WHITE, STEEL);
kit.add("pulses", pulses);

const whirl = kit.spray([333, 1], kit.tex(333, 2), [0, -1.2, 0.2], { radius: 2.0, speed: 0, count: 2, bursts: SPIRIT / 3, gap: 3, life: 8, scale: 0.9, shape: "circle", directional: true });
whirl.emissionAxis = 1;
whirl.behaviors = [{ type: "spin", axis: 1, angle: 0.55 }];
setCurves(whirl, undefined, fadeOut(1, 0.4));
paint(whirl, WHITE, WHITE, PALE_BLUE);
kit.add("whirl", whirl);

// Tall light spikes shooting up all round the ring.
const lightSpikes = kit.spray([228, 3], kit.tex(321, 6), USER_FLOOR, { radius: 2.3, speed: 0, count: 2, bursts: SPIRIT / 3, gap: 3, life: 9, scale: 1.1, shape: "circle", directional: true });
lightSpikes.emissionAxis = 1;
lightSpikes.axis = [0, 1, 0];
lightSpikes.initVelAxisAmplifier = 0.38;
lightSpikes.startDelayFrames = 3;
setCurves(lightSpikes, grow(0.4, 0.3, 1.3), fadeOut(1, 0.4));
paint(lightSpikes, WHITE, WHITE, PALE_BLUE);
kit.add("lightSpikes", lightSpikes);

const glints = kit.spray([333, 1], kit.tex(298, 1), USER, { radius: 2.4, speed: 0.01, count: 1, bursts: 7, gap: 4, life: 10, scale: 0.3, shape: "ball" });
setCurves(glints, twinkle(1), twinkle(1));
paint(glints, WHITE);
kit.add("glints", glints);

// --- 2. the slam ---
const hammer = kit.parked(hammerTex, [FOE[0], FOE[1] + DROP_HEIGHT, FOE[2]], 3.0, DROP);
hammer.axis = [0, -1, 0];
hammer.initVelAxisAmplifier = DROP_HEIGHT / DROP;
spin(hammer, deg(-6), deg(-6), deg(30));
setCurves(hammer, hold(1), hold(1));
paint(hammer, WHITE);
kit.add("hammer", hammer);

const blur = kit.spray([228, 3], kit.tex(411, 0), [FOE[0], FOE[1] + DROP_HEIGHT * 0.6, FOE[2]], { radius: 1.2, speed: 0, count: 3, bursts: DROP, gap: 1, life: 5, scale: 2.4, shape: "circle", directional: true });
blur.axis = [0, -1, 0];
blur.initVelAxisAmplifier = 0.9;
setCurves(blur, undefined, fadeInOut(0.8, 0.2, 0.5));
paint(blur, WHITE, WHITE, PALE_BLUE);
kit.add("blur", blur);

const slammed = kit.parked(hammerTex, [FOE[0], FOE[1] + 0.6, FOE[2]], 3.0, HIT_STOP + 8);
setCurves(slammed, hold(1), fadeOut(1, 0.6));
paint(slammed, WHITE);
kit.add("slammed", slammed);

// --- 3. the ground breaks ---
const flash = kit.parked(kit.tex(228, 1), FOE, 2.0, 14);
spin(flash, 0.05);
setCurves(flash, grow(0.4, 0.2, 2.4), fadeOut(1, 0.35));
paint(flash, WHITE, WHITE, YELLOW);
kit.add("flash", flash);

// A jagged dark fissure splitting the ground under the foe.
const fissure = kit.parked(kit.tex(579, 2), [0, -1.7, 0.9], 2.2, HIT_STOP + HOLD - 6);
fissure.aspectRatio = 3.0;
setCurves(fissure, { start: 0.2, mid: 1, end: 1.1, curveIn: 0.12, curveOut: 1 }, fadeInOut(0.9, 0.05, 0.7));
paint(fissure, FISSURE);
kit.add("fissure", fissure);

// Slabs jutting up out of the ground round the foe, then dropping back.
const slabs = kit.spray([333, 1], rockTex, FOE_FLOOR, { radius: 1.7, speed: 0.04, count: 5, life: 22, scale: 1.2, shape: "circle" });
slabs.emissionAxis = 1;
slabs.axis = [0, 1, 0];
slabs.initVelAxisAmplifier = 0.3;
slabs.airResistance = 0.9;
slabs.behaviors = [{ type: "gravity", magnitude: [0, -0.02, 0] }];
spin(slabs, -0.04, 0.04, 0, true);
setCurves(slabs, { start: 0.4, mid: 1, end: 0.9, curveIn: 0.15, curveOut: 0.8 }, fadeOut(1, 0.7));
paint(slabs, WHITE);
kit.add("slabs", slabs);

// Rock chunks flying out from the foe.
const chunks = kit.spray([333, 1], rockTex, FOE, { radius: 0.6, speed: 0.38, count: 8, life: 22, scale: 0.75 });
chunks.startDelayFrames = HIT_STOP;
chunks.axis = [0, 1, 0];
chunks.initVelAxisAmplifier = 0.18;
chunks.airResistance = 0.95; // let them fly: the shell's own drag stops them short
chunks.behaviors = [{ type: "gravity", magnitude: [0, -0.022, 0] }];
spin(chunks, -0.25, 0.25, 0, true);
setCurves(chunks, grow(0.5, 0.15, 0.85), fadeOut(1, 0.7));
paint(chunks, WHITE);
kit.add("chunks", chunks);

const dust = kit.spray([333, 1], kit.tex(321, 5), FOE_FLOOR, { radius: 1.4, speed: 0.1, count: 6, life: 22, scale: 1.0, shape: "circle" });
dust.emissionAxis = 1;
spin(dust, -0.05, 0.05, 0, true);
setCurves(dust, grow(0.5, 0.25, 1.6), fadeOut(0.9, 0.4));
kit.prism(dust, [TAN, WHITE, SAND]);
kit.add("dust", dust);

const streaks = kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.5, speed: 0.5, count: 8, life: 9, scale: 2.0, directional: true });
streaks.axis = [0, 1, 0];
streaks.initVelAxisAmplifier = 0.5;
setCurves(streaks, undefined, fadeOut());
kit.prism(streaks, [ORANGE, YELLOW, ORANGE]);
kit.add("streaks", streaks);

const shards = kit.spray([228, 3], kit.tex(465, 3), FOE, { radius: 0.5, speed: 0.6, count: 6, life: 10, scale: 0.8, directional: true });
setCurves(shards, grow(1, 0.3, 0.6), fadeOut());
kit.prism(shards, [CYAN, PALE_BLUE, CYAN]);
kit.add("shards", shards);

// --- script ---
const emits = (names: string[], who: "ATTACKER" | "DEFENDER") => names.map((n) => kit.emit(n, who)).join("\n");
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1560, SE1, 14, 0, 0, 120, 0, 0, 0
PlaySound 1509, SE2, 14, 2, -300, 100, 0, 0, 0
PlaySound 1421, SE2, 14, 9, -300, 100, 0, 0, 0
PlaySound 1421, SE2, 14, 20, -100, 110, 0, 0, 0
PlaySound 1421, SE1, 16, ${SPIRIT + 2}, -600, 120, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 3, 26, 28, 31
${emits(["aura", "swirlOuter", "swirlInner", "pulses", "whirl", "lightSpikes", "glints"], "ATTACKER")}
Wait ${SPIRIT - 6}
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 3, 0, 1
Wait 6
ChangeSpriteColor ATTACKER, 10, 0, 1, 26, 28, 31
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, ${SWING}, 0, 8
Wait ${SWING - DROP}
${emits(["hammer", "blur"], "DEFENDER")}
Wait ${DROP}
AudioContainer CONTINUE
PlaySound 1413, SE1, 16, 0, -300, 127, 0, 0, 0
PlaySound 1884, SE2, 16, 0, 0, 127, 0, 0, 0
PlaySound 1442, SE2, 16, ${HIT_STOP}, -400, 120, 0, 0, 0
PlaySound 1475, SE1, 16, ${HIT_STOP}, -700, 120, 0, 0, 0
AudioContainer SUSPEND
${emits(["fissure", "slammed", "flash", "slabs", "dust", "streaks", "shards", "chunks"], "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeBackgroundColor 4, 0, 12, 0, 31, 31, 31
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 31, 31
ShakeScreen VERTICAL, 1x, 0, 1, 0, 4
Wait ${HIT_STOP}
ChangeBackgroundColor 4, 12, 0, 1, 31, 31, 31
ChangeSpriteColor DEFENDER, 14, 0, 1, 31, 31, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 4, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 14
ShakeScreen VERTICAL, 2458, 0, 2, 0, 10
Wait ${HOLD}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [63, 153, 129, 240, 605, 484, 359, 231],
  references: ["reference/Gigaton_Hammer_IX.png", "reference/Gigaton_Hammer_IX_2.png", "reference/Gigaton_Hammer_IX_not_Tinkaton.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("pulses")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("hammer")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("fissure")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("chunks")}, DEFENDER`, "ShakeScreen VERTICAL, 2458", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  spirit f${CAMERA_IN}-${CAMERA_IN + SPIRIT}, slam f${CAMERA_IN + SPIRIT + SWING}, rocks fly f${CAMERA_IN + SPIRIT + SWING + HIT_STOP}`);
