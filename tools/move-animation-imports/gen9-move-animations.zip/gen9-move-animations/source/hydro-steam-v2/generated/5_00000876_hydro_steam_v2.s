MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 928
AudioContainer CONTINUE
PlaySound 1418, PSG, 14, 0, 500, 100, 0, 0, 0
PlaySound 1445, SE2, 14, 2, 1000, 90, 0, 0, 0
PlaySound 1509, SE1, 14, 16, 600, 105, 0, 0, 0
PlaySound 1376, PSG, 14, 24, 0, 0, 0, 0, 0
PlaySound 1407, SE1, 14, 24, 0, 125, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 9, 0, 50, 0, 0
PlaySound 1511, SE2, 16, 33, 600, 120, 0, 0, 0
PlaySound 1475, SE2, 16, 33, -200, 115, 0, 0, 0
PlaySound 1445, SE2, 16, 49, 1400, 85, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 3, 22, 30, 31
Emit 928, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 928, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 928, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 16
Emit 928, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 928, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 4
Wait 8
Emit 928, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 928, 6, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 928, 7, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 928, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -1px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, 9, 0, 8
Wait 9
Emit 928, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 928, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 928, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 928, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 928, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 928, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 928, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 13, 0, 28, 31, 31
Wait 4
ChangeSpriteColor ATTACKER, 8, 0, 2, 22, 30, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 0, 3
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 12
ChangeSpriteColor DEFENDER, 13, 0, 8, 28, 31, 31
Wait 30
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
