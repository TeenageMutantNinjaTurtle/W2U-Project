import { aimed, assert, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Hydro Steam (move 876), v2 - from Logan's keyframes (reference/keyframe-1..6)
// and brief: "startup -> small condense into a water beam -> blasts at target
// -> upon contact deals damage -> steam is emitted from the target".
//   1. Startup: white wind streaks are drawn in to a white-cyan glow at the
//      user's mouth, flecks flying.
//   2. Condense: the glow tightens into a bright, spiky white ball.
//   3-4. The beam: a pale cyan water beam streaked with white blasts across
//      to the foe, the ball still blazing at the mouth.
//   5. Contact: it bursts on the foe in a great white cloud of spray, cyan
//      splash spikes and droplets.
//   6. Steam: white steam rises off the foe after the beam stops.
// Hyper Beam's stream (SPA 228) is the beam; Explosion's puff (321) the
// spray and steam; Aqua Jet's ring (632) the splash.
// v1 (../hydro-steam, from the Bulbapedia still) is kept; reinstall its
// manifest to revert.

const SPA = 928;
const kit = await createKit({ workDir: import.meta.dirname, slug: "hydro-steam-v2", moveId: 876, spaId: SPA, donors: [228, 321, 632, 465, 579, 411] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const STARTUP = 16;
const CONDENSE = 8;
const SPEED = 1.6;
const TRAVEL = 9;
const POUR = 16; // frames the beam is fired
const HIT_STOP = 4;
const STEAM = 30;

const MOUTH: Vec3 = [0.3, 0.8, -1.0];
const FOE: Vec3 = [0, 0.3, 0.8];

const CYAN: Rgb = [0.55, 0.9, 1.0];
const PALE_CYAN: Rgb = [0.85, 0.97, 1.0];
const WATER: Rgb = [0.4, 0.75, 1.0];
const WHITE: Rgb = [1, 1, 1];
const STEAM_WHITE: Rgb = [0.92, 0.94, 0.96];

// --- 1. startup: energy drawn in to the mouth ---
const windIn = kit.spray([228, 3], kit.tex(411, 0), MOUTH, { radius: 2.6, speed: 0, count: 2, bursts: STARTUP / 2, gap: 2, life: 8, scale: 1.8, shape: "sphere", directional: true });
windIn.behaviors = [{ type: "convergence", target: [0, 0, 0], force: 0.16 }];
setCurves(windIn, undefined, fadeInOut(0.9, 0.2, 0.7));
paint(windIn, WHITE, WHITE, PALE_CYAN);
kit.add("windIn", windIn);

const gatherGlow = kit.parked(kit.tex(465, 1), MOUTH, 1.8, STARTUP + 2);
setCurves(gatherGlow, { start: 0.2, mid: 0.8, end: 1.1, curveIn: 0.5, curveOut: 0.5 }, fadeInOut(0.9, 0.2, 0.95));
paint(gatherGlow, PALE_CYAN, WHITE, CYAN);
kit.add("gatherGlow", gatherGlow);

const flecks = kit.spray([333, 1], kit.tex(333, 0), MOUTH, { radius: 1.6, speed: 0.03, count: 1, bursts: STARTUP / 2, gap: 2, life: 9, scale: 0.12, shape: "ball" });
setCurves(flecks, undefined, twinkle());
paint(flecks, WHITE, WHITE, PALE_CYAN);
kit.add("flecks", flecks);

// --- 2. condense: the spiky white ball (it stays blazing while the beam pours) ---
const BALL_LIFE = CONDENSE + POUR + 2;
const ball = kit.parked(kit.tex(579, 2), MOUTH, 1.3, BALL_LIFE);
spin(ball, 0.2);
setCurves(ball, { start: 1.5, mid: 0.8, end: 1.0, curveIn: CONDENSE / BALL_LIFE, curveOut: 0.9 }, fadeInOut(1, 0.1, 0.85));
paint(ball, WHITE, PALE_CYAN, WHITE);
kit.add("ball", ball);

const ballGlow = kit.parked(kit.tex(228, 1), MOUTH, 1.5, BALL_LIFE);
spin(ballGlow, -0.08);
setCurves(ballGlow, { start: 1.6, mid: 0.8, end: 1.1, curveIn: CONDENSE / BALL_LIFE, curveOut: 0.9 }, fadeInOut(0.95, 0.1, 0.85));
paint(ballGlow, WHITE, WHITE, PALE_CYAN);
kit.add("ballGlow", ballGlow);

// --- 3-4. the beam ---
function stream(scale: number, every: number, base: Rgb, start: Rgb, end: Rgb): ReturnType<typeof kit.shell> {
  const r = kit.shell(228, 0);
  r.textureIndex = kit.tex(228, 1);
  aimed(r, SPEED, TRAVEL + 1);
  Object.assign(r, { emitterBasePos: [...MOUTH], baseScale: scale, emitterLifeFrames: POUR, emissionIntervalFrames: every, airResistance: 1.0 });
  setCurves(r, { start: 0.8, mid: 1.0, end: 1.2, curveIn: 0.5, curveOut: 0.5 }, hold(1));
  paint(r, base, start, end, 0.4);
  return r;
}
kit.add("jet", stream(1.25, 1, CYAN, PALE_CYAN, WATER));
kit.add("core", stream(0.6, 2, WHITE, WHITE, PALE_CYAN));

// White streak lines running along the beam.
const lines = kit.spray([228, 3], kit.tex(411, 0), MOUTH, { radius: 0.35, speed: 0, count: 1, bursts: POUR / 2, gap: 2, life: TRAVEL + 1, scale: 2.4, shape: "circle", directional: true });
aimed(lines, SPEED * 1.1, TRAVEL);
setCurves(lines, undefined, hold(0.9));
paint(lines, WHITE);
kit.add("lines", lines);

const mouthSpray = kit.shell(632, 0);
mouthSpray.textureIndex = kit.tex(632, 0);
Object.assign(mouthSpray, { emitterBasePos: [...MOUTH], emissionCount: 2, emitterLifeFrames: 6, initVelPosAmplifier: 0.25, particleLifeFrames: 10, baseScale: 0.25 });
kit.add("mouthSpray", mouthSpray);

// --- 5. contact ---
const flash = kit.parked(kit.tex(228, 1), FOE, 2.4, 12);
spin(flash, 0.05);
setCurves(flash, grow(0.4, 0.2, 2.2), fadeOut(1, 0.35));
paint(flash, WHITE, WHITE, PALE_CYAN);
kit.add("flash", flash);

// The white spray cloud, renewed for as long as the beam pours.
const cloud = kit.spray([333, 1], kit.tex(321, 5), FOE, { radius: 0.8, speed: 0.1, count: 2, bursts: POUR / 4, gap: 4, life: 12, scale: 1.5, shape: "ball" });
spin(cloud, -0.06, 0.06, 0, true);
setCurves(cloud, grow(0.5, 0.25, 1.6), fadeInOut(0.9, 0.1, 0.5));
paint(cloud, WHITE, WHITE, STEAM_WHITE);
kit.add("cloud", cloud);

const spikes = kit.spray([228, 3], kit.tex(321, 6), FOE, { radius: 0.4, speed: 0.5, count: 7, life: 10, scale: 0.7, directional: true });
spikes.axis = [0, 1, 0];
spikes.initVelAxisAmplifier = 0.12;
setCurves(spikes, grow(1.1, 0.3, 0.6), fadeOut());
kit.prism(spikes, [PALE_CYAN, WHITE, CYAN]);
kit.add("spikes", spikes);

const ring = kit.parked(kit.tex(632, 2), FOE, 1.3, 10);
setCurves(ring, grow(0.5, 0.3, 1.9), fadeOut(1, 0.3));
paint(ring, PALE_CYAN, WHITE, CYAN);
kit.add("ring", ring);

const droplets = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.5, speed: 0.35, count: 2, bursts: POUR / 4, gap: 4, life: 12, scale: 0.13 });
droplets.behaviors = [{ type: "gravity", magnitude: [0, -0.015, 0] }];
setCurves(droplets, undefined, fadeOut(1, 0.5));
paint(droplets, WHITE, WHITE, PALE_CYAN);
kit.add("droplets", droplets);

// --- 6. steam rising off the foe ---
const steam = kit.spray([333, 1], kit.tex(321, 5), [0, 0.1, 0.9], { radius: 1.0, speed: 0.01, count: 1, bursts: (STEAM - 10) / 3, gap: 3, life: 20, scale: 0.9, shape: "ball" });
steam.startDelayFrames = POUR - 2;
steam.axis = [0.08, 1, 0];
steam.initVelAxisAmplifier = 0.09;
spin(steam, -0.04, 0.04, 0, true);
setCurves(steam, grow(0.5, 0.3, 1.7), fadeInOut(0.65, 0.2, 0.45));
paint(steam, STEAM_WHITE, WHITE, STEAM_WHITE);
kit.add("steam", steam);

const haze = kit.parked(kit.tex(465, 1), FOE, 3.2, STEAM);
haze.startDelayFrames = POUR - 2;
setCurves(haze, grow(0.6, 0.3, 1.15), fadeInOut(0.45, 0.2, 0.5));
paint(haze, WHITE, WHITE, STEAM_WHITE);
kit.add("haze", haze);

// --- script ---
const emits = (names: string[], who: "ATTACKER" | "DEFENDER", toward = "NONE") => names.map((n) => kit.emit(n, who, toward)).join("\n");
const fireAt = STARTUP + CONDENSE;
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1418, PSG, 14, 0, 500, 100, 0, 0, 0
PlaySound 1445, SE2, 14, 2, 1000, 90, 0, 0, 0
PlaySound 1509, SE1, 14, ${STARTUP}, 600, 105, 0, 0, 0
PlaySound 1376, PSG, 14, ${fireAt}, 0, 0, 0, 0, 0
PlaySound 1407, SE1, 14, ${fireAt}, 0, 125, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, ${TRAVEL}, 0, 50, 0, 0
PlaySound 1511, SE2, 16, ${fireAt + TRAVEL}, 600, 120, 0, 0, 0
PlaySound 1475, SE2, 16, ${fireAt + TRAVEL}, -200, 115, 0, 0, 0
PlaySound 1445, SE2, 16, ${fireAt + TRAVEL + POUR}, 1400, 85, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 3, 22, 30, 31
${emits(["gatherGlow", "windIn", "flecks"], "ATTACKER")}
Wait ${STARTUP}
${emits(["ballGlow", "ball"], "ATTACKER")}
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, ${CONDENSE / 2}
Wait ${CONDENSE}
${emits(["jet", "core", "lines"], "ATTACKER", "DEFENDER")}
${kit.emit("mouthSpray", "ATTACKER")}
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, -1px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, ${TRAVEL}, 0, 8
Wait ${TRAVEL}
${emits(["flash", "cloud", "spikes", "ring", "droplets", "haze", "steam"], "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 13, 0, 28, 31, 31
Wait ${HIT_STOP}
ChangeSpriteColor ATTACKER, 8, 0, 2, 22, 30, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 0, ${(POUR - HIT_STOP) / 4}
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait ${POUR - HIT_STOP}
ChangeSpriteColor DEFENDER, 13, 0, 8, 28, 31, 31
Wait ${STEAM}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

const { built } = await kit.finish({
  script,
  donorMoveIds: [63, 153, 453, 163, 427, 400],
  references: ["reference/keyframe-1.png", "reference/keyframe-2.png", "reference/keyframe-3.png", "reference/keyframe-4.png", "reference/keyframe-5.png", "reference/keyframe-6.png", "reference/Hydro_Steam_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("windIn")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("ball")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("jet")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("steam")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
assert.ok(built("jet").initVelAxisAmplifier * (TRAVEL + 1) > 14, "Beam does not reach the foe");
const at = CAMERA_IN + fireAt;
console.log(`  startup f${CAMERA_IN}, condense f${CAMERA_IN + STARTUP}, beam f${at}-${at + POUR}, contact f${at + TRAVEL}, steam f${at + TRAVEL + POUR - 2}-${at + TRAVEL + POUR + STEAM}`);
