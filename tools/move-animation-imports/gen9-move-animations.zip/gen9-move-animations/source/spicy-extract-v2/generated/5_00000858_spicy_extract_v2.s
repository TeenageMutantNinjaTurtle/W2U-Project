MoveCamera INTERPOLATION, ZOOM_OUT_PERS, 18, 0, 0
LetCMDsFinish CAMERA
LoadSPA 917
AudioContainer CONTINUE
PlaySound 1445, SE2, 14, 0, 2000, 100, 0, 0, 0
PlaySound 1445, SE2, 14, 8, 1600, 90, 0, 0, 0
PlaySound 1561, SE1, 16, 10, 0, 115, 0, 0, 0
PlaySound 1561, SE1, 16, 18, 200, 110, 0, 0, 0
PlaySound 1426, SE2, 16, 26, 0, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 6, 2, 31, 14, 6
Emit 917, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 917, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 917, 2, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 917, 3, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 917, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 917, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 917, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 917, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 917, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 10
ChangeSpriteColor DEFENDER, 0, 12, 2, 31, 12, 6
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 9
Wait 16
ChangeSpriteColor ATTACKER, 6, 0, 2, 31, 14, 6
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 4
Wait 12
ChangeSpriteColor DEFENDER, 12, 0, 2, 31, 12, 6
Wait 6
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
