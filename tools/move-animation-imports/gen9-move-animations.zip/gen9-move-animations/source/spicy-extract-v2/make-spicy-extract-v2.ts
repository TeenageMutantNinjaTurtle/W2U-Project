import { aimed, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Spicy Extract (move 858), v2 - from Logan's keyframes (reference/keyframe-1..4):
//   1. Firing: a squirt of orange spice bursts from the user's pepper.
//   2-3. Travelling: a spreading stream of puffy orange spice blobs - bubbly
//      clusters with yellow-orange rims and dark outlines - swelling as they
//      fly, small drops scattering and falling away.
//   4. Contact: the drops blow up on the foe in jagged, flame-like orange and
//      yellow splats, red-orange flecks flying.
// A status move: the Attack/Defence changes play as Gen 5's own stat
// animations afterwards.
// v1 (../spicy-extract, Explosion's puffs) is kept; reinstall its manifest to
// revert.
//
// Drawn here (32x32 a3i5, see generated/): the spice blob (lumps with light
// rims, darker cores and a dark outline) and the spice burst (a jagged
// nine-pointed splat, yellow at the heart to red-orange at the tips).

const SPA = 917;
const kit = await createKit({ workDir: import.meta.dirname, slug: "spicy-extract-v2", moveId: 858, spaId: SPA, donors: [579, 228] });

// --- timing (30 fps) ---
const WIDE = 18;
const STREAM = 18; // frames the user sprays
const TRAVEL = 10; // a blob's flight to the foe
const HOLD = 16; // after the last blob lands

const MOUTH: Vec3 = [0.3, 0.9, -1.3]; // the pepper's tip, toward the foe
const FOE: Vec3 = [0, 0.3, 0.8];

const WHITE: Rgb = [1, 1, 1];
const WARM: Rgb = [1.0, 0.85, 0.7]; // multiplies the drawn colours a little redder
const HOT: Rgb = [1.0, 0.7, 0.55];
const ORANGE: Rgb = [1.0, 0.5, 0.12];
const RED_ORANGE: Rgb = [1.0, 0.32, 0.1];
const YELLOW: Rgb = [1.0, 0.85, 0.3];

// --- drawn textures ---
type Px = [number, number, number];
const lumps = [{ x: 15, y: 16, r: 8.5 }, { x: 23, y: 12, r: 5.5 }, { x: 22, y: 22, r: 5 }, { x: 8, y: 10, r: 4 }, { x: 9, y: 23, r: 3.5 }];
const blobTex = await kit.drawn("blob", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5;
  const py = y + 0.5;
  const ds = lumps.map((c) => ({ c, d: Math.hypot(px - c.x, py - c.y) })).filter(({ c, d }) => d < c.r);
  if (ds.length === 0) return undefined;
  const edge = lumps.every((c) => Math.hypot(px - c.x, py - c.y) > c.r - 1.2);
  if (edge) return [196, 62, 18] as Px;
  // The lump this pixel sits deepest inside decides its shading.
  const { c, d } = ds.reduce((a, b) => (b.c.r - b.d > a.c.r - a.d ? b : a));
  if (d > c.r - 2.6) return [255, 184, 72] as Px; // light rim
  if (d < c.r * 0.38) return [226, 92, 26] as Px; // darker core
  return [248, 128, 36] as Px;
});

const SPIKES = 9;
const tips = Array.from({ length: SPIKES * 2 }, (_, i) => (i % 2 === 0 ? 14 + ((i * 37) % 5) * 0.5 : 6 + ((i * 53) % 4) * 0.6));
const burstTex = await kit.drawn("burst", 32, 32, "a3i5", (x, y) => {
  const dx = x + 0.5 - 16;
  const dy = y + 0.5 - 16;
  const r = Math.hypot(dx, dy);
  const a = (Math.atan2(dy, dx) + Math.PI * 2) % (Math.PI * 2);
  const f = (a / (Math.PI * 2)) * tips.length;
  const i = Math.floor(f);
  const limit = tips[i % tips.length]! + (tips[(i + 1) % tips.length]! - tips[i % tips.length]!) * (f - i);
  if (r > limit) return undefined;
  if (r > limit - 1.2) return [200, 50, 18] as Px;
  const t = r / limit;
  if (t < 0.35) return [255, 228, 110] as Px;
  if (t < 0.65) return [255, 160, 44] as Px;
  return [242, 94, 28] as Px;
});

// --- 1. the squirt at the pepper ---
const squirt = kit.spray([333, 1], blobTex, MOUTH, { radius: 0.2, speed: 0.12, count: 3, bursts: 3, gap: 3, life: 8, scale: 0.35 });
spin(squirt, -0.2, 0.2, 0, true);
setCurves(squirt, grow(0.5, 0.3, 1.2), fadeOut(1, 0.4));
kit.prism(squirt, [WHITE, WARM, HOT]);
kit.add("squirt", squirt);

const muzzle = kit.parked(kit.tex(579, 2), MOUTH, 0.7, STREAM);
spin(muzzle, 0.2);
setCurves(muzzle, grow(0.5, 0.15, 1.1), fadeInOut(0.9, 0.1, 0.8));
paint(muzzle, ORANGE, YELLOW, RED_ORANGE);
kit.add("muzzle", muzzle);

// --- 2-3. the stream ---
const stream = kit.spray([333, 1], blobTex, MOUTH, { radius: 0.35, speed: 0.05, count: 1, bursts: STREAM, gap: 1, life: TRAVEL, scale: 0.5 });
aimed(stream, 1.6, TRAVEL);
stream.airResistance = 1.0;
spin(stream, -0.15, 0.15, 0, true);
setCurves(stream, grow(0.6, 0.3, 1.5), hold(1));
kit.prism(stream, [WHITE, WARM, HOT]);
kit.add("stream", stream);

const clusters = kit.spray([333, 1], blobTex, MOUTH, { radius: 0.5, speed: 0.04, count: 1, bursts: STREAM / 3, gap: 3, life: TRAVEL, scale: 0.8 });
aimed(clusters, 1.55, TRAVEL);
clusters.airResistance = 1.0;
spin(clusters, -0.1, 0.1, 0, true);
setCurves(clusters, grow(0.5, 0.4, 1.6), hold(1));
kit.prism(clusters, [WHITE, WARM, WHITE]);
kit.add("clusters", clusters);

const drops = kit.spray([333, 1], blobTex, MOUTH, { radius: 0.5, speed: 0.1, count: 1, bursts: STREAM / 2, gap: 2, life: TRAVEL + 2, scale: 0.18 });
aimed(drops, 1.3, TRAVEL + 2);
drops.behaviors = [{ type: "gravity", magnitude: [0, -0.03, 0] }];
spin(drops, -0.2, 0.2, 0, true);
setCurves(drops, hold(1), fadeOut(1, 0.7));
kit.prism(drops, [WHITE, HOT, WARM]);
kit.add("drops", drops);

// --- 4. contact: each arriving blob blows up ---
const pops = kit.spray([333, 1], burstTex, FOE, { radius: 0.9, speed: 0.02, count: 1, bursts: STREAM / 2, gap: 2, life: 8, scale: 0.75, shape: "ball" });
pops.startDelayFrames = TRAVEL;
spin(pops, -0.1, 0.1, 0, true);
setCurves(pops, { start: 0.3, mid: 1.2, end: 1.35, curveIn: 0.3, curveOut: 0.5 }, fadeOut(1, 0.5));
kit.prism(pops, [WHITE, WARM, WHITE]);
kit.add("pops", pops);

const flecks = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.5, speed: 0.38, count: 2, bursts: STREAM / 3, gap: 3, life: 10, scale: 0.13 });
flecks.startDelayFrames = TRAVEL;
flecks.behaviors = [{ type: "gravity", magnitude: [0, -0.015, 0] }];
setCurves(flecks, undefined, fadeOut(1, 0.5));
kit.prism(flecks, [RED_ORANGE, ORANGE, YELLOW]);
kit.add("flecks", flecks);

const finale = kit.parked(burstTex, FOE, 1.9, 12);
finale.startDelayFrames = TRAVEL + STREAM - 2;
spin(finale, 0.04);
setCurves(finale, { start: 0.3, mid: 1.1, end: 1.25, curveIn: 0.25, curveOut: 0.5 }, fadeOut(1, 0.45));
paint(finale, WHITE);
kit.add("finale", finale);

const flash = kit.parked(kit.tex(228, 1), FOE, 1.4, 10);
flash.startDelayFrames = TRAVEL + STREAM - 2;
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.2, 1.7), fadeOut(1, 0.35));
paint(flash, YELLOW, WHITE, ORANGE);
kit.add("flash", flash);

// --- script ---
const script = `MoveCamera INTERPOLATION, ZOOM_OUT_PERS, ${WIDE}, 0, 0
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1445, SE2, 14, 0, 2000, 100, 0, 0, 0
PlaySound 1445, SE2, 14, 8, 1600, 90, 0, 0, 0
PlaySound 1561, SE1, 16, ${TRAVEL}, 0, 115, 0, 0, 0
PlaySound 1561, SE1, 16, ${TRAVEL + 8}, 200, 110, 0, 0, 0
PlaySound 1426, SE2, 16, ${TRAVEL + STREAM - 2}, 0, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 6, 2, 31, 14, 6
${kit.emit("muzzle", "ATTACKER")}
${kit.emit("squirt", "ATTACKER")}
${kit.emit("stream", "ATTACKER", "DEFENDER")}
${kit.emit("clusters", "ATTACKER", "DEFENDER")}
${kit.emit("drops", "ATTACKER", "DEFENDER")}
${kit.emit("pops", "DEFENDER")}
${kit.emit("flecks", "DEFENDER")}
${kit.emit("finale", "DEFENDER")}
${kit.emit("flash", "DEFENDER")}
Wait ${TRAVEL}
ChangeSpriteColor DEFENDER, 0, 12, 2, 31, 12, 6
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, ${STREAM / 2}
Wait ${STREAM - 2}
ChangeSpriteColor ATTACKER, 6, 0, 2, 31, 14, 6
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 4
Wait ${HOLD - 4}
ChangeSpriteColor DEFENDER, 12, 0, 2, 31, 12, 6
Wait 6
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [53, 400, 153, 63],
  references: ["reference/keyframe-1.png", "reference/keyframe-2.png", "reference/keyframe-3.png", "reference/keyframe-4.png", "reference/Spicy_Extract_IX.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveCamera INTERPOLATION, ZOOM_OUT_PERS", `Emit ${SPA}, 2, ATTACKER, DEFENDER`, `Emit ${SPA}, 5, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  spray f${WIDE}-${WIDE + STREAM}, first pop f${WIDE + TRAVEL}, finale f${WIDE + TRAVEL + STREAM - 2}`);
