MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 932
AudioContainer CONTINUE
PlaySound 1759, PSG, 16, 0, 300, 60, 0, 0, 0
PlaySound 1710, SE1, 14, 4, 500, 95, 0, 0, 0
PlaySound 1710, SE2, 14, 16, 300, 100, 0, 0, 0
PlaySound 1418, SE1, 14, 22, 400, 105, 0, 0, 0
PlaySound 1710, SE2, 14, 28, 0, 115, 0, 0, 0
PlaySound 1710, SE2, 14, 40, -200, 120, 0, 0, 0
PlaySound 1683, SE1, FLAT, 56, 0, 127, 0, 0, 0
PlaySound 1475, SE2, 16, 61, -300, 127, 0, 0, 0
PlaySound 1514, SE1, 16, 67, 200, 115, 0, 0, 0
PlaySound 1710, SE2, 16, 77, 600, 90, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 3, 2, 2, 8
ChangeSpriteColor ATTACKER, 0, 10, 4, 31, 26, 6
Emit 932, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 932, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 932, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 932, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 932, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 932, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 932, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 932, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 26
ChangeSpriteColor ATTACKER, 10, 15, 4, 31, 31, 14
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 14
Wait 30
ToggleSpriteVisibility ATTACKER, 3
Emit 932, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 932, 8, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 932, 9, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveCamera INTERPOLATION, DEFENDER, 5, 0, 8
Wait 5
Emit 932, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 932, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 932, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 932, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 932, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 932, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 932, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 932, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 15, 0, 31, 31, 14
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 3
Wait 6
ChangeSpriteColor DEFENDER, 15, 0, 3, 31, 31, 14
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 4, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 14
ShakeScreen VERTICAL, 2458, 0, 2, 0, 10
Wait 34
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 15, 0, 0, 31, 31, 14
ToggleSpriteVisibility ATTACKER, 4
ChangeBackgroundColor 4, 10, 0, 2, 2, 2, 8
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
