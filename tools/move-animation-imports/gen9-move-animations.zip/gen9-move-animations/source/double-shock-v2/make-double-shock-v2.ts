import { aimed, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Double Shock (move 892), v2 - from Logan's keyframes (reference/keyframe-1..6)
// and brief: "a couple second startup where the user draws in electricity ->
// then zaps towards the target as a lightning bolt -> where it hits the
// target and deals immense damage with sparks falling off the target".
//   1-3. Startup (about two seconds): thin white rings pulse out round the
//      user while long lightning bolts are drawn in to it from all round -
//      white at first, then thick yellow, with blue arcs near the end - and
//      it glows from gold to a blazing yellow-white.
//   4. The zap: it turns into a thick white lightning bolt that streaks to
//      the foe.
//   5. The hit: a yellow spiky burst, white bolts crashing down, forks of
//      lightning - a long hit-stop and the heaviest shake.
//   6. Sparks fall off the foe afterwards.
// 120 power. The user is hidden while it is the bolt (ToggleSpriteVisibility
// 3/4). Losing its Electric type is handled by the engine.
// v1 (../double-shock, from the Bulbapedia stills) is kept; reinstall its
// manifest to revert.
//
// Thunder's animated bolt (SPA 256 resource 1, four frames) is every long
// bolt here, drawn as a directional billboard so it lies along its motion;
// Thunder's squiggles (257) are the arcs and forks.

const SPA = 932;
const kit = await createKit({ workDir: import.meta.dirname, slug: "double-shock-v2", moveId: 892, spaId: SPA, donors: [256, 257, 298, 465, 579, 321, 228] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const STARTUP = 56;
const SURGE = 26; // when the bolts turn thick and yellow
const ZAP = 5;
const HIT_STOP = 6;
const HOLD = 34;

const USER: Vec3 = [0, 0.3, 0.2];
const FOE: Vec3 = [0, 0.3, 0.8];

const YELLOW: Rgb = [1.0, 0.92, 0.3];
const PALE_YELLOW: Rgb = [1.0, 0.98, 0.72];
const GOLD: Rgb = [1.0, 0.78, 0.2];
const CYAN: Rgb = [0.45, 0.8, 1.0];
const WHITE: Rgb = [1, 1, 1];

function remapAnim(r: ReturnType<typeof kit.shell>, spaId: number): void {
  r.textureIndex = kit.tex(spaId, r.textureIndex);
  if (r.texAnim) r.texAnim.textures = r.texAnim.textures.map((t, i) => (i < r.texAnim!.textureCount ? kit.tex(spaId, t) : 0));
}
const boltShell = kit.shell(256, 1);
remapAnim(boltShell, 256);

// A long bolt lying along its own motion.
function bolts(pos: Vec3, opts: Parameters<typeof kit.spray>[3], width: number): ReturnType<typeof kit.spray> {
  const r = kit.spray([228, 3], boltShell.textureIndex, pos, { ...opts, directional: true });
  r.texAnim = structuredClone(boltShell.texAnim);
  r.aspectRatio = width;
  setCurves(r, hold(1), fadeInOut(1, 0.1, 0.7));
  r.loopFrames = 6; // flicker through the four frames
  return r;
}
// Upright bolt column (Thunder's own), for the strikes on the foe.
function column(pos: Vec3, life: number, scale: number, delay: number, colour: Rgb): ReturnType<typeof kit.shell> {
  const r = kit.shell(256, 1);
  remapAnim(r, 256);
  Object.assign(r, { emitterBasePos: [...pos], particleLifeFrames: life, baseScale: scale, startDelayFrames: delay });
  paint(r, colour, WHITE, colour);
  return r;
}
function arcs(pos: Vec3, opts: Parameters<typeof kit.spray>[3], colours: [Rgb, Rgb, Rgb], delay = 0): ReturnType<typeof kit.spray> {
  const shell = kit.shell(257, 0);
  remapAnim(shell, 257);
  const r = kit.spray(shell, shell.textureIndex, pos, opts);
  r.texAnim = structuredClone(shell.texAnim);
  r.startDelayFrames = delay;
  spin(r, 0, 0, 0, true);
  if (r.alphaAnim) setCurves(r, undefined, fadeOut(1, 0.6));
  r.loopFrames = 7;
  if (r.colorAnim) kit.prism(r, colours);
  else paint(r, colours[1]);
  return r;
}

// --- 1-3. startup: drawing in electricity ---
const ring = (delay: number) => {
  const r = kit.parked(kit.tex(298, 2), USER, 3.0, 16);
  r.startDelayFrames = delay;
  setCurves(r, grow(0.15, 0.6, 1.25), fadeOut(0.9, 0.5));
  paint(r, WHITE, WHITE, PALE_YELLOW);
  return r;
};
kit.add("ringA", ring(0));
kit.add("ringB", ring(SURGE - 4));

// Bolts appear on a ring round the user and are pulled in to it.
function drawnIn(radius: number, scale: number, width: number, bursts: number, gap: number, delay: number, colours: [Rgb, Rgb, Rgb]): ReturnType<typeof kit.spray> {
  const r = bolts(USER, { radius, speed: 0.03, count: 1, bursts, gap, life: 7, scale, shape: "circle" }, width);
  r.startDelayFrames = delay;
  r.behaviors = [{ type: "convergence", target: [0, 0, 0], force: 0.1 }];
  kit.prism(r, colours);
  return r;
}
kit.add("thinBolts", drawnIn(3.4, 2.0, 0.22, 8, 3, 2, [WHITE, PALE_YELLOW, WHITE]));
kit.add("thickBolts", drawnIn(3.2, 2.4, 0.4, 10, 3, SURGE, [YELLOW, PALE_YELLOW, GOLD]));

const motes = kit.spray([333, 1], kit.tex(333, 0), USER, { radius: 3.0, speed: 0, count: 1, bursts: STARTUP / 3, gap: 3, life: 10, scale: 0.14, shape: "sphere" });
motes.behaviors = [{ type: "convergence", target: [0, 0, 0], force: 0.1 }];
setCurves(motes, undefined, twinkle());
kit.prism(motes, [YELLOW, WHITE, PALE_YELLOW]);
kit.add("motes", motes);

const glow = kit.parked(kit.tex(465, 1), USER, 3.2, STARTUP + 2);
setCurves(glow, { start: 0.3, mid: 0.7, end: 1.2, curveIn: 0.4, curveOut: 0.5 }, { start: 0, mid: 0.55, end: 0.95, curveIn: 0.3, curveOut: 0.55 });
paint(glow, YELLOW, GOLD, PALE_YELLOW);
kit.add("glow", glow);

kit.add("blueArcs", arcs(USER, { radius: 1.5, speed: 0, count: 1, bursts: 8, gap: 3, life: 6, scale: 0.7, shape: "ball" }, [CYAN, WHITE, CYAN], SURGE + 6));

const flare = kit.parked(kit.tex(579, 2), USER, 2.0, 10);
flare.startDelayFrames = STARTUP - 8;
spin(flare, 0.15);
setCurves(flare, grow(0.3, 0.5, 1.5), fadeOut(1, 0.7));
paint(flare, PALE_YELLOW, WHITE, YELLOW);
kit.add("flare", flare);

// --- 4. the zap: the user as a lightning bolt ---
function zap(scale: number, width: number, colour: Rgb, start: Rgb): ReturnType<typeof kit.spray> {
  const r = bolts(USER, { radius: 0.3, speed: 0, count: 1, bursts: ZAP + 1, gap: 1, life: 5, scale, shape: "ball" }, width);
  aimed(r, 3.2, 6); // five frames of travel: a particle is gone on the frame its life runs out
  r.airResistance = 1.0; // the shell's drag would stop it two-thirds of the way across
  setCurves(r, hold(1), fadeOut(1, 0.6));
  paint(r, colour, start, colour);
  return r;
}
kit.add("zapHalo", zap(3.0, 0.7, YELLOW, PALE_YELLOW));
kit.add("zapBolt", zap(2.8, 0.4, WHITE, WHITE));

const launch = kit.parked(kit.tex(228, 1), USER, 2.0, 8);
spin(launch, 0.08);
setCurves(launch, grow(0.5, 0.3, 1.6), fadeOut(1, 0.4));
paint(launch, WHITE, WHITE, YELLOW);
kit.add("launch", launch);

// --- 5. the hit ---
const flash = kit.parked(kit.tex(228, 1), FOE, 2.6, 14);
spin(flash, 0.05);
setCurves(flash, grow(0.4, 0.2, 2.4), fadeOut(1, 0.35));
paint(flash, WHITE, WHITE, PALE_YELLOW);
kit.add("flash", flash);

const spiky = kit.parked(kit.tex(579, 2), FOE, 2.2, 14);
spin(spiky, 0.1);
setCurves(spiky, grow(0.4, 0.25, 1.6), fadeOut(1, 0.4));
paint(spiky, YELLOW, WHITE, GOLD);
kit.add("spiky", spiky);

kit.add("strikeA", column([-0.5, 3.2, 0.8], 9, 3.3, 0, WHITE));
kit.add("strikeB", column([0.7, 3.2, 0.7], 9, 3.0, 5, PALE_YELLOW));

const spikes = kit.spray([228, 3], kit.tex(321, 6), [0, -0.4, 0.8], { radius: 0.4, speed: 0.7, count: 9, life: 10, scale: 0.8, shape: "circle", directional: true });
spikes.emissionAxis = 1;
setCurves(spikes, grow(1.2, 0.3, 0.6), fadeOut());
kit.prism(spikes, [YELLOW, PALE_YELLOW, WHITE]);
kit.add("spikes", spikes);

kit.add("forks", arcs(FOE, { radius: 0.5, speed: 0.2, count: 7, life: 9, scale: 0.9 }, [YELLOW, WHITE, CYAN]));

// --- 6. sparks falling off the foe ---
const fallingSparks = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 1.1, speed: 0.06, count: 2, bursts: 9, gap: 3, life: 14, scale: 0.14, shape: "ball" });
fallingSparks.startDelayFrames = HIT_STOP;
fallingSparks.behaviors = [{ type: "gravity", magnitude: [0, -0.02, 0] }];
setCurves(fallingSparks, undefined, fadeOut(1, 0.5));
kit.prism(fallingSparks, [YELLOW, WHITE, GOLD]);
kit.add("fallingSparks", fallingSparks);

kit.add("lingering", arcs(FOE, { radius: 1.2, speed: 0, count: 1, bursts: 5, gap: 5, life: 6, scale: 0.6, shape: "ball" }, [YELLOW, PALE_YELLOW, WHITE], HIT_STOP + 6));

// --- script ---
const emits = (names: string[], who: "ATTACKER" | "DEFENDER", toward = "NONE") => names.map((n) => kit.emit(n, who, toward)).join("\n");
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1759, PSG, 16, 0, 300, 60, 0, 0, 0
PlaySound 1710, SE1, 14, 4, 500, 95, 0, 0, 0
PlaySound 1710, SE2, 14, 16, 300, 100, 0, 0, 0
PlaySound 1418, SE1, 14, ${SURGE - 4}, 400, 105, 0, 0, 0
PlaySound 1710, SE2, 14, ${SURGE + 2}, 0, 115, 0, 0, 0
PlaySound 1710, SE2, 14, ${SURGE + 14}, -200, 120, 0, 0, 0
PlaySound 1683, SE1, FLAT, ${STARTUP}, 0, 127, 0, 0, 0
PlaySound 1475, SE2, 16, ${STARTUP + ZAP}, -300, 127, 0, 0, 0
PlaySound 1514, SE1, 16, ${STARTUP + ZAP + HIT_STOP}, 200, 115, 0, 0, 0
PlaySound 1710, SE2, 16, ${STARTUP + ZAP + HIT_STOP + 10}, 600, 90, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 3, 2, 2, 8
ChangeSpriteColor ATTACKER, 0, 10, 4, 31, 26, 6
${emits(["glow", "ringA", "thinBolts", "motes", "ringB", "thickBolts", "blueArcs", "flare"], "ATTACKER")}
Wait ${SURGE}
ChangeSpriteColor ATTACKER, 10, 15, 4, 31, 31, 14
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, ${(STARTUP - SURGE) / 2 - 1}
Wait ${STARTUP - SURGE}
ToggleSpriteVisibility ATTACKER, 3
${kit.emit("launch", "ATTACKER")}
${emits(["zapHalo", "zapBolt"], "ATTACKER", "DEFENDER")}
MoveCamera INTERPOLATION, DEFENDER, ${ZAP}, 0, 8
Wait ${ZAP}
${emits(["flash", "spiky", "strikeA", "strikeB", "spikes", "forks", "fallingSparks", "lingering"], "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 15, 0, 31, 31, 14
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 3
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 15, 0, 3, 31, 31, 14
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 4, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 14
ShakeScreen VERTICAL, 2458, 0, 2, 0, 10
Wait ${HOLD}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 15, 0, 0, 31, 31, 14
ToggleSpriteVisibility ATTACKER, 4
ChangeBackgroundColor 4, 10, 0, 2, 2, 2, 8
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [87, 527, 63, 291, 153, 400],
  references: ["reference/keyframe-1.png", "reference/keyframe-2.png", "reference/keyframe-3.png", "reference/keyframe-4.png", "reference/keyframe-5.png", "reference/keyframe-6.png", "reference/Double_Shock_IX.png", "reference/Double_Shock_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("thinBolts")}, ATTACKER`, "ToggleSpriteVisibility ATTACKER, 3", `Emit ${SPA}, ${kit.idx("zapBolt")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("spiky")}, DEFENDER`, "ShakeScreen VERTICAL, 2458", "ToggleSpriteVisibility ATTACKER, 4", "MoveCamera INTERPOLATION, INIT"],
});
const zapAt = CAMERA_IN + STARTUP;
console.log(`  startup f${CAMERA_IN}-${zapAt} (surge f${CAMERA_IN + SURGE}), zap f${zapAt}, hit f${zapAt + ZAP}, sparks to f${zapAt + ZAP + HIT_STOP + HOLD}`);
