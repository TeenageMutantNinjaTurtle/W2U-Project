LoadSPA 936
AudioContainer CONTINUE
PlaySound 1407, SE1, 14, 0, 300, 100, 0, 0, 0
PlaySound 1407, SE2, 14, 2, 390, 100, 0, 0, 0
PlaySound 1407, SE1, 14, 4, 480, 100, 0, 0, 0
PlaySound 1407, SE2, 14, 6, 570, 100, 0, 0, 0
PlaySound 1407, SE1, 14, 8, 660, 100, 0, 0, 0
PlaySound 1407, SE2, 14, 10, 750, 100, 0, 0, 0
PlaySound 1514, SE2, 16, 8, 200, 105, 0, 0, 0
PlaySound 1514, SE1, 16, 10, 280, 105, 0, 0, 0
PlaySound 1514, SE2, 16, 12, 360, 105, 0, 0, 0
PlaySound 1514, SE1, 16, 14, 440, 105, 0, 0, 0
PlaySound 1514, SE2, 16, 16, 520, 105, 0, 0, 0
PlaySound 1514, SE1, 16, 18, 600, 105, 0, 0, 0
PlaySound 1475, SE1, 16, 21, -200, 125, 0, 0, 0
PlaySound 1423, SE2, 16, 21, -300, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 9, 1, 14, 30, 30
Emit 936, 0, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 936, 1, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 936, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 936, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 936, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 936, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 936, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 936, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 936, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 936, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 5
Wait 8
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 8, 1, 16, 30, 31
ShakeSprite DEFENDER, 2, 819, 0, 2, 0, 7
Wait 13
ChangeSpriteColor ATTACKER, 9, 0, 2, 14, 30, 30
ChangeSpriteColor DEFENDER, 8, 14, 0, 26, 31, 31
Wait 3
ChangeSpriteColor DEFENDER, 14, 0, 2, 26, 31, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 5
Wait 14
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
