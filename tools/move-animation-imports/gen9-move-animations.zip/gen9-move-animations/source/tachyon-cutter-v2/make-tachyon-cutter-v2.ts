import { aimed, assert, createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Tachyon Cutter (move 911), v2 - from Logan's keyframes (shown in chat, not
// saved) and brief: "no startup: instead begins throwing parallel slashes in
// quick succession towards the target, after the slashes all connect, the
// target takes damage and explodes with blue and orange light".
//   1. Teal-cyan crescent blades fly from the user to the foe one after
//      another, side by side, each leaving after-images behind it.
//   2. Each one lands as a bright cyan cut on the foe, all at the same angle.
//   3. When the last has landed the foe bursts in light: cyan-white and
//      orange streaks shooting out in every direction.
// Second pass (Logan, 2026-10-01): the user fires a PAIR of slashes; they lie
// horizontal, start close together and converge slightly onto the foe; and
// the light thrown off by the hit stays on the foe instead of flying to the
// edges of the screen.
// Third pass (Logan, 2026-10-01): the first slash curved the wrong way and is
// gone; there are now two streams of slashes, one from the user's left and
// one from its right, converging on the foe; and the foe bursts into blue and
// orange particles that spread outward. Seen in the preview: a crescent
// turned +90 degrees bows toward the camera (wrong); -90 bows toward the foe.
// Streaks sprayed off a sphere are drawn as screen-long lines when they head
// for the camera, so the burst is sprayed off a camera-facing circle instead.
// Two hits: Gen 5 replays the animation per hit, so the camera stays still
// and one hit is about 1.3 seconds.
// v1 (../tachyon-cutter, from the Bulbapedia stills) is kept; reinstall its
// manifest to revert.

const SPA = 936;
const kit = await createKit({ workDir: import.meta.dirname, slug: "tachyon-cutter-v2", moveId: 911, spaId: SPA, donors: [606, 333, 228, 411, 465, 579] });

// --- timing (30 fps), one hit ---
const PER_STREAM = 3;
const STREAM_GAP = 4; // between slashes in one stream
const OFFSET = 2; // the right stream runs this far behind the left
const FLIGHT = 8;
const LAST_LANDS = FLIGHT + (PER_STREAM - 1) * STREAM_GAP + OFFSET;
const BURST_AFTER = 3; // after the last slash lands
const HIT_STOP = 3;
const HOLD = 14;

const SIDE = 1.9; // each stream starts this far to the user's left / right
const HAND: Vec3 = [0, 0.5, -0.4];
const FOE: Vec3 = [0, 0.3, 0.8];
const SPEED = 16 / FLIGHT; // the two Pokemon stand about 16 units apart

const TEAL: Rgb = [0.35, 0.9, 0.85];
const CYAN: Rgb = [0.45, 0.95, 1.0];
const PALE_CYAN: Rgb = [0.85, 1.0, 1.0];
const ORANGE: Rgb = [1.0, 0.6, 0.2];
const YELLOW: Rgb = [1.0, 0.9, 0.4];
const WHITE: Rgb = [1, 1, 1];

// --- 1. two streams of slashes, from the user's left and right, converging ---
const streams: Array<{ name: string; side: 1 | -1; delay: number }> = [
  { name: "streamLeft", side: -1, delay: 0 },
  { name: "streamRight", side: 1, delay: OFFSET },
];
streams.forEach(({ name, side, delay }) => {
  const r = kit.parked(kit.tex(606, 3), [HAND[0] + side * SIDE, HAND[1], HAND[2]], 1.5, FLIGHT + 1);
  r.startDelayFrames = delay;
  aimed(r, SPEED, FLIGHT + 1); // life FLIGHT + 1: gone as it reaches the foe
  // The engine only aims an emitter forward, so a steady sideways pull curves
  // each stream inward: it closes the SIDE gap over the flight.
  r.behaviors = [{ type: "gravity", magnitude: [(-side * 2 * SIDE) / (FLIGHT * FLIGHT), 0, 0] }];
  r.airResistance = 1.0;
  Object.assign(r, { emitterLifeFrames: (PER_STREAM - 1) * STREAM_GAP + 1, emissionIntervalFrames: STREAM_GAP });
  r.aspectRatio = 0.55;
  r.initAngle = deg(-90 + side * 12); // lying flat, bowed toward the foe, each stream turned a little inward
  setCurves(r, grow(0.6, 0.3, 1.15), hold(0.92));
  paint(r, TEAL, PALE_CYAN, TEAL);
  kit.add(name, r);
});

// --- 2. each slash connects: flat cuts across the foe, close together ---
streams.forEach(({ side, delay }, i) => {
  const r = kit.parked(kit.tex(333, 2), [FOE[0], FOE[1] + side * 0.25, FOE[2] + 0.1], 3.0, 8);
  r.startDelayFrames = FLIGHT + delay;
  Object.assign(r, { emitterLifeFrames: (PER_STREAM - 1) * STREAM_GAP + 1, emissionIntervalFrames: STREAM_GAP });
  r.aspectRatio = 0.2;
  r.initAngle = deg(90 + side * 7); // the streak texture is a vertical line
  setCurves(r, grow(0.15, 0.2, 1.05), fadeOut(1, 0.45));
  paint(r, CYAN, WHITE, TEAL);
  kit.add(`cut${i}`, r);
});

const cutSparks = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.5, speed: 0.12, count: 1, bursts: PER_STREAM * 2, gap: STREAM_GAP / 2, life: 8, scale: 0.13 });
cutSparks.startDelayFrames = FLIGHT;
setCurves(cutSparks, undefined, twinkle());
kit.prism(cutSparks, [WHITE, CYAN, PALE_CYAN]);
kit.add("cutSparks", cutSparks);

// --- 3. the foe bursts into blue and orange particles that spread outward ---
const BURST_AT = LAST_LANDS + BURST_AFTER;
const burstAt = <T extends { startDelayFrames: number }>(r: T): T => { r.startDelayFrames = BURST_AT; return r; };

const flash = burstAt(kit.parked(kit.tex(228, 1), FOE, 1.5, 12));
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.2, 1.8), fadeOut(1, 0.35));
paint(flash, PALE_CYAN, WHITE, CYAN);
kit.add("flash", flash);

const spiky = burstAt(kit.parked(kit.tex(579, 2), FOE, 1.2, 11));
spin(spiky, 0.12);
setCurves(spiky, grow(0.4, 0.25, 1.3), fadeOut(1, 0.4));
paint(spiky, CYAN, WHITE, TEAL);
kit.add("spiky", spiky);

const blueRays = burstAt(kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.4, speed: 0.42, count: 9, life: 11, scale: 1.1, shape: "circle", directional: true }));
setCurves(blueRays, undefined, fadeOut(1, 0.45));
kit.prism(blueRays, [CYAN, WHITE, TEAL]);
kit.add("blueRays", blueRays);

const orangeRays = burstAt(kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.4, speed: 0.34, count: 7, life: 11, scale: 0.9, shape: "circle", directional: true }));
setCurves(orangeRays, undefined, fadeOut(1, 0.45));
kit.prism(orangeRays, [ORANGE, YELLOW, ORANGE]);
kit.add("orangeRays", orangeRays);

const flecks = burstAt(kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.5, speed: 0.3, count: 10, life: 14, scale: 0.16, shape: "circle" }));
flecks.variance.lifeTime = 0;
flecks.airResistance = 0.93;
setCurves(flecks, undefined, fadeOut(1, 0.6));
kit.prism(flecks, [ORANGE, CYAN, YELLOW]);
kit.add("flecks", flecks);

// --- script (one hit; no camera moves) ---
const emits = (names: string[], who: "ATTACKER" | "DEFENDER", toward = "NONE") => names.map((n) => kit.emit(n, who, toward)).join("\n");
const slashNames = streams.map((x) => x.name);
const cutNames = streams.map((_, i) => `cut${i}`);
const throws = Array.from({ length: PER_STREAM * 2 }, (_, i) => Math.floor(i / 2) * STREAM_GAP + (i % 2) * OFFSET);
const throwSounds = throws.map((t, i) => `PlaySound 1407, SE${i % 2 ? 2 : 1}, 14, ${t}, ${300 + i * 90}, 100, 0, 0, 0`).join("\n");
const cutSounds = throws.map((t, i) => `PlaySound 1514, SE${i % 2 ? 1 : 2}, 16, ${FLIGHT + t}, ${200 + i * 80}, 105, 0, 0, 0`).join("\n");
const script = `LoadSPA ${SPA}
AudioContainer CONTINUE
${throwSounds}
${cutSounds}
PlaySound 1475, SE1, 16, ${BURST_AT}, -200, 125, 0, 0, 0
PlaySound 1423, SE2, 16, ${BURST_AT}, -300, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 9, 1, 14, 30, 30
${emits(slashNames, "ATTACKER", "DEFENDER")}
${emits([...cutNames, "cutSparks", "flash", "spiky", "blueRays", "orangeRays", "flecks"], "DEFENDER")}
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, ${Math.round(LAST_LANDS / 4)}
Wait ${FLIGHT}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 8, 1, 16, 30, 31
ShakeSprite DEFENDER, 2, 819, 0, 2, 0, ${Math.round((BURST_AT - FLIGHT) / 2)}
Wait ${BURST_AT - FLIGHT}
ChangeSpriteColor ATTACKER, 9, 0, 2, 14, 30, 30
ChangeSpriteColor DEFENDER, 8, 14, 0, 26, 31, 31
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 14, 0, 2, 26, 31, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 8
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 5
Wait ${HOLD}
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [427, 163, 400, 63],
  references: ["reference/SV_Tachyon_Cutter_IX.png", "reference/SV_Tachyon_Cutter_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER, DEFENDER`, `Emit ${SPA}, ${kit.idx("streamRight")}, ATTACKER, DEFENDER`, `Emit ${SPA}, ${kit.idx("cut0")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("orangeRays")}, DEFENDER`],
});
assert.ok(!script.includes("MoveCamera"), "Multi-hit animation moves the camera");
console.log(`  throws f0-${(PER_STREAM - 1) * STREAM_GAP + OFFSET}, cuts f${FLIGHT}-${LAST_LANDS}, burst f${BURST_AT}, one hit ~${BURST_AT + HIT_STOP + HOLD} frames`);
