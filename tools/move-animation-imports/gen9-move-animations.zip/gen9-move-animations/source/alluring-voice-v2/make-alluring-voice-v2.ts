import { createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, shimmer, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Alluring Voice (move 914), v2 - second pass, from Logan's keyframes (shown
// in chat, not saved) and brief: "spawns the veil above the target -> music
// note pulses and deals damage".
//   1. The user sings a short call.
//   2. The veil: a pale shaft of light comes down over the foe from above,
//      faint music notes drifting down inside it, a warm pool on the ground
//      and a sparkle.
//   3. The note: a pink music note appears on the foe and pulses three
//      times; each pulse throws out gold-white rings and white crescent
//      flecks, and is a hit on the foe.
// The confusion is handled by the engine.
// v1 (../alluring-voice) is kept; reinstall its manifest to revert.
//
// Drawn here: the veil (64x64 a5i3 white mask: a soft-edged shaft, narrow at
// the top, widening and fading downward; generated/texture-veil.png) and the
// treble clef (64x64 a5i3 white mask; generated/texture-clef.png). Sing's
// notes (SPA 212) drift in the veil.

const SPA = 907;
const kit = await createKit({ workDir: import.meta.dirname, slug: "alluring-voice-v2", moveId: 914, spaId: SPA, donors: [212, 560, 298, 606, 465, 407] });

// --- timing (30 fps) ---
const CAMERA_IN = 10;
const SING = 10;
const PAN = 8;
const VEIL = 18; // the veil stands before the note appears
const PULSES = 3;
const PULSE_GAP = 9;
const AFTER = 14;

const USER: Vec3 = [0.2, 0.8, -0.4];
const FOE: Vec3 = [0, 0.3, 0.8];
const FOE_FLOOR: Vec3 = [0, -1.5, 0.9];

const PINK: Rgb = [1.0, 0.5, 0.85];
const MINT: Rgb = [0.6, 1.0, 0.85];
const LAVENDER: Rgb = [0.82, 0.74, 1.0];
const CREAM: Rgb = [1.0, 0.95, 0.75];
const GOLD: Rgb = [1.0, 0.86, 0.45];
const SKY: Rgb = [0.6, 0.86, 1.0];
const VEIL_BLUE: Rgb = [0.84, 0.92, 1.0];
const WHITE: Rgb = [1, 1, 1];

// --- drawn textures ---
const veilTex = await kit.drawn("veil", 64, 64, "a5i3", (x, y) => {
  const t = y / 63; // 0 top, 1 bottom
  const half = 10 + 20 * t;
  const d = Math.abs(x - 31.5) / half;
  if (d > 1) return undefined;
  const edge = d > 0.6 ? (1 - d) / 0.4 : 1;
  const a = Math.round(255 * 0.6 * edge * (1 - 0.45 * t));
  return a < 8 ? undefined : [255, 255, 255, a];
});

const strokes: Array<[number, number]> = [];
const line = (x0: number, y0: number, x1: number, y1: number, n = 40) => {
  for (let i = 0; i <= n; i++) strokes.push([x0 + ((x1 - x0) * i) / n, y0 + ((y1 - y0) * i) / n]);
};
const arc = (cx: number, cy: number, r0: number, r1: number, a0: number, a1: number, n = 60) => {
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const a = a0 + (a1 - a0) * t;
    const r = r0 + (r1 - r0) * t;
    strokes.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]);
  }
};
line(35, 6, 29, 58); // stem
arc(36.5, 13, 5.5, 5.5, Math.PI * 0.95, Math.PI * 2.4); // top loop
arc(31, 40, 2.5, 12, -Math.PI * 0.5, Math.PI * 1.55, 120); // spiral
arc(25, 57, 4.5, 4.5, 0, Math.PI * 1.1); // tail hook
const clefTex = await kit.drawn("clef", 64, 64, "a5i3", (x, y) => {
  const px = x + 0.5;
  const py = y + 0.5;
  let d = Infinity;
  for (const [sx, sy] of strokes) d = Math.min(d, Math.hypot(px - sx, py - sy));
  if (Math.hypot(px - 21, py - 57) < 3.2) d = 0; // the dot
  if (d > 2.4) return undefined;
  return [255, 255, 255, d < 1.6 ? 255 : 150];
});

// --- 1. the call ---
const waves = kit.spray([333, 1], kit.tex(212, 0), USER, { radius: 0, speed: 0, count: 1, bursts: 3, gap: 4, life: 10, scale: 1.0, shape: "point" });
setCurves(waves, grow(0.3, 0.5, 1.6), fadeOut(0.9, 0.3));
kit.prism(waves, [PINK, LAVENDER, MINT]);
kit.add("waves", waves);

// --- 2. the veil over the foe ---
const SHOW = VEIL + PULSES * PULSE_GAP + AFTER;
const veil = kit.parked(veilTex, [0, 1.5, 0.6], 3.4, SHOW);
veil.aspectRatio = 0.7;
setCurves(veil, { start: 0.85, mid: 1, end: 1, curveIn: 0.15, curveOut: 1 }, fadeInOut(0.75, 0.12, 0.85));
paint(veil, VEIL_BLUE, WHITE, VEIL_BLUE);
kit.add("veil", veil);

const pool = kit.parked(kit.tex(298, 0), FOE_FLOOR, 1.5, SHOW);
pool.aspectRatio = 2.8;
setCurves(pool, grow(0.4, 0.2, 1.05), fadeInOut(0.6, 0.12, 0.85));
paint(pool, CREAM, WHITE, CREAM);
kit.add("pool", pool);

// Faint notes drifting down inside the veil.
const veilNotes = kit.shell(212, 2);
veilNotes.textureIndex = kit.tex(212, veilNotes.textureIndex);
veilNotes.texAnim!.textures = veilNotes.texAnim!.textures.map((t, i) => (i < veilNotes.texAnim!.textureCount ? kit.tex(212, t) : 0));
Object.assign(veilNotes, {
  emissionType: 4, emissionAxis: 0, radius: 0.9, emitterBasePos: [0, 2.6, 0.7], axis: [0, -1, 0], initVelAxisAmplifier: 0.07, initVelPosAmplifier: 0,
  followEmitter: false, airResistance: 1.0, emissionCount: 1, emitterLifeFrames: VEIL + PULSE_GAP, emissionIntervalFrames: 4, particleLifeFrames: 20, baseScale: 0.4,
});
spin(veilNotes, -0.03, 0.03, 0, true);
setCurves(veilNotes, hold(1), fadeInOut(0.6, 0.2, 0.6));
kit.prism(veilNotes, [WHITE, VEIL_BLUE, LAVENDER]);
kit.add("veilNotes", veilNotes);

const veilSparkle = kit.spray([333, 1], kit.tex(407, 1), FOE, { radius: 1.3, speed: 0, count: 1, bursts: SHOW / 6, gap: 6, life: 9, scale: 0.4, shape: "ball" });
veilSparkle.startDelayFrames = 5;
setCurves(veilSparkle, twinkle(1.1), twinkle(1));
kit.prism(veilSparkle, [WHITE, CREAM, PINK]);
kit.add("veilSparkle", veilSparkle);

// --- 3. the note pulses ---
const NOTE_LIFE = PULSES * PULSE_GAP + 6;
const note = kit.parked(clefTex, [FOE[0], FOE[1] + 0.2, FOE[2] + 0.15], 0.75, NOTE_LIFE);
note.startDelayFrames = VEIL - 4;
setCurves(note, { start: 0.75, mid: 1.3, end: 0.8, curveIn: 0.2, curveOut: 0.6 }, fadeInOut(1, 0.1, 0.85));
shimmer(note, [PINK, WHITE, PINK], PULSE_GAP); // sets the loop pace: one beat per pulse
note.scaleAnim!.loop = true; // the note swells on every beat
kit.add("note", note);

function pulseRings(tex: number, scale: number, delay: number, colours: [Rgb, Rgb, Rgb]): ReturnType<typeof kit.spray> {
  const r = kit.spray([333, 1], tex, FOE, { radius: 0, speed: 0, count: 1, bursts: PULSES, gap: PULSE_GAP, life: 10, scale, shape: "point" });
  r.startDelayFrames = VEIL + delay;
  setCurves(r, grow(0.25, 0.6, 1.25), fadeOut(1, 0.35));
  kit.prism(r, colours);
  return r;
}
kit.add("ringsGold", pulseRings(kit.tex(560, 1), 1.3, 0, [GOLD, CREAM, WHITE]));
kit.add("ringsThin", pulseRings(kit.tex(298, 2), 1.7, 2, [MINT, PINK, SKY]));

const flecks = kit.spray([228, 3], kit.tex(606, 3), FOE, { radius: 0.9, speed: 0.3, count: 4, bursts: PULSES, gap: PULSE_GAP, life: 10, scale: 0.4, directional: true });
flecks.startDelayFrames = VEIL;
setCurves(flecks, undefined, fadeOut(1, 0.5));
paint(flecks, WHITE, WHITE, CREAM);
kit.add("flecks", flecks);

const motes = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 1.2, speed: 0.08, count: 3, bursts: PULSES, gap: PULSE_GAP, life: 12, scale: 0.12, shape: "ball" });
motes.startDelayFrames = VEIL;
setCurves(motes, undefined, twinkle());
kit.prism(motes, [WHITE, CREAM, PINK]);
kit.add("motes", motes);

// --- script ---
const emits = (names: string[], who: "ATTACKER" | "DEFENDER") => names.map((n) => kit.emit(n, who)).join("\n");
const pulseAt = SING + PAN + VEIL;
const pulseSounds = Array.from({ length: PULSES }, (_, i) => `PlaySound 1816, SE${i % 2 ? 1 : 2}, 16, ${pulseAt + i * PULSE_GAP}, ${200 + i * 250}, ${112 + i * 6}, 0, 0, 0`).join("\n");
const pulseHits = Array.from({ length: PULSES }, (_, i) => `ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, ${i === PULSES - 1 ? 1638 : 1229}, 0, 2, 0, 2${i === PULSES - 1 ? "\nShakeScreen VERTICAL, 0.5x, 0, 2, 0, 4" : ""}
Wait ${PULSE_GAP}`).join("\n");
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1523, SE1, 14, 0, 0, 115, 0, 0, 0
PlaySound 1783, SE2, 14, ${SING + PAN}, 0, 105, 0, 0, 0
PlaySound 1509, SE1, 14, ${SING + PAN + 6}, 600, 95, 0, 0, 0
${pulseSounds}
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 2, 31, 20, 28
${kit.emit("waves", "ATTACKER")}
Wait ${SING}
ChangeSpriteColor ATTACKER, 8, 0, 2, 31, 20, 28
MoveCamera INTERPOLATION, DEFENDER, ${PAN}, 0, 8
Wait ${PAN}
${emits(["veil", "pool", "veilNotes", "veilSparkle", "note", "ringsGold", "ringsThin", "flecks", "motes"], "DEFENDER")}
Wait ${VEIL}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 10, 1, 31, 18, 28
${pulseHits}
ChangeSpriteColor DEFENDER, 10, 0, 3, 31, 18, 28
Wait ${AFTER}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [47, 113, 129, 400, 427, 605],
  references: ["reference/Alluring_Voice_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("veil")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("note")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("ringsGold")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
const veilAt = CAMERA_IN + SING + PAN;
console.log(`  call f${CAMERA_IN}, veil f${veilAt}, note pulses f${veilAt + VEIL}/+${PULSE_GAP}/+${2 * PULSE_GAP}`);
