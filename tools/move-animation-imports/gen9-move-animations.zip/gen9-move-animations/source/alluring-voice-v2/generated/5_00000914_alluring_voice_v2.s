MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 907
AudioContainer CONTINUE
PlaySound 1523, SE1, 14, 0, 0, 115, 0, 0, 0
PlaySound 1783, SE2, 14, 18, 0, 105, 0, 0, 0
PlaySound 1509, SE1, 14, 24, 600, 95, 0, 0, 0
PlaySound 1816, SE2, 16, 36, 200, 112, 0, 0, 0
PlaySound 1816, SE1, 16, 45, 450, 118, 0, 0, 0
PlaySound 1816, SE2, 16, 54, 700, 124, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 2, 31, 20, 28
Emit 907, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 10
ChangeSpriteColor ATTACKER, 8, 0, 2, 31, 20, 28
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
Emit 907, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 907, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 907, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 907, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 907, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 907, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 907, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 907, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 907, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 18
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 10, 1, 31, 18, 28
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 2
Wait 9
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 2
Wait 9
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 0, 2
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 4
Wait 9
ChangeSpriteColor DEFENDER, 10, 0, 3, 31, 18, 28
Wait 14
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
