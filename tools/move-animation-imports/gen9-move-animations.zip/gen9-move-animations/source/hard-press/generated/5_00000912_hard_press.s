MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 905
AudioContainer CONTINUE
PlaySound 1560, SE1, 14, 0, -300, 115, 0, 0, 0
PlaySound 1442, SE2, 14, 18, -600, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 2, 24, 26, 31
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 6
Wait 14
ChangeSpriteColor ATTACKER, 10, 0, 1, 24, 26, 31
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 4
Emit 905, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 905, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 6
Emit 905, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 905, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 905, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 905, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
AudioContainer CONTINUE
PlaySound 1413, SE1, 16, 0, -400, 127, 0, 0, 0
PlaySound 1884, SE2, 16, 0, 0, 127, 0, 0, 0
PlaySound 1442, SE2, 16, 6, -300, 120, 0, 0, 0
PlaySound 1475, SE1, 16, 6, -600, 115, 0, 0, 0
AudioContainer SUSPEND
Emit 905, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 905, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 905, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 905, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 905, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeBackgroundColor 4, 0, 10, 0, 31, 31, 31
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 31, 28
ScaleSprite DEFENDER, ROUNDTRIP, -1638, 410, 6, 0, 1
ShakeScreen HORIZON, 1x, 0, 1, 0, 3
Wait 3
ChangeBackgroundColor 4, 10, 0, 1, 31, 31, 31
Wait 9
ChangeSpriteColor DEFENDER, 14, 0, 2, 31, 31, 28
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen HORIZON, 2458, 0, 2, 0, 8
Wait 22
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
