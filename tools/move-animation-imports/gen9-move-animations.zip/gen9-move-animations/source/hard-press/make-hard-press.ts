import { createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Hard Press (move 912) - from Bulbapedia's still (reference/).
//   Two giant steel press plates on hydraulic rams close on the foe from
//   both sides and sandwich it - they stop either side of it, they do not
//   meet - squeezing it slimmer for a moment (Logan, 2026-10-01); a
//   white-gold flash bursts between them and prismatic sparks fly. Then the
//   plates draw back.
// The power depending on the foe's HP is handled by the engine.
//
// The press is drawn here (64x64 a3i5: a tall rounded steel plate with two
// rams running back from it; generated/texture-press.png), mirrored for the
// other side.

const SPA = 905;
const kit = await createKit({ workDir: import.meta.dirname, slug: "hard-press", moveId: 912, spaId: SPA, donors: [228, 579, 465, 411, 333] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const WIND = 14;
const PAN = 10;
const CLOSE = 6;
const SQUEEZE = 12; // the foe is held, squeezed slim and released
const HOLD = 22;

const FOE: Vec3 = [0, 0.3, 0.8];
// A particle's scale is its half-extent, and the plate's face is 0.625 of
// that from the texture's centre. At scale 2.4 the face sits 1.5 from the
// quad's centre, so a centre 2.35 out leaves the faces 0.85 either side of
// the foe.
const PRESS_SCALE = 2.4;
const START_X = 5.6;
const END_X = 2.35;

const STEEL: Rgb = [0.75, 0.82, 0.95];
const PALE: Rgb = [1.0, 0.97, 0.85];
const GOLD: Rgb = [1.0, 0.8, 0.35];
const WHITE: Rgb = [1, 1, 1];

// --- the drawn press ---
const pressTex = await kit.drawn("press", 64, 64, "a3i5", (x, y) => {
  const px = x + 0.5;
  const py = y + 0.5;
  // Plate: x 40..52, y 3..61, rounded ends.
  const inPlate = px >= 40 && px <= 52 && py >= 3 && py <= 61 && !(py < 7 && Math.hypot(px - 46, py - 7) > 6.5) && !(py > 57 && Math.hypot(px - 46, py - 57) > 6.5);
  if (inPlate) {
    if (px < 41.3 || px > 50.7 || py < 4.3 || py > 59.7) return [60, 66, 104];
    if (px < 44) return [250, 252, 255];
    if (px < 47) return [196, 210, 240];
    return [120, 136, 190];
  }
  // Rams: two rods from x 2 to 40 at y 18..25 and 39..46, with collars.
  for (const top of [18, 39]) {
    if (py >= top && py <= top + 7 && px >= 2 && px < 40) {
      if (py < top + 1.2 || py > top + 5.8) return [60, 66, 104];
      const collar = px < 8 || (px > 30 && px < 34);
      if (collar) return py < top + 3.5 ? [220, 226, 245] : [130, 140, 180];
      return py < top + 3 ? [236, 240, 255] : py < top + 4.6 ? [170, 182, 220] : [110, 120, 168];
    }
  }
  return undefined;
});

// --- the press closing ---
function plate(side: 1 | -1): ReturnType<typeof kit.parked> {
  const r = kit.parked(pressTex, [FOE[0] - side * START_X, FOE[1], FOE[2] + 0.4], PRESS_SCALE, CLOSE);
  r.flipTextureS = side === -1;
  r.axis = [side, 0, 0];
  r.initVelAxisAmplifier = (START_X - END_X) / CLOSE;
  r.airResistance = 1.0;
  // It rides in for CLOSE frames and vanishes; a parked twin (shut) takes
  // over where it stops.
  r.particleLifeFrames = CLOSE;
  setCurves(r, hold(1), hold(1));
  paint(r, WHITE);
  return r;
}
kit.add("pressL", plate(1));
kit.add("pressR", plate(-1));

// Clamped either side of the foe for the squeeze...
function shut(side: 1 | -1): ReturnType<typeof kit.parked> {
  const r = kit.parked(pressTex, [FOE[0] - side * END_X, FOE[1], FOE[2] + 0.4], PRESS_SCALE, SQUEEZE + 1);
  r.flipTextureS = side === -1;
  setCurves(r, hold(1), hold(1));
  paint(r, WHITE);
  return r;
}
kit.add("shutL", shut(1));
kit.add("shutR", shut(-1));

// ...then drawing back and fading.
function retract(side: 1 | -1): ReturnType<typeof kit.parked> {
  const r = kit.parked(pressTex, [FOE[0] - side * END_X, FOE[1], FOE[2] + 0.4], PRESS_SCALE, 9);
  r.startDelayFrames = SQUEEZE;
  r.flipTextureS = side === -1;
  r.axis = [-side, 0, 0];
  r.initVelAxisAmplifier = 0.22;
  setCurves(r, hold(1), fadeOut(1, 0.3));
  paint(r, WHITE);
  return r;
}
kit.add("retractL", retract(1));
kit.add("retractR", retract(-1));

// --- impact ---
const flash = kit.parked(kit.tex(228, 1), FOE, 1.5, 14);
spin(flash, 0.05);
setCurves(flash, grow(0.4, 0.2, 2.2), fadeOut(1, 0.35));
paint(flash, PALE, WHITE, GOLD);
kit.add("flash", flash);

const core = kit.parked(kit.tex(465, 1), FOE, 2.2, 14);
core.aspectRatio = 0.4;
setCurves(core, grow(0.5, 0.2, 1.2), fadeOut(1, 0.4));
paint(core, WHITE, WHITE, GOLD);
kit.add("core", core);

const spiky = kit.parked(kit.tex(579, 2), FOE, 1.2, 12);
spin(spiky, 0.12);
setCurves(spiky, grow(0.4, 0.25, 1.5), fadeOut(1, 0.35));
paint(spiky, WHITE, WHITE, PALE);
kit.add("spiky", spiky);

function prismatic(colours: [Rgb, Rgb, Rgb]): ReturnType<typeof kit.spray> {
  const r = kit.spray([228, 3], kit.tex(333, 0), FOE, { radius: 0.4, speed: 0.55, count: 8, life: 14, scale: 0.65, directional: true });
  r.aspectRatio = 0.45;
  setCurves(r, undefined, fadeOut(1, 0.5));
  kit.prism(r, colours);
  return r;
}
kit.add("prismWarm", prismatic([[1.0, 0.4, 0.3], [1.0, 0.9, 0.35], [1.0, 0.6, 0.2]]));
kit.add("prismCool", prismatic([[0.35, 0.9, 1.0], [0.5, 0.55, 1.0], [0.9, 0.95, 1.0]]));

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1560, SE1, 14, 0, -300, 115, 0, 0, 0
PlaySound 1442, SE2, 14, ${WIND + PAN - CLOSE}, -600, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 2, 24, 26, 31
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 6
Wait ${WIND}
ChangeSpriteColor ATTACKER, 10, 0, 1, 24, 26, 31
MoveCamera INTERPOLATION, DEFENDER, ${PAN}, 0, 8
Wait ${PAN - CLOSE}
${kit.emit("pressL", "DEFENDER")}
${kit.emit("pressR", "DEFENDER")}
Wait ${CLOSE}
${kit.emit("shutL", "DEFENDER")}
${kit.emit("shutR", "DEFENDER")}
${kit.emit("retractL", "DEFENDER")}
${kit.emit("retractR", "DEFENDER")}
AudioContainer CONTINUE
PlaySound 1413, SE1, 16, 0, -400, 127, 0, 0, 0
PlaySound 1884, SE2, 16, 0, 0, 127, 0, 0, 0
PlaySound 1442, SE2, 16, ${SQUEEZE / 2}, -300, 120, 0, 0, 0
PlaySound 1475, SE1, 16, ${SQUEEZE / 2}, -600, 115, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("flash", "DEFENDER")}
${kit.emit("core", "DEFENDER")}
${kit.emit("spiky", "DEFENDER")}
${kit.emit("prismWarm", "DEFENDER")}
${kit.emit("prismCool", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeBackgroundColor 4, 0, 10, 0, 31, 31, 31
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 31, 28
ScaleSprite DEFENDER, ROUNDTRIP, -1638, 410, ${SQUEEZE / 2}, 0, 1
ShakeScreen HORIZON, 1x, 0, 1, 0, 3
Wait 3
ChangeBackgroundColor 4, 10, 0, 1, 31, 31, 31
Wait ${SQUEEZE - 3}
ChangeSpriteColor DEFENDER, 14, 0, 2, 31, 31, 28
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen HORIZON, 2458, 0, 2, 0, 8
Wait ${HOLD}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [484, 231, 63, 400, 605],
  references: ["reference/Hard_Press_IX.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 0, DEFENDER`, `Emit ${SPA}, 2, DEFENDER`, "ShakeScreen HORIZON, 2458", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  press lands f${CAMERA_IN + WIND + PAN}, squeeze ${SQUEEZE}f`);
