import { createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Mighty Cleave (move 910) - from Bulbapedia's stills (reference/).
//   1. Golden light gathers on the user.
//   2. A sweeping golden slash across the foe: gold streaks, golden crystal
//      spikes jutting up, dark rock chunks bursting out, big four-point
//      star glints and orange embers.
// The ignoring of Protect is handled by the engine.
//
// Drawn here: a rock chunk (32x32 a3i5: dark faceted rock with gold-lit
// edges; generated/texture-rock.png).

const SPA = 903;
const kit = await createKit({ workDir: import.meta.dirname, slug: "mighty-cleave", moveId: 910, spaId: SPA, donors: [228, 321, 333, 407, 465, 411] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const FORGE = 24;
const SWING = 8;
const HIT_STOP = 4;
const HOLD = 24;

const USER: Vec3 = [0, 0.3, 0.2];
const BLADE: Vec3 = [0.3, 0.2, -0.5];
const FOE: Vec3 = [0, 0.3, 0.8];

const GOLD: Rgb = [1.0, 0.78, 0.25];
const YELLOW: Rgb = [1.0, 0.92, 0.45];
const PALE: Rgb = [1.0, 0.97, 0.8];
const ORANGE: Rgb = [1.0, 0.52, 0.15];
const WHITE: Rgb = [1, 1, 1];

// --- drawn textures ---
type P = [number, number];
const inPoly = (x: number, y: number, poly: P[]) => {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i]!;
    const [xj, yj] = poly[j]!;
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
};
const nearEdge = (px: number, py: number, poly: P[], width: number) =>
  poly.some((a, i) => {
    const b = poly[(i + 1) % poly.length]!;
    const dx = b[0] - a[0];
    const dy = b[1] - a[1];
    const t = Math.max(0, Math.min(1, ((px - a[0]) * dx + (py - a[1]) * dy) / (dx * dx + dy * dy)));
    return Math.hypot(px - (a[0] + dx * t), py - (a[1] + dy * t)) < width;
  });

const rock: P[] = [[5, 11], [15, 4], [27, 9], [29, 22], [18, 29], [6, 24]];
const rockTex = await kit.drawn("rock", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5;
  const py = y + 0.5;
  if (!inPoly(px, py, rock)) return undefined;
  if (nearEdge(px, py, rock, 1.1)) return py < 16 ? [255, 214, 120] : [170, 120, 60];
  if (inPoly(px, py, [rock[0]!, rock[1]!, rock[2]!, [16, 15]])) return [120, 94, 70];
  if (inPoly(px, py, [rock[2]!, rock[3]!, rock[4]!, [16, 15]])) return [70, 54, 42];
  return [92, 72, 56];
});

// --- gathering light ---
const glow = kit.parked(kit.tex(465, 1), BLADE, 3.0, FORGE + 4);
setCurves(glow, grow(0.3, 0.4, 1.1), fadeInOut(0.75, 0.3, 0.8));
paint(glow, GOLD, PALE, ORANGE);
kit.add("glow", glow);

// (A large drawn crystal blade stood over the user here; removed at Logan's
// request, 2026-10-01. The gold glow, gathering motes and gleam remain.)
const gather = kit.spray([333, 1], kit.tex(333, 0), BLADE, { radius: 2.0, speed: 0, count: 1, bursts: 10, gap: 2, life: 10, scale: 0.13, shape: "sphere" });
gather.behaviors = [{ type: "convergence", target: [0, 0, 0], force: 0.12 }];
setCurves(gather, undefined, twinkle());
kit.prism(gather, [GOLD, WHITE, YELLOW]);
kit.add("gather", gather);

const gleam = kit.parked(kit.tex(407, 1), [1.1, 0.8, -0.6], 0.9, 12);
gleam.startDelayFrames = FORGE - 10;
spin(gleam, 0.08, 0.08, deg(20));
setCurves(gleam, twinkle(1.3), twinkle(1));
paint(gleam, WHITE, WHITE, YELLOW);
kit.add("gleam", gleam);

// --- the cleave ---
function slash(scale: number, aspect: number, angle: number, offset: Vec3, delay: number, colour: Rgb, start: Rgb): ReturnType<typeof kit.parked> {
  const r = kit.parked(kit.tex(333, 2), [FOE[0] + offset[0], FOE[1] + offset[1], FOE[2] + offset[2]], scale, 12);
  r.startDelayFrames = delay;
  r.aspectRatio = aspect;
  r.initAngle = angle;
  setCurves(r, grow(0.15, 0.2, 1.05), fadeOut(1, 0.45));
  paint(r, colour, start, colour);
  return r;
}
kit.add("slashA", slash(3.8, 0.45, deg(-75), [0, 0.2, 0], 0, GOLD, WHITE));
kit.add("slashB", slash(3.4, 0.25, deg(-80), [0, -0.3, 0.05], 1, PALE, WHITE));
kit.add("slashC", slash(3.0, 0.3, deg(-70), [0, 0.6, 0.05], 2, ORANGE, YELLOW));

const flash = kit.parked(kit.tex(228, 1), FOE, 1.7, 12);
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.2, 1.9), fadeOut(1, 0.35));
paint(flash, PALE, WHITE, GOLD);
kit.add("flash", flash);

const spikes = kit.spray([228, 3], kit.tex(321, 6), [0, -1.5, 0.8], { radius: 1.6, speed: 0, count: 7, life: 14, scale: 0.9, shape: "circle", directional: true });
spikes.emissionAxis = 1;
spikes.axis = [0, 1, 0];
spikes.initVelAxisAmplifier = 0.2;
spikes.airResistance = 0.8;
setCurves(spikes, grow(0.3, 0.25, 1.4), fadeInOut(1, 0.1, 0.6));
kit.prism(spikes, [GOLD, YELLOW, PALE]);
kit.add("spikes", spikes);

const chunks = kit.spray([333, 1], rockTex, FOE, { radius: 0.5, speed: 0.3, count: 7, life: 18, scale: 0.55 });
chunks.axis = [0, 1, 0];
chunks.initVelAxisAmplifier = 0.12;
chunks.behaviors = [{ type: "gravity", magnitude: [0, -0.02, 0] }];
spin(chunks, -0.2, 0.2, 0, true);
setCurves(chunks, grow(0.5, 0.15, 0.85), fadeOut(1, 0.6));
paint(chunks, WHITE);
kit.add("chunks", chunks);

const stars = kit.spray([333, 1], kit.tex(407, 1), FOE, { radius: 1.6, speed: 0.02, count: 1, bursts: 3, gap: 4, life: 10, scale: 0.8, shape: "ball" });
setCurves(stars, twinkle(1.2), twinkle(1));
paint(stars, WHITE, WHITE, YELLOW);
kit.add("stars", stars);

const embers = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.5, speed: 0.3, count: 6, life: 14, scale: 0.12 });
embers.behaviors = [{ type: "gravity", magnitude: [0, -0.01, 0] }];
setCurves(embers, undefined, twinkle());
kit.prism(embers, [ORANGE, YELLOW, ORANGE]);
kit.add("embers", embers);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1509, SE1, 14, 0, -200, 100, 0, 0, 0
PlaySound 1816, SE2, 14, 8, -400, 100, 0, 0, 0
PlaySound 1421, SE2, 14, ${FORGE - 2}, -300, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${SWING}, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 2, 31, 26, 10
${kit.emit("glow", "ATTACKER")}
${kit.emit("gather", "ATTACKER")}
${kit.emit("gleam", "ATTACKER")}
Wait ${FORGE}
ChangeSpriteColor ATTACKER, 8, 0, 1, 31, 26, 10
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, ${SWING}, 0, 8
Wait ${SWING}
AudioContainer CONTINUE
PlaySound 1514, SE1, 16, 0, 0, 127, 0, 0, 0
PlaySound 1413, SE2, 16, 0, -300, 125, 0, 0, 0
PlaySound 1475, SE1, 16, ${HIT_STOP + 1}, -500, 115, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("slashA", "DEFENDER")}
${kit.emit("slashB", "DEFENDER")}
${kit.emit("slashC", "DEFENDER")}
${kit.emit("flash", "DEFENDER")}
${kit.emit("spikes", "DEFENDER")}
${kit.emit("chunks", "DEFENDER")}
${kit.emit("stars", "DEFENDER")}
${kit.emit("embers", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 13, 0, 31, 26, 12
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 13, 0, 1, 31, 26, 12
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 7
Wait ${HOLD - HIT_STOP}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [163, 400, 153, 236, 605, 63],
  references: ["reference/Mighty_Cleave_IX.png", "reference/Mighty_Cleave_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("gather")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("slashA")}, DEFENDER`, "ShakeScreen VERTICAL, 1x", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  forge f${CAMERA_IN}-${CAMERA_IN + FORGE}, cleave f${CAMERA_IN + FORGE + SWING}`);
