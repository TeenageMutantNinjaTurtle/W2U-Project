import assert from "node:assert/strict";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import {
  parseSpaArchive,
  serializeSpaArchive,
  type SpaArchive,
  type SpaResource,
  type SpaTexture,
} from "../../Pokeweb-Serverless/src/pokeweb/nitroSpa";

// Armor Cannon, second take (move 890) - rebuilt from keyframes of the
// Scarlet/Violet animation, with extra weight for a 120-power signature move.
//
// Keyframes, in order:
//   1. Start       - translucent orange sphere at the arm cannon, white-hot
//                    core, yellow lobes inside, an orange crescent streak, embers.
//   2. Max windup  - the sphere swells huge and pales to cream.
//   3. Condense    - it collapses into a white-hot orb with star-glare rays.
//   4. Fire        - a big pale shockwave ring round the user, a puffy blast
//                    cloud, orange spikes; the user recoils.
//   5. Travel      - a wide beam, white core, orange speed streaks, orange-red
//                    smoke puffing off its edges.
//   6. Impact      - full-screen burst: radial yellow/orange streaks, a white
//                    core, crossing yellow ring arcs, an ember field.
// Requested on top: a held pause after the condense, then the beam; screen
// shakes and flashes on the shot and the hit.
//
// Donors (all white A5I3 masks, so every colour here is painted, not mixed):
//   SPA 606 Psycho Cut  - res 0 (soft held disc) is the shell for every parked
//                         layer; textures: soft disc, clumpy cluster (the
//                         sphere's lobes), crescent.
//   SPA 333 Slash       - res 1 throws glow dots off a sphere: embers.
//   SPA 228 Hyper Beam  - res 0 is the beam (a stream of stretched sunbursts
//                         fired along an aimed axis); res 3 throws directional
//                         sparks off the user. Its sunburst also makes the glare.
//   SPA 321 Explosion   - res 5 draws embers inward (convergence): the energy
//                         sucked into the orb during the pause. Textures: puff
//                         cloud (blast and smoke) and tapered spike (radial
//                         streaks).
//   SPA 407 Moonlight   - texture: four-point star (the glint on the orb).
//   SPA 411 Rain Dance  - res 0 is a hair-thin directional streak: speed lines.
//   SPA 560 Lucky Chant - texture: clean hoop (sphere rim, shockwave, impact
//                         ring arcs).

const WORK_DIR = import.meta.dirname;
const OUT_DIR = path.join(WORK_DIR, "generated");
const DONOR_DIR = path.join(WORK_DIR, "../armor-cannon-v2-donors");

const MOVE_ID = 890;
const OUTPUT_SPA_ID = 845;

const OUT_SCRIPT = path.join(OUT_DIR, `5_${String(MOVE_ID).padStart(8, "0")}_armor_cannon.s`);
const OUT_SPA = path.join(OUT_DIR, `6_${String(OUTPUT_SPA_ID).padStart(8, "0")}.bin`);

type Rgb = [number, number, number];
type Vec3 = [number, number, number];

// --- timing (30 fps) ---------------------------------------------------------
const CAMERA_IN = 16;
const WINDUP = 40; // sphere on screen
const COLLAPSE = 6; // its last frames, snapping shut into the orb
const SWELL = WINDUP - COLLAPSE; // steady swell to max windup
const PAUSE = 20; // held, blazing orb before the shot (~0.67 s)
const BEAM_SPEED = 1.25; // units/frame; ~14.5 units cannon -> foe
const BEAM_TRAVEL = 12;
const BEAM_EMIT = 22; // frames the cannon pours the beam
const KICK_HOLD = 6; // camera holds on the shot before the whip-pan
const IMPACT_HOLD = 30;

const FIRE_FRAME = CAMERA_IN + SWELL + COLLAPSE + PAUSE;
const IMPACT_FRAME = FIRE_FRAME + BEAM_TRAVEL;

// --- placement ---------------------------------------------------------------
// The cannon mouth: in front of the user toward the foe, at chest height.
const CANNON: Vec3 = [0, 0.3, -1.5];
// Impact layers sit on the camera side of the foe so they draw over it.
const IMPACT: Vec3 = [0, 0.2, 0.8];
const SPHERE_MAX = 2.3; // max-windup sphere: about the user's height
const SPHERE_START = 0.35; // fraction of max when it first appears

// --- palette -----------------------------------------------------------------
const CORAL: Rgb = [1.0, 0.5, 0.36];
const PEACH: Rgb = [1.0, 0.72, 0.55];
const CREAM: Rgb = [1.0, 0.93, 0.82];
const RIM_ORANGE: Rgb = [1.0, 0.66, 0.35];
const LOBE_YELLOW: Rgb = [1.0, 0.86, 0.45];
const WHITE_HOT: Rgb = [1.0, 1.0, 0.92];
const PALE_YELLOW: Rgb = [1.0, 0.96, 0.7];
const CRESCENT_ORANGE: Rgb = [1.0, 0.72, 0.2];
const EMBER: Rgb = [1.0, 0.62, 0.12];
const EMBER_DEEP: Rgb = [1.0, 0.3, 0.05];
const SHOCK_PINK: Rgb = [1.0, 0.86, 0.84];
const BLAST_WHITE: Rgb = [1.0, 0.92, 0.88];
const SPIKE_ORANGE: Rgb = [1.0, 0.58, 0.12];
const SPIKE_YELLOW: Rgb = [1.0, 0.88, 0.3];
const BEAM_ORANGE: Rgb = [1.0, 0.56, 0.12];
const BEAM_YELLOW: Rgb = [1.0, 0.84, 0.35];
const BEAM_DEEP: Rgb = [1.0, 0.42, 0.06];
const SMOKE_RED: Rgb = [0.95, 0.34, 0.1];
const SMOKE_DARK: Rgb = [0.62, 0.14, 0.05];
const RING_YELLOW: Rgb = [1.0, 0.9, 0.32];

await mkdir(OUT_DIR, { recursive: true });

const load = async (name: string) => parseSpaArchive(new Uint8Array(await readFile(path.join(DONOR_DIR, name))));
const psychoCut = await load("spa_606.spa");
const slash = await load("spa_333.spa");
const hyperBeam = await load("spa_228.spa");
const explosion = await load("spa_321.spa");
const moonlight = await load("spa_407.spa");
const rainDance = await load("spa_411.spa");
const luckyChant = await load("spa_560.spa");
assert.equal(psychoCut.resources.length, 4, "Unexpected Psycho Cut SPA");
assert.equal(slash.resources.length, 4, "Unexpected Slash SPA");
assert.equal(hyperBeam.resources.length, 4, "Unexpected Hyper Beam SPA");
assert.equal(explosion.resources.length, 7, "Unexpected Explosion SPA");
assert.equal(rainDance.resources.length, 1, "Unexpected Rain Dance SPA");

// --- texture table -----------------------------------------------------------

const TEX = { disc: 0, lobes: 1, crescent: 2, dot: 3, hoop: 4, sunburst: 5, star: 6, puff: 7, spike: 8, streak: 9 } as const;
const TEXTURE_SOURCES: Array<{ donor: SpaArchive; index: number; label: string }> = [
  { donor: psychoCut, index: 1, label: "soft disc" },
  { donor: psychoCut, index: 2, label: "clumpy cluster" },
  { donor: psychoCut, index: 3, label: "crescent" },
  { donor: slash, index: 0, label: "glow dot" },
  { donor: luckyChant, index: 1, label: "clean hoop" },
  { donor: hyperBeam, index: 1, label: "sunburst" },
  { donor: moonlight, index: 1, label: "four-point star" },
  { donor: explosion, index: 5, label: "puff cloud" },
  { donor: explosion, index: 6, label: "tapered spike" },
  { donor: rainDance, index: 0, label: "thin streak" },
];
assert.equal(TEXTURE_SOURCES.length, Object.keys(TEX).length, "Texture table and index map disagree");
const textures: SpaTexture[] = TEXTURE_SOURCES.map((source, index) => {
  const texture = source.donor.textures[source.index];
  assert.ok(texture, `Donor texture ${source.index} (${source.label}) is missing`);
  assert.equal(texture.useSharedTexture, false, `Texture ${source.label} is shared`);
  assert.equal(texture.format, 6, `Texture ${source.label} is not A5I3; a tint would multiply, not paint`);
  const clone = structuredClone(texture);
  clone.index = index;
  return clone;
});

// --- builders ----------------------------------------------------------------

interface Curve3 { start: number; mid: number; end: number; curveIn: number; curveOut: number }

function retexture(resource: SpaResource, textureIndex: number): void {
  resource.textureIndex = textureIndex;
  if (resource.texAnim) resource.texAnim.textures = resource.texAnim.textures.map(() => textureIndex);
  delete resource.childResource;
}

function setCurves(resource: SpaResource, scale: Curve3 | undefined, alpha: Curve3): void {
  assert.ok(resource.alphaAnim, "Donor shell lost its alpha curve");
  if (scale) {
    assert.ok(resource.scaleAnim, "Donor shell lost its scale curve");
    Object.assign(resource.scaleAnim, scale, { loop: false });
  }
  Object.assign(resource.alphaAnim, alpha, { loop: false });
  resource.loopFrames = 1;
}

function paint(resource: SpaResource, base: Rgb, start: Rgb, end: Rgb, peak = 0.3): void {
  assert.ok(resource.colorAnim, "Donor shell lost its colour curve");
  resource.color = [...base];
  Object.assign(resource.colorAnim, { start: [...start], end: [...end], curveIn: 0, curvePeak: peak, curveOut: 1, interpolate: true, loop: false, randomStartColor: false });
}

function spin(resource: SpaResource, rate: number, startAngle = 0): void {
  resource.hasRotation = rate !== 0;
  resource.minRotation = rate;
  resource.maxRotation = rate;
  resource.randomInitAngle = false;
  resource.initAngle = startAngle;
}

/** One parked billboard on Psycho Cut's held disc: no emission shape, no motion. */
function parked(textureIndex: number, pos: Vec3, scale: number, life: number): SpaResource {
  const resource = structuredClone(psychoCut.resources[0]!);
  retexture(resource, textureIndex);
  Object.assign(resource, {
    emissionType: 0, emissionAxis: 0, radius: 0, axis: [0, 1, 0],
    initVelAxisAmplifier: 0, initVelPosAmplifier: 0, airResistance: 1.0,
    followEmitter: false, behaviors: [], emitterBasePos: [...pos],
    baseScale: scale, aspectRatio: 1, particleLifeFrames: life,
    emitterLifeFrames: 1, emissionCount: 1, emissionIntervalFrames: 1, startDelayFrames: 0,
  });
  spin(resource, 0);
  return resource;
}

/** A burst of particles thrown off a sphere round `pos`. */
function burst(donor: SpaResource, textureIndex: number, pos: Vec3, opts: { radius: number; speed: number; count: number; bursts?: number; gap?: number; life: number; scale: number }): SpaResource {
  const resource = structuredClone(donor);
  retexture(resource, textureIndex);
  Object.assign(resource, {
    emissionType: 1, emissionAxis: 0, radius: opts.radius, emitterBasePos: [...pos], axis: [0, 1, 0],
    initVelAxisAmplifier: 0, initVelPosAmplifier: opts.speed, followEmitter: false,
    emissionCount: opts.count, emitterLifeFrames: Math.max(1, ((opts.bursts ?? 1) - 1) * (opts.gap ?? 1) + 1),
    emissionIntervalFrames: opts.gap ?? 1, particleLifeFrames: opts.life, baseScale: opts.scale, startDelayFrames: 0,
  });
  return resource;
}

/** Fired along an axis the VM aims at the foe (Emit ..., ATTACKER, DEFENDER). */
function aimed(resource: SpaResource, speed: number, life: number): void {
  resource.axis = [1, 0, 0];
  resource.initVelAxisAmplifier = speed;
  resource.particleLifeFrames = life;
  resource.followEmitter = false;
}

// --- windup ------------------------------------------------------------------
// Every sphere layer shares one life: swell steadily for SWELL frames, then
// snap shut over COLLAPSE frames as the orb takes over.
const swellTo = (startFraction: number, endFraction = 0.05): Curve3 => ({ start: startFraction, mid: 1, end: endFraction, curveIn: SWELL / WINDUP, curveOut: SWELL / WINDUP });
const fadeIn = (level: number): Curve3 => ({ start: 0, mid: level, end: level, curveIn: 0.15, curveOut: 1 });

// The sphere: half-strength so the user shows through, coral paling to cream.
const sphere = parked(TEX.disc, CANNON, SPHERE_MAX, WINDUP);
setCurves(sphere, swellTo(SPHERE_START), fadeIn(0.55));
paint(sphere, PEACH, CORAL, CREAM, 0.45);

// Its rim: a clean hoop just outside it.
const rim = parked(TEX.hoop, CANNON, SPHERE_MAX * 1.02, WINDUP);
setCurves(rim, swellTo(SPHERE_START), fadeIn(0.5));
paint(rim, PEACH, RIM_ORANGE, CREAM, 0.45);

// The lobes round the core, turning slowly.
const lobes = parked(TEX.lobes, CANNON, SPHERE_MAX * 0.55, WINDUP);
spin(lobes, 0.04);
setCurves(lobes, swellTo(SPHERE_START + 0.1), fadeIn(0.85));
paint(lobes, LOBE_YELLOW, LOBE_YELLOW, PALE_YELLOW, 0.5);

// The core: a white-hot dot, growing a little faster than the sphere.
const core = parked(TEX.dot, CANNON, 0.9, WINDUP);
setCurves(core, swellTo(0.25, 0.3), fadeIn(1));
paint(core, WHITE_HOT, WHITE_HOT, WHITE_HOT);

// Crescent streaks rolling round the rim in opposite directions.
function crescent(scale: number, rate: number, startAngle: number): SpaResource {
  const resource = parked(TEX.crescent, CANNON, scale, WINDUP);
  spin(resource, rate, startAngle);
  setCurves(resource, swellTo(SPHERE_START, 0.2), { start: 0, mid: 0.9, end: 0, curveIn: 0.2, curveOut: SWELL / WINDUP });
  paint(resource, CRESCENT_ORANGE, PALE_YELLOW, CRESCENT_ORANGE);
  return resource;
}
const crescentA = crescent(SPHERE_MAX * 1.15, -0.16, 0);
const crescentB = crescent(SPHERE_MAX * 1.05, 0.11, Math.PI);

// Embers drifting up off the sphere's surface.
const embers = burst(slash.resources[1]!, TEX.dot, CANNON, { radius: SPHERE_MAX * 0.7, speed: 0.08, count: 1, bursts: 14, gap: 2, life: 14, scale: 0.16 });
embers.startDelayFrames = 4;
embers.behaviors = [{ type: "gravity", magnitude: [0, 0.004, 0] }];
embers.airResistance = 1.0;
paint(embers, EMBER, [1.0, 0.85, 0.4], EMBER_DEEP);

// --- condense and pause ------------------------------------------------------
// Emitted as the sphere starts to collapse; held through the pause.
const ORB_LIFE = COLLAPSE + PAUSE + 2;
const orbIn = COLLAPSE / ORB_LIFE;

// The orb: arrives large (inside the collapsing sphere) and tightens to a
// small white-hot ball, swelling a touch just before the shot.
const orb = parked(TEX.disc, CANNON, 0.75, ORB_LIFE);
setCurves(orb, { start: 2.2, mid: 1, end: 1.25, curveIn: orbIn, curveOut: 0.8 }, { start: 0, mid: 1, end: 1, curveIn: orbIn * 0.5, curveOut: 1 });
paint(orb, WHITE_HOT, PALE_YELLOW, WHITE_HOT);

// Star-glare rays: Hyper Beam's sunburst, slowly turning, flaring at the end.
const glare = parked(TEX.sunburst, CANNON, 1.5, ORB_LIFE);
spin(glare, 0.03);
setCurves(glare, { start: 0.2, mid: 1, end: 1.35, curveIn: orbIn, curveOut: 0.75 }, { start: 0, mid: 0.95, end: 0.95, curveIn: orbIn, curveOut: 1 });
paint(glare, PALE_YELLOW, WHITE_HOT, PALE_YELLOW);

// The glint: a big four-point star turning the other way.
const glint = parked(TEX.star, CANNON, 1.9, ORB_LIFE);
spin(glint, -0.02, Math.PI / 4);
setCurves(glint, { start: 0.3, mid: 1, end: 1.2, curveIn: orbIn, curveOut: 0.75 }, { start: 0, mid: 0.9, end: 0.9, curveIn: orbIn, curveOut: 1 });
paint(glint, WHITE_HOT, WHITE_HOT, WHITE_HOT);

// Energy drawn in through the pause: Explosion's inward embers.
const converge = structuredClone(explosion.resources[5]!);
retexture(converge, TEX.dot);
assert.ok(converge.behaviors.some((b) => b.type === "convergence"), "Explosion embers lost their convergence");
Object.assign(converge, { emitterBasePos: [...CANNON], radius: 2.4, startDelayFrames: 0, emitterLifeFrames: PAUSE - 6, emissionCount: 2, emissionIntervalFrames: 2, particleLifeFrames: 10, baseScale: 0.5 });
paint(converge, SPIKE_YELLOW, PALE_YELLOW, EMBER);

// --- fire --------------------------------------------------------------------

// The shockwave: a pale hoop round the user, blowing out fast.
const shockwave = parked(TEX.hoop, [0, 0.2, -0.6], 1.2, 12);
setCurves(shockwave, { start: 0.5, mid: 3.0, end: 4.0, curveIn: 0.45, curveOut: 0.45 }, { start: 0.85, mid: 0.6, end: 0, curveIn: 0.3, curveOut: 0.3 });
paint(shockwave, SHOCK_PINK, [1, 1, 1], SHOCK_PINK);

// The blast cloud: puffs pushed out ahead of the cannon.
const blast = burst(psychoCut.resources[0]!, TEX.puff, CANNON, { radius: 0.5, speed: 0.06, count: 5, life: 16, scale: 1.3 });
aimed(blast, 0.3, 16);
blast.airResistance = 0.92;
blast.hasRotation = true;
blast.minRotation = -0.05;
blast.maxRotation = 0.05;
blast.randomInitAngle = true;
setCurves(blast, { start: 0.5, mid: 1.3, end: 1.6, curveIn: 0.3, curveOut: 0.5 }, { start: 0.95, mid: 0.8, end: 0, curveIn: 0.2, curveOut: 0.3 });
paint(blast, BLAST_WHITE, [1, 1, 1], SHOCK_PINK);

// Orange spikes radiating off the cannon: Hyper Beam's user sparks on
// Explosion's tapered spike, pointing the way they fly.
function spikes(pos: Vec3, opts: { count: number; bursts: number; speed: number; life: number; scale: number }): SpaResource {
  const resource = burst(hyperBeam.resources[3]!, TEX.spike, pos, { radius: 0.3, speed: opts.speed, count: opts.count, bursts: opts.bursts, gap: 3, life: opts.life, scale: opts.scale });
  assert.equal(resource.drawType, 1, "Spikes are not directional billboards");
  setCurves(resource, { start: 1.2, mid: 1, end: 0.6, curveIn: 0.3, curveOut: 0.5 }, { start: 1, mid: 1, end: 0, curveIn: 0.3, curveOut: 0.5 });
  paint(resource, SPIKE_ORANGE, SPIKE_YELLOW, SPIKE_ORANGE, 0.4);
  return resource;
}
const fireSpikes = spikes(CANNON, { count: 10, bursts: 1, speed: 0.35, life: 10, scale: 0.35 });

// --- beam --------------------------------------------------------------------
// Hyper Beam's stream, wider and more parallel than Hyper Beam's cone, each
// sunburst dying as it reaches the foe; a narrower white stream rides inside.
function beamStream(scale: number, base: Rgb, start: Rgb, end: Rgb): SpaResource {
  const resource = structuredClone(hyperBeam.resources[0]!);
  retexture(resource, TEX.sunburst);
  assert.equal(resource.drawType, 1, "Beam is no longer a directional billboard");
  aimed(resource, BEAM_SPEED, BEAM_TRAVEL + 1);
  Object.assign(resource, { emitterBasePos: [...CANNON], baseScale: scale, emitterLifeFrames: BEAM_EMIT, emissionIntervalFrames: 2, airResistance: 1.0 });
  setCurves(resource, { start: 0.8, mid: 1.3, end: 1.6, curveIn: 0.5, curveOut: 0.5 }, { start: 1, mid: 1, end: 0.6, curveIn: 0.5, curveOut: 0.7 });
  paint(resource, base, start, end, 0.4);
  return resource;
}
const beam = beamStream(2.2, BEAM_ORANGE, BEAM_YELLOW, BEAM_DEEP);
const beamCore = beamStream(1.1, WHITE_HOT, WHITE_HOT, PALE_YELLOW);

// Smoke: red-orange puffs shed off the beam, slower than it, rising and
// swelling as they thin out.
const smoke = burst(psychoCut.resources[0]!, TEX.puff, CANNON, { radius: 0.9, speed: 0.03, count: 1, bursts: Math.ceil(BEAM_EMIT / 3), gap: 3, life: 16, scale: 1.0 });
aimed(smoke, 0.85, 16);
smoke.behaviors = [{ type: "gravity", magnitude: [0, 0.006, 0] }];
smoke.hasRotation = true;
smoke.minRotation = -0.06;
smoke.maxRotation = 0.06;
smoke.randomInitAngle = true;
setCurves(smoke, { start: 0.6, mid: 1.2, end: 1.7, curveIn: 0.4, curveOut: 0.6 }, { start: 0, mid: 0.85, end: 0, curveIn: 0.2, curveOut: 0.5 });
paint(smoke, SMOKE_RED, BEAM_DEEP, SMOKE_DARK);

// Speed lines: Rain Dance's hair-thin streak, flying faster than the beam.
const streaks = structuredClone(rainDance.resources[0]!);
retexture(streaks, TEX.streak);
assert.equal(streaks.drawType, 1, "Rain streak is no longer a directional billboard");
Object.assign(streaks, { emissionType: 1, emissionAxis: 0, radius: 1.1, emitterBasePos: [...CANNON], initVelPosAmplifier: 0, emitterLifeFrames: BEAM_EMIT, emissionCount: 1, emissionIntervalFrames: 2, startDelayFrames: 0, baseScale: 1.4 });
aimed(streaks, 2.0, 8);
setCurves(streaks, undefined, { start: 0, mid: 1, end: 0, curveIn: 0.2, curveOut: 0.6 });
paint(streaks, SPIKE_YELLOW, PALE_YELLOW, BEAM_ORANGE);

// --- impact ------------------------------------------------------------------

const impactCore = parked(TEX.disc, IMPACT, 1.0, 18);
setCurves(impactCore, { start: 0.5, mid: 2.2, end: 2.6, curveIn: 0.2, curveOut: 0.5 }, { start: 1, mid: 1, end: 0, curveIn: 0.3, curveOut: 0.4 });
paint(impactCore, WHITE_HOT, [1, 1, 1], PALE_YELLOW);

const sunburst = parked(TEX.sunburst, IMPACT, 2.0, 20);
spin(sunburst, 0.05);
setCurves(sunburst, { start: 0.3, mid: 1.5, end: 2.0, curveIn: 0.2, curveOut: 0.5 }, { start: 1, mid: 1, end: 0, curveIn: 0.3, curveOut: 0.45 });
paint(sunburst, PALE_YELLOW, WHITE_HOT, SPIKE_YELLOW);

// One burst: the beam is still pouring in when these fly, and the two
// together must stay inside the DS's 49 particle polygons.
const radial = spikes(IMPACT, { count: 10, bursts: 1, speed: 0.55, life: 12, scale: 0.55 });

// Two hoops squashed to ellipses and tilted opposite ways: the crossing rings.
function ringArc(angleDeg: number, delay: number): SpaResource {
  const resource = parked(TEX.hoop, IMPACT, 1.4, 16);
  resource.aspectRatio = 0.42;
  resource.initAngle = (angleDeg * Math.PI) / 180;
  resource.startDelayFrames = delay;
  setCurves(resource, { start: 0.4, mid: 2.2, end: 2.8, curveIn: 0.35, curveOut: 0.5 }, { start: 1, mid: 1, end: 0, curveIn: 0.3, curveOut: 0.4 });
  paint(resource, RING_YELLOW, WHITE_HOT, SPIKE_ORANGE);
  return resource;
}
const ringA = ringArc(35, 0);
const ringB = ringArc(-35, 2);

const impactEmbers = burst(slash.resources[1]!, TEX.dot, IMPACT, { radius: 0.5, speed: 0.32, count: 7, life: 18, scale: 0.22 });
impactEmbers.behaviors = [{ type: "gravity", magnitude: [0, -0.008, 0] }];
impactEmbers.airResistance = 0.97;
paint(impactEmbers, EMBER, [1.0, 0.9, 0.5], EMBER_DEEP);

const impactSmoke = burst(psychoCut.resources[0]!, TEX.puff, IMPACT, { radius: 0.8, speed: 0.05, count: 4, life: 26, scale: 1.3 });
impactSmoke.startDelayFrames = 4;
impactSmoke.behaviors = [{ type: "gravity", magnitude: [0, 0.004, 0] }];
impactSmoke.hasRotation = true;
impactSmoke.minRotation = -0.04;
impactSmoke.maxRotation = 0.04;
impactSmoke.randomInitAngle = true;
setCurves(impactSmoke, { start: 0.6, mid: 1.3, end: 1.8, curveIn: 0.3, curveOut: 0.6 }, { start: 0, mid: 0.75, end: 0, curveIn: 0.2, curveOut: 0.45 });
paint(impactSmoke, SMOKE_RED, BEAM_ORANGE, SMOKE_DARK);

// --- archive -----------------------------------------------------------------

const RES = {
  sphere: 0, rim: 1, lobes: 2, core: 3, crescentA: 4, crescentB: 5, embers: 6,
  orb: 7, glare: 8, glint: 9, converge: 10,
  shockwave: 11, blast: 12, fireSpikes: 13,
  beam: 14, beamCore: 15, smoke: 16, streaks: 17,
  impactCore: 18, sunburst: 19, radial: 20, ringA: 21, ringB: 22, impactEmbers: 23, impactSmoke: 24,
} as const;
const resources = [
  sphere, rim, lobes, core, crescentA, crescentB, embers,
  orb, glare, glint, converge,
  shockwave, blast, fireSpikes,
  beam, beamCore, smoke, streaks,
  impactCore, sunburst, radial, ringA, ringB, impactEmbers, impactSmoke,
];
assert.equal(resources.length, Object.keys(RES).length, "Resource table and index map disagree");
resources.forEach((resource, index) => {
  resource.index = index;
  assert.ok(resource.textureIndex < textures.length, `Resource ${index} texture index out of range`);
  assert.equal(resource.childResource, undefined, `Resource ${index} kept a donor child`);
});

const archive: SpaArchive = { resourceCount: resources.length, textureCount: textures.length, resources, textures, warnings: [], rawHeader: psychoCut.rawHeader?.slice() };
const spaBytes = serializeSpaArchive(archive);
await writeFile(OUT_SPA, spaBytes);

// --- round-trip checks -------------------------------------------------------

const reparsed = parseSpaArchive(spaBytes);
const built = (index: number) => reparsed.resources[index]!;
const close = (got: readonly number[], want: readonly number[], tol = 0.04) => got.every((v, i) => Math.abs(v - want[i]!) <= tol);
const show = (v: readonly number[]) => `[${v.map((c) => c.toFixed(2)).join(",")}]`;
assert.equal(reparsed.resources.length, resources.length, "Resource count changed on round-trip");
assert.equal(reparsed.textures.length, textures.length, "Texture count changed on round-trip");
for (const [index, resource] of reparsed.resources.entries()) {
  assert.equal(resource.textureIndex, resources[index]!.textureIndex, `Resource ${index} texture index drifted`);
}

// Windup: everything on the cannon, one shared life; the sphere swells to
// max, pales, and snaps shut.
for (const index of [RES.sphere, RES.rim, RES.lobes, RES.core, RES.crescentA, RES.crescentB]) {
  assert.ok(close(built(index).emitterBasePos, CANNON), `Windup layer ${index} sits at ${show(built(index).emitterBasePos)}`);
  assert.equal(built(index).particleLifeFrames, WINDUP, `Windup layer ${index} life drifted`);
}
const builtSphere = built(RES.sphere);
assert.ok(builtSphere.scaleAnim!.start < 0.5 && builtSphere.scaleAnim!.mid === 1 && builtSphere.scaleAnim!.end < 0.1, "Sphere does not swell then collapse");
assert.ok(Math.abs(builtSphere.scaleAnim!.curveIn - SWELL / WINDUP) < 0.02, "Sphere swell does not run to the collapse");
assert.ok(builtSphere.alphaAnim!.mid < 0.7, "Sphere is opaque; the user would not show through it");
assert.ok(builtSphere.colorAnim!.end[2] > builtSphere.colorAnim!.start[2] + 0.3, "Sphere does not pale toward cream");
assert.ok(built(RES.crescentA).minRotation * built(RES.crescentB).minRotation < 0, "Crescents do not counter-rotate");

// Condense: the orb, glare and glint outlive the pause and are on the cannon.
for (const index of [RES.orb, RES.glare, RES.glint]) {
  assert.ok(close(built(index).emitterBasePos, CANNON), `Orb layer ${index} is off the cannon`);
  assert.ok(built(index).particleLifeFrames >= COLLAPSE + PAUSE, `Orb layer ${index} dies before the shot`);
}
assert.ok(built(RES.orb).color.every((c) => c > 0.85), "Orb is not white-hot");
assert.ok(built(RES.converge).behaviors.some((b) => b.type === "convergence"), "Pause embers are not drawn inward");
assert.ok(built(RES.converge).emitterLifeFrames + built(RES.converge).particleLifeFrames <= PAUSE + 6, "Pause embers outlast the pause");

// Fire and beam.
assert.ok(built(RES.shockwave).scaleAnim!.end >= 3, "Shockwave does not blow out");
for (const index of [RES.beam, RES.beamCore, RES.smoke, RES.streaks, RES.blast]) {
  assert.ok(built(index).axis[0] > 0.9 && built(index).initVelAxisAmplifier > 0.2, `Aimed layer ${index} is not fired along its forward axis`);
}
for (const index of [RES.beam, RES.beamCore]) {
  assert.ok(Math.abs(built(index).initVelAxisAmplifier - BEAM_SPEED) < 0.01, `Beam ${index} speed drifted`);
  assert.equal(built(index).particleLifeFrames, BEAM_TRAVEL + 1, `Beam ${index} does not die at the foe`);
  assert.equal(built(index).emitterLifeFrames, BEAM_EMIT, `Beam ${index} pour time drifted`);
}
assert.ok(built(RES.beamCore).baseScale < built(RES.beam).baseScale, "Beam core is not inside the beam");
assert.ok(built(RES.beamCore).color.every((c) => c > 0.85), "Beam core is not white-hot");
assert.ok(built(RES.streaks).initVelAxisAmplifier > BEAM_SPEED, "Speed lines do not outrun the beam");

// Impact.
for (const index of [RES.impactCore, RES.sunburst, RES.radial, RES.ringA, RES.ringB, RES.impactEmbers, RES.impactSmoke]) {
  assert.ok(close(built(index).emitterBasePos, IMPACT), `Impact layer ${index} sits at ${show(built(index).emitterBasePos)}`);
}
assert.ok(built(RES.ringA).aspectRatio < 0.6 && built(RES.ringB).aspectRatio < 0.6, "Ring arcs are not squashed into ellipses");
assert.ok(built(RES.ringA).initAngle !== built(RES.ringB).initAngle, "Ring arcs do not cross");

// --- move script -------------------------------------------------------------

const emit = (res: number, target: "ATTACKER" | "DEFENDER", toward = "NONE") => `Emit ${OUTPUT_SPA_ID}, ${res}, ${target}, ${toward}, 2px, 0, 0, 1x, 1x, 1x, 1x`;

const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${OUTPUT_SPA_ID}
AudioContainer CONTINUE
PlaySound 1418, PSG, 14, 0, 0, 120, 0, 0, 0
PlaySound 1376, PSG, 14, ${SWELL + COLLAPSE}, 0, 0, 0, 0, 0
AdjustSound PSG, 0, 0, 0, 3000, 0, ${SWELL}, 0, 0
PlaySound 1509, SE1, 14, ${SWELL + 2}, 0, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 1, 0, 0, 0
ChangeSpriteColor ATTACKER, 0, 8, 2, 31, 18, 6
${emit(RES.sphere, "ATTACKER")}
${emit(RES.rim, "ATTACKER")}
${emit(RES.lobes, "ATTACKER")}
${emit(RES.core, "ATTACKER")}
${emit(RES.crescentA, "ATTACKER")}
${emit(RES.crescentB, "ATTACKER")}
${emit(RES.embers, "ATTACKER")}
Wait ${SWELL}
${emit(RES.orb, "ATTACKER")}
${emit(RES.glare, "ATTACKER")}
${emit(RES.glint, "ATTACKER")}
Wait ${COLLAPSE}
${emit(RES.converge, "ATTACKER")}
ChangeSpriteColor ATTACKER, 8, 14, 1, 31, 26, 16
ShakeScreen VERTICAL, 410, 0, 1, 1, ${PAUSE / 2 - 1}
Wait ${PAUSE}
AudioContainer CONTINUE
PlaySound 1975, SE1, 16, 0, 0, 127, 0, 0, 0
PlaySound 1424, SE2, 14, 0, -300, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${BEAM_TRAVEL}, 0, 50, 0, 0
PlaySound 1475, SE1, 16, ${BEAM_TRAVEL}, 0, 127, 0, 0, 0
PlaySound 1420, SE2, 16, ${BEAM_TRAVEL}, 0, 127, 0, 0, 0
PlaySound 1475, SE1, 16, ${BEAM_TRAVEL + 7}, -400, 120, 0, 0, 0
PlaySound 1420, SE2, 16, ${BEAM_TRAVEL + 12}, -200, 110, 0, 0, 0
PlaySound 1475, SE1, 16, ${BEAM_TRAVEL + 16}, -600, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 16, 0, 1, 31, 27, 20
ChangeSpriteColor ATTACKER, 14, 0, 1, 31, 26, 16
${emit(RES.shockwave, "ATTACKER")}
${emit(RES.blast, "ATTACKER", "DEFENDER")}
${emit(RES.fireSpikes, "ATTACKER")}
${emit(RES.beam, "ATTACKER", "DEFENDER")}
${emit(RES.beamCore, "ATTACKER", "DEFENDER")}
${emit(RES.smoke, "ATTACKER", "DEFENDER")}
${emit(RES.streaks, "ATTACKER", "DEFENDER")}
ShakeScreen VERTICAL, 1x, 0, 1, 0, ${KICK_HOLD - 1}
ShakeSprite ATTACKER, 2, 1229, 0, 1, 1, 4
Wait ${KICK_HOLD}
MoveCamera INTERPOLATION, DEFENDER, ${BEAM_TRAVEL - KICK_HOLD}, 0, 24
Wait ${BEAM_TRAVEL - KICK_HOLD}
${emit(RES.impactCore, "DEFENDER")}
${emit(RES.sunburst, "DEFENDER")}
${emit(RES.radial, "DEFENDER")}
${emit(RES.ringA, "DEFENDER")}
${emit(RES.ringB, "DEFENDER")}
${emit(RES.impactEmbers, "DEFENDER")}
${emit(RES.impactSmoke, "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 31, 31
ChangeBackgroundColor 4, 14, 0, 2, 31, 16, 2
ShakeScreen VERTICAL, 1.5x, 0, 2, 0, 12
ShakeSprite DEFENDER, 2, 1638, 0, 1, 2, 14
Wait 6
ChangeSpriteColor DEFENDER, 14, 0, 2, 31, 31, 31
Wait ${IMPACT_HOLD - 6}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await writeFile(OUT_SCRIPT, script, "utf8");

console.log(`Wrote ${OUT_SPA} (${spaBytes.length} bytes, ${resources.length} resources, ${textures.length} textures)`);
console.log(`  windup f${CAMERA_IN}-${CAMERA_IN + SWELL} (max ${SPHERE_MAX}), condense f${CAMERA_IN + SWELL}-${CAMERA_IN + SWELL + COLLAPSE}, pause ${PAUSE}f, fire f${FIRE_FRAME}, impact f${IMPACT_FRAME}`);
console.log(`Wrote ${OUT_SCRIPT}`);
