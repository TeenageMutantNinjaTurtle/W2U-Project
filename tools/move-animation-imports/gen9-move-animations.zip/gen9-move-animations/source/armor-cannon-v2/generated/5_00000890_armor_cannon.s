MoveCamera INTERPOLATION, ATTACKER, 16, 0, 8
LetCMDsFinish CAMERA
LoadSPA 845
AudioContainer CONTINUE
PlaySound 1418, PSG, 14, 0, 0, 120, 0, 0, 0
PlaySound 1376, PSG, 14, 40, 0, 0, 0, 0, 0
AdjustSound PSG, 0, 0, 0, 3000, 0, 34, 0, 0
PlaySound 1509, SE1, 14, 36, 0, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 1, 0, 0, 0
ChangeSpriteColor ATTACKER, 0, 8, 2, 31, 18, 6
Emit 845, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 34
Emit 845, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 6
Emit 845, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor ATTACKER, 8, 14, 1, 31, 26, 16
ShakeScreen VERTICAL, 410, 0, 1, 1, 9
Wait 20
AudioContainer CONTINUE
PlaySound 1975, SE1, 16, 0, 0, 127, 0, 0, 0
PlaySound 1424, SE2, 14, 0, -300, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 12, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 12, 0, 127, 0, 0, 0
PlaySound 1420, SE2, 16, 12, 0, 127, 0, 0, 0
PlaySound 1475, SE1, 16, 19, -400, 120, 0, 0, 0
PlaySound 1420, SE2, 16, 24, -200, 110, 0, 0, 0
PlaySound 1475, SE1, 16, 28, -600, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 16, 0, 1, 31, 27, 20
ChangeSpriteColor ATTACKER, 14, 0, 1, 31, 26, 16
Emit 845, 11, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 12, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 13, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 14, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 15, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 16, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 17, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeScreen VERTICAL, 1x, 0, 1, 0, 5
ShakeSprite ATTACKER, 2, 1229, 0, 1, 1, 4
Wait 6
MoveCamera INTERPOLATION, DEFENDER, 6, 0, 24
Wait 6
Emit 845, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 20, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 21, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 22, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 23, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 845, 24, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 31, 31
ChangeBackgroundColor 4, 14, 0, 2, 31, 16, 2
ShakeScreen VERTICAL, 1.5x, 0, 2, 0, 12
ShakeSprite DEFENDER, 2, 1638, 0, 1, 2, 14
Wait 6
ChangeSpriteColor DEFENDER, 14, 0, 2, 31, 31, 31
Wait 24
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
