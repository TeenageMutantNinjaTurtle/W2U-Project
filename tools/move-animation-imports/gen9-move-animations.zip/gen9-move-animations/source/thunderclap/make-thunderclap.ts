import { createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Thunderclap (move 909) - from Bulbapedia's stills (reference/).
//   1. Cyan lightning crackles round the user's head and a bolt forks up
//      into the sky.
//   2. A thin white bolt strikes straight down onto the foe, cyan sparks
//      crackling out round it in a blue glow.
// A quick priority move: a short build-up, a sharp strike.
//
// Thunder's lightning column (SPA 256 resource 1, four animated frames) is
// the bolt both ways; Thunder's squiggles (257) are the crackles.

const SPA = 902;
const kit = await createKit({ workDir: import.meta.dirname, slug: "thunderclap", moveId: 909, spaId: SPA, donors: [256, 257, 465] });

// --- timing (30 fps) ---
const CAMERA_IN = 10;
const CRACKLE = 18;
const PAN = 8;
const HIT_STOP = 3;
const HOLD = 18;

const USER: Vec3 = [0, 0.6, 0.2];
const FOE: Vec3 = [0, 0.3, 0.8];

const CYAN: Rgb = [0.45, 1.0, 0.95];
const PALE_CYAN: Rgb = [0.85, 1.0, 1.0];
const BLUE: Rgb = [0.4, 0.7, 1.0];
const WHITE: Rgb = [1, 1, 1];

function remapAnim(r: ReturnType<typeof kit.shell>, spaId: number): void {
  r.textureIndex = kit.tex(spaId, r.textureIndex);
  if (r.texAnim) r.texAnim.textures = r.texAnim.textures.map((t, i) => (i < r.texAnim!.textureCount ? kit.tex(spaId, t) : 0));
}

function column(pos: Vec3, life: number, scale: number, colour: Rgb, start: Rgb): ReturnType<typeof kit.shell> {
  const r = kit.shell(256, 1);
  remapAnim(r, 256);
  Object.assign(r, { emitterBasePos: [...pos], particleLifeFrames: life, baseScale: scale });
  paint(r, colour, start, colour);
  return r;
}

function crackles(pos: Vec3, opts: Parameters<typeof kit.spray>[3], colours: [Rgb, Rgb, Rgb]): ReturnType<typeof kit.spray> {
  const shell = kit.shell(257, 0);
  remapAnim(shell, 257);
  const r = kit.spray(shell, shell.textureIndex, pos, opts);
  r.texAnim = structuredClone(shell.texAnim);
  spin(r, 0, 0, 0, true);
  if (r.alphaAnim) setCurves(r, undefined, fadeOut(1, 0.6));
  r.loopFrames = 7;
  if (r.colorAnim) kit.prism(r, colours);
  else paint(r, colours[1]);
  return r;
}

// --- crackling round the user ---
kit.add("userCrackle", crackles(USER, { radius: 1.6, speed: 0, count: 1, bursts: 7, gap: 2, life: 6, scale: 0.8, shape: "ball" }, [CYAN, WHITE, PALE_CYAN]));

const skyBolt = column([0.2, 3.6, 0.2], 10, 3.2, PALE_CYAN, WHITE);
skyBolt.startDelayFrames = CRACKLE - 10;
kit.add("skyBolt", skyBolt);

const glowUp = kit.parked(kit.tex(465, 1), [0, 1.2, 0.2], 2.0, CRACKLE);
setCurves(glowUp, grow(0.4, 0.3, 1.1), fadeInOut(0.6, 0.2, 0.7));
paint(glowUp, CYAN, WHITE, BLUE);
kit.add("glowUp", glowUp);

// --- the strike ---
kit.add("strike", column([0, 3.2, 0.8], 9, 3.4, WHITE, WHITE));
kit.add("strikeHalo", column([0, 3.2, 0.7], 9, 3.9, CYAN, PALE_CYAN));

const flash = kit.shell(256, 0);
remapAnim(flash, 256);
Object.assign(flash, { emitterBasePos: [...FOE], particleLifeFrames: 10, baseScale: 1.6 });
paint(flash, PALE_CYAN, WHITE, CYAN);
kit.add("flash", flash);

const glow = kit.parked(kit.tex(465, 1), FOE, 2.2, 14);
setCurves(glow, grow(0.4, 0.2, 1.3), fadeOut(0.8, 0.4));
paint(glow, BLUE, PALE_CYAN, BLUE);
kit.add("glow", glow);

kit.add("foeCrackle", crackles(FOE, { radius: 0.6, speed: 0.14, count: 6, life: 8, scale: 0.75 }, [CYAN, WHITE, PALE_CYAN]));

const sparks = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.5, speed: 0.4, count: 8, life: 12, scale: 0.12 });
sparks.behaviors = [{ type: "gravity", magnitude: [0, -0.012, 0] }];
setCurves(sparks, undefined, twinkle());
kit.prism(sparks, [CYAN, WHITE, BLUE]);
kit.add("sparks", sparks);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1710, SE1, 14, 0, 300, 100, 0, 0, 0
PlaySound 1710, SE2, 14, ${CRACKLE - 10}, 0, 115, 0, 0, 0
PlaySound 1683, SE1, FLAT, ${CRACKLE + PAN - 2}, 0, 127, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 1, 18, 31, 31
${kit.emit("glowUp", "ATTACKER")}
${kit.emit("userCrackle", "ATTACKER")}
${kit.emit("skyBolt", "ATTACKER")}
Wait ${CRACKLE}
ChangeSpriteColor ATTACKER, 8, 0, 1, 18, 31, 31
MoveCamera INTERPOLATION, DEFENDER, ${PAN}, 0, 8
Wait ${PAN}
AudioContainer CONTINUE
PlaySound 1475, SE1, 16, 0, 0, 120, 0, 0, 0
PlaySound 1514, SE2, 16, 2, 300, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 12, 0, 28, 31, 31
${kit.emit("strike", "DEFENDER")}
${kit.emit("strikeHalo", "DEFENDER")}
${kit.emit("flash", "DEFENDER")}
${kit.emit("glow", "DEFENDER")}
${kit.emit("foeCrackle", "DEFENDER")}
${kit.emit("sparks", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 13, 0, 22, 31, 31
Wait ${HIT_STOP}
ChangeBackgroundColor 4, 12, 0, 1, 28, 31, 31
ChangeSpriteColor DEFENDER, 13, 0, 1, 22, 31, 31
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 10
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 5
Wait ${HOLD - HIT_STOP}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [87, 85, 605],
  references: ["reference/SV_Thunderclap_IX.png", "reference/SV_Thunderclap_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 1, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 3, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  crackle f${CAMERA_IN}-${CAMERA_IN + CRACKLE}, strike f${CAMERA_IN + CRACKLE + PAN}`);
