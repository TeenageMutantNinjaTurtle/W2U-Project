MoveCamera INTERPOLATION, ATTACKER, 14, 0, 8
LetCMDsFinish CAMERA
LoadSPA 913
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -1200, 120, 0, 0, 0
PlaySound 1467, SE2, 14, 6, 0, 90, 0, 0, 0
PlaySound 1474, SE1, 14, 18, -600, 115, 0, 0, 0
PlaySound 1435, SE2, 14, 30, -400, 100, 0, 0, 0
PlaySound 1426, SE2, 14, 46, -300, 115, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 9, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 2, 4, 0, 9
ChangeSpriteColor ATTACKER, 0, 8, 2, 18, 10, 31
Emit 913, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 913, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 913, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 913, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 913, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 913, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 913, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 22
ChangeSpriteColor ATTACKER, 8, 0, 3, 18, 10, 31
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 10
Wait 24
Emit 913, 7, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveCamera INTERPOLATION, DEFENDER, 9, 0, 8
Wait 9
AudioContainer CONTINUE
PlaySound 1475, SE1, 16, 0, -500, 125, 0, 0, 0
PlaySound 1815, SE2, 16, 0, 300, 115, 0, 0, 0
PlaySound 1435, SE1, 16, 7, -800, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 913, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 913, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 913, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 913, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 913, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 913, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 913, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 14, 4, 24
Wait 5
ChangeSpriteColor DEFENDER, 14, 0, 2, 14, 4, 24
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 7
Wait 21
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 10, 0, 2, 4, 0, 9
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
