import { aimed, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Last Respects (move 854), v2 - from Logan's three keyframes (reference/):
//   1. Startup: violet spirit flames lick up round the user, glowing spirit
//      orbs float up, and long dark-violet shadow blades with lavender edges
//      jut out diagonally.
//   2. Preparing: a great column of purple spirit smoke billows up through
//      the user into the sky, white specks streaming up inside it, small
//      purple puffs curling off its base.
//   3. Hit: a violet burst on the foe: a dark hole at the centre, a jagged
//      white-lavender rim round it, violet streaks blasting outward, a
//      flicker of red and blue at the edges.
// v1 (../last-respects, from the Bulbapedia stills) is kept; reinstall its
// manifest to revert.

const SPA = 913;
const kit = await createKit({ workDir: import.meta.dirname, slug: "last-respects-v2", moveId: 854, spaId: SPA, donors: [465, 321, 228, 411, 298] });

// --- timing (30 fps) ---
const CAMERA_IN = 14;
const STARTUP = 22;
const PREPARE = 24;
const PAN = 9;
const HIT_STOP = 5;
const HOLD = 26;

// --- placement (attacker / defender relative; "2px" anchor is mid-body) ---
const USER: Vec3 = [0, 0.3, 0.2];
const FLOOR: Vec3 = [0, -1.6, 0.1];
const COLUMN_BASE: Vec3 = [0, -1.0, -0.2]; // just behind the user
const FOE: Vec3 = [0, 0.3, 0.8];

const VIOLET: Rgb = [0.62, 0.32, 1.0];
const BRIGHT_VIOLET: Rgb = [0.78, 0.5, 1.0];
const LAVENDER: Rgb = [0.9, 0.82, 1.0];
const DARK_VIOLET: Rgb = [0.3, 0.1, 0.55];
const SMOKE: Rgb = [0.5, 0.25, 0.78];
const DEEP_SMOKE: Rgb = [0.32, 0.12, 0.55];
const HOLE: Rgb = [0.08, 0.02, 0.14];
const RED: Rgb = [1.0, 0.3, 0.35];
const BLUE: Rgb = [0.35, 0.55, 1.0];
const WHITE: Rgb = [1, 1, 1];

// --- 1. startup ---
// Spirit flames licking up from a ring round the user.
const flames = kit.spray([228, 3], kit.tex(321, 6), FLOOR, { radius: 1.7, speed: 0, count: 1, bursts: 11, gap: 2, life: 12, scale: 0.9, shape: "circle", directional: true });
flames.emissionAxis = 1;
flames.axis = [0, 1, 0];
flames.initVelAxisAmplifier = 0.2;
setCurves(flames, grow(0.4, 0.3, 1.3), fadeInOut(0.9, 0.2, 0.55));
kit.prism(flames, [VIOLET, BRIGHT_VIOLET, LAVENDER]);
kit.add("flames", flames);

// Glowing spirit orbs drifting up.
const orbs = kit.spray([333, 1], kit.tex(465, 1), USER, { radius: 2.0, speed: 0, count: 1, bursts: 9, gap: 3, life: 18, scale: 0.4, shape: "ball" });
orbs.axis = [0, 1, 0];
orbs.initVelAxisAmplifier = 0.05;
setCurves(orbs, grow(0.4, 0.3, 1), fadeInOut(1, 0.2, 0.6));
kit.prism(orbs, [BRIGHT_VIOLET, LAVENDER, VIOLET]);
kit.add("orbs", orbs);

// Shadow blades jutting out diagonally: long tapered dark-violet shards.
const blades = kit.spray([228, 3], kit.tex(465, 3), [0, -0.6, 0.2], { radius: 0.8, speed: 0.22, count: 2, bursts: 4, gap: 4, life: 11, scale: 1.3, shape: "circle", directional: true });
blades.axis = [0, 1, 0];
blades.initVelAxisAmplifier = 0.14;
blades.airResistance = 0.88;
setCurves(blades, grow(0.3, 0.3, 1.2), fadeInOut(1, 0.15, 0.6));
kit.prism(blades, [DARK_VIOLET, VIOLET, LAVENDER]);
kit.add("blades", blades);

// --- 2. preparing: the spirit column ---
const columnGlow = kit.parked(kit.tex(465, 1), [0, 2.0, -0.3], 5.0, PREPARE + 4);
columnGlow.startDelayFrames = STARTUP - 4;
columnGlow.aspectRatio = 0.42;
setCurves(columnGlow, grow(0.3, 0.35, 1.1), fadeInOut(0.6, 0.25, 0.75));
paint(columnGlow, VIOLET, DARK_VIOLET, SMOKE);
kit.add("columnGlow", columnGlow);

const column = kit.spray([333, 1], kit.tex(321, 5), COLUMN_BASE, { radius: 0.5, speed: 0, count: 1, bursts: PREPARE / 2, gap: 2, life: 22, scale: 1.1, shape: "ball" });
column.startDelayFrames = STARTUP - 4;
column.axis = [0, 1, 0];
column.initVelAxisAmplifier = 0.24;
spin(column, -0.05, 0.05, 0, true);
setCurves(column, grow(0.6, 0.3, 1.9), fadeInOut(0.85, 0.15, 0.65));
kit.prism(column, [SMOKE, DEEP_SMOKE, BRIGHT_VIOLET]);
kit.add("column", column);

const specks = kit.spray([228, 3], kit.tex(411, 0), [0, 0.6, -0.2], { radius: 1.0, speed: 0, count: 2, bursts: PREPARE / 2, gap: 2, life: 9, scale: 0.55, shape: "ball", directional: true });
specks.startDelayFrames = STARTUP;
specks.axis = [0, 1, 0];
specks.initVelAxisAmplifier = 0.35;
setCurves(specks, undefined, fadeInOut(1, 0.2, 0.6));
paint(specks, WHITE, WHITE, LAVENDER);
kit.add("specks", specks);

const basePuffs = kit.spray([333, 1], kit.tex(321, 5), FLOOR, { radius: 1.4, speed: 0.03, count: 1, bursts: 5, gap: 4, life: 14, scale: 0.55, shape: "circle" });
basePuffs.startDelayFrames = STARTUP;
basePuffs.emissionAxis = 1;
spin(basePuffs, -0.08, 0.08, 0, true);
setCurves(basePuffs, grow(0.4, 0.3, 1.3), fadeInOut(0.8, 0.2, 0.5));
kit.prism(basePuffs, [SMOKE, LAVENDER, DEEP_SMOKE]);
kit.add("basePuffs", basePuffs);

// --- the strike: spirits stream to the foe ---
const spirits = kit.spray([228, 3], kit.tex(411, 0), [0, 1.2, -0.6], { radius: 0.8, speed: 0, count: 2, bursts: PAN - 2, gap: 1, life: 6, scale: 2.0, directional: true });
aimed(spirits, 2.2, 6);
setCurves(spirits, undefined, fadeInOut(1, 0.2, 0.6));
kit.prism(spirits, [VIOLET, LAVENDER, BRIGHT_VIOLET]);
kit.add("spirits", spirits);

// --- 3. hit ---
const flash = kit.parked(kit.tex(228, 1), FOE, 2.0, 12);
spin(flash, 0.05);
setCurves(flash, grow(0.4, 0.2, 2.2), fadeOut(1, 0.35));
paint(flash, LAVENDER, WHITE, VIOLET);
kit.add("flash", flash);

const aura = kit.parked(kit.tex(465, 1), FOE, 3.0, 16);
setCurves(aura, grow(0.4, 0.2, 1.3), fadeOut(0.85, 0.4));
paint(aura, VIOLET, BRIGHT_VIOLET, DARK_VIOLET);
kit.add("aura", aura);

const hole = kit.parked(kit.tex(298, 0), FOE, 0.9, 16);
setCurves(hole, grow(0.3, 0.2, 1.3), fadeOut(0.95, 0.5));
paint(hole, HOLE);
kit.add("hole", hole);

const rim = kit.parked(kit.tex(465, 2), FOE, 1.8, 13);
spin(rim, 0.08);
setCurves(rim, grow(0.3, 0.25, 1.5), fadeOut(1, 0.4));
paint(rim, LAVENDER, WHITE, BRIGHT_VIOLET);
kit.add("rim", rim);

const burst = kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.5, speed: 0.85, count: 14, life: 9, scale: 2.2, directional: true });
setCurves(burst, undefined, fadeOut(1, 0.45));
kit.prism(burst, [VIOLET, LAVENDER, WHITE]);
kit.add("burst", burst);

const shards = kit.spray([228, 3], kit.tex(465, 3), FOE, { radius: 0.4, speed: 0.55, count: 8, life: 10, scale: 0.8, directional: true });
setCurves(shards, grow(1.2, 0.3, 0.6), fadeOut());
kit.prism(shards, [BRIGHT_VIOLET, DARK_VIOLET, LAVENDER]);
kit.add("shards", shards);

const fringe = kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.8, speed: 0.7, count: 4, life: 7, scale: 1.4, directional: true });
setCurves(fringe, undefined, fadeOut());
kit.prism(fringe, [RED, BLUE, RED]);
kit.add("fringe", fringe);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -1200, 120, 0, 0, 0
PlaySound 1467, SE2, 14, 6, 0, 90, 0, 0, 0
PlaySound 1474, SE1, 14, ${STARTUP - 4}, -600, 115, 0, 0, 0
PlaySound 1435, SE2, 14, ${STARTUP + 8}, -400, 100, 0, 0, 0
PlaySound 1426, SE2, 14, ${STARTUP + PREPARE}, -300, 115, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${PAN}, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 2, 4, 0, 9
ChangeSpriteColor ATTACKER, 0, 8, 2, 18, 10, 31
${kit.emit("flames", "ATTACKER")}
${kit.emit("orbs", "ATTACKER")}
${kit.emit("blades", "ATTACKER")}
${kit.emit("columnGlow", "ATTACKER")}
${kit.emit("column", "ATTACKER")}
${kit.emit("specks", "ATTACKER")}
${kit.emit("basePuffs", "ATTACKER")}
Wait ${STARTUP}
ChangeSpriteColor ATTACKER, 8, 0, 3, 18, 10, 31
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 10
Wait ${PREPARE}
${kit.emit("spirits", "ATTACKER", "DEFENDER")}
MoveCamera INTERPOLATION, DEFENDER, ${PAN}, 0, 8
Wait ${PAN}
AudioContainer CONTINUE
PlaySound 1475, SE1, 16, 0, -500, 125, 0, 0, 0
PlaySound 1815, SE2, 16, 0, 300, 115, 0, 0, 0
PlaySound 1435, SE1, 16, ${HIT_STOP + 2}, -800, 110, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("aura", "DEFENDER")}
${kit.emit("flash", "DEFENDER")}
${kit.emit("hole", "DEFENDER")}
${kit.emit("rim", "DEFENDER")}
${kit.emit("burst", "DEFENDER")}
${kit.emit("shards", "DEFENDER")}
${kit.emit("fringe", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 14, 4, 24
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 14, 0, 2, 14, 4, 24
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 7
Wait ${HOLD - HIT_STOP}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 10, 0, 2, 4, 0, 9
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [129, 605, 240, 153, 236, 247, 261],
  references: ["reference/keyframe-1-startup.png", "reference/keyframe-2-preparing.webp", "reference/keyframe-3-hit.webp", "reference/Last_Respects_IX.png", "reference/Last_Respects_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, `Emit ${SPA}, 4, ATTACKER`, `Emit ${SPA}, 7, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 10, DEFENDER`, "ShakeScreen VERTICAL, 1x", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  startup f${CAMERA_IN}-${CAMERA_IN + STARTUP}, column to f${CAMERA_IN + STARTUP + PREPARE}, hit f${CAMERA_IN + STARTUP + PREPARE + PAN}`);
