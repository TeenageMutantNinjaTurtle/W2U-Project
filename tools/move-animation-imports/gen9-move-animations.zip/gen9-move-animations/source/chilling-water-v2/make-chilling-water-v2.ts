import { assert, createKit, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Chilling Water (move 886), v2 - from Bulbapedia's stills (reference/).
//   1. A glassy blue water sphere with white wave swirls is lobbed high over
//      the foe, trailing glittering droplets.
//   2. It bursts on the foe in an icy cyan splash.
// v1 (../chilling-water) is kept; reinstall its manifest to revert.
//
// The sphere is Mud Bomb's (SPA 605): its texture is a glossy blue ball, so
// untinted it reads as water. It rides Mud Bomb's curved lob (EmitProjectile
// CURVE) with Hyper Beam's swirl rings turning on top as the white waves.
// Aqua Tail's (580) bubbles and spray, Aqua Jet's (632) ring, Dazzling
// Gleam's shard for the splash.

const SPA = 880;
const kit = await createKit({ workDir: import.meta.dirname, slug: "chilling-water-v2", moveId: 886, spaId: SPA, donors: [605, 228, 580, 632, 465] });

const WIDE = 20;
const LOB = 30;
const HOLD = 22;

const FOE: Vec3 = [0, 0.3, 0.8];

const WHITE: Rgb = [1, 1, 1];
const PALE_CYAN: Rgb = [0.85, 0.98, 1.0];
const CYAN: Rgb = [0.45, 0.88, 1.0];
const WATER: Rgb = [0.35, 0.65, 1.0];

// Riding the lob (Mud Bomb's emitter-following ball).
function rider(texIndex: number, scale: number): ReturnType<typeof kit.shell> {
  const r = kit.shell(605, 0);
  assert.ok(r.followEmitter, "Mud Bomb's ball no longer follows its emitter");
  r.textureIndex = texIndex;
  Object.assign(r, { particleLifeFrames: LOB + 1, baseScale: scale });
  return r;
}
const ball = rider(kit.tex(605, 2), 1.2);
paint(ball, WHITE);
kit.add("ball", ball);

const waves = rider(kit.tex(228, 3), 1.05);
spin(waves, 0.25);
setCurves(waves, hold(1), undefined);
paint(waves, WHITE, WHITE, PALE_CYAN);
kit.add("waves", waves);

// Droplets shed along the arc.
const trail = kit.spray([333, 1], kit.tex(333, 0), [0, 0, 0], { radius: 0.5, speed: 0.04, count: 1, bursts: LOB, gap: 1, life: 10, scale: 0.12 });
trail.behaviors = [{ type: "gravity", magnitude: [0, -0.01, 0] }];
setCurves(trail, undefined, twinkle());
kit.prism(trail, [WHITE, PALE_CYAN, CYAN]);
kit.add("trail", trail);

// --- the splash ---
const ring = kit.parked(kit.tex(632, 2), FOE, 1.2, 10);
setCurves(ring, grow(0.5, 0.3, 1.8), fadeOut(1, 0.3));
paint(ring, PALE_CYAN, WHITE, CYAN);
kit.add("ring", ring);

const bubbles = kit.shell(580, 1);
bubbles.textureIndex = kit.tex(580, 2);
Object.assign(bubbles, { emitterBasePos: [...FOE], emissionCount: 4 });
paint(bubbles, PALE_CYAN, WHITE, CYAN);
kit.add("bubbles", bubbles);

const spray = kit.shell(580, 2);
spray.textureIndex = kit.tex(580, 3);
Object.assign(spray, { emitterBasePos: [...FOE], emissionCount: 3 });
paint(spray, PALE_CYAN, WHITE, WATER);
kit.add("spray", spray);

const shards = kit.spray([228, 3], kit.tex(465, 3), FOE, { radius: 0.3, speed: 0.4, count: 8, life: 10, scale: 0.5, directional: true });
shards.axis = [0, 1, 0];
shards.initVelAxisAmplifier = 0.12;
setCurves(shards, grow(1.2, 0.3, 0.6), fadeOut());
kit.prism(shards, [WHITE, PALE_CYAN, CYAN]);
kit.add("shards", shards);

const lob = (name: string) => `EmitProjectile ${SPA}, ${kit.idx(name)}, CURVE, ATTACKER, DEFENDER, 2px, ${LOB}f, 4px, 3686, 1x, 0`;
const script = `MoveCamera INTERPOLATION, ZOOM_OUT_PERS, ${WIDE}, 0, 0
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1452, SE1, 16, 0, 500, 80, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, ${LOB}, 0, 48, 0, 0
PlaySound 1511, SE2, 16, ${LOB}, 0, 115, 0, 0, 0
PlaySound 1651, SE1, 16, ${LOB}, -500, 110, 0, 0, 0
AudioContainer SUSPEND
${lob("ball")}
${lob("waves")}
${lob("trail")}
Wait ${LOB}
${kit.emit("ring", "DEFENDER")}
${kit.emit("bubbles", "DEFENDER")}
${kit.emit("spray", "DEFENDER")}
${kit.emit("shards", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 18, 28, 31
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 8
Wait 8
ChangeSpriteColor DEFENDER, 12, 0, 2, 18, 28, 31
Wait ${HOLD - 8}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [426, 63, 401, 453, 605],
  references: ["reference/Chilling_Water_IX.png", "reference/Chilling_Water_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `EmitProjectile ${SPA}, 0, CURVE, ATTACKER, DEFENDER`, `Emit ${SPA}, 3, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  lob ${LOB}f, splash f${WIDE + LOB}`);
