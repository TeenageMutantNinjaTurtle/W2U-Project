MoveCamera INTERPOLATION, ZOOM_OUT_PERS, 20, 0, 0
LetCMDsFinish CAMERA
LoadSPA 880
AudioContainer CONTINUE
PlaySound 1452, SE1, 16, 0, 500, 80, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 30, 0, 48, 0, 0
PlaySound 1511, SE2, 16, 30, 0, 115, 0, 0, 0
PlaySound 1651, SE1, 16, 30, -500, 110, 0, 0, 0
AudioContainer SUSPEND
EmitProjectile 880, 0, CURVE, ATTACKER, DEFENDER, 2px, 30f, 4px, 3686, 1x, 0
EmitProjectile 880, 1, CURVE, ATTACKER, DEFENDER, 2px, 30f, 4px, 3686, 1x, 0
EmitProjectile 880, 2, CURVE, ATTACKER, DEFENDER, 2px, 30f, 4px, 3686, 1x, 0
Wait 30
Emit 880, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 880, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 880, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 880, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 18, 28, 31
ShakeSprite DEFENDER, 2, 819, 0, 2, 1, 8
Wait 8
ChangeSpriteColor DEFENDER, 12, 0, 2, 18, 28, 31
Wait 14
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
