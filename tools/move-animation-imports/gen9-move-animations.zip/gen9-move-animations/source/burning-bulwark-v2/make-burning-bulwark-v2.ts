import { createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Burning Bulwark (move 908), v2 - from Bulbapedia's stills (reference/).
//   1. The user's crest blazes up into a great crown of orange-yellow flame
//      blades over a pink glow, embers drifting.
//   2. A glowing blue honeycomb barrier stands in front of it.
// The burn on contact is handled by the engine.
// v1 (../burning-bulwark) is kept; reinstall its manifest to revert.
//
// The barrier is drawn here (64x64 a5i3 white mask: a disc of hexagonal cells
// with bright cell walls and rim; generated/texture-honeycomb.png).

const SPA = 901;
const kit = await createKit({ workDir: import.meta.dirname, slug: "burning-bulwark-v2", moveId: 908, spaId: SPA, donors: [321, 465, 579, 298] });

// --- timing (30 fps) ---
const CAMERA_IN = 14;
const BLAZE = 26;
const SHIELD = 28;

const USER: Vec3 = [0, 0.3, 0.2];
const CREST: Vec3 = [0, 1.3, 0.2];
const FRONT: Vec3 = [0.3, 0.3, -1.4];

const ORANGE: Rgb = [1.0, 0.55, 0.12];
const YELLOW: Rgb = [1.0, 0.85, 0.3];
const GOLD: Rgb = [1.0, 0.7, 0.2];
const PINK: Rgb = [1.0, 0.55, 0.7];
const SKY: Rgb = [0.55, 0.85, 1.0];
const PALE_SKY: Rgb = [0.85, 0.95, 1.0];
const WHITE: Rgb = [1, 1, 1];

// --- the drawn honeycomb ---
const S = 7.5; // cell circumradius (flat-topped hexagons)
const IN = (S * Math.sqrt(3)) / 2;
const hexDist = (dx: number, dy: number) => Math.max(Math.abs(dy), Math.abs(dx) * (Math.sqrt(3) / 2) + Math.abs(dy) / 2) / IN;
const honeyTex = await kit.drawn("honeycomb", 64, 64, "a5i3", (x, y) => {
  const px = x + 0.5 - 32;
  const py = y + 0.5 - 32;
  const r = Math.hypot(px, py);
  if (r > 30.5) return undefined;
  if (r > 28) return [255, 255, 255, 255];
  let best = Infinity;
  for (let i = -5; i <= 5; i++) {
    for (let j = -5; j <= 5; j++) {
      const cx = 1.5 * S * i;
      const cy = 2 * IN * (j + (i & 1 ? 0.5 : 0));
      best = Math.min(best, hexDist(px - cx, py - cy));
    }
  }
  const wall = best > 0.8;
  const glow = Math.min(1, 0.25 + 0.5 * (r / 28) ** 2);
  return [255, 255, 255, Math.round(255 * (wall ? 0.9 : glow * 0.55))];
});

// --- the blaze ---
const glow = kit.parked(kit.tex(465, 1), CREST, 3.0, BLAZE + 6);
setCurves(glow, grow(0.4, 0.35, 1.15), fadeInOut(0.7, 0.25, 0.75));
paint(glow, PINK, ORANGE, PINK);
kit.add("glow", glow);

const crown = kit.spray([228, 3], kit.tex(321, 6), CREST, { radius: 0.35, speed: 0.12, count: 5, bursts: 4, gap: 4, life: 16, scale: 1.0, directional: true });
crown.axis = [0, 1, 0];
crown.initVelAxisAmplifier = 0.14;
crown.airResistance = 0.88;
setCurves(crown, grow(0.4, 0.3, 1.5), fadeInOut(1, 0.12, 0.65));
kit.prism(crown, [ORANGE, YELLOW, GOLD]);
kit.add("crown", crown);

const flare = kit.parked(kit.tex(579, 2), CREST, 1.6, BLAZE);
spin(flare, 0.05);
setCurves(flare, grow(0.3, 0.3, 1.2), fadeInOut(0.85, 0.2, 0.7));
paint(flare, YELLOW, WHITE, ORANGE);
kit.add("flare", flare);

const embers = kit.spray([333, 1], kit.tex(333, 0), USER, { radius: 1.8, speed: 0, count: 1, bursts: 12, gap: 3, life: 16, scale: 0.13, shape: "ball" });
embers.axis = [0, 1, 0];
embers.initVelAxisAmplifier = 0.06;
setCurves(embers, undefined, twinkle());
kit.prism(embers, [ORANGE, YELLOW, WHITE]);
kit.add("embers", embers);

// --- the barrier ---
const shield = kit.parked(honeyTex, FRONT, 2.6, SHIELD);
shield.aspectRatio = 0.8;
setCurves(shield, { start: 0.2, mid: 1, end: 1, curveIn: 0.2, curveOut: 1 }, fadeInOut(0.95, 0.12, 0.75));
paint(shield, SKY, WHITE, SKY);
kit.add("shield", shield);

const sheen = kit.parked(kit.tex(465, 1), FRONT, 2.4, SHIELD);
sheen.aspectRatio = 0.8;
setCurves(sheen, { start: 0.2, mid: 1, end: 1, curveIn: 0.2, curveOut: 1 }, fadeInOut(0.4, 0.15, 0.7));
paint(sheen, PALE_SKY, WHITE, SKY);
kit.add("sheen", sheen);

const glints = kit.spray([333, 1], kit.tex(298, 1), FRONT, { radius: 1.5, speed: 0, count: 1, bursts: 6, gap: 3, life: 10, scale: 0.3, shape: "circle" });
glints.startDelayFrames = 4;
setCurves(glints, twinkle(1), twinkle(1));
kit.prism(glints, [WHITE, PALE_SKY, YELLOW]);
kit.add("glints", glints);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1426, SE1, 14, 0, -300, 115, 0, 0, 0
PlaySound 1425, SE2, 14, 8, 200, 100, 0, 0, 0
PlaySound 1471, SE1, 14, ${BLAZE - 4}, 0, 115, 0, 0, 0
PlaySound 1358, SE2, 14, ${BLAZE + 10}, 0, 80, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 2, 31, 16, 6
${kit.emit("glow", "ATTACKER")}
${kit.emit("crown", "ATTACKER")}
${kit.emit("flare", "ATTACKER")}
${kit.emit("embers", "ATTACKER")}
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 8
Wait ${BLAZE - 6}
${kit.emit("sheen", "ATTACKER")}
${kit.emit("shield", "ATTACKER")}
${kit.emit("glints", "ATTACKER")}
Wait 6
ChangeSpriteColor ATTACKER, 10, 0, 2, 31, 16, 6
Wait ${SHIELD - 6}
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [182, 153, 63, 400, 129],
  references: ["reference/Burning_Bulwark_IX.png", "reference/Burning_Bulwark_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 1, ATTACKER`, `Emit ${SPA}, 4, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  blaze f${CAMERA_IN}-${CAMERA_IN + BLAZE}, shield from f${CAMERA_IN + BLAZE - 6}`);
