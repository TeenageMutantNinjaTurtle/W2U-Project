MoveCamera INTERPOLATION, ATTACKER, 14, 0, 8
LetCMDsFinish CAMERA
LoadSPA 901
AudioContainer CONTINUE
PlaySound 1426, SE1, 14, 0, -300, 115, 0, 0, 0
PlaySound 1425, SE2, 14, 8, 200, 100, 0, 0, 0
PlaySound 1471, SE1, 14, 22, 0, 115, 0, 0, 0
PlaySound 1358, SE2, 14, 36, 0, 80, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 2, 31, 16, 6
Emit 901, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 901, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 901, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 901, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 8
Wait 20
Emit 901, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 901, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 901, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 6
ChangeSpriteColor ATTACKER, 10, 0, 2, 31, 16, 6
Wait 22
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
