MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
AudioContainer CONTINUE
PlaySound 1421, SE1, 14, 0, -200, 115, 0, 0, 0
AudioContainer SUSPEND
Wait 8
LoadSPA 854
Emit 854, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 854, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 854, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 854, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
AudioContainer CONTINUE
PlaySound 1420, SE2, 16, 0, 0, 115, 0, 0, 0
AudioContainer SUSPEND
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
