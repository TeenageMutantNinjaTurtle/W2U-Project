import { assert, createKit, deg, fadeOut, grow, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Population Bomb (move 860) - from Bulbapedia's still (reference/).
// A crisp white-yellow hit flash on the foe, long white light rays slashing
// out of it, a little rainbow glitter.
// This is a multi-hit move: Gen 5 replays the animation for every hit (up to
// 10), so it follows Fury Attack's pattern - no camera moves, a quick user
// lunge, a short hit and squash - about 20 frames a hit.
//
// Textures: Slash's hit star and glow dot, Hyper Beam's sunburst, Rain
// Dance's hair streak (the light rays).

const SPA = 854;
const kit = await createKit({ workDir: import.meta.dirname, slug: "population-bomb", moveId: 860, spaId: SPA, donors: [228, 411] });

const LUNGE = 8; // user's lunge reaches the foe
const FOE: Vec3 = [0, 0.3, 0.8];

const WHITE: Rgb = [1, 1, 1];
const PALE_YELLOW: Rgb = [1.0, 0.96, 0.7];
const YELLOW: Rgb = [1.0, 0.86, 0.35];
const PINK: Rgb = [1.0, 0.55, 0.8];
const CYAN: Rgb = [0.5, 0.9, 1.0];

const star = kit.parked(kit.tex(333, 1), FOE, 0.9, 10);
spin(star, 0.08, 0.08, deg(15));
setCurves(star, grow(0.4, 0.25, 1.4), fadeOut(1, 0.4));
paint(star, WHITE, WHITE, PALE_YELLOW);
kit.add("star", star);

const glow = kit.parked(kit.tex(228, 1), FOE, 1.1, 9);
setCurves(glow, grow(0.3, 0.3, 1.6), fadeOut(0.9, 0.3));
paint(glow, PALE_YELLOW, WHITE, YELLOW);
kit.add("glow", glow);

// Long white light rays slashing out of the flash.
const rays = kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.2, speed: 0.75, count: 4, life: 7, scale: 2.0, directional: true });
setCurves(rays, undefined, fadeOut(1, 0.3));
paint(rays, WHITE, WHITE, PALE_YELLOW);
kit.add("rays", rays);

// Rainbow glitter.
const glitter = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.5, speed: 0.3, count: 6, life: 10, scale: 0.12 });
setCurves(glitter, undefined, twinkle());
kit.prism(glitter, [PINK, CYAN, YELLOW]);
kit.add("glitter", glitter);

const script = `MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
AudioContainer CONTINUE
PlaySound 1421, SE1, 14, 0, -200, 115, 0, 0, 0
AudioContainer SUSPEND
Wait ${LUNGE}
LoadSPA ${SPA}
${kit.emit("glow", "DEFENDER")}
${kit.emit("star", "DEFENDER")}
${kit.emit("rays", "DEFENDER")}
${kit.emit("glitter", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
AudioContainer CONTINUE
PlaySound 1420, SE2, 16, 0, 0, 115, 0, 0, 0
AudioContainer SUSPEND
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
`;

const { reparsed } = await kit.finish({
  script,
  donorMoveIds: [31, 163, 63, 240],
  references: ["reference/Population_Bomb_IX.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveSprite ATTACKER, ROUNDTRIP", `Emit ${SPA}, 0, DEFENDER`, "ScaleSprite DEFENDER, ROUNDTRIP"],
});
const longest = Math.max(...reparsed.resources.map((r) => r.startDelayFrames + r.emitterLifeFrames + r.particleLifeFrames));
assert.ok(LUNGE + longest <= 24, `A single hit runs ${LUNGE + longest} frames; ten of them would drag`);
assert.ok(!script.includes("MoveCamera"), "Multi-hit animation moves the camera");
console.log(`  one hit ~${LUNGE + longest} frames`);
