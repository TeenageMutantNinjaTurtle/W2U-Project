import { aimed, assert, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Collision Course (move 878), v2 - from Bulbapedia's stills (reference/).
//   1. A huge glowing orange-gold fiery oval wheel with pink-red feathered
//      wings spread round it, against a dark sky.
//   2. A yellow fire splash on the foe, a white-and-black shockwave ring
//      spinning across the ground, grey smoke and embers.
// v1 (../collision-course) is kept; reinstall its manifest to revert.
//
// The wheel is Magma Storm's spiral (SPA 643) stretched to a tall oval. The
// wings are drawn here (64x64 a5i3: seven feathers fanning from a root;
// generated/texture-wing.png), the right one mirrored with flipTextureS.

const SPA = 872;
const kit = await createKit({ workDir: import.meta.dirname, slug: "collision-course-v2", moveId: 878, spaId: SPA, donors: [643, 228, 321, 579, 770, 298] });

// --- timing (30 fps) ---
const CAMERA_IN = 14;
const SIGIL = 30;
const DIVE = 10;
const HOLD = 28;

const SIGIL_POS: Vec3 = [0, 1.6, -0.8];
const FOE: Vec3 = [0, 0.3, 0.8];
const FOE_GROUND: Vec3 = [0, -1.9, 0.6];

const GOLD: Rgb = [1.0, 0.78, 0.2];
const ORANGE: Rgb = [1.0, 0.5, 0.1];
const RED: Rgb = [1.0, 0.25, 0.2];
const WING_PINK: Rgb = [1.0, 0.5, 0.58];
const YELLOW: Rgb = [1.0, 0.9, 0.25];
const WHITE: Rgb = [1, 1, 1];
const GREY: Rgb = [0.6, 0.6, 0.62];
const BLACK: Rgb = [0.08, 0.06, 0.08];

// --- the drawn wing ---
const wingTex = await kit.drawn("wing", 64, 64, "a5i3", (x, y) => {
  // Feathers fan out from a root at the lower right toward the upper left.
  const rx = 58;
  const ry = 50;
  const dx = x - rx;
  const dy = y - ry;
  const dist = Math.hypot(dx, dy);
  const ang = Math.atan2(dy, dx); // radians, 0 = right
  let best = 0;
  for (let i = 0; i < 7; i++) {
    const a = Math.PI * (0.95 + i * 0.1); // fan from left to up-left
    const len = 56 - i * 4.5;
    const along = dist * Math.cos(ang - a);
    const across = dist * Math.sin(ang - a);
    if (along < 4 || along > len) continue;
    const width = 4.2 * Math.sin(Math.PI * (along / len)) + 0.6;
    if (Math.abs(across) <= width) best = Math.max(best, 1 - Math.abs(across) / (width + 0.5));
  }
  if (best <= 0) return undefined;
  return [255, 255, 255, Math.round(140 + 115 * best)];
});

// --- the sigil ---
const wheel = kit.parked(kit.tex(643, 3), SIGIL_POS, 2.0, SIGIL + 2);
wheel.aspectRatio = 0.62;
spin(wheel, -0.18);
setCurves(wheel, grow(0.2, 0.3, 1.1), fadeInOut(1, 0.15, 0.95));
paint(wheel, GOLD, YELLOW, ORANGE);
kit.add("wheel", wheel);

const glow = kit.parked(kit.tex(298, 0), SIGIL_POS, 2.0, SIGIL + 2);
glow.aspectRatio = 0.65;
setCurves(glow, grow(0.3, 0.3, 1.15), fadeInOut(0.55, 0.2, 0.9));
paint(glow, ORANGE, GOLD, RED);
kit.add("glow", glow);

function wing(side: -1 | 1): ReturnType<typeof kit.parked> {
  const r = kit.parked(wingTex, [SIGIL_POS[0] + side * 1.5, SIGIL_POS[1] + 0.2, SIGIL_POS[2] + 0.1], 1.9, SIGIL - 4);
  r.startDelayFrames = 4;
  r.flipTextureS = side > 0; // mirror the right-hand wing
  setCurves(r, grow(0.3, 0.35, 1.05), fadeInOut(0.8, 0.2, 0.85));
  paint(r, WING_PINK, WHITE, RED);
  return r;
}
kit.add("wingLeft", wing(-1));
kit.add("wingRight", wing(1));

const embersUp = kit.spray([333, 1], kit.tex(333, 0), SIGIL_POS, { radius: 1.6, speed: 0.06, count: 1, bursts: 10, gap: 3, life: 14, scale: 0.14, shape: "ball" });
setCurves(embersUp, undefined, twinkle());
kit.prism(embersUp, [GOLD, ORANGE, YELLOW]);
kit.add("embersUp", embersUp);

// --- the dive ---
const diving = kit.parked(kit.tex(643, 3), SIGIL_POS, 1.6, DIVE + 1);
diving.aspectRatio = 0.62;
spin(diving, -0.35);
aimed(diving, 1.6, DIVE + 1, 0.12);
setCurves(diving, hold(1), hold(1));
paint(diving, GOLD, YELLOW, ORANGE);
kit.add("diving", diving);

// --- impact ---
const fire = kit.spray([333, 1], kit.tex(579, 2), FOE, { radius: 0.9, speed: 0.12, count: 2, bursts: 4, gap: 3, life: 14, scale: 0.8, shape: "ball" });
spin(fire, -0.15, 0.15, 0, true);
setCurves(fire, grow(0.5, 0.25, 1.4), fadeOut(1, 0.4));
kit.prism(fire, [YELLOW, GOLD, ORANGE]);
kit.add("fire", fire);

const flash = kit.parked(kit.tex(228, 1), FOE, 1.6, 12);
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.25, 2.0), fadeOut(1, 0.35));
paint(flash, YELLOW, WHITE, ORANGE);
kit.add("flash", flash);

function shock(colour: Rgb, scale: number, delay: number): ReturnType<typeof kit.parked> {
  const r = kit.parked(kit.tex(770, 2), FOE_GROUND, scale, 20);
  r.aspectRatio = 3.2;
  r.startDelayFrames = delay;
  setCurves(r, grow(0.3, 0.4, 1.5), fadeOut(1, 0.4));
  paint(r, colour);
  return r;
}
kit.add("shockWhite", shock(WHITE, 1.6, 0));
kit.add("shockDark", shock(BLACK, 1.4, 3));

const smoke = kit.spray([333, 1], kit.tex(321, 5), FOE_GROUND, { radius: 1.4, speed: 0.08, count: 4, life: 24, scale: 1.0, shape: "circle" });
smoke.emissionAxis = 1;
smoke.startDelayFrames = 2;
spin(smoke, -0.04, 0.04, 0, true);
setCurves(smoke, grow(0.5, 0.3, 1.4), fadeInOut(0.7, 0.2, 0.5));
paint(smoke, GREY, WHITE, GREY);
kit.add("smoke", smoke);

const embers = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.6, speed: 0.4, count: 8, life: 16, scale: 0.15 });
embers.behaviors = [{ type: "gravity", magnitude: [0, -0.008, 0] }];
setCurves(embers, undefined, twinkle());
kit.prism(embers, [GOLD, ORANGE, RED]);
kit.add("embers", embers);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1975, SE1, 14, 0, 0, 120, 0, 0, 0
PlaySound 1497, SE2, 14, 6, 300, 100, 0, 0, 0
PlaySound 1424, SE1, 14, ${SIGIL}, -300, 120, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, ${DIVE}, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 13, 1, 2, 1, 6
AdjustCamera INTERPOLATION_RELATIVE, 0, 0, 0, 0, 2px, 0, 18, 0, 20
${kit.emit("glow", "ATTACKER")}
${kit.emit("wheel", "ATTACKER")}
${kit.emit("wingLeft", "ATTACKER")}
${kit.emit("wingRight", "ATTACKER")}
${kit.emit("embersUp", "ATTACKER")}
Wait ${SIGIL}
${kit.emit("diving", "ATTACKER", "DEFENDER")}
MoveCamera INTERPOLATION, DEFENDER, ${DIVE}, 0, 12
Wait ${DIVE}
AudioContainer CONTINUE
PlaySound 1475, SE1, 16, 0, -500, 127, 0, 0, 0
PlaySound 1425, SE2, 16, 0, 0, 120, 0, 0, 0
PlaySound 1475, SE1, 16, 8, -700, 110, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("flash", "DEFENDER")}
${kit.emit("fire", "DEFENDER")}
${kit.emit("shockWhite", "DEFENDER")}
${kit.emit("shockDark", "DEFENDER")}
${kit.emit("smoke", "DEFENDER")}
${kit.emit("embers", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 24, 6
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 4, 0, 6
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 8
Wait 6
ChangeSpriteColor DEFENDER, 14, 0, 1, 31, 24, 6
Wait ${HOLD - 6}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 13, 0, 1, 2, 1, 6
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

const { built } = await kit.finish({
  script,
  donorMoveIds: [463, 63, 153, 400, 564, 129, 163],
  references: ["reference/Collision_Course_IX.png", "reference/Collision_Course_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, "ChangeBackgroundColor 4, 0, 13, 1, 2, 1, 6", `Emit ${SPA}, 2, ATTACKER`, `Emit ${SPA}, 5, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 8, DEFENDER`, "ShakeScreen VERTICAL, 1x", "MoveCamera INTERPOLATION, INIT"],
});
assert.ok(built("wingRight").flipTextureS && !built("wingLeft").flipTextureS, "Wings are not mirrored");
assert.ok(built("wheel").aspectRatio < 0.7, "Wheel is not a tall oval");
console.log(`  sigil f${CAMERA_IN}-${CAMERA_IN + SIGIL}, dive ${DIVE}f, impact f${CAMERA_IN + SIGIL + DIVE}`);
