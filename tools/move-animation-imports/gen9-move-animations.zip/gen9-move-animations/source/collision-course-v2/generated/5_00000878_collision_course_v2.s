MoveCamera INTERPOLATION, ATTACKER, 14, 0, 8
LetCMDsFinish CAMERA
LoadSPA 872
AudioContainer CONTINUE
PlaySound 1975, SE1, 14, 0, 0, 120, 0, 0, 0
PlaySound 1497, SE2, 14, 6, 300, 100, 0, 0, 0
PlaySound 1424, SE1, 14, 30, -300, 120, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 10, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 13, 1, 2, 1, 6
AdjustCamera INTERPOLATION_RELATIVE, 0, 0, 0, 0, 2px, 0, 18, 0, 20
Emit 872, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 872, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 872, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 872, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 872, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 30
Emit 872, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 12
Wait 10
AudioContainer CONTINUE
PlaySound 1475, SE1, 16, 0, -500, 127, 0, 0, 0
PlaySound 1425, SE2, 16, 0, 0, 120, 0, 0, 0
PlaySound 1475, SE1, 16, 8, -700, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 872, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 872, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 872, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 872, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 872, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 872, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 24, 6
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 4, 0, 6
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 8
Wait 6
ChangeSpriteColor DEFENDER, 14, 0, 1, 31, 24, 6
Wait 22
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 13, 0, 1, 2, 1, 6
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
