import { mkdir, readFile, writeFile } from "node:fs/promises";
import { NARC } from "../../Pokeweb-Serverless/src/nds/narc";
import { NintendoDSRom } from "../../Pokeweb-Serverless/src/nds/rom";
import { loadProjectFromRomBytes } from "../../Pokeweb-Serverless/src/pokeweb/loader";
import { decompileMoveAnimationBytes, getMoveAnimationTargetInfo } from "../../Pokeweb-Serverless/src/pokeweb/moveAnimationModel";
const [romPath, outDir, ...ids] = process.argv.slice(2).filter((a) => a !== "--");
await mkdir(outDir!, { recursive: true });
const bytes = new Uint8Array(await readFile(romPath!));
const rom = new NintendoDSRom(bytes);
const project = await loadProjectFromRomBytes(bytes, "rom.nds");
const names = project.texts.banks.moves ?? {};
const spaNarc = new NARC(rom.getFileByName("a/0/0/6"));
for (const id of ids.map(Number)) {
  const t = getMoveAnimationTargetInfo(project, id)!;
  const anim = new NARC(rom.getFileByName(t.sourcePath)).files[t.index]!;
  const script = decompileMoveAnimationBytes(anim);
  await writeFile(`${outDir}/move_${id}_animation.s`, script);
  const spas = [...new Set([...script.matchAll(/LoadSPA (\d+)/g)].map((m) => Number(m[1])))];
  for (const s of spas) await writeFile(`${outDir}/spa_${s}.spa`, spaNarc.files[s]!);
  console.log(`${id} ${names[id]}: ${anim.length}b, SPAs ${spas.join(",") || "none"}`);
}
