import { readFile } from "node:fs/promises";
import { parseSpaArchive } from "../../Pokeweb-Serverless/src/pokeweb/nitroSpa";
const [spa] = process.argv.slice(2).filter((a) => a !== "--");
const a = parseSpaArchive(new Uint8Array(await readFile(`../work/donor-pool/spa_${spa}.spa`)));
for (const r of a.resources) console.log(`E${r.index}: tex=${r.textureIndex} texAnim=${r.texAnim ? JSON.stringify({ t: r.texAnim.textures.slice(0, r.texAnim.textureCount), step: r.texAnim.step, loop: r.texAnim.loop, rand: r.texAnim.randomizeInit }) : "-"} loopFrames=${r.loopFrames} child=${r.childResource ? `tex${r.childResource.textureIndex}` : "-"}`);
