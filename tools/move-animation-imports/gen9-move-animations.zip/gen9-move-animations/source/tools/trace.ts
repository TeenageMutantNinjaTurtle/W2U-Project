import { readFile } from "node:fs/promises";
import { parseSpaArchive } from "../../Pokeweb-Serverless/src/pokeweb/nitroSpa";
import { simulateSplPreview } from "../../Pokeweb-Serverless/src/pokeweb/splEmitterSimulator";
import { buildMoveAnimationPreview, loadMoveSpaArchive } from "../../Pokeweb-Serverless/src/pokeweb/moveAnimationPreviewModel";
import { loadMoveAnimationBattleEnvironment } from "../../Pokeweb-Serverless/src/pokeweb/moveAnimationBattleEnvironment";
import { loadProjectFromRomBytes } from "../../Pokeweb-Serverless/src/pokeweb/loader";
const args = process.argv.slice(2).filter((a) => a !== "--");
const [romPath, scriptPath, spaPath, moveIdRaw, namesRaw, ...frames] = args;
const NAMES = namesRaw!.split(",");
const project = await loadProjectFromRomBytes(new Uint8Array(await readFile(romPath!)), "rom.nds");
const custom = new Map<number, any>();
const m = /(\d+)(?!.*\d)/.exec(spaPath!.replace(/\.[^.]+$/, ""));
custom.set(Number(m![1]), parseSpaArchive(new Uint8Array(await readFile(spaPath!))));
const preview = await buildMoveAnimationPreview(project, Number(moveIdRaw), await readFile(scriptPath!, "utf8"), {
  loadSpaArchive: (p: any, id: number) => Promise.resolve(custom.get(id)).then((a) => a ?? loadMoveSpaArchive(p, id)),
});
preview.battleEnvironment = await loadMoveAnimationBattleEnvironment(project);
const f = (n: number) => n.toFixed(1);
for (const fr of frames) {
  const ps = simulateSplPreview(preview, Number(fr));
  const byRes = new Map<number, any[]>();
  for (const p of ps) { if (!byRes.has(p.resourceIndex)) byRes.set(p.resourceIndex, []); byRes.get(p.resourceIndex)!.push(p); }
  const parts = [...byRes.entries()].sort((a, b) => a[0] - b[0]).map(([r, list]) => {
    const p0: any = list[0];
    const rng = (k: number) => { const v = list.map((p: any) => p.position[k]); return list.length === 1 ? f(v[0]) : `${f(Math.min(...v))}..${f(Math.max(...v))}`; };
    const cols = [...new Set(list.map((p: any) => p.color.map((c: number) => c.toFixed(1)).join("/")))].slice(0, 3).join(" ");
    return `${NAMES[r] ?? r}${list.length > 1 ? `(${list.length})` : ""}@(${rng(0)},${rng(1)},${rng(2)}) a=${p0.alpha.toFixed(2)} sc=${p0.scale.toFixed(1)} c=${cols}`;
  });
  console.log(`f${String(fr).padStart(3)} [${ps.length}] ${parts.join(" | ") || "-"}`);
}
