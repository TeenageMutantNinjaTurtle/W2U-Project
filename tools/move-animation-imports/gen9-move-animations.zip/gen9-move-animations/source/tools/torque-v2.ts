// Shared builder for the five Torque v2 animations (Blazing, Wicked, Noxious,
// Combat, Magical), from Bulbapedia's stills. All five play out the same way:
//   1. The Starmobile revs inside a wreath of its type's energy rising off the
//      ground round it.
//   2. It slams into the foe: a flattened vortex of the type's colour swirls
//      on the ground round the foe, and a crown of spikes fans up out of it
//      round a bright core spark.
// Each move picks colours, the rising texture and one extra impact layer.
import { createKit, fadeInOut, fadeOut, grow, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "./anim-kit";

export type Tint = [number, number, number]; // 0-31 sprite colour
export type Extra = "flames" | "shadows" | "blobs" | "streaks" | "stars";

export interface TorqueStyle {
  workDir: string;
  slug: string;
  moveId: number;
  spaId: number;
  references: string[];
  aura: [Rgb, Rgb, Rgb]; // rising wreath, random per particle
  rising: "flame" | "jagged" | "puff"; // what the wreath is made of
  vortex: [Rgb, Rgb, Rgb]; // ground swirl: base, start, end
  fan: [Rgb, Rgb, Rgb]; // the crown of spikes
  core: [Rgb, Rgb, Rgb]; // the centre spark
  extra: Extra;
  extraColours: [Rgb, Rgb, Rgb];
  userTint: Tint;
  foeTint: Tint;
  dim?: Tint; // darken the background to this colour while it plays
  revSounds: string[]; // PlaySound lines during the rev (frame offsets from its start)
  hitSounds: string[];
}

const CAMERA_IN = 12;
const REV = 26;
const DASH = 8;
const HIT_STOP = 4;
const HOLD = 22;

const USER: Vec3 = [0, 0.3, 0.2];
const USER_FLOOR: Vec3 = [0, -1.5, 0.2];
const FOE: Vec3 = [0, 0.3, 0.8];
const FOE_FLOOR: Vec3 = [0, -1.5, 0.8];
const WHITE: Rgb = [1, 1, 1];

export async function buildTorque(style: TorqueStyle): Promise<void> {
  const kit = await createKit({ workDir: style.workDir, slug: style.slug, moveId: style.moveId, spaId: style.spaId, donors: [228, 321, 465, 579, 411, 298] });
  const SPA = style.spaId;

  // --- the rev ---
  const risingTex = { flame: kit.tex(321, 6), jagged: kit.tex(579, 2), puff: kit.tex(321, 5) }[style.rising];
  const aura = kit.spray([228, 3], risingTex, USER_FLOOR, { radius: 1.9, speed: 0, count: 2, bursts: 10, gap: 2, life: 10, scale: style.rising === "flame" ? 0.85 : 0.7, shape: "circle", directional: style.rising === "flame" });
  aura.emissionAxis = 1;
  aura.axis = [0, 1, 0];
  aura.initVelAxisAmplifier = 0.26;
  if (style.rising !== "flame") spin(aura, -0.1, 0.1, 0, true);
  setCurves(aura, grow(0.5, 0.3, 1.25), fadeInOut(1, 0.2, 0.55));
  kit.prism(aura, style.aura);
  kit.add("aura", aura);

  const glow = kit.parked(kit.tex(465, 1), USER, 2.6, REV + 2);
  setCurves(glow, grow(0.5, 0.35, 1.1), fadeInOut(0.6, 0.25, 0.85));
  paint(glow, style.aura[1], style.aura[0], style.aura[2]);
  kit.add("glow", glow);

  const sparks = kit.spray([228, 3], kit.tex(411, 0), USER_FLOOR, { radius: 1.6, speed: 0.3, count: 1, bursts: 8, gap: 3, life: 6, scale: 1.0, shape: "circle", directional: true });
  sparks.emissionAxis = 1;
  sparks.axis = [0, 1, 0];
  sparks.initVelAxisAmplifier = 0.12;
  setCurves(sparks, undefined, fadeOut());
  kit.prism(sparks, [style.fan[0], WHITE, style.fan[2]]);
  kit.add("sparks", sparks);

  // (The charge's streak trail was removed at Logan's request, 2026-10-01: the
  // spray shells have drag, so it stalled between the two Pokemon and showed
  // as stray lights in the top right during the camera pan.)

  // --- the hit ---
  const swirl = (scale: number, delay: number, level: number) => {
    const r = kit.parked(kit.tex(228, 3), FOE_FLOOR, scale, HOLD - delay);
    r.aspectRatio = 3.0;
    r.startDelayFrames = delay;
    setCurves(r, grow(0.35, 0.3, 1.2), fadeInOut(level, 0.1, 0.6));
    paint(r, ...style.vortex);
    return r;
  };
  kit.add("swirlOuter", swirl(3.4, 0, 1));
  kit.add("swirlInner", swirl(2.4, 2, 0.85));

  const whirl = kit.spray([333, 1], kit.tex(333, 2), [0, -1.2, 0.8], { radius: 2.4, speed: 0, count: 3, bursts: 5, gap: 2, life: 8, scale: 1.1, shape: "circle", directional: true });
  whirl.emissionAxis = 1;
  whirl.behaviors = [{ type: "spin", axis: 1, angle: 0.5 }];
  setCurves(whirl, undefined, fadeOut(1, 0.4));
  kit.prism(whirl, style.vortex);
  kit.add("whirl", whirl);

  const fan = kit.spray([228, 3], kit.tex(321, 6), [0, -1.0, 0.8], { radius: 0.6, speed: 0.4, count: 12, life: 10, scale: 0.8, directional: true });
  fan.axis = [0, 1, 0];
  fan.initVelAxisAmplifier = 0.28;
  setCurves(fan, grow(0.8, 0.3, 1.0), fadeOut(1, 0.45));
  kit.prism(fan, style.fan);
  kit.add("fan", fan);

  const core = kit.parked(kit.tex(579, 2), FOE, 1.3, 10);
  spin(core, 0.12);
  setCurves(core, grow(0.4, 0.25, 1.4), fadeOut(1, 0.35));
  paint(core, ...style.core);
  kit.add("core", core);

  const flash = kit.parked(kit.tex(228, 1), FOE, 1.4, 10);
  spin(flash, 0.06);
  setCurves(flash, grow(0.4, 0.2, 1.8), fadeOut(1, 0.35));
  paint(flash, style.core[1], WHITE, style.core[2]);
  kit.add("flash", flash);

  const [ea, eb, ec] = style.extraColours;
  let extra;
  switch (style.extra) {
    case "flames": {
      extra = kit.spray([333, 1], kit.tex(321, 5), FOE_FLOOR, { radius: 1.6, speed: 0.02, count: 2, bursts: 4, gap: 3, life: 14, scale: 0.8, shape: "circle" });
      extra.emissionAxis = 1;
      extra.axis = [0, 1, 0];
      extra.initVelAxisAmplifier = 0.12;
      spin(extra, -0.08, 0.08, 0, true);
      setCurves(extra, grow(0.5, 0.3, 1.3), fadeInOut(0.9, 0.15, 0.5));
      break;
    }
    case "shadows": {
      extra = kit.spray([228, 3], kit.tex(465, 3), [0, -0.9, 0.8], { radius: 0.5, speed: 0.35, count: 7, life: 12, scale: 0.9, directional: true });
      extra.axis = [0, 1, 0];
      extra.initVelAxisAmplifier = 0.2;
      setCurves(extra, grow(0.6, 0.3, 1.1), fadeOut(1, 0.5));
      break;
    }
    case "blobs": {
      extra = kit.spray([333, 1], kit.tex(465, 1), FOE, { radius: 0.5, speed: 0.3, count: 7, life: 16, scale: 0.5 });
      extra.axis = [0, 1, 0];
      extra.initVelAxisAmplifier = 0.12;
      extra.behaviors = [{ type: "gravity", magnitude: [0, -0.02, 0] }];
      setCurves(extra, grow(0.6, 0.2, 1.1), fadeOut(1, 0.6));
      break;
    }
    case "streaks": {
      extra = kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.4, speed: 0.75, count: 7, life: 9, scale: 2.0, directional: true });
      setCurves(extra, undefined, fadeOut());
      break;
    }
    case "stars": {
      extra = kit.spray([333, 1], kit.tex(298, 3), FOE, { radius: 0.6, speed: 0.22, count: 6, life: 16, scale: 0.35 });
      spin(extra, -0.15, 0.15, 0, true);
      setCurves(extra, grow(0.4, 0.2, 1), twinkle(1));
      break;
    }
  }
  kit.prism(extra, [ea, eb, ec]);
  kit.add("extra", extra);

  // --- script ---
  const t = (rgb: Tint) => rgb.join(", ");
  const [ur, ug, ub] = style.userTint;
  const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1487, SE1, 14, 0, 500, 70, 0, 0, 0
PlaySound 1487, SE1, 14, 12, 900, 80, 0, 0, 0
${style.revSounds.join("\n")}
PlaySound 1536, SE2, 14, ${REV - 2}, 0, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${DASH}, 0, 50, 0, 0
AudioContainer SUSPEND
${style.dim ? `ChangeBackgroundColor 4, 0, 8, 1, ${t(style.dim)}` : ""}
ChangeSpriteColor ATTACKER, 0, 10, 2, ${ur}, ${ug}, ${ub}
${kit.emit("aura", "ATTACKER")}
${kit.emit("glow", "ATTACKER")}
${kit.emit("sparks", "ATTACKER")}
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 13
Wait ${REV}
ChangeSpriteColor ATTACKER, 10, 0, 1, ${ur}, ${ug}, ${ub}
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, ${DASH}, 0, 8
Wait ${DASH}
AudioContainer CONTINUE
PlaySound 1420, SE1, 16, 0, -300, 125, 0, 0, 0
${style.hitSounds.join("\n")}
AudioContainer SUSPEND
${kit.emit("swirlOuter", "DEFENDER")}
${kit.emit("swirlInner", "DEFENDER")}
${kit.emit("whirl", "DEFENDER")}
${kit.emit("fan", "DEFENDER")}
${kit.emit("core", "DEFENDER")}
${kit.emit("flash", "DEFENDER")}
${kit.emit("extra", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, ${t(style.foeTint)}
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 12, 0, 1, ${t(style.foeTint)}
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait ${HOLD - HIT_STOP}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
${style.dim ? `ChangeBackgroundColor 4, 8, 0, 1, ${t(style.dim)}` : ""}
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`.replace(/\n\n+/g, "\n");

  await kit.finish({
    script,
    donorMoveIds: [63, 240, 153, 400, 605, 129],
    references: style.references,
    expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("swirlOuter")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("fan")}, DEFENDER`, "ShakeScreen VERTICAL, 1x", "MoveCamera INTERPOLATION, INIT"],
  });
  console.log(`  rev f${CAMERA_IN}-${CAMERA_IN + REV}, hit f${CAMERA_IN + REV + DASH}`);
}
