// Verify a staged preview ROM after installing one move, then record it.
// usage: vite-node verify.ts -- <stage.nds> <moveId> <slug>
// Checks the shipped move's script and SPA match its generated files, and that
// every other move in installed.json is still byte-identical. Only then is the
// registry updated (the caller promotes the stage ROM).
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { NARC } from "../../Pokeweb-Serverless/src/nds/narc";
import { NintendoDSRom } from "../../Pokeweb-Serverless/src/nds/rom";
import { parseSpaArchive } from "../../Pokeweb-Serverless/src/pokeweb/nitroSpa";

const WORK = path.join(import.meta.dirname, "..");
const REGISTRY = path.join(import.meta.dirname, "installed.json");
type Entry = { slug: string; anim: string; spaId: number | null; spa: string | null };

const [stagePath, moveRaw, slug] = process.argv.slice(2).filter((a) => a !== "--");
const moveId = Number(moveRaw);
const sha = (b: Uint8Array) => createHash("sha256").update(b).digest("hex").slice(0, 16);
const rom = new NintendoDSRom(new Uint8Array(await readFile(stagePath!)));
const anims = new NARC(rom.getFileByName("a/0/6/5"));
const spas = new NARC(rom.getFileByName("a/0/0/6"));
const registry: Record<string, Entry> = JSON.parse(await readFile(REGISTRY, "utf8"));

const manifest = JSON.parse(await readFile(path.join(WORK, slug!, "moveanim.json"), "utf8"));
const spaId: number | null = manifest.reservedSpaIds?.[0] ?? null;
registry[String(moveId)] = {
  slug: slug!,
  anim: `${slug}/${manifest.animation}`,
  spaId,
  spa: spaId === null ? null : `${slug}/${manifest.spas[0]}`,
};

let failures = 0;
for (const [id, entry] of Object.entries(registry)) {
  const want = new Uint8Array(await readFile(path.join(WORK, entry.anim)));
  if (sha(anims.files[Number(id)]!) !== sha(want)) { console.log(`MISMATCH script ${id} (${entry.slug})`); failures++; }
  if (entry.spaId !== null && entry.spa) {
    const wantSpa = new Uint8Array(await readFile(path.join(WORK, entry.spa)));
    if (sha(spas.files[entry.spaId]!) !== sha(wantSpa)) { console.log(`MISMATCH spa ${entry.spaId} (${entry.slug})`); failures++; }
  }
}
const shipped = spaId === null ? null : parseSpaArchive(spas.files[spaId]!);
console.log(`verify: ${Object.keys(registry).length} moves checked, ${failures} mismatches; a/0/0/6 has ${spas.files.length} files${shipped ? `; spa ${spaId}: ${shipped.resources.length}res/${shipped.textures.length}tex warn=${shipped.warnings.length}` : ""}`);
if (failures > 0 || (shipped && shipped.warnings.length > 0)) process.exit(1);
await writeFile(REGISTRY, `${JSON.stringify(Object.fromEntries(Object.entries(registry).sort(([a], [b]) => Number(a) - Number(b))), null, 2)}\n`);
