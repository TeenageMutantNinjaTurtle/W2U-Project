#!/usr/bin/env bash
# usage: tools/ship.sh <slug> <moveId>      (NO_INSTALL=1 to stop after lint)
# generate -> compile -> lint -> install into a stage copy -> verify -> promote
set -uo pipefail
slug=$1; move=$2
cd "${POKEWEB_PROJECT_ROOT:-.}" || exit 1
W="${ANIMATION_WORK_DIR:-work}"
pad=$(printf %08d "$move")
gen=$(timeout 300 npx vite-node "$W/$slug/make-$slug.ts" 2>&1) || { echo "$gen" | grep -vE "^\s+at " | tail -15; echo "GENERATE FAILED"; exit 1; }
echo "$gen" | grep -E "^Wrote|^  "
script=$(ls "$W/$slug/generated/5_${pad}_"*.s | head -1)
rm -f "$W/$slug/generated/5_${pad}.bin"
timeout 300 npx vite-node scripts/move-animation-helper.ts -- compile --script "$script" --out "$W/$slug/generated/5_${pad}.bin" --move "$move" 2>&1 | tail -1
[ -f "$W/$slug/generated/5_${pad}.bin" ] || { echo "COMPILE FAILED"; exit 1; }
lint=$(timeout 300 npx vite-node scripts/move-animation-workflow.ts -- lint --manifest "$W/$slug/moveanim.json" 2>&1)
echo "$lint" | grep -iE "lint |error|peak|polygon-pressure"
echo "$lint" | grep -q "Lint PASS" || { echo "LINT FAILED"; exit 1; }
echo "$lint" | grep -q "polygon-pressure" && [ "${ALLOW_PRESSURE:-}" != 1 ] && { echo "OVER PARTICLE BUDGET (set ALLOW_PRESSURE=1 to install anyway)"; exit 1; }
[ "${NO_INSTALL:-}" = 1 ] && exit 0
rm -f "$W/mp-stage.nds"
timeout 600 npx vite-node scripts/move-animation-workflow.ts -- install --manifest "$W/$slug/moveanim.json" --preview-rom "$W/moves-preview.nds" --out "$W/mp-stage.nds" 2>&1 | grep -E "Installed|a/0/0/6|a/0/6/5|rror" 
timeout 600 npx vite-node "$W/tools/verify.ts" -- "$W/mp-stage.nds" "$move" "$slug" 2>&1 | tail -6 || { echo "VERIFY FAILED (stage kept, preview untouched)"; exit 1; }
mv -f "$W/mp-stage.nds" "$W/moves-preview.nds" && echo "SHIPPED $slug -> move $move"
