#!/usr/bin/env bash
# usage: tools/fetch-ref.sh <slug> <bulbagarden thumb or full URL>...
# Downloads the full-size images into work/<slug>/reference/.
slug=$1; shift
D="${ANIMATION_WORK_DIR:-work}/$slug/reference"
mkdir -p "$D"
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"
for url in "$@"; do
  full=$(echo "$url" | sed -E 's#/thumb/([^/]+/[^/]+/[^/]+)/[^/]+$#/\1#')
  name=$(basename "$full")
  curl -s -A "$UA" -H "Referer: https://bulbapedia.bulbagarden.net/" -o "$D/$name" -w "$name: %{http_code} %{size_download}B\n" --max-time 60 "$full"
done
