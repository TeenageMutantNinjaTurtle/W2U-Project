MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
ChangeBackgroundColor 4, 0, 14, 1, 2, 0, 5
LetCMDsFinish CAMERA
LoadSPA 927
AudioContainer CONTINUE
PlaySound 1514, SE1, 16, 0, -400, 127, 0, 0, 0
PlaySound 1423, SE2, 16, 1, -300, 110, 0, 0, 0
PlaySound 1783, SE2, 14, 5, -500, 105, 0, 0, 0
PlaySound 1816, SE1, 14, 22, 700, 115, 0, 0, 0
PlaySound 1509, SE2, 14, 33, 1200, 90, 0, 0, 0
PlaySound 1475, SE1, 16, 41, -300, 127, 0, 0, 0
PlaySound 1423, SE2, 16, 41, -700, 127, 0, 0, 0
PlaySound 1420, SE2, 16, 48, -200, 115, 0, 0, 0
AudioContainer SUSPEND
Emit 927, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 927, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
Wait 2
ChangeSpriteColor DEFENDER, 0, 12, 0, 31, 16, 30
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 5
Wait 4
ChangeSpriteColor DEFENDER, 12, 5, 2, 24, 10, 31
Wait 35
ChangeSpriteColor DEFENDER, 5, 15, 0, 31, 26, 31
Wait 5
ChangeSpriteColor DEFENDER, 15, 0, 2, 31, 26, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 4, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 14
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 23
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 14, 0, 2, 2, 0, 5
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
