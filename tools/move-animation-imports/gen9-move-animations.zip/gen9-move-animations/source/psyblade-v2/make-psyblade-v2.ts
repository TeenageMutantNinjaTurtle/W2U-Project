import { createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Psyblade (move 875), v2 - from Logan's keyframes (reference/keyframe-1..4)
// and brief: "no startup: instead just does a single thick slash across the
// target -> then the psychic mist condenses into a point, pauses -> then
// explodes dealing damage".
//   1. The scene goes dark and one thick magenta slash with a white-hot core
//      sweeps across the foe.
//   2. Psychic mist hangs along the cut: purple, magenta and blue cloud, dark
//      blue spikes under it, magenta rings floating.
//   3. The mist condenses into a single point - and holds.
//   4. It explodes: white and magenta light streaks burst out in every
//      direction with cyan flecks, glitter and an olive-gold spiky star.
// 80 power, boosted on Electric Terrain (the engine's business); the pause
// and blast carry the weight.
// v1 (../psyblade, from the Bulbapedia stills) is kept; reinstall its
// manifest to revert.

const SPA = 927;
const kit = await createKit({ workDir: import.meta.dirname, slug: "psyblade-v2", moveId: 875, spaId: SPA, donors: [333, 321, 298, 465, 228, 411, 579, 407] });

// --- timing (30 fps) ---
const CAMERA_IN = 8;
const SLASH = 8;
const MIST = 14;
const CONDENSE = 10;
const PAUSE = 9;
const HIT_STOP = 5;
const HOLD = 28;

const FOE: Vec3 = [0, 0.3, 0.8];
const TILT = 10; // degrees the cut rises, left to right
const along = (t: number, lift = 0): Vec3 => [FOE[0] + t * Math.cos(deg(TILT)), FOE[1] + t * Math.sin(deg(TILT)) + lift, FOE[2] + 0.1];

const MAGENTA: Rgb = [1.0, 0.35, 0.95];
const PINK: Rgb = [1.0, 0.7, 0.98];
const VIOLET: Rgb = [0.62, 0.3, 1.0];
const BLUE: Rgb = [0.35, 0.4, 1.0];
const DEEP_BLUE: Rgb = [0.16, 0.14, 0.6];
const CYAN: Rgb = [0.45, 0.9, 1.0];
const OLIVE_GOLD: Rgb = [0.85, 0.82, 0.3];
const WHITE: Rgb = [1, 1, 1];

// --- 1. the slash ---
function blade(scale: number, aspect: number, colour: Rgb, start: Rgb, level: number, life: number): ReturnType<typeof kit.parked> {
  const r = kit.parked(kit.tex(333, 2), FOE, scale, life);
  r.aspectRatio = aspect;
  r.initAngle = deg(-(90 - TILT)); // the streak texture is a vertical line
  setCurves(r, grow(0.08, 0.2, 1.05), fadeOut(level, 0.5));
  paint(r, colour, start, colour);
  return r;
}
kit.add("bladeGlow", blade(6.4, 0.85, VIOLET, MAGENTA, 0.6, SLASH + 8));
kit.add("blade", blade(6.0, 0.5, MAGENTA, WHITE, 1, SLASH + 6));
kit.add("bladeCore", blade(5.6, 0.2, WHITE, WHITE, 1, SLASH + 4));

const slashSparks = kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.4, speed: 0.6, count: 6, life: 7, scale: 1.4, directional: true });
slashSparks.startDelayFrames = 2;
setCurves(slashSparks, undefined, fadeOut());
kit.prism(slashSparks, [WHITE, PINK, MAGENTA]);
kit.add("slashSparks", slashSparks);

// --- 2. the mist along the cut ---
const MIST_AT = 3;
[-1.7, 0, 1.7].forEach((t, i) => {
  const r = kit.spray([333, 1], kit.tex(321, 5), along(t, 0.3), { radius: 0.7, speed: 0.02, count: 1, bursts: 3, gap: 3, life: 13, scale: 1.3, shape: "ball" });
  r.startDelayFrames = MIST_AT + i;
  r.axis = [0, 1, 0];
  r.initVelAxisAmplifier = 0.04;
  spin(r, -0.05, 0.05, 0, true);
  setCurves(r, grow(0.5, 0.3, 1.4), fadeInOut(0.8, 0.2, 0.6));
  kit.prism(r, [MAGENTA, VIOLET, BLUE]);
  kit.add(`mist${i}`, r);
});

const spikes = kit.spray([228, 3], kit.tex(321, 6), along(0, -0.7), { radius: 1.9, speed: 0, count: 3, bursts: 2, gap: 4, life: 11, scale: 0.9, shape: "circle", directional: true });
spikes.startDelayFrames = MIST_AT;
spikes.axis = [0.15, 1, 0];
spikes.initVelAxisAmplifier = 0.1;
setCurves(spikes, grow(0.4, 0.3, 1.2), fadeInOut(0.9, 0.2, 0.6));
kit.prism(spikes, [DEEP_BLUE, BLUE, VIOLET]);
kit.add("spikes", spikes);

const rings = kit.spray([333, 1], kit.tex(298, 2), along(0, 0.4), { radius: 1.9, speed: 0.02, count: 1, bursts: 5, gap: 3, life: 12, scale: 0.35, shape: "ball" });
rings.startDelayFrames = MIST_AT + 2;
setCurves(rings, grow(0.5, 0.3, 1.1), fadeInOut(1, 0.2, 0.7));
kit.prism(rings, [MAGENTA, PINK, MAGENTA]);
kit.add("rings", rings);

// --- 3. the mist condenses to a point ---
const CONDENSE_AT = SLASH + MIST;
const implode = kit.spray([333, 1], kit.tex(321, 5), FOE, { radius: 2.6, speed: 0, count: 8, life: CONDENSE, scale: 1.1, shape: "sphere" });
implode.startDelayFrames = CONDENSE_AT;
implode.behaviors = [{ type: "convergence", target: [0, 0, 0], force: 0.2 }];
spin(implode, -0.08, 0.08, 0, true);
setCurves(implode, { start: 1, mid: 0.7, end: 0.15, curveIn: 0.3, curveOut: 0.4 }, fadeInOut(0.85, 0.15, 0.85));
kit.prism(implode, [MAGENTA, VIOLET, BLUE]);
kit.add("implode", implode);

const inRings = kit.spray([333, 1], kit.tex(298, 2), FOE, { radius: 2.4, speed: 0, count: 5, life: CONDENSE, scale: 0.35, shape: "sphere" });
inRings.startDelayFrames = CONDENSE_AT;
inRings.behaviors = [{ type: "convergence", target: [0, 0, 0], force: 0.2 }];
setCurves(inRings, { start: 1, mid: 0.7, end: 0.2, curveIn: 0.3, curveOut: 0.4 }, fadeInOut(1, 0.15, 0.85));
kit.prism(inRings, [MAGENTA, PINK, MAGENTA]);
kit.add("inRings", inRings);

const collapse = kit.parked(kit.tex(465, 1), FOE, 3.4, CONDENSE);
collapse.startDelayFrames = CONDENSE_AT;
setCurves(collapse, { start: 1, mid: 0.5, end: 0.08, curveIn: 0.4, curveOut: 0.4 }, fadeInOut(0.8, 0.2, 0.9));
paint(collapse, MAGENTA, VIOLET, PINK);
kit.add("collapse", collapse);

// The point, held through the pause.
const PAUSE_AT = CONDENSE_AT + CONDENSE;
const point = kit.parked(kit.tex(407, 1), FOE, 0.55, PAUSE);
point.startDelayFrames = PAUSE_AT;
spin(point, 0.1, 0.1, deg(45));
setCurves(point, { start: 0.5, mid: 1, end: 1.3, curveIn: 0.3, curveOut: 0.8 }, hold(1));
paint(point, WHITE, PINK, WHITE);
kit.add("point", point);

const pointGlow = kit.parked(kit.tex(465, 1), FOE, 0.6, PAUSE);
pointGlow.startDelayFrames = PAUSE_AT;
setCurves(pointGlow, { start: 0.6, mid: 1, end: 1.5, curveIn: 0.3, curveOut: 0.8 }, hold(0.9));
paint(pointGlow, MAGENTA, PINK, WHITE);
kit.add("pointGlow", pointGlow);

// --- 4. the explosion ---
const BLAST_AT = PAUSE_AT + PAUSE;
const blastAt = <T extends { startDelayFrames: number }>(r: T, extra = 0): T => { r.startDelayFrames = BLAST_AT + extra; return r; };

const flash = blastAt(kit.parked(kit.tex(228, 1), FOE, 2.6, 14));
spin(flash, 0.05);
setCurves(flash, grow(0.3, 0.2, 2.4), fadeOut(1, 0.35));
paint(flash, WHITE, WHITE, PINK);
kit.add("flash", flash);

const star = blastAt(kit.parked(kit.tex(579, 2), FOE, 2.2, 14));
spin(star, 0.08);
setCurves(star, grow(0.3, 0.25, 1.6), fadeOut(1, 0.4));
paint(star, OLIVE_GOLD, WHITE, OLIVE_GOLD);
kit.add("star", star);

const rays = blastAt(kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.3, speed: 1.0, count: 14, life: 10, scale: 2.8, directional: true }));
setCurves(rays, undefined, fadeOut(1, 0.45));
kit.prism(rays, [WHITE, MAGENTA, PINK]);
kit.add("rays", rays);

const flecks = blastAt(kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.8, speed: 0.6, count: 10, life: 12, scale: 1.0, directional: true }), 1);
setCurves(flecks, undefined, fadeOut(1, 0.5));
kit.prism(flecks, [CYAN, MAGENTA, WHITE]);
kit.add("flecks", flecks);

const glitter = blastAt(kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.6, speed: 0.45, count: 10, life: 16, scale: 0.13 }), 1);
glitter.airResistance = 0.93;
setCurves(glitter, undefined, twinkle());
kit.prism(glitter, [PINK, WHITE, CYAN]);
kit.add("glitter", glitter);

const shock = blastAt(kit.parked(kit.tex(298, 2), FOE, 1.6, 12));
shock.aspectRatio = 2.2;
shock.initAngle = deg(TILT);
setCurves(shock, grow(0.3, 0.3, 2.2), fadeOut(1, 0.35));
paint(shock, MAGENTA, WHITE, VIOLET);
kit.add("shock", shock);

// --- script ---
const names = ["bladeGlow", "blade", "bladeCore", "slashSparks", "mist0", "mist1", "mist2", "spikes", "rings", "implode", "inRings", "collapse", "pointGlow", "point", "flash", "star", "rays", "flecks", "glitter", "shock"];
const script = `MoveCamera INTERPOLATION, DEFENDER, ${CAMERA_IN}, 0, 8
ChangeBackgroundColor 4, 0, 14, 1, 2, 0, 5
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1514, SE1, 16, 0, -400, 127, 0, 0, 0
PlaySound 1423, SE2, 16, 1, -300, 110, 0, 0, 0
PlaySound 1783, SE2, 14, ${MIST_AT + 2}, -500, 105, 0, 0, 0
PlaySound 1816, SE1, 14, ${CONDENSE_AT}, 700, 115, 0, 0, 0
PlaySound 1509, SE2, 14, ${PAUSE_AT + 1}, 1200, 90, 0, 0, 0
PlaySound 1475, SE1, 16, ${BLAST_AT}, -300, 127, 0, 0, 0
PlaySound 1423, SE2, 16, ${BLAST_AT}, -700, 127, 0, 0, 0
PlaySound 1420, SE2, 16, ${BLAST_AT + HIT_STOP + 2}, -200, 115, 0, 0, 0
AudioContainer SUSPEND
${names.map((n) => kit.emit(n, "DEFENDER")).join("\n")}
ToggleFreezeSprite DEFENDER, START
Wait 2
ChangeSpriteColor DEFENDER, 0, 12, 0, 31, 16, 30
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 5
Wait 4
ChangeSpriteColor DEFENDER, 12, 5, 2, 24, 10, 31
Wait ${BLAST_AT - 6}
ChangeSpriteColor DEFENDER, 5, 15, 0, 31, 26, 31
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 15, 0, 2, 31, 26, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 4, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 14
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait ${HOLD - HIT_STOP}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 14, 0, 2, 2, 0, 5
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [427, 163, 400, 63, 129, 153, 236],
  references: ["reference/keyframe-1.png", "reference/keyframe-2.webp", "reference/keyframe-3.png", "reference/keyframe-4.webp", "reference/Psyblade_IX.png", "reference/Psyblade_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveCamera INTERPOLATION, DEFENDER", "ChangeBackgroundColor 4, 0, 14, 1, 2, 0, 5", `Emit ${SPA}, 1, DEFENDER`, `Emit ${SPA}, ${kit.idx("implode")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("rays")}, DEFENDER`, "ShakeScreen VERTICAL, 2458", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  slash f${CAMERA_IN}, mist f${CAMERA_IN + MIST_AT}, condense f${CAMERA_IN + CONDENSE_AT}, pause f${CAMERA_IN + PAUSE_AT}, blast f${CAMERA_IN + BLAST_AT}`);
