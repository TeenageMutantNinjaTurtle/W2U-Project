import { assert, createKit, fadeOut, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Fillet Away (move 868) - from Bulbapedia's still (reference/).
// The user sheds its flesh: big curved tan-and-salmon slabs peel off and fly
// away, revealing a slimmer body, in a haze of glittery golden-brown dust.
// Status move on the user; the stat boosts play separately.
//
// Slabs are Psycho Cut's blade arc and crescent in flesh tones, tumbling off
// under gravity; the sprite squashes thin as they go.

const SPA = 862;
const kit = await createKit({ workDir: import.meta.dirname, slug: "fillet-away", moveId: 868, spaId: SPA, donors: [606, 298] });

const CAMERA_IN = 14;
const SHED = 30;

const BODY: Vec3 = [0, 0.1, 0.4];

const TAN: Rgb = [0.94, 0.76, 0.64];
const SALMON: Rgb = [0.85, 0.48, 0.4];
const DEEP_FLESH: Rgb = [0.62, 0.3, 0.26];
const GOLD: Rgb = [1.0, 0.82, 0.45];
const BROWN: Rgb = [0.7, 0.48, 0.3];
const WHITE: Rgb = [1, 1, 1];

// Slabs peeling off and flying away, two waves.
function slabs(tex: number, delay: number, colours: [Rgb, Rgb, Rgb]): ReturnType<typeof kit.spray> {
  const r = kit.spray([333, 1], tex, BODY, { radius: 0.7, speed: 0.22, count: 3, bursts: 2, gap: 5, life: 22, scale: 1.1 });
  r.startDelayFrames = delay;
  r.axis = [0, 1, 0];
  r.initVelAxisAmplifier = 0.1;
  r.behaviors = [{ type: "gravity", magnitude: [0, -0.018, 0] }];
  r.airResistance = 0.97;
  spin(r, -0.18, 0.18, 0, true);
  setCurves(r, hold(1), fadeOut(1, 0.6));
  kit.prism(r, colours);
  return r;
}
kit.add("slabs", slabs(kit.tex(606, 4), 0, [TAN, SALMON, TAN]));
kit.add("strips", slabs(kit.tex(606, 3), 4, [SALMON, DEEP_FLESH, TAN]));

// Glittery golden-brown dust.
const dust = kit.spray([333, 1], kit.tex(333, 0), BODY, { radius: 1.2, speed: 0.06, count: 2, bursts: 10, gap: 2, life: 16, scale: 0.12, shape: "ball" });
dust.behaviors = [{ type: "gravity", magnitude: [0, -0.004, 0] }];
setCurves(dust, undefined, twinkle());
kit.prism(dust, [GOLD, BROWN, TAN]);
kit.add("dust", dust);

const glints = kit.spray([333, 1], kit.tex(298, 1), BODY, { radius: 1.3, speed: 0.01, count: 1, bursts: 6, gap: 4, life: 12, scale: 0.3, shape: "ball" });
glints.startDelayFrames = 6;
setCurves(glints, twinkle(1), twinkle(1));
paint(glints, WHITE, WHITE, GOLD);
kit.add("glints", glints);

const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1423, SE1, 14, 0, -400, 115, 0, 0, 0
PlaySound 1423, SE2, 14, 5, 200, 110, 0, 0, 0
PlaySound 1509, SE1, 14, 12, 300, 90, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 12, 0, 31, 31, 31
${kit.emit("slabs", "ATTACKER")}
${kit.emit("strips", "ATTACKER")}
${kit.emit("dust", "ATTACKER")}
${kit.emit("glints", "ATTACKER")}
ScaleSprite ATTACKER, ROUNDTRIP, -1229, 819, 4, 1, 1
Wait 4
ChangeSpriteColor ATTACKER, 12, 0, 2, 31, 31, 31
Wait ${SHED - 4}
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

const { built } = await kit.finish({
  script,
  donorMoveIds: [427, 129, 163],
  references: ["reference/Fillet_Away_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, "ScaleSprite ATTACKER, ROUNDTRIP", "MoveCamera INTERPOLATION, INIT"],
});
assert.ok(built("slabs").behaviors.some((b) => b.type === "gravity"), "Slabs do not fall away");
console.log(`  shed f${CAMERA_IN}-${CAMERA_IN + SHED}`);
