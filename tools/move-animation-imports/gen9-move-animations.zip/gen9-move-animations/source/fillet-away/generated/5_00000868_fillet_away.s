MoveCamera INTERPOLATION, ATTACKER, 14, 0, 8
LetCMDsFinish CAMERA
LoadSPA 862
AudioContainer CONTINUE
PlaySound 1423, SE1, 14, 0, -400, 115, 0, 0, 0
PlaySound 1423, SE2, 14, 5, 200, 110, 0, 0, 0
PlaySound 1509, SE1, 14, 12, 300, 90, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 12, 0, 31, 31, 31
Emit 862, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 862, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 862, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 862, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, -1229, 819, 4, 1, 1
Wait 4
ChangeSpriteColor ATTACKER, 12, 0, 2, 31, 31, 31
Wait 26
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
