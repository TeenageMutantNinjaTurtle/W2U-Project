MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 897
AudioContainer CONTINUE
PlaySound 1509, SE1, 14, 0, 0, 100, 0, 0, 0
PlaySound 1497, SE2, 14, 6, 300, 100, 0, 0, 0
PlaySound 1421, SE2, 14, 22, -300, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 8, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 2, 14, 31, 12
Emit 897, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 897, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 897, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 897, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 897, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 18
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 3, 0, 1
Wait 6
ChangeSpriteColor ATTACKER, 10, 0, 1, 14, 31, 12
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
AudioContainer CONTINUE
PlaySound 1424, SE1, 16, 0, -300, 125, 0, 0, 0
PlaySound 1475, SE2, 16, 0, -400, 115, 0, 0, 0
PlaySound 1509, SE2, 16, 6, 400, 100, 0, 0, 0
AudioContainer SUSPEND
Emit 897, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 897, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 897, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 897, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 897, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 897, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 897, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 16, 31, 14
Wait 4
ChangeSpriteColor DEFENDER, 12, 0, 1, 16, 31, 14
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 18
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
