import { createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Ivy Cudgel (move 904) - from Bulbapedia's stills (reference/). This is the
// Teal Mask (Grass) look; Gen 5 can't switch a move's animation by form, so
// the Water, Fire and Rock masks share it.
//   1. The user glows green, its club raised inside a whirling green ring,
//      leaves and light motes swirling up round it.
//   2. The club comes down: an explosion of green, teal, yellow and orange
//      streaks shooting out and up, teal arcs sweeping the ground, dark
//      debris flying and dotted light trails.

const SPA = 897;
const kit = await createKit({ workDir: import.meta.dirname, slug: "ivy-cudgel", moveId: 904, spaId: SPA, donors: [228, 242, 321, 411, 465, 579] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const RAISE = 24;
const SWING = 8;
const HIT_STOP = 4;
const HOLD = 22;

const USER: Vec3 = [0, 0.3, 0.2];
const CLUB: Vec3 = [0, 1.9, 0.2];
const FOE: Vec3 = [0, 0.3, 0.8];
const FOE_FLOOR: Vec3 = [0, -1.5, 0.8];

const GREEN: Rgb = [0.45, 1.0, 0.35];
const LEAF: Rgb = [0.3, 0.8, 0.3];
const TEAL: Rgb = [0.3, 0.95, 0.8];
const YELLOW: Rgb = [1.0, 0.92, 0.35];
const ORANGE: Rgb = [1.0, 0.55, 0.2];
const PALE: Rgb = [0.85, 1.0, 0.8];
const DEBRIS: Rgb = [0.24, 0.22, 0.2];
const WHITE: Rgb = [1, 1, 1];

// --- the raised club ---
const aura = kit.parked(kit.tex(465, 1), USER, 2.8, RAISE + 2);
setCurves(aura, grow(0.5, 0.35, 1.1), fadeInOut(0.6, 0.25, 0.85));
paint(aura, GREEN, PALE, TEAL);
kit.add("aura", aura);

const ring = kit.parked(kit.tex(228, 3), CLUB, 2.0, RAISE + 2);
ring.aspectRatio = 2.8;
setCurves(ring, grow(0.3, 0.3, 1.15), fadeInOut(0.95, 0.15, 0.8));
paint(ring, GREEN, WHITE, TEAL);
kit.add("ring", ring);

const whirl = kit.spray([333, 1], kit.tex(333, 2), CLUB, { radius: 1.4, speed: 0, count: 2, bursts: 8, gap: 3, life: 8, scale: 0.8, shape: "circle", directional: true });
whirl.emissionAxis = 1;
whirl.behaviors = [{ type: "spin", axis: 1, angle: 0.5 }];
setCurves(whirl, undefined, fadeOut(1, 0.4));
kit.prism(whirl, [GREEN, PALE, TEAL]);
kit.add("whirl", whirl);

const leaves = kit.spray([333, 1], kit.tex(242, 1), [0, 0.6, 0.2], { radius: 1.5, speed: 0, count: 1, bursts: 8, gap: 3, life: 14, scale: 0.3, shape: "circle" });
leaves.emissionAxis = 1;
leaves.axis = [0, 1, 0];
leaves.initVelAxisAmplifier = 0.08;
leaves.behaviors = [{ type: "spin", axis: 1, angle: 0.25 }];
spin(leaves, -0.2, 0.2, 0, true);
setCurves(leaves, hold(1), fadeInOut(1, 0.15, 0.7));
paint(leaves, WHITE);
kit.add("leaves", leaves);

const motes = kit.spray([333, 1], kit.tex(333, 0), USER, { radius: 1.4, speed: 0, count: 1, bursts: 10, gap: 2, life: 12, scale: 0.13, shape: "ball" });
motes.axis = [0, 1, 0];
motes.initVelAxisAmplifier = 0.1;
setCurves(motes, undefined, twinkle());
kit.prism(motes, [GREEN, YELLOW, PALE]);
kit.add("motes", motes);

// --- the blow ---
const flash = kit.parked(kit.tex(228, 1), FOE, 1.8, 12);
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.2, 2.0), fadeOut(1, 0.35));
paint(flash, PALE, WHITE, YELLOW);
kit.add("flash", flash);

const burst = kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.3, speed: 0.8, count: 12, life: 10, scale: 2.4, directional: true });
burst.axis = [0, 1, 0];
burst.initVelAxisAmplifier = 0.25;
setCurves(burst, undefined, fadeOut(1, 0.5));
kit.prism(burst, [GREEN, TEAL, YELLOW]);
kit.add("burst", burst);

const embers = kit.spray([228, 3], kit.tex(321, 6), FOE, { radius: 0.3, speed: 0.55, count: 6, life: 10, scale: 0.7, directional: true });
embers.axis = [0, 1, 0];
embers.initVelAxisAmplifier = 0.2;
setCurves(embers, grow(1.2, 0.3, 0.6), fadeOut());
kit.prism(embers, [ORANGE, YELLOW, GREEN]);
kit.add("embers", embers);

const sweep = (scale: number, delay: number, rate: number) => {
  const r = kit.parked(kit.tex(228, 3), FOE_FLOOR, scale, HOLD - delay);
  r.aspectRatio = 3.0;
  r.startDelayFrames = delay;
  spin(r, rate);
  setCurves(r, grow(0.35, 0.3, 1.25), fadeInOut(1, 0.1, 0.6));
  paint(r, TEAL, WHITE, GREEN);
  return r;
};
kit.add("sweepOuter", sweep(3.4, 0, 0.05));
kit.add("sweepInner", sweep(2.3, 3, -0.07));

const debris = kit.spray([333, 1], kit.tex(579, 2), FOE, { radius: 0.4, speed: 0.35, count: 6, life: 14, scale: 0.18 });
debris.axis = [0, 1, 0];
debris.initVelAxisAmplifier = 0.15;
debris.behaviors = [{ type: "gravity", magnitude: [0, -0.025, 0] }];
spin(debris, -0.3, 0.3, 0, true);
setCurves(debris, hold(1), fadeOut(1, 0.7));
paint(debris, DEBRIS);
kit.add("debris", debris);

const dots = kit.spray([228, 3], kit.tex(333, 0), FOE, { radius: 0.6, speed: 0.45, count: 2, bursts: 4, gap: 2, life: 10, scale: 0.12 });
setCurves(dots, undefined, fadeOut());
kit.prism(dots, [GREEN, YELLOW, PALE]);
kit.add("dots", dots);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1509, SE1, 14, 0, 0, 100, 0, 0, 0
PlaySound 1497, SE2, 14, 6, 300, 100, 0, 0, 0
PlaySound 1421, SE2, 14, ${RAISE - 2}, -300, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${SWING}, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 2, 14, 31, 12
${kit.emit("aura", "ATTACKER")}
${kit.emit("ring", "ATTACKER")}
${kit.emit("whirl", "ATTACKER")}
${kit.emit("leaves", "ATTACKER")}
${kit.emit("motes", "ATTACKER")}
Wait ${RAISE - 6}
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 3, 0, 1
Wait 6
ChangeSpriteColor ATTACKER, 10, 0, 1, 14, 31, 12
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
MoveCamera INTERPOLATION, DEFENDER, ${SWING}, 0, 8
Wait ${SWING}
AudioContainer CONTINUE
PlaySound 1424, SE1, 16, 0, -300, 125, 0, 0, 0
PlaySound 1475, SE2, 16, 0, -400, 115, 0, 0, 0
PlaySound 1509, SE2, 16, ${HIT_STOP + 2}, 400, 100, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("flash", "DEFENDER")}
${kit.emit("burst", "DEFENDER")}
${kit.emit("embers", "DEFENDER")}
${kit.emit("sweepOuter", "DEFENDER")}
${kit.emit("sweepInner", "DEFENDER")}
${kit.emit("debris", "DEFENDER")}
${kit.emit("dots", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 16, 31, 14
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 12, 0, 1, 16, 31, 14
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait ${HOLD - HIT_STOP}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [63, 75, 153, 400, 605, 564],
  references: ["reference/Ivy_Cudgel_IX.png", "reference/Ivy_Cudgel_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 5, DEFENDER`, "ShakeScreen VERTICAL, 1x", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  raise f${CAMERA_IN}-${CAMERA_IN + RAISE}, blow f${CAMERA_IN + RAISE + SWING}`);
