import { aimed, assert, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Twin Beam (move 888), v2 - from Logan's keyframes (reference/keyframe-1..4)
// and brief: "startup has multiple pink strands loop around the user ->
// converges into an orb in front of the user and enlarges it -> then fires a
// small beam of pink light at the target -> dealing damage".
//   1. White-lavender strands loop round the user in a scatter of pink and
//      cyan glitter and sparkles.
//   2. They converge into an orb in front of it: a magenta ring round a
//      blue-violet heart with a bright core, which swells into a disc with a
//      white-lavender rim.
//   3. A thin pink-white beam fires from the orb to the foe.
//   4. A small pink splash on the foe: magenta flecks and lavender arcs.
// Two hits: Gen 5 replays the animation per hit, so the camera stays still
// and one hit is about 3 seconds. Second pass (Logan: "way too fast, slow it
// down" and "a second or so pause after the orb gets condensed, before firing"):
// every phase is longer and the finished orb holds for a second.
// v1 (../twin-beam, from the Bulbapedia stills) is kept; reinstall its
// manifest to revert.

const SPA = 931;
const kit = await createKit({ workDir: import.meta.dirname, slug: "twin-beam-v2", moveId: 888, spaId: SPA, donors: [228, 298, 560, 465, 606, 579] });

// --- timing (30 fps), one hit ---
const STRANDS = 22;
const ORB_AT = 16; // the orb starts forming while the strands close in
const ORB_GROW = 18;
const PAUSE = 30; // the finished orb holds before it fires
const BEAM_SPEED = 1.5;
const TRAVEL = 10;
const HOLD = 16;

const BODY: Vec3 = [0, 0.2, 0.1];
const ORB: Vec3 = [0.4, 1.0, -1.4]; // in front of the user, at head height
const FOE: Vec3 = [0, 0.3, 0.8];

const LAVENDER: Rgb = [0.88, 0.8, 1.0];
const VIOLET: Rgb = [0.6, 0.4, 1.0];
const DEEP_VIOLET: Rgb = [0.3, 0.2, 0.75];
const PINK: Rgb = [1.0, 0.5, 0.88];
const MAGENTA: Rgb = [1.0, 0.3, 0.8];
const CYAN: Rgb = [0.45, 0.9, 1.0];
const WHITE: Rgb = [1, 1, 1];

// --- 1. the strands looping round the user ---
function strand(y: number, scale: number, rate: number, delay: number): ReturnType<typeof kit.parked> {
  const r = kit.parked(kit.tex(228, 3), [BODY[0], BODY[1] + y, BODY[2]], scale, STRANDS + 4 - delay);
  r.startDelayFrames = delay;
  r.aspectRatio = 3.0;
  spin(r, rate);
  // Loops out, then is drawn in toward the orb.
  setCurves(r, { start: 0.5, mid: 1.1, end: 0.2, curveIn: 0.35, curveOut: 0.6 }, fadeInOut(0.95, 0.15, 0.75));
  paint(r, LAVENDER, WHITE, VIOLET);
  return r;
}
kit.add("strandLow", strand(-0.8, 1.5, 0.3, 0));
kit.add("strandHigh", strand(0.6, 1.3, -0.27, 3));

const glitter = kit.spray([333, 1], kit.tex(333, 0), ORB, { radius: 2.6, speed: 0, count: 2, bursts: 8, gap: 3, life: 13, scale: 0.14, shape: "sphere" });
glitter.behaviors = [{ type: "convergence", target: [0, 0, 0], force: 0.09 }];
setCurves(glitter, undefined, twinkle());
kit.prism(glitter, [PINK, CYAN, WHITE]);
kit.add("glitter", glitter);

const sparkles = kit.spray([333, 1], kit.tex(298, 1), BODY, { radius: 2.0, speed: 0.01, count: 1, bursts: 6, gap: 4, life: 10, scale: 0.28, shape: "ball" });
setCurves(sparkles, twinkle(1), twinkle(1));
kit.prism(sparkles, [WHITE, PINK, CYAN]);
kit.add("sparkles", sparkles);

// --- 2. the orb ---
const ORB_LIFE = ORB_GROW + PAUSE + TRAVEL + 4;
// Swells to full size, then holds through the pause and the shot.
const swell = { start: 0.15, mid: 1.0, end: 1.0, curveIn: ORB_GROW / ORB_LIFE, curveOut: 1 };
function orbLayer(tex: number, scale: number, level: number, colour: Rgb, start: Rgb, end: Rgb): ReturnType<typeof kit.parked> {
  const r = kit.parked(tex, ORB, scale, ORB_LIFE);
  r.aspectRatio = 0.8; // a disc turned toward the foe
  setCurves(r, swell, fadeInOut(level, 0.08, 0.92));
  paint(r, colour, start, end);
  return r;
}
kit.add("orbFill", orbLayer(kit.tex(298, 0), 1.5, 0.85, DEEP_VIOLET, VIOLET, DEEP_VIOLET));
kit.add("orbRim", orbLayer(kit.tex(560, 1), 1.7, 1, LAVENDER, MAGENTA, WHITE));
kit.add("orbCore", orbLayer(kit.tex(465, 1), 0.9, 1, CYAN, WHITE, WHITE));

const crackle = kit.parked(kit.tex(579, 2), ORB, 0.8, ORB_GROW + PAUSE);
spin(crackle, 0.12);
setCurves(crackle, { start: 0.4, mid: 1, end: 1.4, curveIn: 0.3, curveOut: 0.85 }, fadeInOut(0.9, 0.15, 0.9));
paint(crackle, MAGENTA, PINK, MAGENTA);
kit.add("crackle", crackle);

// Held: a slow shimmer of sparkles round the orb, then a flare as it fires.
const held = kit.spray([333, 1], kit.tex(298, 1), ORB, { radius: 1.3, speed: 0, count: 1, bursts: PAUSE / 5, gap: 5, life: 10, scale: 0.26, shape: "ball" });
held.startDelayFrames = ORB_GROW;
setCurves(held, twinkle(1), twinkle(1));
kit.prism(held, [WHITE, PINK, CYAN]);
kit.add("held", held);

const flare = kit.parked(kit.tex(228, 1), ORB, 1.3, 8);
flare.startDelayFrames = ORB_GROW + PAUSE - 5;
spin(flare, 0.1);
setCurves(flare, grow(0.3, 0.5, 1.5), fadeOut(1, 0.6));
paint(flare, WHITE, WHITE, PINK);
kit.add("flare", flare);

// --- 3. the beam ---
function stream(scale: number, colour: Rgb, start: Rgb): ReturnType<typeof kit.shell> {
  const r = kit.shell(228, 0);
  r.textureIndex = kit.tex(228, 1);
  aimed(r, BEAM_SPEED, TRAVEL);
  Object.assign(r, { emitterBasePos: [...ORB], baseScale: scale, emitterLifeFrames: 9, emissionIntervalFrames: 1, airResistance: 1.0 });
  setCurves(r, hold(1), hold(1));
  paint(r, colour, start, colour);
  return r;
}
kit.add("beam", stream(0.42, PINK, LAVENDER));
kit.add("beamCore", stream(0.2, WHITE, WHITE));

// --- 4. the splash on the foe ---
const pop = kit.parked(kit.tex(579, 2), FOE, 0.9, 9);
spin(pop, 0.12);
setCurves(pop, grow(0.4, 0.25, 1.3), fadeOut(1, 0.4));
paint(pop, PINK, WHITE, MAGENTA);
kit.add("pop", pop);

const arcs = kit.spray([333, 1], kit.tex(606, 3), FOE, { radius: 0.4, speed: 0.12, count: 3, life: 9, scale: 0.7, shape: "ball" });
spin(arcs, -0.3, 0.3, 0, true);
setCurves(arcs, grow(0.5, 0.3, 1.2), fadeOut(1, 0.4));
kit.prism(arcs, [LAVENDER, VIOLET, WHITE]);
kit.add("arcs", arcs);

const flecks = kit.spray([228, 3], kit.tex(465, 3), FOE, { radius: 0.3, speed: 0.4, count: 6, life: 9, scale: 0.35, directional: true });
flecks.axis = [0, 1, 0];
flecks.initVelAxisAmplifier = 0.1;
setCurves(flecks, grow(1, 0.3, 0.6), fadeOut());
kit.prism(flecks, [MAGENTA, PINK, WHITE]);
kit.add("flecks", flecks);

// --- script (one hit; no camera moves) ---
const emits = (names: string[], who: "ATTACKER" | "DEFENDER", toward = "NONE") => names.map((n) => kit.emit(n, who, toward)).join("\n");
const fireAt = ORB_AT + ORB_GROW + PAUSE;
const script = `LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1783, SE1, 14, 0, 0, 100, 0, 0, 0
PlaySound 1509, SE2, 14, ${ORB_AT}, 700, 95, 0, 0, 0
PlaySound 1509, SE1, 14, ${ORB_AT + ORB_GROW}, 1100, 90, 0, 0, 0
PlaySound 1418, PSG, 14, ${ORB_AT + ORB_GROW + 6}, 900, 90, 0, 0, 0
PlaySound 1376, PSG, 14, ${fireAt}, 0, 0, 0, 0, 0
PlaySound 1816, SE2, 14, ${fireAt}, 500, 115, 0, 0, 0
PlaySound 1423, SE1, 16, ${fireAt + TRAVEL}, -300, 110, 0, 0, 0
AudioContainer SUSPEND
${emits(["strandLow", "strandHigh", "glitter", "sparkles"], "ATTACKER")}
Wait ${ORB_AT}
${emits(["orbFill", "orbRim", "orbCore", "crackle", "held", "flare"], "ATTACKER")}
Wait ${ORB_GROW + PAUSE}
${emits(["beam", "beamCore"], "ATTACKER", "DEFENDER")}
Wait ${TRAVEL}
${emits(["pop", "arcs", "flecks"], "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 11, 0, 31, 20, 30
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 4
Wait 3
ChangeSpriteColor DEFENDER, 11, 0, 1, 31, 20, 30
Wait ${HOLD - 3}
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [427, 129, 63, 400, 381],
  references: ["reference/keyframe-1.webp", "reference/keyframe-2.png", "reference/keyframe-3.png", "reference/keyframe-4.png", "reference/Twin_Beam_IX.png", "reference/Twin_Beam_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, `Emit ${SPA}, ${kit.idx("orbRim")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("beam")}, ATTACKER, DEFENDER`, `Emit ${SPA}, ${kit.idx("pop")}, DEFENDER`],
});
assert.ok(!script.includes("MoveCamera"), "Multi-hit animation moves the camera");
console.log(`  strands f0, orb f${ORB_AT}-${ORB_AT + ORB_GROW}, held ${PAUSE}f, beam f${fireAt}, hit f${fireAt + TRAVEL}, one hit ~${fireAt + TRAVEL + HOLD} frames`);
