LoadSPA 931
AudioContainer CONTINUE
PlaySound 1783, SE1, 14, 0, 0, 100, 0, 0, 0
PlaySound 1509, SE2, 14, 16, 700, 95, 0, 0, 0
PlaySound 1509, SE1, 14, 34, 1100, 90, 0, 0, 0
PlaySound 1418, PSG, 14, 40, 900, 90, 0, 0, 0
PlaySound 1376, PSG, 14, 64, 0, 0, 0, 0, 0
PlaySound 1816, SE2, 14, 64, 500, 115, 0, 0, 0
PlaySound 1423, SE1, 16, 74, -300, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 931, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 931, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 931, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 931, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 16
Emit 931, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 931, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 931, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 931, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 931, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 931, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 48
Emit 931, 10, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 931, 11, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 10
Emit 931, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 931, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 931, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 11, 0, 31, 20, 30
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 4
Wait 3
ChangeSpriteColor DEFENDER, 11, 0, 1, 31, 20, 30
Wait 13
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
