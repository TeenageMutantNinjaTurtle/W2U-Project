LoadSPA 922
AudioContainer CONTINUE
PlaySound 1762, SE1, 14, 0, 0, 120, 0, 0, 0
PlaySound 1511, SE2, 16, 9, 600, 110, 0, 0, 0
PlaySound 1686, SE1, 16, 12, 0, 120, 0, 0, 0
PlaySound 1511, SE2, 14, 22, -300, 100, 0, 0, 0
AudioContainer SUSPEND
Emit 922, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 922, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 922, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 922, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ScaleSprite ATTACKER, ROUNDTRIP, 819, -1229, 2, 0, 1
Wait 4
ToggleSpriteVisibility ATTACKER, 3
Wait 5
Emit 922, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 922, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 922, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 922, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 922, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 922, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 922, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 922, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 922, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 3
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 10, 0, 16, 26, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 6
Wait 3
ChangeSpriteColor DEFENDER, 10, 0, 1, 16, 26, 31
Wait 7
Emit 922, 13, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 922, 14, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 922, 15, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 2
ToggleSpriteVisibility ATTACKER, 4
ScaleSprite ATTACKER, ROUNDTRIP, -819, 1229, 3, 0, 1
Wait 10
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
