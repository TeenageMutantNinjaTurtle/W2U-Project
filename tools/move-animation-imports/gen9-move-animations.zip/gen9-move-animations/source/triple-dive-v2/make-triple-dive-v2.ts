import { assert, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Triple Dive (move 865), v2 - from Logan's keyframes (reference/keyframe-1..4):
//   1. Submersion: the user plunges into the ground in a wide splash crown,
//      curling cyan water tendrils fanning up off a ripple, droplets flying.
//   2. Appearing: it bursts up out of the water in front of the foe, splash
//      columns either side.
//   3. Hitting: a cyan splash wall slams into the foe, spray streaking out
//      sideways, bubbles and droplets.
//   4. Returning: it surfaces back on its own side in another splash crown.
// Three hits: Gen 5 replays the animation per hit, so the camera stays still
// and each hit is about 39 frames (1.3 s). The user is hidden while under
// (ToggleSpriteVisibility 3/4). Dive's splash (SPA 461) for the crowns and
// columns, Aqua Tail's (580) bubbles and spray, Sticky Web's rings (770) for
// the ripples.
// v1 (../triple-dive) is kept; reinstall its manifest to revert.

const SPA = 922;
const kit = await createKit({ workDir: import.meta.dirname, slug: "triple-dive-v2", moveId: 865, spaId: SPA, donors: [461, 770, 580, 465, 411] });

// --- timing (30 fps), one hit ---
const UNDER = 9; // dive -> surfaces at the foe
const STRIKE = 3; // surfaces -> hits
const RETURN = 10; // hit -> resurfaces home
const HOLD = 10;

const USER_GROUND: Vec3 = [0, -2.0, 0];
const FOE_GROUND: Vec3 = [0, -1.8, 0.6];
const FRONT_GROUND: Vec3 = [0, -1.8, -0.4]; // just in front of the foe (toward the user)
const FOE: Vec3 = [0, 0.2, 0.8];

const WHITE: Rgb = [1, 1, 1];
const PALE_CYAN: Rgb = [0.8, 0.97, 1.0];
const CYAN: Rgb = [0.35, 0.85, 1.0];
const BLUE: Rgb = [0.2, 0.6, 1.0];

// --- splash pieces ---
function crown(pos: Vec3, delay = 0): ReturnType<typeof kit.shell> {
  const r = kit.shell(461, 0);
  r.textureIndex = kit.tex(461, 0);
  Object.assign(r, { emitterBasePos: [...pos], particleLifeFrames: 13, emitterLifeFrames: 3, startDelayFrames: delay, emissionCount: 3 });
  paint(r, WHITE, PALE_CYAN, CYAN);
  return r;
}
function column(pos: Vec3, delay = 0): ReturnType<typeof kit.shell> {
  const r = kit.shell(461, 2);
  r.textureIndex = kit.tex(461, 2);
  Object.assign(r, { emitterBasePos: [...pos], particleLifeFrames: 12, emitterLifeFrames: 5, startDelayFrames: delay });
  paint(r, PALE_CYAN, CYAN, WHITE);
  return r;
}
function ripple(pos: Vec3, scale: number, delay = 0): ReturnType<typeof kit.parked> {
  const r = kit.parked(kit.tex(770, 2), pos, scale, 14);
  r.startDelayFrames = delay;
  r.aspectRatio = 3.2;
  setCurves(r, grow(0.3, 0.4, 1.5), fadeOut(0.9, 0.3));
  paint(r, PALE_CYAN, WHITE, CYAN);
  return r;
}
// Curling water tendrils fanning up off a flat ring.
function tendrils(pos: Vec3, radius: number, count: number, delay = 0): ReturnType<typeof kit.spray> {
  const r = kit.spray([228, 3], kit.tex(465, 3), [pos[0], pos[1] + 0.2, pos[2]], { radius, speed: 0.08, count, life: 11, scale: 0.95, shape: "circle", directional: true });
  r.startDelayFrames = delay;
  r.emissionAxis = 1;
  r.axis = [0, 1, 0];
  r.initVelAxisAmplifier = 0.3;
  r.behaviors = [{ type: "gravity", magnitude: [0, -0.02, 0] }];
  setCurves(r, grow(0.5, 0.3, 1.2), fadeOut(1, 0.5));
  kit.prism(r, [CYAN, PALE_CYAN, BLUE]);
  return r;
}

// --- 1. submersion ---
kit.add("diveCrown", crown(USER_GROUND));
kit.add("diveColumn", column(USER_GROUND));
kit.add("diveRipple", ripple(USER_GROUND, 1.7));
kit.add("diveTendrils", tendrils(USER_GROUND, 1.5, 5));

// --- 2. appearing before the foe ---
kit.add("upColumnL", column([FRONT_GROUND[0] - 1.1, FRONT_GROUND[1], FRONT_GROUND[2]]));
kit.add("upColumnR", column([FRONT_GROUND[0] + 1.1, FRONT_GROUND[1], FRONT_GROUND[2]]));
kit.add("upRipple", ripple(FRONT_GROUND, 1.4));
kit.add("upTendrils", tendrils(FRONT_GROUND, 1.2, 4));

// --- 3. the hit ---
const star = kit.shell(461, 1);
star.textureIndex = kit.tex(461, 1);
Object.assign(star, { emitterBasePos: [...FOE], startDelayFrames: STRIKE, emitterLifeFrames: 4 });
paint(star, CYAN, WHITE, BLUE);
kit.add("star", star);

const wall = kit.spray([228, 3], kit.tex(411, 0), [0, -0.6, 0.6], { radius: 0.4, speed: 0.7, count: 6, life: 8, scale: 2.0, shape: "circle", directional: true });
wall.startDelayFrames = STRIKE;
wall.axis = [0, 1, 0];
wall.initVelAxisAmplifier = 0.12;
setCurves(wall, undefined, fadeOut(1, 0.5));
kit.prism(wall, [WHITE, PALE_CYAN, CYAN]);
kit.add("wall", wall);

const spray = kit.shell(580, 2);
spray.textureIndex = kit.tex(580, 3);
Object.assign(spray, { emitterBasePos: [...FOE], emissionCount: 3, startDelayFrames: STRIKE });
paint(spray, PALE_CYAN, WHITE, CYAN);
kit.add("spray", spray);

const bubbles = kit.shell(580, 1);
bubbles.textureIndex = kit.tex(580, 2);
Object.assign(bubbles, { emitterBasePos: [...FOE], emissionCount: 3, startDelayFrames: STRIKE });
paint(bubbles, PALE_CYAN, WHITE, CYAN);
kit.add("bubbles", bubbles);

const droplets = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.5, speed: 0.35, count: 4, life: 11, scale: 0.13 });
droplets.startDelayFrames = STRIKE;
droplets.behaviors = [{ type: "gravity", magnitude: [0, -0.015, 0] }];
setCurves(droplets, undefined, twinkle());
kit.prism(droplets, [WHITE, PALE_CYAN, CYAN]);
kit.add("droplets", droplets);

// --- 4. returning home ---
kit.add("homeCrown", crown(USER_GROUND));
kit.add("homeColumn", column(USER_GROUND));
kit.add("homeRipple", ripple(USER_GROUND, 1.5));

// --- script (one hit; no camera moves) ---
const script = `LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1762, SE1, 14, 0, 0, 120, 0, 0, 0
PlaySound 1511, SE2, 16, ${UNDER}, 600, 110, 0, 0, 0
PlaySound 1686, SE1, 16, ${UNDER + STRIKE}, 0, 120, 0, 0, 0
PlaySound 1511, SE2, 14, ${UNDER + STRIKE + RETURN}, -300, 100, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("diveCrown", "ATTACKER")}
${kit.emit("diveColumn", "ATTACKER")}
${kit.emit("diveRipple", "ATTACKER")}
${kit.emit("diveTendrils", "ATTACKER")}
ScaleSprite ATTACKER, ROUNDTRIP, 819, -1229, 2, 0, 1
Wait 4
ToggleSpriteVisibility ATTACKER, 3
Wait ${UNDER - 4}
${kit.emit("upColumnL", "DEFENDER")}
${kit.emit("upColumnR", "DEFENDER")}
${kit.emit("upRipple", "DEFENDER")}
${kit.emit("upTendrils", "DEFENDER")}
${kit.emit("star", "DEFENDER")}
${kit.emit("wall", "DEFENDER")}
${kit.emit("spray", "DEFENDER")}
${kit.emit("bubbles", "DEFENDER")}
${kit.emit("droplets", "DEFENDER")}
Wait ${STRIKE}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 10, 0, 16, 26, 31
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 6
Wait 3
ChangeSpriteColor DEFENDER, 10, 0, 1, 16, 26, 31
Wait ${RETURN - 3}
${kit.emit("homeCrown", "ATTACKER")}
${kit.emit("homeColumn", "ATTACKER")}
${kit.emit("homeRipple", "ATTACKER")}
Wait 2
ToggleSpriteVisibility ATTACKER, 4
ScaleSprite ATTACKER, ROUNDTRIP, -819, 1229, 3, 0, 1
Wait ${HOLD}
LetCMDsFinish ALL
ToggleFreezeSprite DEFENDER, STOP
LetCMDsFinish ALL
TerminateMoveScript
`;

const { reparsed } = await kit.finish({
  script,
  donorMoveIds: [291, 564, 401, 163, 240],
  references: ["reference/keyframe-1.png", "reference/keyframe-2.png", "reference/keyframe-3.png", "reference/keyframe-4.png", "reference/Triple_Dive_IX.png", "reference/Triple_Dive_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, "ToggleSpriteVisibility ATTACKER, 3", `Emit ${SPA}, 4, DEFENDER`, `Emit ${SPA}, 9, DEFENDER`, `Emit ${SPA}, 14, ATTACKER`, "ToggleSpriteVisibility ATTACKER, 4"],
});
assert.ok(!script.includes("MoveCamera"), "Multi-hit animation moves the camera");
const homeAt = UNDER + STRIKE + RETURN;
const tail = Math.max(...reparsed.resources.slice(kit.idx("homeCrown")).map((r) => r.startDelayFrames + r.emitterLifeFrames + r.particleLifeFrames));
console.log(`  dive f0, surfaces f${UNDER}, hit f${UNDER + STRIKE}, home f${homeAt}, one hit ~${homeAt + Math.max(HOLD, tail)} frames`);
