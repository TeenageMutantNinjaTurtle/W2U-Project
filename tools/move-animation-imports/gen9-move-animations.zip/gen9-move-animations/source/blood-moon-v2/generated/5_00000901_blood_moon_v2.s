MoveCamera INTERPOLATION, ATTACKER, 14, 0, 8
LetCMDsFinish CAMERA
LoadSPA 894
AudioContainer CONTINUE
PlaySound 1471, SE1, 14, 0, -400, 115, 0, 0, 0
PlaySound 1418, PSG, 14, 8, -600, 110, 0, 0, 0
PlaySound 1962, SE2, 14, 28, 0, 110, 0, 0, 0
PlaySound 1376, PSG, 14, 30, 0, 0, 0, 0, 0
AdjustSound PSG, 0, 0, 0, 3000, 0, 34, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 12, 2, 6, 0, 2
Emit 894, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 894, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 894, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 894, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 30
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 4
Emit 894, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 894, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
AudioContainer CONTINUE
PlaySound 1475, SE1, 16, 0, -300, 127, 0, 0, 0
PlaySound 1420, SE2, 16, 0, -500, 127, 0, 0, 0
PlaySound 1424, SE2, 16, 6, -300, 120, 0, 0, 0
AudioContainer SUSPEND
Emit 894, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 894, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 894, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 894, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 894, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 6, 8
Wait 6
ChangeSpriteColor DEFENDER, 14, 0, 2, 31, 6, 8
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 4, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 14
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait 20
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 12, 0, 2, 6, 0, 2
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
