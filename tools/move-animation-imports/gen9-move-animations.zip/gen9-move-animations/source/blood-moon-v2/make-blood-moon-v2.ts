import { aimed, createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Blood Moon (move 901), v2 - from Bulbapedia's stills (reference/).
//   1. A great blood-red moon swells in front of the user among dusky
//      grey-mauve smoke clouds, red embers drifting through the dark.
//   2. A thick red beam with a white-hot core strikes down on the foe: a
//      red-pink spiky flash, orange spark streaks and pale violet shockwave
//      rings.
// 140 power: the arena goes dark red, a long hit-stop, a heavy shake.
// v1 (../blood-moon) is kept; reinstall its manifest to revert.
//
// The moon is drawn here (64x64 a3i5: a shaded red sphere with darker
// craters and a pink glowing rim; generated/texture-moon.png).

const SPA = 894;
const kit = await createKit({ workDir: import.meta.dirname, slug: "blood-moon-v2", moveId: 901, spaId: SPA, donors: [228, 321, 465, 579, 411, 560] });

// --- timing (30 fps) ---
const CAMERA_IN = 14;
const RISE = 30;
const BEAM_SPEED = 2.0;
const TRAVEL = 8;
const HIT_STOP = 6;
const HOLD = 26;

const MOON: Vec3 = [0.2, 1.4, -1.2];
const FOE: Vec3 = [0, 0.3, 0.8];

const RED: Rgb = [0.9, 0.1, 0.15];
const BLOOD: Rgb = [0.65, 0.04, 0.1];
const PINK: Rgb = [1.0, 0.45, 0.55];
const ORANGE: Rgb = [1.0, 0.5, 0.2];
const MAUVE: Rgb = [0.55, 0.45, 0.5];
const DUSK: Rgb = [0.38, 0.3, 0.36];
const LAVENDER: Rgb = [0.85, 0.8, 1.0];
const WHITE: Rgb = [1, 1, 1];

// --- the drawn moon ---
const craters = [
  { x: -9, y: -7, r: 7 },
  { x: 7, y: -12, r: 5 },
  { x: -3, y: 8, r: 6.5 },
  { x: 11, y: 5, r: 4.5 },
  { x: -14, y: 6, r: 3.5 },
];
const R = 27;
const moonTex = await kit.drawn("moon", 64, 64, "a3i5", (x, y) => {
  const dx = x + 0.5 - 32;
  const dy = y + 0.5 - 32;
  const r = Math.hypot(dx, dy);
  if (r > R + 4) return undefined;
  if (r > R) return [255, 110, 130, Math.round((1 - (r - R) / 4) * 190)]; // glow halo
  if (r > R - 2) return [255, 120, 125];
  const nz = Math.sqrt(Math.max(0, 1 - (r / R) ** 2));
  // Lit from the lower right, darkest in the upper middle.
  let light = 0.45 + 0.3 * (dx / R) * 0.5 + 0.35 * (dy / R) + 0.2 * (1 - nz);
  if (craters.some((c) => Math.hypot(dx - c.x, dy - c.y) < c.r)) light *= 0.75;
  light = Math.max(0.3, Math.min(1, light));
  return [Math.round(150 + 105 * light), Math.round(18 + 60 * light * light), Math.round(28 + 50 * light * light)];
});

// --- the rising moon ---
const moon = kit.parked(moonTex, MOON, 2.4, RISE + TRAVEL + 2);
setCurves(moon, { start: 0.05, mid: 1, end: 1.05, curveIn: 0.45, curveOut: 1 }, { start: 0, mid: 1, end: 0.6, curveIn: 0.2, curveOut: 0.9 });
paint(moon, WHITE);
kit.add("moon", moon);

const halo = kit.parked(kit.tex(465, 1), MOON, 4.0, RISE + TRAVEL + 2);
setCurves(halo, { start: 0.1, mid: 1, end: 1.1, curveIn: 0.5, curveOut: 1 }, fadeInOut(0.7, 0.4, 0.85));
paint(halo, RED, BLOOD, PINK);
kit.add("halo", halo);

const clouds = kit.spray([333, 1], kit.tex(321, 5), MOON, { radius: 2.6, speed: 0.015, count: 1, bursts: 9, gap: 3, life: 24, scale: 1.3, shape: "circle" });
spin(clouds, -0.03, 0.03, 0, true);
setCurves(clouds, grow(0.5, 0.4, 1.2), fadeInOut(0.8, 0.25, 0.65));
kit.prism(clouds, [MAUVE, DUSK, MAUVE]);
kit.add("clouds", clouds);

const embers = kit.spray([228, 3], kit.tex(411, 0), [0, 0, -0.6], { radius: 3.0, speed: 0.04, count: 1, bursts: 12, gap: 2, life: 12, scale: 0.6, shape: "ball", directional: true });
embers.axis = [0, 1, 0];
embers.initVelAxisAmplifier = 0.05;
setCurves(embers, undefined, twinkle());
kit.prism(embers, [RED, ORANGE, PINK]);
kit.add("embers", embers);

// --- the beam ---
function stream(scale: number, colour: Rgb, start: Rgb): ReturnType<typeof kit.shell> {
  const r = kit.shell(228, 0);
  r.textureIndex = kit.tex(228, 1);
  aimed(r, BEAM_SPEED, TRAVEL);
  Object.assign(r, { emitterBasePos: [...MOON], baseScale: scale, emitterLifeFrames: 10, emissionIntervalFrames: 1, airResistance: 1.0 });
  setCurves(r, hold(1), hold(1));
  paint(r, colour, start, colour);
  return r;
}
kit.add("beam", stream(1.1, RED, PINK));
kit.add("core", stream(0.5, WHITE, WHITE));

// --- impact ---
const flash = kit.parked(kit.tex(228, 1), FOE, 2.0, 14);
spin(flash, 0.05);
setCurves(flash, grow(0.4, 0.2, 2.2), fadeOut(1, 0.35));
paint(flash, WHITE, WHITE, PINK);
kit.add("flash", flash);

const spiky = kit.parked(kit.tex(579, 2), FOE, 2.0, 14);
spin(spiky, 0.1);
setCurves(spiky, grow(0.4, 0.25, 1.5), fadeOut(1, 0.4));
paint(spiky, RED, PINK, BLOOD);
kit.add("spiky", spiky);

const sparks = kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.4, speed: 0.7, count: 9, life: 10, scale: 1.6, directional: true });
setCurves(sparks, undefined, fadeOut());
kit.prism(sparks, [ORANGE, PINK, [1.0, 0.85, 0.5]]);
kit.add("sparks", sparks);

function shockwave(scale: number, delay: number, angle: number): ReturnType<typeof kit.parked> {
  const r = kit.parked(kit.tex(560, 1), FOE, scale, 14);
  r.startDelayFrames = delay;
  r.aspectRatio = 2.4;
  r.initAngle = angle;
  setCurves(r, grow(0.3, 0.35, 1.4), fadeOut(0.9, 0.3));
  paint(r, LAVENDER, WHITE, LAVENDER);
  return r;
}
kit.add("waveA", shockwave(1.8, 0, deg(-20)));
kit.add("waveB", shockwave(2.4, 4, deg(15)));

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1471, SE1, 14, 0, -400, 115, 0, 0, 0
PlaySound 1418, PSG, 14, 8, -600, 110, 0, 0, 0
PlaySound 1962, SE2, 14, ${RISE - 2}, 0, 110, 0, 0, 0
PlaySound 1376, PSG, 14, ${RISE}, 0, 0, 0, 0, 0
AdjustSound PSG, 0, 0, 0, 3000, 0, 34, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 12, 2, 6, 0, 2
${kit.emit("halo", "ATTACKER")}
${kit.emit("moon", "ATTACKER")}
${kit.emit("clouds", "ATTACKER")}
${kit.emit("embers", "ATTACKER")}
Wait ${RISE}
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 4
${kit.emit("beam", "ATTACKER", "DEFENDER")}
${kit.emit("core", "ATTACKER", "DEFENDER")}
MoveCamera INTERPOLATION, DEFENDER, ${TRAVEL}, 0, 8
Wait ${TRAVEL}
AudioContainer CONTINUE
PlaySound 1475, SE1, 16, 0, -300, 127, 0, 0, 0
PlaySound 1420, SE2, 16, 0, -500, 127, 0, 0, 0
PlaySound 1424, SE2, 16, ${HIT_STOP}, -300, 120, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("flash", "DEFENDER")}
${kit.emit("spiky", "DEFENDER")}
${kit.emit("sparks", "DEFENDER")}
${kit.emit("waveA", "DEFENDER")}
${kit.emit("waveB", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 6, 8
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 14, 0, 2, 31, 6, 8
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 4, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 14
ShakeScreen VERTICAL, 2458, 0, 2, 0, 8
Wait ${HOLD - HIT_STOP}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 12, 0, 2, 6, 0, 2
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [63, 153, 605, 400, 240, 381],
  references: ["reference/Blood_Moon_IX.png", "reference/Blood_Moon_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, `Emit ${SPA}, 4, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 6, DEFENDER`, "ShakeScreen VERTICAL, 2458", "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  rise f${CAMERA_IN}-${CAMERA_IN + RISE}, beam ${TRAVEL}f, hit f${CAMERA_IN + RISE + TRAVEL}`);
