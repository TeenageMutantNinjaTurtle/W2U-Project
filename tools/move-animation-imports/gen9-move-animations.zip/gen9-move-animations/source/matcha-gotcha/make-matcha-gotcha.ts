import { aimed, assert, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Matcha Gotcha (move 902) - from Bulbapedia's stills (reference/).
//   1. Steam curls off the user as it fires gushes of matcha that splatter
//      across the field in long green streaks.
//   2. The matcha bursts over the foe: a splash of green splotches and tea
//      leaves round a yellow-green glow.
// It drains HP, so green wisps flow back to the user and it glows.
//
// Drawn here: a liquid splat (32x32 a5i3 white mask: a lumpy blob with
// satellite droplets; generated/texture-splat.png). Razor Leaf's (242) leaf
// for the tea leaves; Mud Bomb's (605) lob carries the gushes.

const SPA = 895;
const kit = await createKit({ workDir: import.meta.dirname, slug: "matcha-gotcha", moveId: 902, spaId: SPA, donors: [605, 242, 321, 465, 580] });

// --- timing (30 fps) ---
const WIDE = 18;
const STEAM = 10;
const LOB = 24;
const STAGGER = 6;
const SPLASH = 18;
const DRAIN = 14;
const HEAL = 16;

const USER: Vec3 = [0, 0.2, 0.2];
const TOP: Vec3 = [0, 1.4, 0.2];
const FOE: Vec3 = [0, 0.3, 0.8];

const MATCHA: Rgb = [0.55, 0.82, 0.35];
const PALE_MATCHA: Rgb = [0.78, 0.95, 0.6];
const DEEP_GREEN: Rgb = [0.3, 0.62, 0.3];
const YELLOW_GREEN: Rgb = [0.85, 1.0, 0.4];
const STEAM_GREY: Rgb = [0.85, 0.9, 0.85];
const WHITE: Rgb = [1, 1, 1];

// --- the drawn splat ---
const lumps = [
  { x: 16, y: 16, r: 7.5 },
  { x: 11, y: 13, r: 5 },
  { x: 21, y: 12, r: 4.5 },
  { x: 20, y: 21, r: 5 },
  { x: 11, y: 21, r: 4 },
];
const drops = [
  { x: 4, y: 9, r: 2 },
  { x: 27, y: 6, r: 1.6 },
  { x: 28, y: 24, r: 2.2 },
  { x: 6, y: 27, r: 1.5 },
  { x: 16, y: 3, r: 1.4 },
];
const splatTex = await kit.drawn("splat", 32, 32, "a5i3", (x, y) => {
  const px = x + 0.5;
  const py = y + 0.5;
  const inside = [...lumps, ...drops].some((c) => Math.hypot(px - c.x, py - c.y) < c.r);
  if (!inside) return undefined;
  const edge = [...lumps, ...drops].every((c) => Math.hypot(px - c.x, py - c.y) > c.r - 1.2);
  return [255, 255, 255, edge ? 170 : 245];
});

// --- steam ---
const steam = kit.spray([333, 1], kit.tex(321, 5), TOP, { radius: 0.4, speed: 0, count: 1, bursts: 5, gap: 2, life: 16, scale: 0.5, shape: "ball" });
steam.axis = [0, 1, 0];
steam.initVelAxisAmplifier = 0.05;
spin(steam, -0.05, 0.05, 0, true);
setCurves(steam, grow(0.5, 0.4, 1.4), fadeInOut(0.6, 0.25, 0.5));
paint(steam, STEAM_GREY, WHITE, STEAM_GREY);
kit.add("steam", steam);

// --- the gushes (ride Mud Bomb's lob) ---
function rider(texIndex: number, scale: number): ReturnType<typeof kit.shell> {
  const r = kit.shell(605, 0);
  assert.ok(r.followEmitter, "Mud Bomb's ball no longer follows its emitter");
  r.textureIndex = texIndex;
  Object.assign(r, { particleLifeFrames: LOB + 1, baseScale: scale });
  return r;
}
const glob = rider(splatTex, 1.0);
spin(glob, 0.2);
setCurves(glob, hold(1), undefined);
paint(glob, MATCHA, PALE_MATCHA, MATCHA);
kit.add("glob", glob);

const sheen = rider(kit.tex(465, 1), 1.3);
setCurves(sheen, hold(1), undefined);
paint(sheen, PALE_MATCHA, WHITE, PALE_MATCHA);
kit.add("sheen", sheen);

// Splotches shed along the arc and dropping: the long green streaks.
const shed = kit.spray([333, 1], splatTex, [0, 0, 0], { radius: 0.5, speed: 0.03, count: 1, bursts: LOB, gap: 1, life: 9, scale: 0.42 });
shed.behaviors = [{ type: "gravity", magnitude: [0, -0.02, 0] }];
spin(shed, -0.1, 0.1, 0, true);
setCurves(shed, grow(0.6, 0.3, 1.1), fadeOut(0.9, 0.5));
kit.prism(shed, [MATCHA, PALE_MATCHA, DEEP_GREEN]);
kit.add("shed", shed);

// --- the splash ---
const glow = kit.parked(kit.tex(465, 1), FOE, 2.4, 16);
setCurves(glow, grow(0.4, 0.25, 1.3), fadeOut(0.85, 0.4));
paint(glow, YELLOW_GREEN, WHITE, MATCHA);
kit.add("glow", glow);

const splash = kit.spray([333, 1], splatTex, FOE, { radius: 0.4, speed: 0.3, count: 7, life: 16, scale: 0.65 });
splash.axis = [0, 1, 0];
splash.initVelAxisAmplifier = 0.08;
splash.behaviors = [{ type: "gravity", magnitude: [0, -0.018, 0] }];
spin(splash, -0.15, 0.15, 0, true);
setCurves(splash, grow(0.5, 0.2, 1.2), fadeOut(1, 0.55));
kit.prism(splash, [MATCHA, PALE_MATCHA, DEEP_GREEN]);
kit.add("splash", splash);

const leaves = kit.spray([333, 1], kit.tex(242, 1), FOE, { radius: 0.5, speed: 0.22, count: 6, life: 18, scale: 0.35 });
leaves.behaviors = [{ type: "gravity", magnitude: [0, -0.01, 0] }];
spin(leaves, -0.2, 0.2, 0, true);
setCurves(leaves, hold(1), fadeOut(1, 0.6));
paint(leaves, WHITE, WHITE, PALE_MATCHA);
kit.add("leaves", leaves);

const spray = kit.shell(580, 2);
spray.textureIndex = kit.tex(580, 3);
Object.assign(spray, { emitterBasePos: [...FOE], emissionCount: 3 });
paint(spray, PALE_MATCHA, WHITE, MATCHA);
kit.add("spray", spray);

// --- drain ---
const wisps = kit.spray([333, 1], kit.tex(465, 1), FOE, { radius: 0.6, speed: 0.02, count: 1, bursts: 5, gap: 2, life: DRAIN + 2, scale: 0.45 });
aimed(wisps, 1.15, DRAIN + 2);
wisps.airResistance = 1.0; // the spray shell's drag would stall it part-way
setCurves(wisps, hold(1), fadeInOut(1, 0.15, 0.85));
kit.prism(wisps, [MATCHA, YELLOW_GREEN, PALE_MATCHA]);
kit.add("wisps", wisps);

const heal = kit.spray([333, 1], kit.tex(333, 0), USER, { radius: 1.2, speed: 0, count: 1, bursts: 6, gap: 2, life: 12, scale: 0.2, shape: "ball" });
heal.axis = [0, 1, 0];
heal.initVelAxisAmplifier = 0.06;
setCurves(heal, undefined, twinkle());
kit.prism(heal, [YELLOW_GREEN, WHITE, MATCHA]);
kit.add("heal", heal);

// --- script ---
const lob = (name: string) => `EmitProjectile ${SPA}, ${kit.idx(name)}, CURVE, ATTACKER, DEFENDER, 2px, ${LOB}f, 4px, 3686, 1x, 0`;
const script = `MoveCamera INTERPOLATION, ZOOM_OUT_PERS, ${WIDE}, 0, 0
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1784, SE1, 14, 0, -400, 90, 0, 0, 0
PlaySound 1452, SE2, 16, ${STEAM}, 300, 100, 0, 0, 0
PlaySound 1452, SE2, 16, ${STEAM + STAGGER}, 0, 100, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${LOB + STAGGER}, 0, 48, 0, 0
PlaySound 1511, SE1, 16, ${STEAM + LOB}, 0, 115, 0, 0, 0
PlaySound 1446, SE1, 16, ${STEAM + LOB + STAGGER}, 400, 110, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("steam", "ATTACKER")}
ChangeSpriteColor ATTACKER, 0, 8, 2, 16, 28, 10
Wait ${STEAM}
${lob("glob")}
${lob("sheen")}
${lob("shed")}
Wait ${STAGGER}
${lob("glob")}
${lob("shed")}
ChangeSpriteColor ATTACKER, 8, 0, 1, 16, 28, 10
Wait ${LOB - STAGGER}
${kit.emit("glow", "DEFENDER")}
${kit.emit("splash", "DEFENDER")}
${kit.emit("leaves", "DEFENDER")}
${kit.emit("spray", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 16, 28, 10
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 10
Wait ${STAGGER}
ChangeSpriteColor DEFENDER, 12, 0, 1, 16, 28, 10
Wait ${SPLASH - STAGGER}
ToggleFreezeSprite DEFENDER, STOP
AudioContainer CONTINUE
PlaySound 1474, SE1, 14, 0, 0, 90, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 16, ${DRAIN}, 0, -50, 0, 0
AudioContainer SUSPEND
${kit.emit("wisps", "DEFENDER", "ATTACKER")}
Wait ${DRAIN}
AudioContainer CONTINUE
PlaySound 1784, SE2, 14, 0, 0, 100, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("heal", "ATTACKER")}
ChangeSpriteColor ATTACKER, 0, 10, 2, 18, 31, 12
Wait 8
ChangeSpriteColor ATTACKER, 10, 0, 2, 18, 31, 12
Wait ${HEAL - 8}
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [188, 605, 75, 401, 202],
  references: ["reference/Matcha_Gotcha_IX.png", "reference/Matcha_Gotcha_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveCamera INTERPOLATION, ZOOM_OUT_PERS", `EmitProjectile ${SPA}, 1, CURVE`, `Emit ${SPA}, 4, DEFENDER`, `Emit ${SPA}, 8, DEFENDER, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  lobs f${WIDE + STEAM} and f${WIDE + STEAM + STAGGER}, splash f${WIDE + STEAM + LOB}, heal f${WIDE + STEAM + LOB + SPLASH + DRAIN}`);
