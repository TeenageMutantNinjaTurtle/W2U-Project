MoveCamera INTERPOLATION, ZOOM_OUT_PERS, 18, 0, 0
LetCMDsFinish CAMERA
LoadSPA 895
AudioContainer CONTINUE
PlaySound 1784, SE1, 14, 0, -400, 90, 0, 0, 0
PlaySound 1452, SE2, 16, 10, 300, 100, 0, 0, 0
PlaySound 1452, SE2, 16, 16, 0, 100, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 30, 0, 48, 0, 0
PlaySound 1511, SE1, 16, 34, 0, 115, 0, 0, 0
PlaySound 1446, SE1, 16, 40, 400, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 895, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor ATTACKER, 0, 8, 2, 16, 28, 10
Wait 10
EmitProjectile 895, 1, CURVE, ATTACKER, DEFENDER, 2px, 24f, 4px, 3686, 1x, 0
EmitProjectile 895, 2, CURVE, ATTACKER, DEFENDER, 2px, 24f, 4px, 3686, 1x, 0
EmitProjectile 895, 3, CURVE, ATTACKER, DEFENDER, 2px, 24f, 4px, 3686, 1x, 0
Wait 6
EmitProjectile 895, 1, CURVE, ATTACKER, DEFENDER, 2px, 24f, 4px, 3686, 1x, 0
EmitProjectile 895, 3, CURVE, ATTACKER, DEFENDER, 2px, 24f, 4px, 3686, 1x, 0
ChangeSpriteColor ATTACKER, 8, 0, 1, 16, 28, 10
Wait 18
Emit 895, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 895, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 895, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 895, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 16, 28, 10
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 10
Wait 6
ChangeSpriteColor DEFENDER, 12, 0, 1, 16, 28, 10
Wait 12
ToggleFreezeSprite DEFENDER, STOP
AudioContainer CONTINUE
PlaySound 1474, SE1, 14, 0, 0, 90, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 16, 14, 0, -50, 0, 0
AudioContainer SUSPEND
Emit 895, 8, DEFENDER, ATTACKER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 14
AudioContainer CONTINUE
PlaySound 1784, SE2, 14, 0, 0, 100, 0, 0, 0
AudioContainer SUSPEND
Emit 895, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor ATTACKER, 0, 10, 2, 18, 31, 12
Wait 8
ChangeSpriteColor ATTACKER, 10, 0, 2, 18, 31, 12
Wait 8
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
