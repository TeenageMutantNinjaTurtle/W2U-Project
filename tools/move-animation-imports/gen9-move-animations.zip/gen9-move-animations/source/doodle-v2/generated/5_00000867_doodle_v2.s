MoveCamera INTERPOLATION, DEFENDER, 14, 0, 12
LetCMDsFinish CAMERA
LoadSPA 861
AudioContainer CONTINUE
PlaySound 1412, SE1, 16, 0, 0, 100, 0, 0, 0
PlaySound 1350, SE1, 16, 60, 0, 0, 0, 0, 0
PlaySound 1541, SE2, 16, 0, 0, 127, 0, 0, 0
PlaySound 1541, SE2, 16, 32, 400, 127, 0, 0, 0
AudioContainer SUSPEND
Emit 861, 0, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 861, 1, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 861, 2, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 18
MoveCamera INTERPOLATION, ATTACKER, 14, 0, 12
Wait 14
Emit 861, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 861, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 861, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 861, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor ATTACKER, 0, 8, 2, 31, 28, 14
Wait 26
ChangeSpriteColor ATTACKER, 8, 0, 1, 31, 28, 14
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 16, 0, 12
LetCMDsFinish ALL
TerminateMoveScript
