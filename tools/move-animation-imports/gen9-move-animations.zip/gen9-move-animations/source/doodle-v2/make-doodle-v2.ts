import { assert, createKit, fadeInOut, grow, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Doodle (move 867), v2 - from Bulbapedia's stills (reference/).
//   1. A golden box of light forms round the foe: a glowing outline on the
//      ground, light walls fading upward, vertical gold streaks rising.
//   2. The same box then forms round the user (copying the ability), with
//      gold sparkles drifting down.
// An earlier, separate attempt lives in ../doodle (never installed here).
//
// The light walls are a drawn 64x64 a5i3 texture: a glow fading upward with
// brighter side edges (generated/texture-lightbox.png), tinted gold. The floor
// outline is Signal Beam's square outline (SPA 498) laid flat. Sounds are
// Sketch's.

const SPA = 861;
const kit = await createKit({ workDir: import.meta.dirname, slug: "doodle-v2", moveId: 867, spaId: SPA, donors: [498, 411, 298] });

// --- timing (30 fps) ---
const FOE_IN = 14;
const BOX = 36; // a box's life
const PAN = 14;
const USER_AT = 18; // user's box starts this long after the foe's

const GOLD: Rgb = [1.0, 0.85, 0.35];
const PALE_GOLD: Rgb = [1.0, 0.95, 0.7];
const WHITE: Rgb = [1, 1, 1];

// --- the drawn light walls ---
const lightTex = await kit.drawn("lightbox", 64, 64, "a5i3", (x, y) => {
  const rise = 1 - y / 63; // 0 at the bottom, 1 at the top
  const fade = Math.pow(1 - rise, 1.4);
  const edge = x < 3 || x > 60;
  const a = Math.round(255 * Math.min(1, edge ? 0.25 + fade : 0.85 * fade));
  return a < 8 ? undefined : [255, 255, 255, a];
});

// One golden box round a battler: walls, floor outline, rising streaks.
function box(prefix: string, base: Vec3, delay: number): void {
  const walls = kit.parked(lightTex, [base[0], base[1] + 1.1, base[2] + 0.4], 1.7, BOX);
  walls.aspectRatio = 1.25;
  walls.startDelayFrames = delay;
  setCurves(walls, { start: 1, mid: 1, end: 1, curveIn: 0, curveOut: 1 }, fadeInOut(0.75, 0.2, 0.75));
  paint(walls, GOLD, PALE_GOLD, GOLD);
  kit.add(`${prefix}Walls`, walls);

  const floor = kit.parked(kit.tex(498, 0), [base[0], base[1] - 0.6, base[2] + 0.4], 1.6, BOX);
  floor.aspectRatio = 2.6;
  floor.startDelayFrames = delay;
  setCurves(floor, grow(0.6, 0.2, 1.05), fadeInOut(1, 0.15, 0.8));
  paint(floor, PALE_GOLD, WHITE, GOLD);
  kit.add(`${prefix}Floor`, floor);

  const streaks = kit.spray([228, 3], kit.tex(411, 0), [base[0], base[1] - 0.6, base[2] + 0.4], { radius: 1.5, speed: 0, count: 1, bursts: 10, gap: 3, life: 12, scale: 1.3, shape: "circle", directional: true });
  streaks.emissionAxis = 1;
  streaks.axis = [0, 1, 0];
  streaks.initVelAxisAmplifier = 0.35;
  streaks.startDelayFrames = delay + 4;
  setCurves(streaks, undefined, fadeInOut(1, 0.2, 0.5));
  kit.prism(streaks, [GOLD, PALE_GOLD, WHITE]);
  kit.add(`${prefix}Streaks`, streaks);
}

// Battler feet sit about 2 units below the 2px emit anchor.
box("foe", [0, -1.4, 0.2], 0);
box("user", [0, -1.4, 0.2], 0);

// Gold sparkles drifting down round the user as the ability lands.
const sparkles = kit.spray([333, 1], kit.tex(298, 1), [0, 2.4, 0.4], { radius: 1.6, speed: 0, count: 1, bursts: 10, gap: 3, life: 18, scale: 0.3, shape: "ball" });
sparkles.axis = [0, 1, 0];
sparkles.initVelAxisAmplifier = -0.1;
spin(sparkles, 0.06, 0.06, 0, true);
setCurves(sparkles, twinkle(1), twinkle(1));
kit.prism(sparkles, [GOLD, PALE_GOLD, WHITE]);
kit.add("sparkles", sparkles);

const script = `MoveCamera INTERPOLATION, DEFENDER, ${FOE_IN}, 0, 12
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1412, SE1, 16, 0, 0, 100, 0, 0, 0
PlaySound 1350, SE1, 16, ${BOX + PAN + 10}, 0, 0, 0, 0, 0
PlaySound 1541, SE2, 16, 0, 0, 127, 0, 0, 0
PlaySound 1541, SE2, 16, ${USER_AT + PAN}, 400, 127, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("foeWalls", "DEFENDER")}
${kit.emit("foeFloor", "DEFENDER")}
${kit.emit("foeStreaks", "DEFENDER")}
Wait ${USER_AT}
MoveCamera INTERPOLATION, ATTACKER, ${PAN}, 0, 12
Wait ${PAN}
${kit.emit("userWalls", "ATTACKER")}
${kit.emit("userFloor", "ATTACKER")}
${kit.emit("userStreaks", "ATTACKER")}
${kit.emit("sparkles", "ATTACKER")}
ChangeSpriteColor ATTACKER, 0, 8, 2, 31, 28, 14
Wait ${BOX - 10}
ChangeSpriteColor ATTACKER, 8, 0, 1, 31, 28, 14
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 16, 0, 12
LetCMDsFinish ALL
TerminateMoveScript
`;

const { built } = await kit.finish({
  script,
  donorMoveIds: [324, 240, 129, 166],
  references: ["reference/Doodle_IX.png", "reference/Doodle_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, DEFENDER`, "MoveCamera INTERPOLATION, ATTACKER", `Emit ${SPA}, 3, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
assert.ok(built("foeFloor").aspectRatio > 2.4, "Floor outline is not flat");
assert.equal(built("foeWalls").textureIndex, lightTex, "Walls are not the drawn light box");
console.log(`  foe box f${FOE_IN}, user box f${FOE_IN + USER_AT + PAN}`);
