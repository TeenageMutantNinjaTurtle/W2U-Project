MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 938
AudioContainer CONTINUE
PlaySound 1759, PSG, 16, 0, 400, 60, 0, 0, 0
PlaySound 1710, SE1, 14, 4, 500, 95, 0, 0, 0
PlaySound 1710, SE2, 14, 14, 300, 105, 0, 0, 0
PlaySound 1421, SE1, 14, 24, 400, 120, 0, 0, 0
PlaySound 1683, SE2, FLAT, 35, 0, 127, 0, 0, 0
PlaySound 1475, SE1, 16, 40, -300, 127, 0, 0, 0
PlaySound 1413, SE2, 16, 46, -300, 120, 0, 0, 0
PlaySound 1710, SE1, 16, 56, 300, 95, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 4, 31, 30, 10
Emit 938, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 8
Wait 18
ChangeBackgroundColor 4, 0, 12, 2, 1, 1, 6
ChangeSpriteColor ATTACKER, 8, 15, 2, 31, 30, 6
ScaleSprite ATTACKER, ROUNDTRIP, 819, -1229, 3, 0, 1
Wait 6
ToggleSpriteVisibility ATTACKER, 3
Wait 8
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 3
Emit 938, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 938, 20, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 5
ToggleFreezeSprite DEFENDER, START
ChangeBackgroundColor 4, 12, 14, 0, 31, 31, 24
ChangeSpriteColor DEFENDER, 0, 15, 0, 31, 31, 12
ShakeScreen VERTICAL, 1x, 0, 1, 0, 4
Wait 6
ChangeBackgroundColor 4, 14, 0, 3, 31, 31, 24
ChangeSpriteColor DEFENDER, 15, 0, 3, 31, 31, 12
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 4, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 2458, 0, 2, 0, 6
Wait 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 18
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 15, 0, 0, 31, 30, 6
ToggleSpriteVisibility ATTACKER, 4
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
