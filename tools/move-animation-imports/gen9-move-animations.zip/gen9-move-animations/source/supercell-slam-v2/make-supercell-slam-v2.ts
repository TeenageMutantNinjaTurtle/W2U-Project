import { createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Supercell Slam (move 916), v2 - from Logan's keyframes (shown in chat, not
// saved) and brief: "user gathers electricity -> leaps up -> slams its
// lightning absorption onto the target -> dealing damage and rumbling the
// ground".
//   1. Gather: small white-yellow arcs crackle over the user and a sparkle
//      glints on its back as sparks are drawn in to it.
//   2. Leap: the sky darkens, it blazes solid yellow and shoots upward with
//      lightning forking round it.
//   3. Slam: a column of yellow light comes down on the foe with the user, a
//      blazing yellow mass, inside it; bolts fork down either side and yellow
//      spikes burst along the ground.
//   4. Impact: a huge yellow-white flash with prismatic streaks.
//   5. Rumble: white shockwave rings spread at three heights, bolts flicker
//      up off the ground and sparks scatter while the ground shakes.
// The user is hidden from the leap until the end (ToggleSpriteVisibility
// 3/4). The crash damage on a miss is handled by the engine.
// v1 (../supercell-slam, from the Bulbapedia stills) is kept; reinstall its
// manifest to revert.

const SPA = 938;
const kit = await createKit({ workDir: import.meta.dirname, slug: "supercell-slam-v2", moveId: 916, spaId: SPA, donors: [256, 257, 228, 321, 298, 465, 411, 407, 579] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const GATHER = 24;
const LEAP = 8;
const PAN = 8;
const DROP = 5;
const HIT_STOP = 6;
const RUMBLE = 30;

const USER: Vec3 = [0, 0.3, 0.2];
const BACK: Vec3 = [0.2, 1.3, 0.3];
const FOE: Vec3 = [0, 0.3, 0.8];
const FOE_FLOOR: Vec3 = [0, -1.5, 0.8];
const DROP_HEIGHT = 4.5;

const YELLOW: Rgb = [1.0, 0.92, 0.25];
const PALE_YELLOW: Rgb = [1.0, 0.98, 0.72];
const GOLD: Rgb = [1.0, 0.75, 0.2];
const ICE_WHITE: Rgb = [0.9, 0.95, 1.0];
const WHITE: Rgb = [1, 1, 1];

function remapAnim(r: ReturnType<typeof kit.shell>, spaId: number): void {
  r.textureIndex = kit.tex(spaId, r.textureIndex);
  if (r.texAnim) r.texAnim.textures = r.texAnim.textures.map((t, i) => (i < r.texAnim!.textureCount ? kit.tex(spaId, t) : 0));
}
// Thunder's upright bolt column.
function column(pos: Vec3, life: number, scale: number, delay: number, colour: Rgb): ReturnType<typeof kit.shell> {
  const r = kit.shell(256, 1);
  remapAnim(r, 256);
  Object.assign(r, { emitterBasePos: [...pos], particleLifeFrames: life, baseScale: scale, startDelayFrames: delay });
  paint(r, colour, WHITE, colour);
  return r;
}
// Thunder's squiggle arcs.
function arcs(pos: Vec3, opts: Parameters<typeof kit.spray>[3], colours: [Rgb, Rgb, Rgb], delay = 0): ReturnType<typeof kit.spray> {
  const shell = kit.shell(257, 0);
  remapAnim(shell, 257);
  const r = kit.spray(shell, shell.textureIndex, pos, opts);
  r.texAnim = structuredClone(shell.texAnim);
  r.startDelayFrames = delay;
  spin(r, 0, 0, 0, true);
  if (r.alphaAnim) setCurves(r, undefined, fadeOut(1, 0.6));
  r.loopFrames = 7;
  if (r.colorAnim) kit.prism(r, colours);
  else paint(r, colours[1]);
  return r;
}

// --- 1. gathering electricity ---
kit.add("bodyArcs", arcs(USER, { radius: 1.0, speed: 0, count: 1, bursts: GATHER / 3, gap: 3, life: 6, scale: 0.45, shape: "ball" }, [WHITE, PALE_YELLOW, YELLOW]));

const sparkle = kit.parked(kit.tex(407, 1), BACK, 0.5, 12);
sparkle.startDelayFrames = 4;
spin(sparkle, 0.08);
setCurves(sparkle, twinkle(1.3), twinkle(1));
paint(sparkle, WHITE, WHITE, PALE_YELLOW);
kit.add("sparkle", sparkle);

const drawnIn = kit.spray([333, 1], kit.tex(333, 0), USER, { radius: 2.6, speed: 0, count: 1, bursts: GATHER / 2, gap: 2, life: 10, scale: 0.14, shape: "sphere" });
drawnIn.behaviors = [{ type: "convergence", target: [0, 0, 0], force: 0.11 }];
setCurves(drawnIn, undefined, twinkle());
kit.prism(drawnIn, [YELLOW, WHITE, PALE_YELLOW]);
kit.add("drawnIn", drawnIn);

const charge = kit.parked(kit.tex(465, 1), USER, 2.8, GATHER + LEAP);
setCurves(charge, { start: 0.3, mid: 0.7, end: 1.2, curveIn: 0.5, curveOut: 0.6 }, { start: 0, mid: 0.45, end: 0.95, curveIn: 0.4, curveOut: 0.7 });
paint(charge, YELLOW, GOLD, PALE_YELLOW);
kit.add("charge", charge);

// --- 2. the leap ---
const leapBolts = arcs(USER, { radius: 1.8, speed: 0.1, count: 2, bursts: 3, gap: 3, life: 7, scale: 0.9, shape: "ball" }, [YELLOW, WHITE, PALE_YELLOW], GATHER - 4);
kit.add("leapBolts", leapBolts);

const upStreak = kit.spray([228, 3], kit.tex(411, 0), USER, { radius: 0.7, speed: 0, count: 3, bursts: 4, gap: 1, life: 6, scale: 2.6, shape: "circle", directional: true });
upStreak.startDelayFrames = GATHER;
upStreak.emissionAxis = 1;
upStreak.axis = [0, 1, 0];
upStreak.initVelAxisAmplifier = 1.1;
upStreak.airResistance = 1.0;
setCurves(upStreak, undefined, fadeInOut(1, 0.15, 0.6));
kit.prism(upStreak, [YELLOW, WHITE, PALE_YELLOW]);
kit.add("upStreak", upStreak);

const leapFlash = kit.parked(kit.tex(228, 1), USER, 1.8, 8);
leapFlash.startDelayFrames = GATHER;
spin(leapFlash, 0.08);
setCurves(leapFlash, grow(0.5, 0.3, 1.5), fadeOut(1, 0.4));
paint(leapFlash, PALE_YELLOW, WHITE, YELLOW);
kit.add("leapFlash", leapFlash);

// --- 3. the slam ---
const lightColumn = kit.parked(kit.tex(465, 1), [0, 2.4, 0.7], 4.2, DROP + HIT_STOP + 8);
lightColumn.aspectRatio = 0.45;
setCurves(lightColumn, grow(0.7, 0.2, 1.05), fadeInOut(0.85, 0.15, 0.6));
paint(lightColumn, YELLOW, PALE_YELLOW, GOLD);
kit.add("lightColumn", lightColumn);

// The user, a blazing yellow mass, coming down.
function mass(texIndex: number, scale: number, colour: Rgb, start: Rgb): ReturnType<typeof kit.parked> {
  const r = kit.parked(texIndex, [FOE[0], FOE[1] + DROP_HEIGHT, FOE[2] + 0.1], scale, DROP + 1);
  r.axis = [0, -1, 0];
  r.initVelAxisAmplifier = DROP_HEIGHT / DROP;
  setCurves(r, hold(1), hold(1));
  paint(r, colour, start, colour);
  return r;
}
kit.add("massGlow", mass(kit.tex(465, 1), 2.4, YELLOW, PALE_YELLOW));
const massCore = mass(kit.tex(579, 2), 1.5, PALE_YELLOW, WHITE);
spin(massCore, 0.2);
kit.add("massCore", massCore);

kit.add("forkL", column([-1.6, 3.2, 0.7], 9, 3.2, 1, YELLOW));
kit.add("forkR", column([1.7, 3.2, 0.6], 9, 3.0, 3, PALE_YELLOW));

// --- 4. impact ---
const flash = kit.parked(kit.tex(228, 1), FOE, 2.8, 14);
flash.startDelayFrames = DROP;
spin(flash, 0.05);
setCurves(flash, grow(0.4, 0.2, 2.4), fadeOut(1, 0.35));
paint(flash, PALE_YELLOW, WHITE, YELLOW);
kit.add("flash", flash);

const groundSpikes = kit.spray([228, 3], kit.tex(321, 6), [0, -1.1, 0.8], { radius: 0.5, speed: 0.7, count: 9, life: 10, scale: 0.9, shape: "circle", directional: true });
groundSpikes.startDelayFrames = DROP;
groundSpikes.emissionAxis = 1;
setCurves(groundSpikes, grow(1.2, 0.3, 0.6), fadeOut());
kit.prism(groundSpikes, [YELLOW, PALE_YELLOW, WHITE]);
kit.add("groundSpikes", groundSpikes);

function prismatic(colours: [Rgb, Rgb, Rgb], speed: number): ReturnType<typeof kit.spray> {
  const r = kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.5, speed, count: 7, life: 9, scale: 2.2, directional: true });
  r.startDelayFrames = DROP;
  setCurves(r, undefined, fadeOut(1, 0.45));
  kit.prism(r, colours);
  return r;
}
kit.add("prismWarm", prismatic([[1.0, 0.45, 0.4], YELLOW, [1.0, 0.6, 0.9]], 1.0));
kit.add("prismCool", prismatic([[0.4, 0.9, 1.0], WHITE, [0.5, 1.0, 0.6]], 0.9));

// --- 5. the rumble ---
const RUMBLE_AT = DROP + HIT_STOP;
const shock = (y: number, scale: number, delay: number, rate: number) => {
  const r = kit.parked(kit.tex(228, 3), [0, y, 0.8], scale, 18);
  r.startDelayFrames = RUMBLE_AT + delay;
  r.aspectRatio = 3.2;
  spin(r, rate);
  setCurves(r, grow(0.25, 0.4, 1.35), fadeInOut(0.95, 0.08, 0.5));
  paint(r, WHITE, WHITE, ICE_WHITE);
  return r;
};
kit.add("shockLow", shock(-1.5, 1.9, 0, 0.06));
kit.add("shockMid", shock(0.4, 1.5, 3, -0.05));
kit.add("shockHigh", shock(2.2, 1.2, 6, 0.06));

kit.add("groundBolts", arcs(FOE_FLOOR, { radius: 1.7, speed: 0, count: 1, bursts: RUMBLE / 4, gap: 4, life: 7, scale: 0.9, shape: "circle" }, [YELLOW, WHITE, PALE_YELLOW], RUMBLE_AT));

const sparks = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 1.6, speed: 0.08, count: 2, bursts: RUMBLE / 4, gap: 4, life: 12, scale: 0.13, shape: "ball" });
sparks.startDelayFrames = RUMBLE_AT;
sparks.behaviors = [{ type: "gravity", magnitude: [0, -0.012, 0] }];
setCurves(sparks, undefined, twinkle());
kit.prism(sparks, [YELLOW, WHITE, GOLD]);
kit.add("sparks", sparks);

// --- script ---
const emits = (names: string[], who: "ATTACKER" | "DEFENDER") => names.map((n) => kit.emit(n, who)).join("\n");
const slamAt = GATHER + LEAP + PAN;
const rumbleBeats = Math.round(RUMBLE / 5);
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1759, PSG, 16, 0, 400, 60, 0, 0, 0
PlaySound 1710, SE1, 14, 4, 500, 95, 0, 0, 0
PlaySound 1710, SE2, 14, 14, 300, 105, 0, 0, 0
PlaySound 1421, SE1, 14, ${GATHER}, 400, 120, 0, 0, 0
PlaySound 1683, SE2, FLAT, ${slamAt - DROP}, 0, 127, 0, 0, 0
PlaySound 1475, SE1, 16, ${slamAt}, -300, 127, 0, 0, 0
PlaySound 1413, SE2, 16, ${slamAt + HIT_STOP}, -300, 120, 0, 0, 0
PlaySound 1710, SE1, 16, ${slamAt + HIT_STOP + 10}, 300, 95, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 4, 31, 30, 10
${emits(["charge", "bodyArcs", "sparkle", "drawnIn", "leapBolts", "upStreak", "leapFlash"], "ATTACKER")}
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, ${GATHER / 2 - 4}
Wait ${GATHER - 6}
ChangeBackgroundColor 4, 0, 12, 2, 1, 1, 6
ChangeSpriteColor ATTACKER, 8, 15, 2, 31, 30, 6
ScaleSprite ATTACKER, ROUNDTRIP, 819, -1229, 3, 0, 1
Wait 6
ToggleSpriteVisibility ATTACKER, 3
Wait ${LEAP}
MoveCamera INTERPOLATION, DEFENDER, ${PAN}, 0, 8
Wait ${PAN - DROP}
${emits(["lightColumn", "massGlow", "massCore", "forkL", "forkR", "flash", "groundSpikes", "prismWarm", "prismCool", "shockLow", "shockMid", "shockHigh", "groundBolts", "sparks"], "DEFENDER")}
Wait ${DROP}
ToggleFreezeSprite DEFENDER, START
ChangeBackgroundColor 4, 12, 14, 0, 31, 31, 24
ChangeSpriteColor DEFENDER, 0, 15, 0, 31, 31, 12
ShakeScreen VERTICAL, 1x, 0, 1, 0, 4
Wait ${HIT_STOP}
ChangeBackgroundColor 4, 14, 0, 3, 31, 31, 24
ChangeSpriteColor DEFENDER, 15, 0, 3, 31, 31, 12
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 4, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, ${rumbleBeats + 4}
ShakeScreen VERTICAL, 2458, 0, 2, 0, 6
Wait 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, ${rumbleBeats}
Wait ${RUMBLE - 12}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 15, 0, 0, 31, 30, 6
ToggleSpriteVisibility ATTACKER, 4
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [87, 527, 63, 153, 129, 605, 291],
  references: ["reference/Supercell_Slam_IX.png", "reference/Supercell_Slam_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("bodyArcs")}, ATTACKER`, "ToggleSpriteVisibility ATTACKER, 3", "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("massGlow")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("shockLow")}, DEFENDER`, "ShakeScreen VERTICAL, 2458", "ToggleSpriteVisibility ATTACKER, 4", "MoveCamera INTERPOLATION, INIT"],
});
const at = CAMERA_IN + slamAt;
console.log(`  gather f${CAMERA_IN}, leap f${CAMERA_IN + GATHER}, slam lands f${at}, rumble f${at + HIT_STOP}-${at + HIT_STOP + RUMBLE}`);
