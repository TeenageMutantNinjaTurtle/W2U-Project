import { createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Curve3, type Rgb, type Vec3 } from "../tools/anim-kit";

// Lumina Crash (move 855), v2 - from Logan's keyframes (shown in chat, not
// saved), in Logan's order:
//   1. Startup: thin violet-white beams shoot from the user's eyes into a
//      crystal of overlapping translucent pink hexagons with a deep violet
//      core, a white star flare at its heart throwing long thin light rays;
//      a little pink hexagon floats beside it.
//   2. Expansion: the crystal swells, its violet core churning.
//   3. Quick condense/expand: it collapses to a point, then a huge pink
//      sphere with a glowing magenta rim bursts out, white light streaking
//      outward inside it.
//   4. Hit: a white flash on the foe with long lavender crystal blades
//      radiating from it over a pink glow.
//   5. Rumble: the foe, tinted pink, shudders while translucent hexagon tiles
//      with star flares in their centres appear round it and shatter into
//      pink fragments, sparkles twinkling.
// v1 (../lumina-crash, from the Bulbapedia stills) is kept; reinstall its
// manifest to revert.
//
// Drawn here: a pointy-topped hexagon tile (64x64 a5i3 white mask:
// translucent fill, bright rim, faint inner bevel; generated/texture-hex.png).

const SPA = 914;
const kit = await createKit({ workDir: import.meta.dirname, slug: "lumina-crash-v2", moveId: 855, spaId: SPA, donors: [471, 298, 407, 411, 228, 465, 560] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const STARTUP = 18;
const EXPAND = 12;
const CONDENSE = 4;
const BURST = 8;
const PAN = 8;
const HIT_STOP = 5;
const RUMBLE = 36;

const EYE: Vec3 = [0.35, 1.2, -0.3];
const FRONT: Vec3 = [0.2, 0.4, -1.7];
const UPPER: Vec3 = [0.5, 1.3, -1.9];
const FOE: Vec3 = [0, 0.3, 0.8];

const PINK: Rgb = [1.0, 0.5, 0.88];
const MAGENTA: Rgb = [0.95, 0.3, 0.9];
const PALE_PINK: Rgb = [1.0, 0.85, 0.97];
const LAVENDER: Rgb = [0.85, 0.78, 1.0];
const VIOLET: Rgb = [0.6, 0.3, 1.0];
const DEEP_VIOLET: Rgb = [0.32, 0.12, 0.7];
const BLUE_PINK: Rgb = [0.7, 0.6, 1.0];
const PALE_BLUE: Rgb = [0.75, 0.88, 1.0];
const WHITE: Rgb = [1, 1, 1];

// --- the drawn hexagon ---
const IN_R = 29 * (Math.sqrt(3) / 2); // inradius of a pointy-top hexagon of circumradius 29
const hexNorm = (x: number, y: number) =>
  Math.max(Math.abs(x), Math.abs(0.5 * x + (Math.sqrt(3) / 2) * y), Math.abs(-0.5 * x + (Math.sqrt(3) / 2) * y)) / IN_R;
const hexTex = await kit.drawn("hex", 64, 64, "a5i3", (x, y) => {
  const px = x + 0.5 - 32;
  const py = y + 0.5 - 32;
  const d = hexNorm(px, py);
  if (d > 1) return undefined;
  if (d > 0.88) return [255, 255, 255, 250];
  if (d > 0.72 && d < 0.77) return [255, 255, 255, 150];
  const sheen = 0.5 - (px + py) / 120; // brighter toward the upper left
  return [255, 255, 255, Math.round(255 * (0.3 + 0.2 * sheen))];
});

// --- 1-2. startup and expansion: the crystal ---
const CRYSTAL_LIFE = STARTUP + EXPAND;
const swell = (to: number): Curve3 => ({ start: 0.15, mid: 1, end: to, curveIn: (STARTUP * 0.6) / CRYSTAL_LIFE, curveOut: STARTUP / CRYSTAL_LIFE });
function crystal(pos: Vec3, scale: number, to: number, colour: Rgb, start: Rgb, level: number, texIndex = hexTex): ReturnType<typeof kit.parked> {
  const r = kit.parked(texIndex, pos, scale, CRYSTAL_LIFE);
  setCurves(r, swell(to), { start: 0, mid: level, end: level, curveIn: 0.15, curveOut: 1 });
  paint(r, colour, start, colour);
  return r;
}
kit.add("hexUpper", crystal(UPPER, 1.6, 1.4, BLUE_PINK, PALE_PINK, 0.85));
kit.add("hexOuter", crystal(FRONT, 2.0, 1.6, PINK, PALE_PINK, 1));
kit.add("hexCore", crystal(FRONT, 1.35, 1.6, DEEP_VIOLET, VIOLET, 0.9));

const churn = crystal(FRONT, 1.0, 1.7, VIOLET, DEEP_VIOLET, 0.6, kit.tex(228, 3));
spin(churn, 0.18);
kit.add("churn", churn);

const glow = crystal(FRONT, 1.0, 1.8, PALE_PINK, WHITE, 0.9, kit.tex(228, 1));
spin(glow, 0.05);
kit.add("glow", glow);

const flare = crystal(FRONT, 0.9, 2.0, WHITE, WHITE, 1, kit.tex(407, 1));
spin(flare, -0.04, -0.04, deg(45));
kit.add("flare", flare);

// Long thin light rays flickering through the heart of the crystal.
const rays = kit.spray([228, 3], kit.tex(411, 0), FRONT, { radius: 0, speed: 0.01, count: 3, bursts: CRYSTAL_LIFE / 3, gap: 3, life: 5, scale: 3.0, shape: "sphere", directional: true });
rays.startDelayFrames = 4;
setCurves(rays, hold(1), fadeOut(1, 0.5));
kit.prism(rays, [WHITE, LAVENDER, PALE_PINK]);
kit.add("rays", rays);

// The eye beams: thin streams from the user's eyes into the crystal.
function beam(scale: number, colour: Rgb, start: Rgb): ReturnType<typeof kit.shell> {
  const r = kit.shell(228, 0);
  r.textureIndex = kit.tex(228, 1);
  const dir = [FRONT[0] - EYE[0], FRONT[1] - EYE[1], FRONT[2] - EYE[2]];
  const len = Math.hypot(...dir);
  const travel = 4;
  Object.assign(r, {
    emitterBasePos: [...EYE], axis: dir.map((a) => a / len), initVelAxisAmplifier: len / travel, particleLifeFrames: travel,
    followEmitter: false, baseScale: scale, emitterLifeFrames: STARTUP, emissionIntervalFrames: 1, airResistance: 1.0, startDelayFrames: 2,
  });
  setCurves(r, hold(1), hold(1));
  paint(r, colour, start, colour);
  return r;
}
kit.add("beam", beam(0.35, VIOLET, LAVENDER));
kit.add("beamCore", beam(0.16, WHITE, WHITE));

const bits = kit.spray([333, 1], hexTex, FRONT, { radius: 1.8, speed: 0.01, count: 1, bursts: 5, gap: 5, life: 14, scale: 0.22, shape: "ball" });
setCurves(bits, grow(0.3, 0.3), fadeInOut(1, 0.2, 0.7));
kit.prism(bits, [PINK, MAGENTA, PALE_PINK]);
kit.add("bits", bits);

// --- 3. condense, then the sphere bursts out ---
const condense = kit.parked(hexTex, FRONT, 2.0 * 1.6, CONDENSE);
setCurves(condense, { start: 1, mid: 1, end: 0.05, curveIn: 0, curveOut: 0 }, hold(1));
paint(condense, PINK, PALE_PINK, WHITE);
kit.add("condense", condense);

const pinch = kit.parked(kit.tex(407, 1), FRONT, 1.8, CONDENSE + 2);
spin(pinch, 0.2, 0.2, deg(45));
setCurves(pinch, { start: 1, mid: 1, end: 0.2, curveIn: 0, curveOut: 0.2 }, hold(1));
paint(pinch, WHITE);
kit.add("pinch", pinch);

const balloon = (curveEnd: number): Curve3 => ({ start: 0.1, mid: 1, end: curveEnd, curveIn: 0.55, curveOut: 0.55 });
const sphereFill = kit.parked(kit.tex(465, 1), FRONT, 6.0, BURST + PAN);
setCurves(sphereFill, balloon(1.25), fadeOut(0.85, 0.5));
paint(sphereFill, PALE_PINK, WHITE, PINK);
kit.add("sphereFill", sphereFill);

const sphereRim = kit.parked(kit.tex(560, 1), FRONT, 5.0, BURST + PAN);
setCurves(sphereRim, balloon(1.3), fadeOut(1, 0.5));
paint(sphereRim, MAGENTA, PINK, MAGENTA);
kit.add("sphereRim", sphereRim);

const sphereRays = kit.spray([228, 3], kit.tex(411, 0), FRONT, { radius: 0.3, speed: 1.1, count: 12, bursts: 2, gap: 3, life: 8, scale: 2.4, directional: true });
setCurves(sphereRays, undefined, fadeOut(1, 0.4));
kit.prism(sphereRays, [WHITE, PALE_PINK, LAVENDER]);
kit.add("sphereRays", sphereRays);

// --- 4. the hit ---
const hitFlash = kit.parked(kit.tex(228, 1), FOE, 2.2, 12);
spin(hitFlash, 0.05);
setCurves(hitFlash, grow(0.4, 0.2, 2.4), fadeOut(1, 0.35));
paint(hitFlash, WHITE, WHITE, PALE_PINK);
kit.add("hitFlash", hitFlash);

const hitGlow = kit.parked(kit.tex(465, 1), FOE, 3.0, 16);
setCurves(hitGlow, grow(0.4, 0.2, 1.3), fadeOut(0.8, 0.4));
paint(hitGlow, PINK, PALE_PINK, MAGENTA);
kit.add("hitGlow", hitGlow);

const blades = kit.spray([228, 3], kit.tex(465, 3), FOE, { radius: 0.3, speed: 0.75, count: 12, life: 10, scale: 1.5, directional: true });
setCurves(blades, grow(0.6, 0.25, 1.2), fadeOut(1, 0.45));
kit.prism(blades, [LAVENDER, WHITE, PALE_PINK]);
kit.add("blades", blades);

// --- 5. the rumble: hexagon tiles appear round the foe and shatter ---
const TILE_HOLD = 10;
const spots: Array<{ pos: Vec3; scale: number; colour: Rgb; delay: number }> = [
  { pos: [-1.6, 1.4, 1.0], scale: 1.3, colour: LAVENDER, delay: 2 },
  { pos: [1.5, 1.8, 1.0], scale: 1.0, colour: PALE_BLUE, delay: 5 },
  { pos: [-1.9, -0.3, 1.0], scale: 1.1, colour: PALE_BLUE, delay: 8 },
  { pos: [1.7, 0.1, 1.0], scale: 1.4, colour: LAVENDER, delay: 11 },
];
spots.forEach((s, i) => {
  const tile = kit.parked(hexTex, s.pos, s.scale, TILE_HOLD + 2);
  tile.startDelayFrames = s.delay;
  setCurves(tile, { start: 0.3, mid: 1, end: 1.1, curveIn: 0.25, curveOut: 0.85 }, { start: 0, mid: 1, end: 0, curveIn: 0.2, curveOut: 0.85 });
  paint(tile, s.colour, WHITE, s.colour);
  kit.add(`tile${i}`, tile);

  const star = kit.parked(kit.tex(407, 1), s.pos, s.scale * 0.8, TILE_HOLD + 2);
  star.startDelayFrames = s.delay + 1;
  spin(star, 0.06, 0.06, deg(45));
  setCurves(star, twinkle(1.2), { start: 0.3, mid: 1, end: 0, curveIn: 0.3, curveOut: 0.85 });
  paint(star, WHITE, WHITE, PALE_PINK);
  kit.add(`star${i}`, star);

  const shards = kit.spray([333, 1], kit.tex(471, 2), s.pos, { radius: 0.4 * s.scale, speed: 0.12, count: 6, life: 14, scale: 0.26 });
  shards.startDelayFrames = s.delay + TILE_HOLD;
  shards.behaviors = [{ type: "gravity", magnitude: [0, -0.02, 0] }];
  spin(shards, -0.3, 0.3, 0, true);
  setCurves(shards, hold(1), fadeOut(1, 0.55));
  kit.prism(shards, [PINK, PALE_PINK, WHITE]);
  kit.add(`shards${i}`, shards);
});

const sparkles = kit.spray([333, 1], kit.tex(298, 1), FOE, { radius: 2.2, speed: 0.01, count: 1, bursts: 10, gap: 3, life: 10, scale: 0.3, shape: "ball" });
sparkles.startDelayFrames = 4;
setCurves(sparkles, twinkle(1), twinkle(1));
kit.prism(sparkles, [WHITE, PALE_PINK, LAVENDER]);
kit.add("sparkles", sparkles);

// --- script ---
const tiles = spots.flatMap((_, i) => [kit.emit(`tile${i}`, "DEFENDER"), kit.emit(`star${i}`, "DEFENDER"), kit.emit(`shards${i}`, "DEFENDER")]).join("\n");
const shatterSounds = spots.map((s) => `PlaySound 1509, SE2, 14, ${HIT_STOP + s.delay + TILE_HOLD}, ${300 + s.delay * 40}, 100, 0, 0, 0`).join("\n");
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1783, SE1, 14, 0, -500, 115, 0, 0, 0
PlaySound 1418, PSG, 14, 2, 600, 100, 0, 0, 0
PlaySound 1718, SE2, 14, ${STARTUP}, -300, 110, 0, 0, 0
PlaySound 1816, SE1, 14, ${STARTUP + EXPAND}, 600, 115, 0, 0, 0
PlaySound 1423, SE2, 14, ${STARTUP + EXPAND + CONDENSE}, -600, 127, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 1, 18, 4, 20
ChangeSpriteColor ATTACKER, 0, 6, 2, 31, 20, 30
${kit.emit("beam", "ATTACKER")}
${kit.emit("beamCore", "ATTACKER")}
${kit.emit("hexUpper", "ATTACKER")}
${kit.emit("hexOuter", "ATTACKER")}
${kit.emit("hexCore", "ATTACKER")}
${kit.emit("churn", "ATTACKER")}
${kit.emit("glow", "ATTACKER")}
${kit.emit("flare", "ATTACKER")}
${kit.emit("rays", "ATTACKER")}
${kit.emit("bits", "ATTACKER")}
Wait ${STARTUP}
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, ${EXPAND / 2}
Wait ${EXPAND}
${kit.emit("condense", "ATTACKER")}
${kit.emit("pinch", "ATTACKER")}
Wait ${CONDENSE}
ChangeSpriteColor ATTACKER, 6, 0, 1, 31, 20, 30
${kit.emit("sphereFill", "ATTACKER")}
${kit.emit("sphereRim", "ATTACKER")}
${kit.emit("sphereRays", "ATTACKER")}
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait ${BURST}
MoveCamera INTERPOLATION, DEFENDER, ${PAN}, 0, 8
Wait ${PAN}
AudioContainer CONTINUE
PlaySound 1475, SE1, 16, 0, -300, 127, 0, 0, 0
PlaySound 1423, SE2, 16, 0, -200, 120, 0, 0, 0
${shatterSounds}
AudioContainer SUSPEND
${kit.emit("hitGlow", "DEFENDER")}
${kit.emit("hitFlash", "DEFENDER")}
${kit.emit("blades", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 22, 30
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 14, 10, 1, 31, 16, 28
${tiles}
${kit.emit("sparkles", "DEFENDER")}
ShakeSprite DEFENDER, 2, 819, 0, 1, 1, ${RUMBLE - 6}
ShakeScreen HORIZON, 0.5x, 0, 1, 0, ${RUMBLE / 2 - 2}
Wait ${RUMBLE - 8}
ChangeSpriteColor DEFENDER, 10, 0, 2, 31, 16, 28
Wait 8
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 10, 0, 1, 18, 4, 20
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [301, 129, 236, 240, 63, 605, 113],
  references: ["reference/Lumina_Crash_IX.png", "reference/Lumina_Crash_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, `Emit ${SPA}, 10, ATTACKER`, `Emit ${SPA}, 12, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 17, DEFENDER`, "ShakeScreen HORIZON", "MoveCamera INTERPOLATION, INIT"],
});
const at = CAMERA_IN + STARTUP + EXPAND;
console.log(`  startup f${CAMERA_IN}, expand f${CAMERA_IN + STARTUP}, condense f${at}, burst f${at + CONDENSE}, hit f${at + CONDENSE + BURST + PAN}, rumble to f${at + CONDENSE + BURST + PAN + HIT_STOP + RUMBLE}`);
