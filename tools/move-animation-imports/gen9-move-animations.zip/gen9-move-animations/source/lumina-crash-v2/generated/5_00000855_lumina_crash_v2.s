MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 914
AudioContainer CONTINUE
PlaySound 1783, SE1, 14, 0, -500, 115, 0, 0, 0
PlaySound 1418, PSG, 14, 2, 600, 100, 0, 0, 0
PlaySound 1718, SE2, 14, 18, -300, 110, 0, 0, 0
PlaySound 1816, SE1, 14, 30, 600, 115, 0, 0, 0
PlaySound 1423, SE2, 14, 34, -600, 127, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 1, 18, 4, 20
ChangeSpriteColor ATTACKER, 0, 6, 2, 31, 20, 30
Emit 914, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 18
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 6
Wait 12
Emit 914, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 11, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 4
ChangeSpriteColor ATTACKER, 6, 0, 1, 31, 20, 30
Emit 914, 12, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 13, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 14, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeScreen VERTICAL, 1x, 0, 2, 0, 4
Wait 8
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
AudioContainer CONTINUE
PlaySound 1475, SE1, 16, 0, -300, 127, 0, 0, 0
PlaySound 1423, SE2, 16, 0, -200, 120, 0, 0, 0
PlaySound 1509, SE2, 14, 17, 380, 100, 0, 0, 0
PlaySound 1509, SE2, 14, 20, 500, 100, 0, 0, 0
PlaySound 1509, SE2, 14, 23, 620, 100, 0, 0, 0
PlaySound 1509, SE2, 14, 26, 740, 100, 0, 0, 0
AudioContainer SUSPEND
Emit 914, 16, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 17, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 22, 30
Wait 5
ChangeSpriteColor DEFENDER, 14, 10, 1, 31, 16, 28
Emit 914, 18, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 19, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 20, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 21, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 22, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 23, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 24, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 25, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 26, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 27, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 28, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 29, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 914, 30, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite DEFENDER, 2, 819, 0, 1, 1, 30
ShakeScreen HORIZON, 0.5x, 0, 1, 0, 16
Wait 28
ChangeSpriteColor DEFENDER, 10, 0, 2, 31, 16, 28
Wait 8
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 10, 0, 1, 18, 4, 20
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
