MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 883
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -800, 120, 0, 0, 0
PlaySound 1467, SE2, 14, 6, 0, 90, 0, 0, 0
PlaySound 1421, SE2, 14, 22, -200, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 10, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 2, 14, 6, 24
Emit 883, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 883, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 883, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 8
Wait 22
ChangeSpriteColor ATTACKER, 10, 0, 1, 14, 6, 24
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
Emit 883, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 883, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 883, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 883, 6, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
AudioContainer CONTINUE
PlaySound 1420, SE1, 16, 0, -400, 125, 0, 0, 0
PlaySound 1475, SE2, 16, 0, -200, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 883, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 883, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 883, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 16, 8, 28
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 4, 0, 6
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 5
Wait 6
ChangeSpriteColor DEFENDER, 12, 0, 1, 16, 8, 28
Wait 16
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
