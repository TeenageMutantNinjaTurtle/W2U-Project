import { aimed, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Rage Fist (move 889) - from Bulbapedia's stills (reference/).
//   1. The user fumes with anger marks inside a dark violet ghostly aura,
//      violet streaks darting off it.
//   2. A dark swirl ring snaps at its fist and a giant spectral indigo fist
//      inside a white-blue comet blaze flies at the foe.
//
// The fist is Mega Punch's (SPA 169, texture 3), tinted indigo. The anger
// mark is drawn here as Raging Bull's (32x32 a3i5: four separate red hooks
// pinwheeled round the centre; generated/texture-anger.png).

const SPA = 883;
const kit = await createKit({ workDir: import.meta.dirname, slug: "rage-fist", moveId: 889, spaId: SPA, donors: [169, 228, 321, 465, 411, 298] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const FUME = 22;
const FLIGHT = 10;
const HOLD = 22;

const USER: Vec3 = [0, 0.2, 0.2];
const HEAD: Vec3 = [0.4, 1.6, 0.5];
const FIST: Vec3 = [0.2, 0.3, -1.0];
const FOE: Vec3 = [0, 0.3, 0.8];

const VIOLET: Rgb = [0.55, 0.3, 1.0];
const DARK_VIOLET: Rgb = [0.25, 0.08, 0.5];
const INDIGO: Rgb = [0.32, 0.22, 0.8];
const ICE_BLUE: Rgb = [0.75, 0.88, 1.0];
const WHITE: Rgb = [1, 1, 1];

// --- the drawn anger mark (Raging Bull's, at Logan's request) ---
const ANGER_RED = [190, 26, 48];
const angerTex = await kit.drawn("anger", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5 - 16;
  const py = y + 0.5 - 16;
  const tilt = (-25 * Math.PI) / 180;
  for (let k = 0; k < 4; k++) {
    // Each stroke is an arc round a point 15 px out; only the part bowing
    // toward the centre is drawn.
    const a = tilt + (k * Math.PI) / 2;
    const cx = 15 * Math.cos(a);
    const cy = 15 * Math.sin(a);
    const dx = px - cx;
    const dy = py - cy;
    const d = Math.hypot(dx, dy);
    if (Math.abs(d - 7.5) > 1.9) continue;
    const toCentre = Math.atan2(-cy, -cx);
    let off = Math.atan2(dy, dx) - toCentre;
    off = Math.atan2(Math.sin(off), Math.cos(off));
    if (Math.abs(off) < 1.2) return ANGER_RED;
  }
  return undefined;
});

// --- fuming ---
const aura = kit.spray([333, 1], kit.tex(321, 5), [USER[0], USER[1] - 1.2, USER[2]], { radius: 1.2, speed: 0.02, count: 1, bursts: 10, gap: 2, life: 14, scale: 0.7, shape: "circle" });
aura.emissionAxis = 1;
aura.axis = [0, 1, 0];
aura.initVelAxisAmplifier = 0.12;
spin(aura, -0.06, 0.06, 0, true);
setCurves(aura, grow(0.5, 0.3, 1.2), fadeInOut(0.75, 0.2, 0.5));
kit.prism(aura, [VIOLET, DARK_VIOLET, INDIGO]);
kit.add("aura", aura);

const marks = kit.spray([333, 1], angerTex, HEAD, { radius: 0.6, speed: 0, count: 1, bursts: 3, gap: 6, life: 12, scale: 0.55, shape: "ball" });
setCurves(marks, { start: 0.4, mid: 1.2, end: 0.9, curveIn: 0.25, curveOut: 0.5 }, fadeInOut(1, 0.1, 0.75));
paint(marks, WHITE);
kit.add("marks", marks);

const darts = kit.spray([228, 3], kit.tex(411, 0), USER, { radius: 1.0, speed: 0.4, count: 1, bursts: 6, gap: 3, life: 7, scale: 1.2, directional: true });
setCurves(darts, undefined, fadeOut());
kit.prism(darts, [VIOLET, WHITE, INDIGO]);
kit.add("darts", darts);

// --- the punch ---
const swirlRing = kit.parked(kit.tex(228, 3), FIST, 1.0, 12);
spin(swirlRing, -0.3);
setCurves(swirlRing, grow(0.4, 0.3, 1.6), fadeOut(1, 0.4));
paint(swirlRing, DARK_VIOLET, VIOLET, DARK_VIOLET);
kit.add("swirlRing", swirlRing);

function flying(texIndex: number, scale: number, colour: Rgb, start: Rgb, level: number): ReturnType<typeof kit.parked> {
  const r = kit.parked(texIndex, FIST, scale, FLIGHT + 1);
  aimed(r, 1.5, FLIGHT + 1);
  setCurves(r, grow(0.6, 0.25, 1.1), hold(level));
  paint(r, colour, start, colour);
  return r;
}
kit.add("blaze", flying(kit.tex(465, 1), 2.0, ICE_BLUE, WHITE, 0.85));
kit.add("fist", flying(kit.tex(169, 3), 1.3, INDIGO, VIOLET, 1));

const comet = kit.spray([228, 3], kit.tex(411, 0), FIST, { radius: 0.8, speed: 0, count: 2, bursts: FLIGHT, gap: 1, life: 6, scale: 1.4, directional: true });
aimed(comet, 1.2, 6);
setCurves(comet, undefined, fadeInOut(0.9, 0.2, 0.6));
kit.prism(comet, [ICE_BLUE, WHITE, VIOLET]);
kit.add("comet", comet);

// --- impact ---
const flash = kit.parked(kit.tex(228, 1), FOE, 1.5, 12);
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.25, 1.9), fadeOut(1, 0.35));
paint(flash, ICE_BLUE, WHITE, VIOLET);
kit.add("flash", flash);

const burst = kit.spray([333, 1], kit.tex(321, 5), FOE, { radius: 0.5, speed: 0.12, count: 5, life: 16, scale: 0.8, shape: "ball" });
spin(burst, -0.06, 0.06, 0, true);
setCurves(burst, grow(0.5, 0.25, 1.4), fadeOut(0.85, 0.4));
kit.prism(burst, [DARK_VIOLET, VIOLET, INDIGO]);
kit.add("burst", burst);

const spikes = kit.spray([228, 3], kit.tex(321, 6), FOE, { radius: 0.3, speed: 0.5, count: 8, life: 10, scale: 0.5, directional: true });
setCurves(spikes, grow(1.2, 0.3, 0.6), fadeOut());
kit.prism(spikes, [VIOLET, ICE_BLUE, WHITE]);
kit.add("spikes", spikes);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -800, 120, 0, 0, 0
PlaySound 1467, SE2, 14, 6, 0, 90, 0, 0, 0
PlaySound 1421, SE2, 14, ${FUME}, -200, 120, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${FLIGHT}, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 2, 14, 6, 24
${kit.emit("aura", "ATTACKER")}
${kit.emit("marks", "ATTACKER")}
${kit.emit("darts", "ATTACKER")}
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 8
Wait ${FUME}
ChangeSpriteColor ATTACKER, 10, 0, 1, 14, 6, 24
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
${kit.emit("swirlRing", "ATTACKER")}
${kit.emit("blaze", "ATTACKER", "DEFENDER")}
${kit.emit("fist", "ATTACKER", "DEFENDER")}
${kit.emit("comet", "ATTACKER", "DEFENDER")}
MoveCamera INTERPOLATION, DEFENDER, ${FLIGHT}, 0, 8
Wait ${FLIGHT}
AudioContainer CONTINUE
PlaySound 1420, SE1, 16, 0, -400, 125, 0, 0, 0
PlaySound 1475, SE2, 16, 0, -200, 110, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("flash", "DEFENDER")}
${kit.emit("burst", "DEFENDER")}
${kit.emit("spikes", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 16, 8, 28
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 4, 0, 6
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 5
Wait 6
ChangeSpriteColor DEFENDER, 12, 0, 1, 16, 8, 28
Wait ${HOLD - 6}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [5, 63, 153, 605, 240, 247, 261],
  references: ["reference/Rage_Fist_IX.png", "reference/Rage_Fist_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 1, ATTACKER`, `Emit ${SPA}, 5, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 7, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  fume f${CAMERA_IN}-${CAMERA_IN + FUME}, fist ${FLIGHT}f, impact f${CAMERA_IN + FUME + FLIGHT}`);
