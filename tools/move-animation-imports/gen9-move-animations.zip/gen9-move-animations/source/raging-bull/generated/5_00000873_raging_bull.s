MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 867
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -500, 115, 0, 0, 0
PlaySound 1467, SE2, 14, 4, 300, 90, 0, 0, 0
PlaySound 1420, SE2, 14, 18, -600, 80, 0, 0, 0
PlaySound 1420, SE2, 14, 25, -600, 80, 0, 0, 0
PlaySound 1421, SE1, 14, 32, -300, 125, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 10, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 13, 3, 31, 13, 4
Emit 867, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 867, 10, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 9
Wait 18
Emit 867, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 6
Wait 14
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
Emit 867, 1, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 867, 2, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 867, 3, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 867, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor ATTACKER, 13, 0, 2, 31, 13, 4
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
AudioContainer CONTINUE
PlaySound 1475, SE1, 16, 0, -400, 125, 0, 0, 0
PlaySound 1420, SE2, 16, 0, -200, 120, 0, 0, 0
AudioContainer SUSPEND
Emit 867, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 867, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 867, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 867, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 31, 31, 24
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 4, 0, 6
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 5
ChangeSpriteColor DEFENDER, 12, 0, 1, 31, 31, 24
Wait 19
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
