import { aimed, assert, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Raging Bull (move 873) - from Bulbapedia's Normal-form stills (reference/).
//   1. The user barrels forward as a yellow-white energy comet through a
//      tunnel of white wind swirls, with orange embers and streaks.
//   2. A yellow-white explosion on the foe with red and orange streaks, orange
//      smoky wisps and grey dust clouds rolling along the ground.
// The Fighting/Fire/Water stills are Paldean Tauros variants; an animation
// can't switch on the user's form here, so the Normal one is used.
//
// Startup added at Logan's request (2026-10-01, reference/keyframe-startup-
// tint.png and anger-mark.png): the user first turns the colour of the move
// and anger marks pop above it, steam puffing off its head. A script can't
// tell which Tauros is attacking (ATTACKER_POKEMON is a battle position, not
// a species or form), so the tint is one colour: the orange-red of Logan's
// screenshot. Change TINT to recolour it.
// The anger mark is drawn here to match Logan's image (32x32 a3i5: four thick
// red curved strokes pinwheeled round the centre, each bowing inward;
// generated/texture-anger.png).

const SPA = 867;
const kit = await createKit({ workDir: import.meta.dirname, slug: "raging-bull", moveId: 873, spaId: SPA, donors: [228, 321, 465, 606] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const RAGE = 18; // the tint and anger marks
const STAMP = 14; // pawing and dust before the charge
const CHARGE = 10;
const HOLD = 24;

const USER: Vec3 = [0, 0.1, -0.6];
const USER_FEET: Vec3 = [0, -1.9, 0];
const FOE: Vec3 = [0, 0.2, 0.8];
const FOE_GROUND: Vec3 = [0, -1.9, 0.6];

const YELLOW: Rgb = [1.0, 0.92, 0.35];
const PALE: Rgb = [1.0, 0.98, 0.8];
const ORANGE: Rgb = [1.0, 0.55, 0.15];
const RED: Rgb = [1.0, 0.3, 0.25];
const WHITE: Rgb = [1, 1, 1];
const GREY: Rgb = [0.62, 0.6, 0.6];

const puffTex = kit.tex(321, 5);

// The startup tint, as a 0-31 sprite colour: orange-red.
const TINT = "31, 13, 4";
const HEAD: Vec3 = [-0.5, 1.9, 0.2];

// --- stamp ---
const dust = kit.spray([333, 1], puffTex, USER_FEET, { radius: 0.8, speed: 0.08, count: 2, bursts: 4, gap: 4, life: 16, scale: 0.6, shape: "circle" });
dust.emissionAxis = 1;
spin(dust, -0.05, 0.05, 0, true);
setCurves(dust, grow(0.5, 0.3, 1.3), fadeInOut(0.7, 0.2, 0.5));
paint(dust, GREY, WHITE, GREY);
kit.add("dust", dust);

// --- the comet ---
const head = kit.parked(kit.tex(465, 1), USER, 1.4, CHARGE + 1);
aimed(head, 1.5, CHARGE + 1);
setCurves(head, grow(0.6, 0.3, 1.2), hold(1));
paint(head, PALE, WHITE, YELLOW);
kit.add("head", head);

const tail = kit.shell(228, 0);
tail.textureIndex = kit.tex(228, 1);
aimed(tail, 1.4, 8);
Object.assign(tail, { emitterBasePos: [...USER], baseScale: 1.4, emitterLifeFrames: CHARGE, emissionIntervalFrames: 2, airResistance: 1.0 });
setCurves(tail, { start: 1.1, mid: 0.8, end: 0.4, curveIn: 0.4, curveOut: 0.6 }, fadeOut(1, 0.4));
paint(tail, YELLOW, PALE, ORANGE);
kit.add("tail", tail);

// White wind swirls opening round the path, left behind as the comet passes.
const swirls = kit.spray([333, 1], kit.tex(228, 3), USER, { radius: 0.2, speed: 0, count: 1, bursts: 4, gap: 2, life: 10, scale: 1.4 });
aimed(swirls, 0.9, 10);
spin(swirls, -0.2, -0.2, 0, true);
setCurves(swirls, grow(0.4, 0.4, 1.4), fadeOut(0.8, 0.3));
paint(swirls, WHITE, WHITE, PALE);
kit.add("swirls", swirls);

const embers = kit.spray([333, 1], kit.tex(333, 0), USER, { radius: 1.0, speed: 0.08, count: 1, bursts: CHARGE, gap: 1, life: 8, scale: 0.16 });
aimed(embers, 1.0, 8);
setCurves(embers, undefined, twinkle());
kit.prism(embers, [ORANGE, YELLOW, RED]);
kit.add("embers", embers);

// --- impact ---
const flash = kit.parked(kit.tex(228, 1), FOE, 1.6, 12);
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.25, 2.0), fadeOut(1, 0.35));
paint(flash, PALE, WHITE, YELLOW);
kit.add("flash", flash);

const streaks = kit.spray([228, 3], kit.tex(321, 6), FOE, { radius: 0.3, speed: 0.6, count: 10, life: 11, scale: 0.6, directional: true });
setCurves(streaks, grow(1.2, 0.3, 0.6), fadeOut());
kit.prism(streaks, [YELLOW, RED, ORANGE]);
kit.add("streaks", streaks);

const wisps = kit.parked(kit.tex(606, 3), FOE, 2.0, 18);
wisps.emissionCount = 2;
spin(wisps, -0.12, 0.12, 0, true);
setCurves(wisps, grow(0.5, 0.3, 1.3), fadeOut(0.6, 0.3));
paint(wisps, ORANGE, YELLOW, ORANGE);
kit.add("wisps", wisps);

const groundDust = kit.spray([333, 1], puffTex, FOE_GROUND, { radius: 1.0, speed: 0.12, count: 5, life: 22, scale: 0.9, shape: "circle" });
groundDust.emissionAxis = 1;
spin(groundDust, -0.04, 0.04, 0, true);
setCurves(groundDust, grow(0.5, 0.3, 1.4), fadeInOut(0.75, 0.15, 0.5));
paint(groundDust, GREY, WHITE, GREY);
kit.add("groundDust", groundDust);

// --- the rage startup (added last, so earlier resource numbers are unchanged) ---
const ANGER_RED = [190, 26, 48];
const angerTex = await kit.drawn("anger", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5 - 16;
  const py = y + 0.5 - 16;
  const tilt = (-25 * Math.PI) / 180;
  for (let k = 0; k < 4; k++) {
    // Each stroke is an arc round a point 15 px out; only the part bowing
    // toward the centre is drawn.
    const a = tilt + (k * Math.PI) / 2;
    const cx = 15 * Math.cos(a);
    const cy = 15 * Math.sin(a);
    const dx = px - cx;
    const dy = py - cy;
    const d = Math.hypot(dx, dy);
    if (Math.abs(d - 7.5) > 1.9) continue;
    const toCentre = Math.atan2(-cy, -cx);
    let off = Math.atan2(dy, dx) - toCentre;
    off = Math.atan2(Math.sin(off), Math.cos(off));
    if (Math.abs(off) < 1.2) return ANGER_RED;
  }
  return undefined;
});

const marks = kit.spray([333, 1], angerTex, HEAD, { radius: 0.7, speed: 0, count: 1, bursts: 3, gap: 5, life: 11, scale: 0.6, shape: "ball" });
marks.startDelayFrames = 3;
setCurves(marks, { start: 0.3, mid: 1.25, end: 0.95, curveIn: 0.25, curveOut: 0.5 }, fadeInOut(1, 0.1, 0.75));
paint(marks, WHITE);
kit.add("marks", marks);

const steam = kit.spray([333, 1], puffTex, [HEAD[0], HEAD[1] - 0.6, HEAD[2]], { radius: 0.2, speed: 0, count: 1, bursts: 4, gap: 4, life: 14, scale: 0.4, shape: "ball" });
steam.startDelayFrames = 2;
steam.axis = [0.1, 1, 0];
steam.initVelAxisAmplifier = 0.1;
spin(steam, -0.06, 0.06, 0, true);
setCurves(steam, grow(0.4, 0.3, 1.5), fadeInOut(0.6, 0.2, 0.5));
paint(steam, WHITE);
kit.add("steam", steam);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -500, 115, 0, 0, 0
PlaySound 1467, SE2, 14, 4, 300, 90, 0, 0, 0
PlaySound 1420, SE2, 14, ${RAGE}, -600, 80, 0, 0, 0
PlaySound 1420, SE2, 14, ${RAGE + 7}, -600, 80, 0, 0, 0
PlaySound 1421, SE1, 14, ${RAGE + STAMP}, -300, 125, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, ${CHARGE}, 0, 50, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 13, 3, ${TINT}
${kit.emit("marks", "ATTACKER")}
${kit.emit("steam", "ATTACKER")}
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, ${RAGE / 2}
Wait ${RAGE}
${kit.emit("dust", "ATTACKER")}
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 6
Wait ${STAMP}
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
${kit.emit("head", "ATTACKER", "DEFENDER")}
${kit.emit("tail", "ATTACKER", "DEFENDER")}
${kit.emit("swirls", "ATTACKER", "DEFENDER")}
${kit.emit("embers", "ATTACKER", "DEFENDER")}
ChangeSpriteColor ATTACKER, 13, 0, 2, ${TINT}
MoveCamera INTERPOLATION, DEFENDER, ${CHARGE}, 0, 8
Wait ${CHARGE}
AudioContainer CONTINUE
PlaySound 1475, SE1, 16, 0, -400, 125, 0, 0, 0
PlaySound 1420, SE2, 16, 0, -200, 120, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("flash", "DEFENDER")}
${kit.emit("streaks", "DEFENDER")}
${kit.emit("wisps", "DEFENDER")}
${kit.emit("groundDust", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 31, 31, 24
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 4, 0, 6
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen VERTICAL, 1x, 0, 2, 0, 6
Wait 5
ChangeSpriteColor DEFENDER, 12, 0, 1, 31, 31, 24
Wait ${HOLD - 5}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

const { built } = await kit.finish({
  script,
  donorMoveIds: [63, 153, 605, 427, 163],
  references: ["reference/Raging_Bull_IX_Normal.png", "reference/Raging_Bull_IX_Normal_2.png", "reference/keyframe-startup-tint.png", "reference/anger-mark.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, `Emit ${SPA}, 1, ATTACKER, DEFENDER`, `ChangeSpriteColor ATTACKER, 0, 13, 3, ${TINT}`, `Emit ${SPA}, ${kit.idx("marks")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 5, DEFENDER`, "ShakeScreen VERTICAL, 1x", "MoveCamera INTERPOLATION, INIT"],
});
assert.ok(built("head").initVelAxisAmplifier * (CHARGE + 1) > 14, "Comet does not reach the foe");
console.log(`  rage f${CAMERA_IN}, stamp f${CAMERA_IN + RAGE}, charge f${CAMERA_IN + RAGE + STAMP}, impact f${CAMERA_IN + RAGE + STAMP + CHARGE}`);
