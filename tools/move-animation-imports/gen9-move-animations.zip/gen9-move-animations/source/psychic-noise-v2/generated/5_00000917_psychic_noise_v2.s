MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 939
AudioContainer CONTINUE
PlaySound 1523, SE1, 14, 0, -400, 115, 0, 0, 0
PlaySound 1474, SE2, 14, 2, 600, 105, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 22, 0, 50, 0, 0
PlaySound 1816, SE1, 16, 22, -300, 115, 0, 0, 0
PlaySound 1420, SE2, 16, 22, -200, 105, 0, 0, 0
PlaySound 1420, SE1, 16, 32, -80, 109, 0, 0, 0
PlaySound 1420, SE2, 16, 42, 40, 113, 0, 0, 0
PlaySound 1420, SE1, 16, 52, 160, 117, 0, 0, 0
PlaySound 1509, SE1, 14, 62, 900, 110, 0, 0, 0
PlaySound 1434, SE2, 14, 82, -300, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 2, 20, 28, 31
Emit 939, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 939, 0, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 939, 1, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 10
MoveCamera INTERPOLATION, DEFENDER, 12, 0, 8
Wait 12
ChangeSpriteColor ATTACKER, 8, 0, 2, 20, 28, 31
Emit 939, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 939, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 939, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 939, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 939, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 939, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 939, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 939, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 939, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 939, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeBackgroundColor 4, 0, 8, 1, 10, 0, 12
ChangeSpriteColor DEFENDER, 0, 11, 1, 28, 10, 28
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 3
Wait 10
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 3
Wait 10
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 3
Wait 10
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 3
Wait 10
ChangeBackgroundColor 4, 8, 0, 2, 10, 0, 12
ChangeSpriteColor DEFENDER, 11, 0, 3, 28, 10, 28
Wait 46
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
