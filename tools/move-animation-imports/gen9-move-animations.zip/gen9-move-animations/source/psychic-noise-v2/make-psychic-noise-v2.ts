import { aimed, createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Psychic Noise (move 917), v2 - from Logan's keyframes (reference/keyframe-1..5)
// and brief: "fires circular vocals towards the target -> the target takes
// continuous damage and erupts into small stars around it -> stars turn
// black".
//   1-2. The vocals: big soft cyan-white rings, each with a thin lavender-pink
//      ring inside it, fly from the user to the foe one after another,
//      swelling as they go.
//   3. Continuous damage: a purple haze on the foe, pink sound waves rippling
//      out sideways and upward, black jagged lines, pale rings breaking on it
//      and yellow-white hit sparks popping again and again.
//   4. The foe erupts into small white stars and pale bubbles.
//   5. The stars turn black, with black specks.
// Second pass (Logan, 2026-10-01: "needs to be slower, the projectiles
// should travel slower as well"): the vocals take twice as long to cross and
// leave further apart, and the damage and star phases are longer.
// The healing block is handled by the engine.
// v1 (../psychic-noise, from the Bulbapedia stills) is kept; reinstall its
// manifest to revert.
//
// Drawn here: the sound wave (16x64 a5i3 white mask, as v1: a sine stroke
// running lengthwise; generated/texture-wave.png). Thunder's squiggles (SPA
// 257), tinted black, are the jagged lines.

const SPA = 939;
const kit = await createKit({ workDir: import.meta.dirname, slug: "psychic-noise-v2", moveId: 917, spaId: SPA, donors: [298, 560, 212, 465, 333, 407, 257] });

// --- timing (30 fps) ---
const CAMERA_IN = 10;
const VOCALS = 4;
const VOCAL_GAP = 7;
const TRAVEL = 22;
const ARRIVE = TRAVEL; // the first vocal reaches the foe this long after the Emit
const HITS = 4;
const HIT_GAP = 10;
const NOISE = HITS * HIT_GAP;
const WHITE_STARS = 20; // the stars stay white this long, then darken
const STARS = 46;

const MOUTH: Vec3 = [0.2, 0.6, -0.6];
const FOE: Vec3 = [0, 0.3, 0.8];

const CYAN: Rgb = [0.55, 0.92, 1.0];
const PALE_CYAN: Rgb = [0.85, 0.98, 1.0];
const LAVENDER: Rgb = [0.8, 0.72, 1.0];
const PINK: Rgb = [1.0, 0.55, 0.85];
const MAGENTA: Rgb = [0.9, 0.3, 0.85];
const VIOLET: Rgb = [0.5, 0.25, 0.9];
const YELLOW: Rgb = [1.0, 0.92, 0.4];
const BLACK: Rgb = [0.06, 0.04, 0.09];
const WHITE: Rgb = [1, 1, 1];

// --- the drawn wave (v1's) ---
const waveTex = await kit.drawn("wave", 16, 64, "a5i3", (x, y) => {
  const px = x + 0.5;
  const py = y + 0.5;
  const taper = Math.sin((Math.PI * py) / 64);
  const cx = 8 + 5 * Math.sin((py / 64) * Math.PI * 4) * taper;
  const d = Math.abs(px - cx);
  if (d > 1.8) return undefined;
  return [255, 255, 255, Math.round(255 * Math.min(1, taper * 1.6) * (d < 1.1 ? 1 : 0.55))];
});

// --- 1-2. the vocals ---
const SPEED = 16 / TRAVEL; // the two Pokemon stand about 16 units apart
function vocal(tex: number, scale: number, delay: number, level: number, colours: [Rgb, Rgb, Rgb]): ReturnType<typeof kit.spray> {
  const r = kit.spray([333, 1], tex, MOUTH, { radius: 0, speed: 0, count: 1, bursts: VOCALS, gap: VOCAL_GAP, life: TRAVEL + 2, scale, shape: "point" });
  r.startDelayFrames = delay;
  aimed(r, SPEED, TRAVEL + 2);
  r.variance.lifeTime = 0; // the spray shell varies particle life by up to half; these must all arrive
  r.airResistance = 1.0; // the spray shell's drag would stall them part-way
  setCurves(r, grow(0.3, 0.35, 1.5), fadeInOut(level, 0.1, 0.85));
  kit.prism(r, colours);
  return r;
}
kit.add("vocalSoft", vocal(kit.tex(560, 1), 2.0, 0, 0.8, [PALE_CYAN, CYAN, WHITE]));
kit.add("vocalThin", vocal(kit.tex(298, 2), 1.5, 1, 1, [LAVENDER, PINK, LAVENDER]));

const source = kit.spray([333, 1], kit.tex(212, 0), MOUTH, { radius: 0, speed: 0, count: 1, bursts: VOCALS, gap: VOCAL_GAP, life: 10, scale: 1.0, shape: "point" });
source.variance.lifeTime = 0;
setCurves(source, grow(0.3, 0.5, 1.4), fadeOut(0.9, 0.3));
kit.prism(source, [PALE_CYAN, WHITE, LAVENDER]);
kit.add("source", source);

// --- 3. continuous damage ---
const haze = kit.parked(kit.tex(465, 1), FOE, 2.6, NOISE + 4);
setCurves(haze, grow(0.4, 0.2, 1.15), fadeInOut(0.75, 0.12, 0.8));
paint(haze, VIOLET, MAGENTA, VIOLET);
kit.add("haze", haze);

// Pink sound waves: lying sideways out to the left and right, a few upright.
function waves(angle: number, count: number, radius: number): ReturnType<typeof kit.spray> {
  const r = kit.spray([333, 1], waveTex, FOE, { radius, speed: 0.05, count: 1, bursts: count, gap: Math.floor(NOISE / count), life: 13, scale: 1.5, shape: "circle" });
  r.aspectRatio = 0.3; // the texture is 16x64; quads ignore texture proportions
  r.initAngle = deg(angle);
  setCurves(r, grow(0.5, 0.3, 1.2), fadeInOut(1, 0.2, 0.6));
  kit.prism(r, [PINK, MAGENTA, PINK]);
  return r;
}
kit.add("wavesSide", waves(90, 6, 2.4));
kit.add("wavesUp", waves(0, 3, 1.8));

const blackShell = kit.shell(257, 0);
blackShell.textureIndex = kit.tex(257, blackShell.textureIndex);
if (blackShell.texAnim) blackShell.texAnim.textures = blackShell.texAnim.textures.map((t, i) => (i < blackShell.texAnim!.textureCount ? kit.tex(257, t) : 0));
const blackLines = kit.spray(blackShell, blackShell.textureIndex, [0, 1.2, 0.8], { radius: 2.2, speed: 0, count: 1, bursts: 6, gap: 6, life: 8, scale: 0.8, shape: "circle" });
blackLines.texAnim = structuredClone(blackShell.texAnim);
blackLines.startDelayFrames = 3;
spin(blackLines, 0, 0, 0, true);
blackLines.loopFrames = 7;
paint(blackLines, BLACK);
kit.add("blackLines", blackLines);

// The rings breaking on the foe, and a hit spark with each.
const breaking = kit.spray([333, 1], kit.tex(298, 2), FOE, { radius: 0, speed: 0, count: 1, bursts: HITS, gap: HIT_GAP, life: 10, scale: 1.3, shape: "point" });
setCurves(breaking, grow(0.4, 0.5, 1.4), fadeOut(1, 0.3));
kit.prism(breaking, [PALE_CYAN, LAVENDER, WHITE]);
kit.add("breaking", breaking);

const hitSparks = kit.spray([333, 1], kit.tex(333, 1), FOE, { radius: 0.7, speed: 0, count: 1, bursts: HITS, gap: HIT_GAP, life: 6, scale: 0.7, shape: "ball" });
spin(hitSparks, 0, 0, 0, true);
setCurves(hitSparks, grow(0.4, 0.3, 1.3), fadeOut(1, 0.4));
paint(hitSparks, YELLOW, WHITE, YELLOW);
kit.add("hitSparks", hitSparks);

// --- 4-5. the stars: white, then black ---
// One colour curve does both: white until WHITE_STARS, black a few frames later.
function turning(r: ReturnType<typeof kit.spray>, start: Rgb): void {
  paint(r, start, WHITE, BLACK, WHITE_STARS / STARS);
  r.colorAnim!.curveOut = (WHITE_STARS + 8) / STARS;
}
const stars = kit.spray([333, 1], kit.tex(407, 1), [0, 0.8, 0.8], { radius: 2.2, speed: 0.02, count: 5, bursts: 2, gap: 2, life: STARS, scale: 0.42, shape: "ball" });
stars.variance.lifeTime = 0; // they must all last to turn black
stars.startDelayFrames = NOISE;
spin(stars, -0.02, 0.02, 0, true);
setCurves(stars, { start: 0.2, mid: 1, end: 0.9, curveIn: 0.12, curveOut: 0.9 }, fadeInOut(1, 0.08, 0.85));
turning(stars, WHITE);
kit.add("stars", stars);

const specks = kit.spray([333, 1], kit.tex(333, 0), [0, 0.8, 0.8], { radius: 2.4, speed: 0.03, count: 6, life: STARS, scale: 0.14, shape: "ball" });
specks.variance.lifeTime = 0;
specks.startDelayFrames = NOISE + 1;
setCurves(specks, hold(1), fadeInOut(1, 0.1, 0.85));
turning(specks, PALE_CYAN);
kit.add("specks", specks);

// Pale bubbles round the newborn stars, gone before they darken.
const bubbles = kit.spray([333, 1], kit.tex(298, 2), [0, 1.0, 0.8], { radius: 2.0, speed: 0.02, count: 5, life: WHITE_STARS, scale: 0.4, shape: "ball" });
bubbles.startDelayFrames = NOISE;
bubbles.axis = [0, 1, 0];
bubbles.initVelAxisAmplifier = 0.04;
setCurves(bubbles, grow(0.5, 0.3, 1.1), fadeInOut(0.7, 0.2, 0.6));
kit.prism(bubbles, [PALE_CYAN, WHITE, [0.75, 1.0, 0.85]]);
kit.add("bubbles", bubbles);

const burst = kit.parked(kit.tex(228, 1), FOE, 1.6, 9);
burst.startDelayFrames = NOISE;
spin(burst, 0.06);
setCurves(burst, grow(0.4, 0.3, 1.8), fadeOut(1, 0.35));
paint(burst, WHITE, WHITE, PALE_CYAN);
kit.add("burst", burst);

// --- script ---
const emits = (names: string[], who: "ATTACKER" | "DEFENDER", toward = "NONE") => names.map((n) => kit.emit(n, who, toward)).join("\n");
const HEAD_START = 10; // the camera leaves this long after the first vocal
const hitSounds = Array.from({ length: HITS }, (_, i) => `PlaySound 1420, SE${i % 2 ? 1 : 2}, 16, ${ARRIVE + i * HIT_GAP}, ${-200 + i * 120}, ${105 + i * 4}, 0, 0, 0`).join("\n");
const hits = Array.from({ length: HITS }, () => `ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1\nShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 3\nWait ${HIT_GAP}`).join("\n");
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1523, SE1, 14, 0, -400, 115, 0, 0, 0
PlaySound 1474, SE2, 14, 2, 600, 105, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, ${ARRIVE}, 0, 50, 0, 0
PlaySound 1816, SE1, 16, ${ARRIVE}, -300, 115, 0, 0, 0
${hitSounds}
PlaySound 1509, SE1, 14, ${ARRIVE + NOISE}, 900, 110, 0, 0, 0
PlaySound 1434, SE2, 14, ${ARRIVE + NOISE + WHITE_STARS}, -300, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 2, 20, 28, 31
${kit.emit("source", "ATTACKER")}
${emits(["vocalSoft", "vocalThin"], "ATTACKER", "DEFENDER")}
Wait ${HEAD_START}
MoveCamera INTERPOLATION, DEFENDER, ${ARRIVE - HEAD_START}, 0, 8
Wait ${ARRIVE - HEAD_START}
ChangeSpriteColor ATTACKER, 8, 0, 2, 20, 28, 31
${emits(["haze", "wavesSide", "wavesUp", "blackLines", "breaking", "hitSparks", "burst", "bubbles", "stars", "specks"], "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeBackgroundColor 4, 0, 8, 1, 10, 0, 12
ChangeSpriteColor DEFENDER, 0, 11, 1, 28, 10, 28
${hits}
ChangeBackgroundColor 4, 8, 0, 2, 10, 0, 12
ChangeSpriteColor DEFENDER, 11, 0, 3, 28, 10, 28
Wait ${STARS}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [129, 381, 47, 605, 153, 87],
  references: ["reference/keyframe-1.png", "reference/keyframe-2.png", "reference/keyframe-3.png", "reference/keyframe-4.png", "reference/keyframe-5.png", "reference/Psychic_Noise_IX.png", "reference/Psychic_Noise_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("wavesSide")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("stars")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
const at = CAMERA_IN + ARRIVE;
console.log(`  vocals f${CAMERA_IN}, noise f${at}-${at + NOISE} (${HITS} hits), stars f${at + NOISE}, black from f${at + NOISE + WHITE_STARS}`);
