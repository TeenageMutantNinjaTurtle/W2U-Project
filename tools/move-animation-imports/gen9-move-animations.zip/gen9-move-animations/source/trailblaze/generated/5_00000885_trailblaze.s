MoveCamera INTERPOLATION, ATTACKER, 10, 0, 8
LetCMDsFinish CAMERA
LoadSPA 879
AudioContainer CONTINUE
PlaySound 1421, SE2, 14, 0, 0, 115, 0, 0, 0
PlaySound 1718, SE1, 14, 8, 500, 110, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 10, 0, 50, 0, 0
AudioContainer SUSPEND
Emit 879, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 879, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 4
Wait 8
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
Emit 879, 2, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
AudioContainer CONTINUE
PlaySound 1415, SE1, 16, 0, 0, 115, 0, 0, 0
PlaySound 1420, SE2, 16, 0, 0, 100, 0, 0, 0
AudioContainer SUSPEND
Emit 879, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 879, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 879, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 879, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 3, 0, 4
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 8
Wait 18
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
