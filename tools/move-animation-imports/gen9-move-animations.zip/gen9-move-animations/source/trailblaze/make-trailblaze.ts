import { aimed, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Trailblaze (move 885) - from Bulbapedia's stills (reference/).
//   1. The user dashes off in a spray of green leaves and grey dust clouds.
//   2. A bright green leafy burst on the foe: green spikes and flying leaves.
// Leaves are Razor Leaf's (SPA 242, full colour).

const SPA = 879;
const kit = await createKit({ workDir: import.meta.dirname, slug: "trailblaze", moveId: 885, spaId: SPA, donors: [242, 321, 579, 228] });

const CAMERA_IN = 10;
const KICK = 8;
const DASH = 10;
const HOLD = 18;

const USER: Vec3 = [0, 0, -0.2];
const FEET: Vec3 = [0, -1.8, 0];
const FOE: Vec3 = [0, 0.3, 0.8];

const GREEN: Rgb = [0.4, 1.0, 0.4];
const BRIGHT_GREEN: Rgb = [0.65, 1.0, 0.45];
const YELLOW_GREEN: Rgb = [0.9, 1.0, 0.4];
const WHITE: Rgb = [1, 1, 1];
const GREY: Rgb = [0.75, 0.72, 0.7];

const leafTex = kit.tex(242, 1);

const dust = kit.spray([333, 1], kit.tex(321, 5), FEET, { radius: 0.7, speed: 0.1, count: 2, bursts: 4, gap: 3, life: 16, scale: 0.6, shape: "circle" });
dust.emissionAxis = 1;
spin(dust, -0.05, 0.05, 0, true);
setCurves(dust, grow(0.5, 0.3, 1.3), fadeInOut(0.75, 0.2, 0.5));
paint(dust, GREY, WHITE, GREY);
kit.add("dust", dust);

const kickedLeaves = kit.spray([333, 1], leafTex, USER, { radius: 0.8, speed: 0.22, count: 2, bursts: 4, gap: 2, life: 16, scale: 0.3 });
kickedLeaves.behaviors = [{ type: "gravity", magnitude: [0, -0.01, 0] }];
spin(kickedLeaves, -0.3, 0.3, 0, true);
setCurves(kickedLeaves, hold(1), fadeOut(1, 0.6));
paint(kickedLeaves, WHITE);
kit.add("kickedLeaves", kickedLeaves);

const streamLeaves = kit.spray([333, 1], leafTex, USER, { radius: 0.6, speed: 0.05, count: 1, bursts: DASH, gap: 1, life: DASH, scale: 0.3 });
aimed(streamLeaves, 1.5, DASH);
spin(streamLeaves, -0.35, 0.35, 0, true);
setCurves(streamLeaves, hold(1), hold(1));
paint(streamLeaves, WHITE);
kit.add("streamLeaves", streamLeaves);

const burst = kit.parked(kit.tex(579, 2), FOE, 1.2, 12);
spin(burst, 0.1);
setCurves(burst, grow(0.4, 0.25, 1.5), fadeOut(1, 0.35));
paint(burst, BRIGHT_GREEN, WHITE, GREEN);
kit.add("burst", burst);

const spikes = kit.spray([228, 3], kit.tex(321, 6), FOE, { radius: 0.3, speed: 0.5, count: 9, life: 10, scale: 0.55, directional: true });
setCurves(spikes, grow(1.2, 0.3, 0.6), fadeOut());
kit.prism(spikes, [GREEN, BRIGHT_GREEN, YELLOW_GREEN]);
kit.add("spikes", spikes);

const hitLeaves = kit.spray([333, 1], leafTex, FOE, { radius: 0.4, speed: 0.3, count: 7, life: 18, scale: 0.3 });
hitLeaves.behaviors = [{ type: "gravity", magnitude: [0, -0.008, 0] }];
spin(hitLeaves, -0.3, 0.3, 0, true);
setCurves(hitLeaves, hold(1), fadeOut(1, 0.6));
paint(hitLeaves, WHITE);
kit.add("hitLeaves", hitLeaves);

const dots = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.5, speed: 0.35, count: 6, life: 12, scale: 0.12 });
setCurves(dots, undefined, twinkle());
kit.prism(dots, [YELLOW_GREEN, WHITE, GREEN]);
kit.add("dots", dots);

const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1421, SE2, 14, 0, 0, 115, 0, 0, 0
PlaySound 1718, SE1, 14, ${KICK}, 500, 110, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, ${DASH}, 0, 50, 0, 0
AudioContainer SUSPEND
${kit.emit("dust", "ATTACKER")}
${kit.emit("kickedLeaves", "ATTACKER")}
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 4
Wait ${KICK}
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
${kit.emit("streamLeaves", "ATTACKER", "DEFENDER")}
MoveCamera INTERPOLATION, DEFENDER, ${DASH}, 0, 8
Wait ${DASH}
AudioContainer CONTINUE
PlaySound 1415, SE1, 16, 0, 0, 115, 0, 0, 0
PlaySound 1420, SE2, 16, 0, 0, 100, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("burst", "DEFENDER")}
${kit.emit("spikes", "DEFENDER")}
${kit.emit("hitLeaves", "DEFENDER")}
${kit.emit("dots", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 3, 0, 4
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 8
Wait ${HOLD}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [75, 153, 400, 63],
  references: ["reference/Trailblaze_IX.png", "reference/Trailblaze_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, `Emit ${SPA}, 2, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 3, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  dash f${CAMERA_IN + KICK}, hit f${CAMERA_IN + KICK + DASH}`);
