import { buildTorque } from "../tools/torque-v2";

// Wicked Torque (move 897), v2 - from Bulbapedia's stills (reference/).
//   1. Jagged red-and-black shadow flames rise round the Starmobile.
//   2. A crown of crimson and black spikes bursts up round a yellow spark on
//      the foe over a red ground swirl.
// Shared structure in ../tools/torque-v2.ts. v1 is in ../wicked-torque.
const CRIMSON: [number, number, number] = [1.0, 0.15, 0.3];
const RED: [number, number, number] = [0.85, 0.05, 0.12];
const DARK: [number, number, number] = [0.14, 0.02, 0.06];
const PINK: [number, number, number] = [1.0, 0.55, 0.65];
const YELLOW: [number, number, number] = [1.0, 0.85, 0.3];
const WHITE: [number, number, number] = [1, 1, 1];

await buildTorque({
  workDir: import.meta.dirname, slug: "wicked-torque-v2", moveId: 897, spaId: 890,
  references: ["reference/Wicked_Torque_IX.png", "reference/Wicked_Torque_IX_2.png"],
  aura: [CRIMSON, DARK, RED], rising: "jagged",
  vortex: [CRIMSON, RED, DARK],
  fan: [CRIMSON, DARK, PINK],
  core: [YELLOW, WHITE, [1.0, 0.55, 0.15]],
  extra: "shadows", extraColours: [DARK, CRIMSON, DARK],
  userTint: [20, 2, 6], foeTint: [26, 4, 8], dim: [6, 0, 2],
  revSounds: ["PlaySound 1434, SE2, 14, 2, -900, 120, 0, 0, 0"],
  hitSounds: ["PlaySound 1514, SE2, 16, 0, -200, 120, 0, 0, 0", "PlaySound 1435, SE1, 16, 4, 0, 110, 0, 0, 0"],
});
