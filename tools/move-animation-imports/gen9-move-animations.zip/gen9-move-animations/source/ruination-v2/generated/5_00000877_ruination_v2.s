MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 929
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -1500, 127, 0, 0, 0
PlaySound 1435, SE2, 14, 8, -600, 100, 0, 0, 0
PlaySound 1434, SE1, 14, 16, -1100, 120, 0, 0, 0
PlaySound 1435, SE2, 14, 26, -300, 110, 0, 0, 0
PlaySound 1446, SE2, 16, 48, -400, 110, 0, 0, 0
PlaySound 1475, SE1, 16, 48, -900, 112, 0, 0, 0
PlaySound 1475, SE2, 16, 60, -840, 112, 0, 0, 0
PlaySound 1475, SE1, 16, 72, -780, 112, 0, 0, 0
PlaySound 1475, SE2, 16, 84, -720, 112, 0, 0, 0
PlaySound 1475, SE1, 16, 96, -660, 127, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 2, 8, 0, 2
Emit 929, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 929, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 929, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 929, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 929, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 929, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 929, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 16
ChangeBackgroundColor 4, 8, 14, 2, 8, 0, 2
ChangeSpriteColor ATTACKER, 0, 9, 3, 16, 0, 5
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 9
Wait 22
ChangeSpriteColor ATTACKER, 9, 0, 2, 16, 0, 5
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
Emit 929, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 929, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 929, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 929, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 929, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 929, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 929, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 13, 2, 14, 0, 6
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 3
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 3
Wait 12
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 3
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 3
Wait 12
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 3
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 3
Wait 12
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 0, 3
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 3
Wait 12
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 0, 3
ShakeScreen VERTICAL, 1x, 0, 2, 0, 3
Wait 12
ChangeSpriteColor DEFENDER, 13, 0, 3, 14, 0, 6
Wait 10
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 14, 0, 2, 8, 0, 2
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
