import { assert, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Ruination (move 877), v2 - from Logan's keyframes (shown in chat, not
// saved) and brief: "startup -> builds more darkness around user -> slams
// darkness on target for a few seconds, dealing damage".
//   1. Startup: jagged black shapes rimmed in glowing red, each with a red
//      slit eye, rise out of the ground round the user on a grey swirl;
//      purple orbs with dark hearts drift.
//   2. Build: more and bigger shapes crowd in, the ground goes dark red, red
//      cracks flicker.
//   3. Ruin: darkness slams down on the foe again and again for about two
//      seconds - dark streaks falling from above, black-red shapes bursting
//      up at its feet, red spikes, thin blue lines, pink motes - the foe
//      shuddering on every blow.
// v1 (../ruination, from the Bulbapedia stills) is kept; reinstall its
// manifest to revert.
//
// Drawn here (32x32 a3i5, see generated/): the darkness (a jagged black
// blob with a glowing red rim and a red slit eye) and the orb (a purple glow
// with a dark heart). Electroweb's squiggles (SPA 697) are the red cracks.

const SPA = 929;
const kit = await createKit({ workDir: import.meta.dirname, slug: "ruination-v2", moveId: 877, spaId: SPA, donors: [298, 228, 321, 411, 697, 465, 333] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const STARTUP = 16;
const BUILD = 22;
const PAN = 10;
const BLOWS = 5;
const BLOW_GAP = 12;
const RUIN = BLOWS * BLOW_GAP; // 60 frames: two seconds
const AFTER = 10;

const GROUND: Vec3 = [0, -1.7, 0.1];
const FOE: Vec3 = [0, 0.3, 0.8];
const FOE_GROUND: Vec3 = [0, -1.5, 0.9];

const CRIMSON: Rgb = [0.6, 0.04, 0.12];
const DARK_CRIMSON: Rgb = [0.3, 0.02, 0.08];
const RED: Rgb = [1.0, 0.12, 0.2];
const MAGENTA: Rgb = [1.0, 0.25, 0.65];
const PINK: Rgb = [1.0, 0.5, 0.75];
const BLUE: Rgb = [0.3, 0.45, 1.0];
const BLACK: Rgb = [0.06, 0.02, 0.04];
const GREY: Rgb = [0.6, 0.58, 0.62];
const WHITE: Rgb = [1, 1, 1];

// --- drawn textures ---
const edge = (a: number) => 9.5 + 2.2 * Math.sin(3 * a + 1) + 1.8 * Math.sin(7 * a + 0.4) + 3.2 * Math.pow(Math.abs(Math.sin(2.5 * a + 0.8)), 8);
const darkTex = await kit.drawn("darkness", 32, 32, "a3i5", (x, y) => {
  const dx = x + 0.5 - 16;
  const dy = y + 0.5 - 16;
  const r = Math.hypot(dx, dy);
  const limit = edge(Math.atan2(dy, dx));
  if (r > limit) return undefined;
  // The slit eye.
  const eye = (dx / 2.3) ** 2 + (dy / 4.8) ** 2;
  if (eye < 0.22) return [255, 214, 200];
  if (eye < 1) return [255, 48, 40];
  if (r > limit - 1.3) return [255, 44, 44]; // glowing rim
  if (r > limit - 2.3) return [140, 12, 26];
  return [14, 6, 10];
});

const orbTex = await kit.drawn("orb", 32, 32, "a3i5", (x, y) => {
  const d = Math.hypot(x + 0.5 - 16, y + 0.5 - 16);
  if (d < 3.2) return [34, 8, 46];
  if (d < 5.6) return [236, 110, 255];
  if (d < 8) return [176, 64, 232, 210];
  if (d < 11) return [144, 44, 212, 120];
  if (d < 13.5) return [130, 40, 200, 55];
  return undefined;
});

function cracks(pos: Vec3, radius: number, bursts: number, gap: number, delay: number): ReturnType<typeof kit.spray> {
  const r = kit.spray([333, 1], kit.tex(697, 0), pos, { radius, speed: 0, count: 1, bursts, gap, life: 6, scale: 0.7, shape: "circle" });
  r.startDelayFrames = delay;
  r.emissionAxis = 1;
  assert.ok(kit.spa(697).resources[0]?.texAnim, "Electroweb's squiggle lost its frames");
  r.texAnim = structuredClone(kit.spa(697).resources[0]!.texAnim);
  r.texAnim!.textures = r.texAnim!.textures.map((t, i) => (i < r.texAnim!.textureCount ? kit.tex(697, t) : 0));
  spin(r, 0, 0, 0, true);
  setCurves(r, hold(1), fadeOut(1, 0.6));
  r.loopFrames = 7; // Electroweb's squiggle cycles its four frames over 7 (set after setCurves)
  kit.prism(r, [RED, CRIMSON, MAGENTA]);
  return r;
}

// --- 1. startup ---
const GATHER = STARTUP + BUILD;
const swirl = kit.parked(kit.tex(228, 3), GROUND, 2.2, GATHER + 2);
swirl.aspectRatio = 3.0;
spin(swirl, 0.12);
setCurves(swirl, grow(0.4, 0.3, 1.3), fadeInOut(0.7, 0.15, 0.85));
paint(swirl, GREY, WHITE, CRIMSON);
kit.add("swirl", swirl);

// Darkness rising out of the ground on a ring round the user.
function shapes(count: number, gap: number, delay: number, radius: number, scale: number, life: number): ReturnType<typeof kit.spray> {
  const r = kit.spray([333, 1], darkTex, [GROUND[0], GROUND[1] + 0.5, GROUND[2]], { radius, speed: 0, count: 1, bursts: count, gap, life, scale, shape: "circle" });
  r.startDelayFrames = delay;
  r.emissionAxis = 1;
  r.axis = [0, 1, 0];
  r.initVelAxisAmplifier = 0.03;
  r.airResistance = 0.9;
  spin(r, -0.02, 0.02, 0, true);
  setCurves(r, { start: 0.15, mid: 1, end: 1.1, curveIn: 0.3, curveOut: 0.9 }, { start: 0, mid: 1, end: 0, curveIn: 0.15, curveOut: 0.85 });
  paint(r, WHITE);
  return r;
}
kit.add("firstShapes", shapes(3, 4, 0, 1.8, 0.75, GATHER));
kit.add("smallShapes", shapes(4, 5, 4, 2.6, 0.32, GATHER - 6));

const orbs = kit.spray([333, 1], orbTex, [0, -0.6, 0.1], { radius: 2.2, speed: 0, count: 1, bursts: GATHER / 5, gap: 5, life: 16, scale: 0.4, shape: "ball" });
orbs.axis = [0, 1, 0];
orbs.initVelAxisAmplifier = 0.04;
setCurves(orbs, grow(0.5, 0.3, 1), fadeInOut(1, 0.2, 0.7));
paint(orbs, WHITE);
kit.add("orbs", orbs);

// --- 2. the build ---
const pool = kit.parked(kit.tex(298, 0), GROUND, 2.8, BUILD + 4);
pool.startDelayFrames = STARTUP - 2;
pool.aspectRatio = 3.0;
setCurves(pool, grow(0.3, 0.4, 1.1), fadeInOut(0.8, 0.25, 0.85));
paint(pool, CRIMSON, DARK_CRIMSON, CRIMSON);
kit.add("pool", pool);

kit.add("bigShapes", shapes(4, 4, STARTUP, 2.3, 1.15, BUILD));
kit.add("userCracks", cracks([GROUND[0], GROUND[1] + 0.3, GROUND[2]], 2.0, 5, 4, STARTUP));

// --- 3. ruin: the darkness slams down on the foe ---
const haze = kit.parked(kit.tex(465, 1), [0, 0.6, 0.7], 3.6, RUIN);
haze.aspectRatio = 0.75;
setCurves(haze, grow(0.5, 0.15, 1.05), fadeInOut(0.7, 0.1, 0.85));
paint(haze, DARK_CRIMSON, BLACK, DARK_CRIMSON);
kit.add("haze", haze);

// Dark streaks falling from above.
const fall = kit.spray([228, 3], kit.tex(333, 2), [0, 5.2, 0.8], { radius: 1.3, speed: 0, count: 2, bursts: RUIN / 3, gap: 3, life: 6, scale: 2.6, shape: "circle", directional: true });
fall.emissionAxis = 1;
fall.axis = [0, -1, 0];
fall.initVelAxisAmplifier = 0.95;
setCurves(fall, undefined, fadeInOut(0.95, 0.15, 0.7));
kit.prism(fall, [BLACK, DARK_CRIMSON, BLACK]);
kit.add("fall", fall);

// Each blow: darkness bursting up at the foe's feet with red spikes.
const burst = kit.spray([333, 1], darkTex, [FOE_GROUND[0], FOE_GROUND[1] + 0.5, FOE_GROUND[2]], { radius: 1.3, speed: 0.06, count: 3, bursts: BLOWS, gap: BLOW_GAP, life: 11, scale: 0.6, shape: "circle" });
burst.emissionAxis = 1;
burst.axis = [0, 1, 0];
burst.initVelAxisAmplifier = 0.1;
spin(burst, -0.08, 0.08, 0, true);
setCurves(burst, { start: 0.3, mid: 1.1, end: 0.8, curveIn: 0.25, curveOut: 0.6 }, fadeOut(1, 0.55));
paint(burst, WHITE);
kit.add("burst", burst);

const spikes = kit.spray([228, 3], kit.tex(321, 6), FOE_GROUND, { radius: 1.0, speed: 0.1, count: 3, bursts: BLOWS, gap: BLOW_GAP, life: 8, scale: 0.6, shape: "circle", directional: true });
spikes.emissionAxis = 1;
spikes.axis = [0, 1, 0];
spikes.initVelAxisAmplifier = 0.3;
setCurves(spikes, grow(0.6, 0.3, 1.1), fadeOut(1, 0.45));
kit.prism(spikes, [RED, CRIMSON, MAGENTA]);
kit.add("spikes", spikes);

const blueLines = kit.spray([228, 3], kit.tex(411, 0), [0, 4.0, 0.8], { radius: 1.8, speed: 0, count: 1, bursts: RUIN / 4, gap: 4, life: 6, scale: 1.8, shape: "circle", directional: true });
blueLines.emissionAxis = 1;
blueLines.axis = [0, -1, 0];
blueLines.initVelAxisAmplifier = 0.8;
setCurves(blueLines, undefined, fadeInOut(1, 0.2, 0.6));
paint(blueLines, BLUE, BLUE, MAGENTA);
kit.add("blueLines", blueLines);

const motes = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 1.7, speed: 0, count: 1, bursts: RUIN / 3, gap: 3, life: 14, scale: 0.13, shape: "ball" });
motes.axis = [0, 1, 0];
motes.initVelAxisAmplifier = 0.06;
setCurves(motes, undefined, twinkle());
kit.prism(motes, [PINK, MAGENTA, RED]);
kit.add("motes", motes);

kit.add("foeCracks", cracks([FOE_GROUND[0], FOE_GROUND[1] + 0.4, FOE_GROUND[2]], 1.4, RUIN / 6, 6, 2));

// --- script ---
const emits = (names: string[], who: "ATTACKER" | "DEFENDER") => names.map((n) => kit.emit(n, who)).join("\n");
const ruinAt = GATHER + PAN;
const blowSounds = Array.from({ length: BLOWS }, (_, i) => `PlaySound 1475, SE${i % 2 ? 2 : 1}, 16, ${ruinAt + i * BLOW_GAP}, ${-900 + i * 60}, ${i === BLOWS - 1 ? 127 : 112}, 0, 0, 0`).join("\n");
const blows = Array.from({ length: BLOWS }, (_, i) => `ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 2, 1, 1
ShakeSprite DEFENDER, 2, ${i === BLOWS - 1 ? 1638 : 1229}, 0, 2, 0, 3
ShakeScreen VERTICAL, ${i === BLOWS - 1 ? "1x" : "0.5x"}, 0, 2, 0, 3
Wait ${BLOW_GAP}`).join("\n");
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -1500, 127, 0, 0, 0
PlaySound 1435, SE2, 14, 8, -600, 100, 0, 0, 0
PlaySound 1434, SE1, 14, ${STARTUP}, -1100, 120, 0, 0, 0
PlaySound 1435, SE2, 14, ${STARTUP + 10}, -300, 110, 0, 0, 0
PlaySound 1446, SE2, 16, ${ruinAt}, -400, 110, 0, 0, 0
${blowSounds}
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 2, 8, 0, 2
${emits(["swirl", "firstShapes", "smallShapes", "orbs", "pool", "bigShapes", "userCracks"], "ATTACKER")}
Wait ${STARTUP}
ChangeBackgroundColor 4, 8, 14, 2, 8, 0, 2
ChangeSpriteColor ATTACKER, 0, 9, 3, 16, 0, 5
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, ${BUILD / 2 - 2}
Wait ${BUILD}
ChangeSpriteColor ATTACKER, 9, 0, 2, 16, 0, 5
MoveCamera INTERPOLATION, DEFENDER, ${PAN}, 0, 8
Wait ${PAN}
${emits(["haze", "fall", "burst", "spikes", "blueLines", "motes", "foeCracks"], "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 13, 2, 14, 0, 6
${blows}
ChangeSpriteColor DEFENDER, 13, 0, 3, 14, 0, 6
Wait ${AFTER}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 14, 0, 2, 8, 0, 2
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [527, 247, 399, 63, 153, 240],
  references: ["reference/Ruination_IX.png", "reference/Ruination_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("firstShapes")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("bigShapes")}, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("fall")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("burst")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
const at = CAMERA_IN + ruinAt;
console.log(`  startup f${CAMERA_IN}, build f${CAMERA_IN + STARTUP}, ruin f${at}-${at + RUIN} (${BLOWS} blows, ${BLOW_GAP}f apart)`);
