MoveCamera INTERPOLATION, ATTACKER, 8, 0, 8
LetCMDsFinish CAMERA
LoadSPA 940
AudioContainer CONTINUE
PlaySound 1509, SE1, 14, 0, 500, 105, 0, 0, 0
PlaySound 1421, SE2, 14, 9, 400, 115, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 6, 0, 50, 0, 0
PlaySound 1424, SE1, 16, 17, 300, 127, 0, 0, 0
PlaySound 1420, SE2, 16, 18, 400, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 1, 31, 26, 10
Emit 940, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 940, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 940, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 9
ChangeSpriteColor ATTACKER, 8, 0, 1, 31, 26, 10
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 2px, 49152, 0, 4096, 0
Emit 940, 3, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 940, 4, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 940, 5, ATTACKER, DEFENDER, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveCamera INTERPOLATION, DEFENDER, 6, 0, 8
Wait 6
Emit 940, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 940, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 940, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 940, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 940, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 940, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 2
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 31, 28, 12
ShakeScreen HORIZON, 0.5x, 0, 1, 0, 3
Wait 3
ChangeSpriteColor DEFENDER, 12, 0, 1, 31, 28, 12
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 819, 3, 1, 1
ShakeSprite DEFENDER, 2, 2048, 0, 2, 1, 6
Wait 16
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 10, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
