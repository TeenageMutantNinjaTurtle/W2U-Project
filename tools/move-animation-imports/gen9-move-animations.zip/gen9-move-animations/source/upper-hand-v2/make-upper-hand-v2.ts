import { aimed, createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Upper Hand (move 918), v2 - from Logan's keyframes (shown in chat, not
// saved) and brief: "quick, but has a hand sent flying towards the target
// that slaps any attempt of them using a priority move".
//   1. A big glossy golden hand, palm open, pops up in front of the user.
//   2. It flies at the foe, leaving a row of fading after-images behind it.
//   3. It slaps the foe: the hand swings across it, a white arc and a flash,
//      yellow streaks, and a pale ghost of the hand hangs for a moment.
// A priority move, so it stays quick: about 1.4 seconds.
// v1 (../upper-hand, an uppercut swoosh) is kept; reinstall its manifest to
// revert.
//
// The hand is drawn here (64x64 a3i5: an open palm with four fingers and a
// thumb, golden with a pale highlight, a deeper lower edge and an orange
// outline; generated/texture-hand.png).

const SPA = 940;
const kit = await createKit({ workDir: import.meta.dirname, slug: "upper-hand-v2", moveId: 918, spaId: SPA, donors: [606, 228, 333, 465, 411, 407] });

// --- timing (30 fps) ---
const CAMERA_IN = 8;
const POP = 9;
const FLY = 6;
const SWING = 5;
const HOLD = 16;

const FRONT: Vec3 = [0.9, 0.6, -1.2]; // in front of the user, toward the foe
const FOE: Vec3 = [0, 0.3, 0.8];
const HAND_SCALE = 1.6;
const SPEED = 15 / FLY; // FRONT is about 15 units from the foe

const GOLD: Rgb = [1.0, 0.8, 0.25];
const YELLOW: Rgb = [1.0, 0.92, 0.4];
const PALE: Rgb = [1.0, 0.97, 0.8];
const ORANGE: Rgb = [1.0, 0.6, 0.2];
const WHITE: Rgb = [1, 1, 1];

// --- the drawn hand ---
type P = [number, number];
const capsule = (px: number, py: number, a: P, b: P, r: number) => {
  const dx = b[0] - a[0];
  const dy = b[1] - a[1];
  const t = Math.max(0, Math.min(1, ((px - a[0]) * dx + (py - a[1]) * dy) / (dx * dx + dy * dy)));
  return Math.hypot(px - (a[0] + dx * t), py - (a[1] + dy * t)) - r;
};
const fingers: Array<{ a: P; b: P; r: number }> = [
  { a: [21, 36], b: [17, 15], r: 4.1 },
  { a: [29, 34], b: [28, 8], r: 4.3 },
  { a: [37, 34], b: [39, 9], r: 4.2 },
  { a: [44, 37], b: [49, 17], r: 3.9 },
  { a: [20, 46], b: [8, 34], r: 4.4 }, // thumb
];
const handDistance = (px: number, py: number) => {
  // Palm: an ellipse (approximate distance), unioned with the finger capsules.
  const palm = (Math.hypot((px - 32) / 16, (py - 46) / 14) - 1) * 14;
  return Math.min(palm, ...fingers.map((f) => capsule(px, py, f.a, f.b, f.r)));
};
const handTex = await kit.drawn("hand", 64, 64, "a3i5", (x, y) => {
  const px = x + 0.5;
  const py = y + 0.5;
  const d = handDistance(px, py);
  if (d > 0) return undefined;
  if (d > -1.4) return [232, 128, 24]; // outline
  // Creases between the fingers stay visible where two capsules overlap.
  const inside = fingers.filter((f) => capsule(px, py, f.a, f.b, f.r) < 0).length;
  if (inside >= 2 && py < 36) return [240, 150, 36];
  const light = (-(px - 32) - (py - 34) * 1.2) / 40; // lit from the upper left
  if (light > 0.35) return [255, 240, 150];
  if (light > -0.1) return [255, 212, 84];
  return [250, 176, 52];
});

// --- 1. the hand pops up ---
const glow = kit.parked(kit.tex(465, 1), FRONT, 2.4, POP + 2);
setCurves(glow, grow(0.3, 0.4, 1.1), fadeInOut(0.7, 0.2, 0.8));
paint(glow, GOLD, PALE, ORANGE);
kit.add("glow", glow);

const popHand = kit.parked(handTex, FRONT, HAND_SCALE, POP + 1);
setCurves(popHand, { start: 0.2, mid: 1.15, end: 1.0, curveIn: 0.35, curveOut: 0.6 }, { start: 0, mid: 1, end: 1, curveIn: 0.15, curveOut: 1 });
paint(popHand, WHITE);
kit.add("popHand", popHand);

const glint = kit.parked(kit.tex(407, 1), [FRONT[0] - 0.6, FRONT[1] + 1.0, FRONT[2] - 0.1], 0.5, 8);
glint.startDelayFrames = 3;
spin(glint, 0.08);
setCurves(glint, twinkle(1.2), twinkle(1));
paint(glint, WHITE, WHITE, PALE);
kit.add("glint", glint);

// --- 2. it flies ---
// Life FLY + 1: a particle is last seen one frame before its life runs out,
// so each hand vanishes as it reaches the foe.
const flyHand = kit.parked(handTex, FRONT, HAND_SCALE, FLY + 1);
aimed(flyHand, SPEED, FLY + 1);
setCurves(flyHand, hold(1), hold(1));
paint(flyHand, WHITE);
kit.add("flyHand", flyHand);

// After-images: three more hands a frame apart behind it, fainter.
const afterImages = kit.parked(handTex, FRONT, HAND_SCALE, FLY + 1);
afterImages.startDelayFrames = 1;
aimed(afterImages, SPEED, FLY + 1);
Object.assign(afterImages, { emitterLifeFrames: 3, emissionIntervalFrames: 1 });
setCurves(afterImages, hold(1), fadeOut(0.45, 0.4));
paint(afterImages, WHITE);
kit.add("afterImages", afterImages);

const speedLines = kit.spray([228, 3], kit.tex(411, 0), FRONT, { radius: 1.2, speed: 0, count: 2, bursts: FLY - 1, gap: 1, life: 6, scale: 2.4, shape: "ball", directional: true });
aimed(speedLines, SPEED * 1.1, 6);
speedLines.airResistance = 1.0; // the spray shell's drag would stall them part-way
setCurves(speedLines, undefined, fadeInOut(0.8, 0.2, 0.7));
paint(speedLines, WHITE, WHITE, PALE);
kit.add("speedLines", speedLines);

// --- 3. the slap ---
// The hand swings across the foe from its upper right, turning as it goes.
const slapHand = kit.parked(handTex, [FOE[0] + 1.3, FOE[1] + 0.5, FOE[2] + 0.2], HAND_SCALE, SWING + 1);
slapHand.axis = [-1, -0.15, 0];
slapHand.initVelAxisAmplifier = 2.4 / SWING;
spin(slapHand, deg(70) / SWING, deg(70) / SWING, deg(-35));
setCurves(slapHand, hold(1), fadeOut(1, 0.75));
paint(slapHand, WHITE);
kit.add("slapHand", slapHand);

const ghost = kit.parked(handTex, [FOE[0] - 0.4, FOE[1] + 0.4, FOE[2] + 0.15], HAND_SCALE * 1.1, 12);
ghost.startDelayFrames = SWING - 2;
ghost.initAngle = deg(20);
setCurves(ghost, grow(0.9, 0.3, 1.2), fadeOut(0.4, 0.1));
paint(ghost, WHITE);
kit.add("ghost", ghost);

const slapArc = kit.parked(kit.tex(606, 3), [FOE[0], FOE[1] + 0.3, FOE[2] + 0.25], 2.2, 8);
slapArc.startDelayFrames = 1;
slapArc.flipTextureS = true;
slapArc.aspectRatio = 0.6;
setCurves(slapArc, grow(0.5, 0.3, 1.2), fadeOut(1, 0.4));
paint(slapArc, WHITE, WHITE, PALE);
kit.add("slapArc", slapArc);

const flash = kit.parked(kit.tex(228, 1), FOE, 1.6, 10);
flash.startDelayFrames = 2;
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.25, 1.9), fadeOut(1, 0.35));
paint(flash, WHITE, WHITE, YELLOW);
kit.add("flash", flash);

const hitStar = kit.parked(kit.tex(333, 1), [FOE[0] - 0.3, FOE[1] + 0.2, FOE[2] + 0.3], 1.1, 8);
hitStar.startDelayFrames = 2;
spin(hitStar, 0.1);
setCurves(hitStar, grow(0.4, 0.3, 1.4), fadeOut(1, 0.4));
paint(hitStar, YELLOW, WHITE, GOLD);
kit.add("hitStar", hitStar);

const streaks = kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.4, speed: 0.8, count: 7, life: 8, scale: 1.8, directional: true });
streaks.startDelayFrames = 2;
streaks.axis = [-1, 0, 0]; // thrown the way the hand swings
streaks.initVelAxisAmplifier = 0.4;
setCurves(streaks, undefined, fadeOut());
kit.prism(streaks, [YELLOW, WHITE, GOLD]);
kit.add("streaks", streaks);

// --- script ---
const emits = (names: string[], who: "ATTACKER" | "DEFENDER", toward = "NONE") => names.map((n) => kit.emit(n, who, toward)).join("\n");
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1509, SE1, 14, 0, 500, 105, 0, 0, 0
PlaySound 1421, SE2, 14, ${POP}, 400, 115, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${FLY}, 0, 50, 0, 0
PlaySound 1424, SE1, 16, ${POP + FLY + 2}, 300, 127, 0, 0, 0
PlaySound 1420, SE2, 16, ${POP + FLY + 3}, 400, 110, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 1, 31, 26, 10
${emits(["glow", "popHand", "glint"], "ATTACKER")}
Wait ${POP}
ChangeSpriteColor ATTACKER, 8, 0, 1, 31, 26, 10
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 2px, 49152, 0, 4096, 0
${emits(["flyHand", "afterImages", "speedLines"], "ATTACKER", "DEFENDER")}
MoveCamera INTERPOLATION, DEFENDER, ${FLY}, 0, 8
Wait ${FLY}
${emits(["slapHand", "ghost", "slapArc", "flash", "hitStar", "streaks"], "DEFENDER")}
Wait 2
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 31, 28, 12
ShakeScreen HORIZON, 0.5x, 0, 1, 0, 3
Wait 3
ChangeSpriteColor DEFENDER, 12, 0, 1, 31, 28, 12
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 819, 3, 1, 1
ShakeSprite DEFENDER, 2, 2048, 0, 2, 1, 6
Wait ${HOLD}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 10, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [427, 129, 153, 63, 400, 240, 5],
  references: ["reference/Upper_Hand_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, ${kit.idx("popHand")}, ATTACKER`, `Emit ${SPA}, ${kit.idx("flyHand")}, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("slapHand")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  hand f${CAMERA_IN}, flies f${CAMERA_IN + POP}, slap f${CAMERA_IN + POP + FLY}-${CAMERA_IN + POP + FLY + SWING}`);
