import { createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Syrup Bomb (move 903) - from Bulbapedia's stills (reference/).
//   1. A thick column of glossy red syrup blobs erupts up out of the user,
//      flinging red splashes.
//   2. The syrup comes down on the foe and coats it: the foe turns syrup red,
//      dripping red droplets.
// The Speed drops over the next turns are handled by the engine.
//
// Drawn here: a liquid splat (32x32 a5i3 white mask; as Matcha Gotcha's;
// generated/texture-splat.png). Explosion's puff (321) is the syrup blob.

const SPA = 896;
const kit = await createKit({ workDir: import.meta.dirname, slug: "syrup-bomb", moveId: 903, spaId: SPA, donors: [321, 465, 333] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const ERUPT = 20;
const PAN = 10;
const DROP = 6;
const COAT = 30;

const TOP: Vec3 = [0, 1.2, 0.2];
const FOE: Vec3 = [0, 0.3, 0.8];
const DROP_HEIGHT = 4.5;

const SYRUP: Rgb = [0.92, 0.12, 0.15];
const LIGHT_SYRUP: Rgb = [1.0, 0.5, 0.48];
const DARK_SYRUP: Rgb = [0.62, 0.04, 0.08];
const WHITE: Rgb = [1, 1, 1];

// --- the drawn splat ---
const lumps = [
  { x: 16, y: 16, r: 7.5 },
  { x: 11, y: 13, r: 5 },
  { x: 21, y: 12, r: 4.5 },
  { x: 20, y: 21, r: 5 },
  { x: 11, y: 21, r: 4 },
];
const drops = [
  { x: 4, y: 9, r: 2 },
  { x: 27, y: 6, r: 1.6 },
  { x: 28, y: 24, r: 2.2 },
  { x: 6, y: 27, r: 1.5 },
  { x: 16, y: 3, r: 1.4 },
];
const splatTex = await kit.drawn("splat", 32, 32, "a5i3", (x, y) => {
  const px = x + 0.5;
  const py = y + 0.5;
  const all = [...lumps, ...drops];
  if (!all.some((c) => Math.hypot(px - c.x, py - c.y) < c.r)) return undefined;
  const edge = all.every((c) => Math.hypot(px - c.x, py - c.y) > c.r - 1.2);
  return [255, 255, 255, edge ? 170 : 245];
});
const puffTex = kit.tex(321, 5);

// --- the eruption ---
const column = kit.spray([333, 1], puffTex, TOP, { radius: 0.25, speed: 0, count: 1, bursts: 12, gap: 1, life: 16, scale: 1.0, shape: "ball" });
column.axis = [0, 1, 0];
column.initVelAxisAmplifier = 0.32;
spin(column, -0.06, 0.06, 0, true);
setCurves(column, grow(0.6, 0.25, 1.4), fadeInOut(1, 0.1, 0.7));
kit.prism(column, [SYRUP, LIGHT_SYRUP, DARK_SYRUP]);
kit.add("column", column);

const fling = kit.spray([333, 1], splatTex, [0, 1.6, 0.2], { radius: 0.4, speed: 0.22, count: 2, bursts: 5, gap: 3, life: 14, scale: 0.5, shape: "circle" });
fling.axis = [0, 1, 0];
fling.initVelAxisAmplifier = 0.12;
fling.behaviors = [{ type: "gravity", magnitude: [0, -0.025, 0] }];
spin(fling, -0.15, 0.15, 0, true);
setCurves(fling, grow(0.5, 0.2, 1), fadeOut(1, 0.6));
kit.prism(fling, [SYRUP, LIGHT_SYRUP, DARK_SYRUP]);
kit.add("fling", fling);

const gloss = kit.spray([333, 1], kit.tex(333, 0), TOP, { radius: 0.6, speed: 0, count: 1, bursts: 6, gap: 3, life: 10, scale: 0.18, shape: "ball" });
gloss.axis = [0, 1, 0];
gloss.initVelAxisAmplifier = 0.3;
setCurves(gloss, undefined, twinkle());
paint(gloss, WHITE, WHITE, LIGHT_SYRUP);
kit.add("gloss", gloss);

// --- the drop ---
const blob = kit.parked(puffTex, [FOE[0], FOE[1] + DROP_HEIGHT, FOE[2]], 2.0, DROP);
blob.axis = [0, -1, 0];
blob.initVelAxisAmplifier = DROP_HEIGHT / DROP;
spin(blob, 0.08);
setCurves(blob, hold(1), hold(1));
paint(blob, SYRUP, LIGHT_SYRUP, SYRUP);
kit.add("blob", blob);

const rain = kit.spray([333, 1], splatTex, [FOE[0], FOE[1] + DROP_HEIGHT, FOE[2]], { radius: 1.0, speed: 0, count: 1, bursts: DROP, gap: 1, life: DROP, scale: 0.4, shape: "ball" });
rain.axis = [0, -1, 0];
rain.initVelAxisAmplifier = DROP_HEIGHT / DROP;
spin(rain, -0.1, 0.1, 0, true);
setCurves(rain, hold(1), hold(1));
kit.prism(rain, [SYRUP, LIGHT_SYRUP, DARK_SYRUP]);
kit.add("rain", rain);

// --- the coating ---
const splash = kit.spray([333, 1], puffTex, FOE, { radius: 0.6, speed: 0.1, count: 5, life: 16, scale: 1.0, shape: "ball" });
spin(splash, -0.08, 0.08, 0, true);
setCurves(splash, grow(0.5, 0.2, 1.3), fadeOut(1, 0.4));
kit.prism(splash, [SYRUP, LIGHT_SYRUP, DARK_SYRUP]);
kit.add("splash", splash);

const splats = kit.spray([333, 1], splatTex, FOE, { radius: 0.4, speed: 0.28, count: 7, life: 16, scale: 0.55 });
splats.axis = [0, 1, 0];
splats.initVelAxisAmplifier = 0.06;
splats.behaviors = [{ type: "gravity", magnitude: [0, -0.02, 0] }];
spin(splats, -0.15, 0.15, 0, true);
setCurves(splats, grow(0.5, 0.2, 1.1), fadeOut(1, 0.6));
kit.prism(splats, [SYRUP, LIGHT_SYRUP, DARK_SYRUP]);
kit.add("splats", splats);

const drips = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 1.3, speed: 0, count: 1, bursts: 10, gap: 2, life: 14, scale: 0.16, shape: "ball" });
drips.startDelayFrames = 6;
drips.behaviors = [{ type: "gravity", magnitude: [0, -0.012, 0] }];
setCurves(drips, hold(1), fadeOut(1, 0.6));
kit.prism(drips, [SYRUP, DARK_SYRUP, LIGHT_SYRUP]);
kit.add("drips", drips);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1452, SE1, 14, 0, -600, 115, 0, 0, 0
PlaySound 1446, SE2, 14, 4, -300, 100, 0, 0, 0
PlaySound 1452, SE2, 14, 10, -300, 100, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 2, 31, 6, 6
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 3, 0, 1
${kit.emit("column", "ATTACKER")}
${kit.emit("fling", "ATTACKER")}
${kit.emit("gloss", "ATTACKER")}
Wait ${ERUPT}
ChangeSpriteColor ATTACKER, 8, 0, 1, 31, 6, 6
MoveCamera INTERPOLATION, DEFENDER, ${PAN}, 0, 8
Wait ${PAN - DROP}
${kit.emit("blob", "DEFENDER")}
${kit.emit("rain", "DEFENDER")}
Wait ${DROP}
AudioContainer CONTINUE
PlaySound 1511, SE1, 16, 0, -400, 120, 0, 0, 0
PlaySound 1446, SE2, 16, 2, -500, 115, 0, 0, 0
PlaySound 1446, SE2, 16, 14, -700, 90, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("splash", "DEFENDER")}
${kit.emit("splats", "DEFENDER")}
${kit.emit("drips", "DEFENDER")}
ChangeSpriteColor DEFENDER, 0, 13, 0, 31, 5, 6
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 8
Wait ${COAT - 10}
ChangeSpriteColor DEFENDER, 13, 0, 3, 31, 5, 6
Wait 10
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [153, 605, 188, 401],
  references: ["reference/Syrup_Bomb_IX.png", "reference/Syrup_Bomb_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 3, DEFENDER`, `Emit ${SPA}, 7, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  erupt f${CAMERA_IN}-${CAMERA_IN + ERUPT}, splash f${CAMERA_IN + ERUPT + PAN}`);
