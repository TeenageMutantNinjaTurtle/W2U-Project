MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 896
AudioContainer CONTINUE
PlaySound 1452, SE1, 14, 0, -600, 115, 0, 0, 0
PlaySound 1446, SE2, 14, 4, -300, 100, 0, 0, 0
PlaySound 1452, SE2, 14, 10, -300, 100, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 2, 31, 6, 6
ScaleSprite ATTACKER, ROUNDTRIP, -819, 819, 3, 0, 1
Emit 896, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 896, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 896, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 20
ChangeSpriteColor ATTACKER, 8, 0, 1, 31, 6, 6
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 4
Emit 896, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 896, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 6
AudioContainer CONTINUE
PlaySound 1511, SE1, 16, 0, -400, 120, 0, 0, 0
PlaySound 1446, SE2, 16, 2, -500, 115, 0, 0, 0
PlaySound 1446, SE2, 16, 14, -700, 90, 0, 0, 0
AudioContainer SUSPEND
Emit 896, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 896, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 896, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor DEFENDER, 0, 13, 0, 31, 5, 6
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 8
Wait 20
ChangeSpriteColor DEFENDER, 13, 0, 3, 31, 5, 6
Wait 10
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
