MoveCamera INTERPOLATION, ZOOM_OUT_PERS, 18, 0, 0
LetCMDsFinish CAMERA
LoadSPA 877
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, -600, 80, 0, 0, 0
PlaySound 1509, SE2, 14, 14, 900, 70, 0, 0, 0
PlaySound 1376, SE1, 14, 56, 0, 0, 0, 0, 0
AudioContainer SUSPEND
AdjustCamera INTERPOLATION_RELATIVE, 0, 0, 0, 0, 2px, 0, 20, 0, 20
ChangeBackgroundColor 4, 0, 7, 2, 18, 24, 31
Emit 877, 0, ATTACKER, NONE, 0, 0, 0, 1x, 1x, 1x, 1x
Emit 877, 1, ATTACKER, NONE, 0, 0, 0, 1x, 1x, 1x, 1x
Wait 56
ChangeBackgroundColor 4, 7, 0, 2, 18, 24, 31
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
