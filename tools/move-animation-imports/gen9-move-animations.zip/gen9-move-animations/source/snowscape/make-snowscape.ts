import { createKit, fadeInOut, paint, setCurves, spin, twinkle, type Rgb } from "../tools/anim-kit";

// Snowscape (move 883) - from Bulbapedia's still (reference/).
// The user looks skyward while soft white snowflakes start drifting down
// across the field; the scene takes a cool cast.
// A wide shot that tilts up to the sky, the arena cooling, flakes and a few
// twinkling crystals drifting down. The weather itself is the engine's.

const SPA = 877;
const kit = await createKit({ workDir: import.meta.dirname, slug: "snowscape", moveId: 883, spaId: SPA, donors: [298] });

const WIDE = 18;
const SNOW = 56;

const WHITE: Rgb = [1, 1, 1];
const PALE_BLUE: Rgb = [0.85, 0.94, 1.0];

const flakes = kit.spray([333, 1], kit.tex(333, 0), [0, 7.0, -2.0], { radius: 6.5, speed: 0, count: 2, bursts: 20, gap: 2, life: 34, scale: 0.13, shape: "ball" });
flakes.axis = [0.12, -1, 0];
flakes.initVelAxisAmplifier = 0.11;
flakes.behaviors = [{ type: "spin", axis: 1, angle: 0.03 }];
setCurves(flakes, undefined, fadeInOut(1, 0.15, 0.75));
kit.prism(flakes, [WHITE, PALE_BLUE, WHITE]);
kit.add("flakes", flakes);

const crystals = kit.spray([333, 1], kit.tex(298, 1), [0, 6.0, -2.0], { radius: 6.0, speed: 0, count: 1, bursts: 10, gap: 4, life: 24, scale: 0.25, shape: "ball" });
crystals.axis = [0.12, -1, 0];
crystals.initVelAxisAmplifier = 0.1;
spin(crystals, -0.05, 0.05, 0, true);
setCurves(crystals, twinkle(1), twinkle(1));
paint(crystals, WHITE, WHITE, PALE_BLUE);
kit.add("crystals", crystals);

const script = `MoveCamera INTERPOLATION, ZOOM_OUT_PERS, ${WIDE}, 0, 0
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1497, SE1, 14, 0, -600, 80, 0, 0, 0
PlaySound 1509, SE2, 14, 14, 900, 70, 0, 0, 0
PlaySound 1376, SE1, 14, ${SNOW}, 0, 0, 0, 0, 0
AudioContainer SUSPEND
AdjustCamera INTERPOLATION_RELATIVE, 0, 0, 0, 0, 2px, 0, 20, 0, 20
ChangeBackgroundColor 4, 0, 7, 2, 18, 24, 31
${kit.emit("flakes", "ATTACKER", "NONE", "0")}
${kit.emit("crystals", "ATTACKER", "NONE", "0")}
Wait ${SNOW}
ChangeBackgroundColor 4, 7, 0, 2, 18, 24, 31
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 16, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [163, 129],
  references: ["reference/Snowscape_IX.png"],
  expectText: [`LoadSPA ${SPA}`, "MoveCamera INTERPOLATION, ZOOM_OUT_PERS", "AdjustCamera INTERPOLATION_RELATIVE", `Emit ${SPA}, 0, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  snow f${WIDE}-${WIDE + SNOW}`);
