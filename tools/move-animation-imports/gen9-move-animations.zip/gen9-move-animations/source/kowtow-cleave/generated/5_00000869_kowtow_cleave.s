MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 863
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -900, 120, 0, 0, 0
PlaySound 1435, SE2, 14, 22, 0, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 1, 4, 0, 2
ChangeSpriteColor ATTACKER, 0, 10, 2, 20, 0, 4
ScaleSprite ATTACKER, ROUNDTRIP, 410, -1229, 6, 8, 1
Emit 863, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 863, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 863, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 22
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 10, 0, 1, 20, 0, 4
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
AudioContainer CONTINUE
PlaySound 1514, SE1, 16, 0, -300, 125, 0, 0, 0
PlaySound 1514, SE2, 16, 3, 200, 120, 0, 0, 0
PlaySound 1420, SE1, 16, 2, -400, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 863, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 863, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 863, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 863, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 863, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 863, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 31, 4, 6
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen HORIZON, 0.5x, 0, 1, 1, 4
Wait 6
ChangeSpriteColor DEFENDER, 12, 0, 1, 31, 4, 6
Wait 16
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 10, 0, 1, 4, 0, 2
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
