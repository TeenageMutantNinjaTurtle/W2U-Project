import { assert, createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Kowtow Cleave (move 869) - from Bulbapedia's stills (reference/).
//   1. The user bows low, cloaked in a dark red aura, red-black flame and
//      smoke rising behind it.
//   2. On the foe, an X of red-black slash lines, splattered red and
//      magenta shards, black flecks.
//
// Textures: Slash's streak (the X lines), Explosion's puff and spike,
// Hyper Beam's sunburst. Night Slash's sounds. The spinning sweep arc on
// the foe was removed at Logan's request (2026-10-01); he kept the X slash.

const SPA = 863;
const kit = await createKit({ workDir: import.meta.dirname, slug: "kowtow-cleave", moveId: 869, spaId: SPA, donors: [606, 321, 228] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const BOW = 22;
const DASH = 8;
const HOLD = 22;

const USER: Vec3 = [0, 0, -0.2];
const BEHIND_USER: Vec3 = [0, 0.4, 0.6];
const FOE: Vec3 = [0, 0.2, 0.8];

const DARK_RED: Rgb = [0.55, 0.03, 0.08];
const RED: Rgb = [1.0, 0.12, 0.15];
const MAGENTA: Rgb = [1.0, 0.25, 0.75];
const BLACK: Rgb = [0.06, 0.02, 0.04];
const WHITE: Rgb = [1, 1, 1];

// --- the bow ---
const aura = kit.parked(kit.tex(228, 1), BEHIND_USER, 2.0, BOW + 4);
spin(aura, 0.03);
setCurves(aura, grow(0.4, 0.4, 1.15), fadeInOut(0.75, 0.25, 0.85));
paint(aura, DARK_RED, RED, DARK_RED);
kit.add("aura", aura);

// Red-black flames and smoke rising behind the user.
const flames = kit.spray([228, 3], kit.tex(321, 6), [BEHIND_USER[0], BEHIND_USER[1] - 1.4, BEHIND_USER[2]], { radius: 1.3, speed: 0, count: 2, bursts: 9, gap: 2, life: 12, scale: 0.6, shape: "circle", directional: true });
flames.emissionAxis = 1;
flames.axis = [0, 1, 0];
flames.initVelAxisAmplifier = 0.22;
setCurves(flames, grow(0.8, 0.3, 1.4), fadeInOut(1, 0.2, 0.5));
kit.prism(flames, [RED, DARK_RED, BLACK]);
kit.add("flames", flames);

const smoke = kit.spray([333, 1], kit.tex(321, 5), [BEHIND_USER[0], BEHIND_USER[1] - 1.0, BEHIND_USER[2]], { radius: 1.0, speed: 0.02, count: 1, bursts: 6, gap: 3, life: 16, scale: 0.8, shape: "circle" });
smoke.emissionAxis = 1;
smoke.axis = [0, 1, 0];
smoke.initVelAxisAmplifier = 0.12;
spin(smoke, -0.05, 0.05, 0, true);
setCurves(smoke, grow(0.5, 0.3, 1.4), fadeInOut(0.6, 0.2, 0.5));
paint(smoke, BLACK, DARK_RED, BLACK);
kit.add("smoke", smoke);

// --- the cleave ---
const streakTex = kit.tex(333, 2);
function slashLine(angle: number, delay: number, colour: Rgb, scale: number): ReturnType<typeof kit.parked> {
  const r = kit.parked(streakTex, FOE, scale, 14);
  r.aspectRatio = 0.45;
  r.initAngle = deg(angle);
  r.startDelayFrames = delay;
  setCurves(r, grow(0.2, 3 / 14, 1.05), fadeOut(1, 0.55));
  paint(r, colour, WHITE, colour);
  return r;
}
kit.add("slashA", slashLine(-55, 0, RED, 2.5));
kit.add("slashACore", slashLine(-55, 0, BLACK, 1.9));
kit.add("slashB", slashLine(40, 3, RED, 2.3));
kit.add("slashBCore", slashLine(40, 3, BLACK, 1.7));

const shards = kit.spray([228, 3], kit.tex(321, 6), FOE, { radius: 0.3, speed: 0.55, count: 10, life: 11, scale: 0.55, directional: true });
shards.startDelayFrames = 1;
setCurves(shards, grow(1.2, 0.3, 0.6), fadeOut());
kit.prism(shards, [RED, MAGENTA, BLACK]);
kit.add("shards", shards);

const flecks = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.4, speed: 0.4, count: 8, life: 13, scale: 0.14 });
setCurves(flecks, undefined, twinkle());
kit.prism(flecks, [BLACK, MAGENTA, RED]);
kit.add("flecks", flecks);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -900, 120, 0, 0, 0
PlaySound 1435, SE2, 14, ${BOW}, 0, 115, 0, 0, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 10, 1, 4, 0, 2
ChangeSpriteColor ATTACKER, 0, 10, 2, 20, 0, 4
ScaleSprite ATTACKER, ROUNDTRIP, 410, -1229, 6, 8, 1
${kit.emit("aura", "ATTACKER")}
${kit.emit("flames", "ATTACKER")}
${kit.emit("smoke", "ATTACKER")}
Wait ${BOW}
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 10, 0, 1, 20, 0, 4
MoveCamera INTERPOLATION, DEFENDER, ${DASH}, 0, 8
Wait ${DASH}
AudioContainer CONTINUE
PlaySound 1514, SE1, 16, 0, -300, 125, 0, 0, 0
PlaySound 1514, SE2, 16, 3, 200, 120, 0, 0, 0
PlaySound 1420, SE1, 16, 2, -400, 110, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("slashA", "DEFENDER")}
${kit.emit("slashACore", "DEFENDER")}
${kit.emit("slashB", "DEFENDER")}
${kit.emit("slashBCore", "DEFENDER")}
${kit.emit("shards", "DEFENDER")}
${kit.emit("flecks", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 31, 4, 6
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
ShakeScreen HORIZON, 0.5x, 0, 1, 1, 4
Wait 6
ChangeSpriteColor DEFENDER, 12, 0, 1, 31, 4, 6
Wait ${HOLD - 6}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 10, 0, 1, 4, 0, 2
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

const { built } = await kit.finish({
  script,
  donorMoveIds: [163, 427, 153, 63, 400],
  references: ["reference/Kowtow_Cleave_IX.png", "reference/Kowtow_Cleave_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, "ScaleSprite ATTACKER, ROUNDTRIP, 410, -1229", `Emit ${SPA}, 0, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 3, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
assert.ok(Math.abs(built("slashA").initAngle - built("slashB").initAngle) > deg(60), "Slash lines do not cross");
console.log(`  bow f${CAMERA_IN}-${CAMERA_IN + BOW}, cleave f${CAMERA_IN + BOW + DASH}`);
