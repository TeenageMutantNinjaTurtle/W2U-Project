import { assert, createKit, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Temper Flare (move 915), v2 - from Logan's keyframes (shown in chat, not
// saved) and brief: "anger marks as startup -> envelops itself with fire
// until its bright hot -> launches itself at the target in a vortex of flames
// -> deals damage upon impact".
//   1. Two glowing red-orange anger marks pop above the user's head, a big
//      one and a small one.
//   2. Steam puffs off its head and flames rise up behind it; it reddens,
//      then burns bright orange-hot as the scene turns red.
//   3. It launches at the foe as a vortex of flame: a spinning red-orange
//      swirl round a yellow fireball, leaving a wall of pale yellow fire
//      puffs and red flame arcs along the ground.
//   4. Impact: a yellow fire explosion with white streaks and orange and red
//      flame tongues.
// The user is hidden while it is the vortex (ToggleSpriteVisibility 3/4).
// The doubled power after a failed move is handled by the engine.
// v1 (../temper-flare) is kept; reinstall its manifest to revert.
//
// The anger mark is drawn here: Raging Bull's four-hook symbol in red-orange
// with a glowing orange outline (32x32 a3i5; generated/texture-anger.png).

const SPA = 937;
const kit = await createKit({ workDir: import.meta.dirname, slug: "temper-flare-v2", moveId: 915, spaId: SPA, donors: [321, 228, 605, 606, 465, 579, 411] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const ANGER = 16;
const IGNITE = 28;
const LAUNCH = 9;
const HIT_STOP = 5;
const HOLD = 26;

const USER: Vec3 = [0, 0.3, 0.2];
const HEAD: Vec3 = [0.2, 2.0, 0.3];
const BEHIND: Vec3 = [0, -1.3, 0.6]; // the ground just behind the user
const FOE: Vec3 = [0, 0.3, 0.8];

const RED: Rgb = [0.95, 0.2, 0.1];
const ORANGE: Rgb = [1.0, 0.5, 0.12];
const YELLOW: Rgb = [1.0, 0.88, 0.3];
const PALE: Rgb = [1.0, 0.97, 0.7];
const WHITE: Rgb = [1, 1, 1];

// --- the drawn anger mark ---
const angerTex = await kit.drawn("anger", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5 - 16;
  const py = y + 0.5 - 16;
  const tilt = (-25 * Math.PI) / 180;
  let nearest = Infinity;
  for (let k = 0; k < 4; k++) {
    // Each stroke is an arc round a point 15 px out; only the part bowing
    // toward the centre is drawn.
    const a = tilt + (k * Math.PI) / 2;
    const cx = 15 * Math.cos(a);
    const cy = 15 * Math.sin(a);
    const dx = px - cx;
    const dy = py - cy;
    const toCentre = Math.atan2(-cy, -cx);
    let off = Math.atan2(dy, dx) - toCentre;
    off = Math.atan2(Math.sin(off), Math.cos(off));
    if (Math.abs(off) < 1.0) nearest = Math.min(nearest, Math.abs(Math.hypot(dx, dy) - 7.5));
  }
  if (nearest <= 1.3) return [236, 52, 34]; // the stroke
  if (nearest <= 2.3) return [255, 160, 60]; // its glowing outline
  return undefined;
});

// --- 1. anger marks ---
const STAGE = ANGER + IGNITE;
function mark(pos: Vec3, scale: number, delay: number): ReturnType<typeof kit.parked> {
  const r = kit.parked(angerTex, pos, scale, ANGER + 10 - delay);
  r.startDelayFrames = delay;
  setCurves(r, { start: 0.3, mid: 1.25, end: 1.0, curveIn: 0.2, curveOut: 0.45 }, fadeInOut(1, 0.1, 0.8));
  paint(r, WHITE);
  return r;
}
kit.add("markBig", mark(HEAD, 0.7, 2));
kit.add("markSmall", mark([HEAD[0] + 0.9, HEAD[1] - 0.2, HEAD[2]], 0.4, 6));

// --- 2. enveloped in fire ---
const steam = kit.spray([333, 1], kit.tex(321, 5), [HEAD[0] - 0.2, HEAD[1] - 0.6, HEAD[2]], { radius: 0.4, speed: 0, count: 1, bursts: 6, gap: 4, life: 14, scale: 0.45, shape: "ball" });
steam.startDelayFrames = ANGER - 6;
steam.axis = [0.1, 1, 0];
steam.initVelAxisAmplifier = 0.1;
spin(steam, -0.06, 0.06, 0, true);
setCurves(steam, grow(0.4, 0.3, 1.5), fadeInOut(0.7, 0.2, 0.5));
paint(steam, WHITE);
kit.add("steam", steam);

const flames = kit.spray([228, 3], kit.tex(321, 6), BEHIND, { radius: 1.5, speed: 0, count: 2, bursts: IGNITE / 2, gap: 2, life: 12, scale: 1.1, shape: "circle", directional: true });
flames.startDelayFrames = ANGER;
flames.emissionAxis = 1;
flames.axis = [0, 1, 0];
flames.initVelAxisAmplifier = 0.3;
setCurves(flames, grow(0.4, 0.3, 1.4), fadeInOut(1, 0.15, 0.55));
kit.prism(flames, [RED, ORANGE, YELLOW]);
kit.add("flames", flames);

const blaze = kit.spray([333, 1], kit.tex(321, 5), [0, -0.4, 0.7], { radius: 1.0, speed: 0, count: 1, bursts: IGNITE / 3, gap: 3, life: 14, scale: 1.1, shape: "ball" });
blaze.startDelayFrames = ANGER + 4;
blaze.axis = [0, 1, 0];
blaze.initVelAxisAmplifier = 0.14;
spin(blaze, -0.08, 0.08, 0, true);
setCurves(blaze, grow(0.5, 0.3, 1.4), fadeInOut(0.9, 0.15, 0.55));
kit.prism(blaze, [ORANGE, RED, YELLOW]);
kit.add("blaze", blaze);

const heat = kit.parked(kit.tex(465, 1), USER, 3.2, IGNITE + 2);
heat.startDelayFrames = ANGER;
setCurves(heat, { start: 0.4, mid: 0.8, end: 1.2, curveIn: 0.4, curveOut: 0.6 }, { start: 0, mid: 0.5, end: 0.9, curveIn: 0.35, curveOut: 0.6 });
paint(heat, ORANGE, RED, YELLOW);
kit.add("heat", heat);

const embers = kit.spray([333, 1], kit.tex(333, 0), USER, { radius: 1.8, speed: 0, count: 1, bursts: IGNITE / 3, gap: 3, life: 12, scale: 0.13, shape: "ball" });
embers.startDelayFrames = ANGER;
embers.axis = [0, 1, 0];
embers.initVelAxisAmplifier = 0.1;
setCurves(embers, undefined, twinkle());
kit.prism(embers, [YELLOW, ORANGE, WHITE]);
kit.add("embers", embers);

// --- 3. the launch: a vortex of flame riding to the foe ---
function rider(texIndex: number, scale: number, colour: Rgb, start: Rgb): ReturnType<typeof kit.shell> {
  const r = kit.shell(605, 0);
  assert.ok(r.followEmitter, "Mud Bomb's ball no longer follows its emitter");
  r.textureIndex = texIndex;
  Object.assign(r, { particleLifeFrames: LAUNCH + 1, baseScale: scale });
  setCurves(r, grow(0.7, 0.3, 1.1), undefined); // Mud Bomb's rider has no alpha curve
  paint(r, colour, start, colour);
  return r;
}
const fireball = rider(kit.tex(465, 1), 1.9, YELLOW, PALE);
kit.add("fireball", fireball);
const swirl = rider(kit.tex(228, 3), 2.1, ORANGE, YELLOW);
spin(swirl, -0.5);
kit.add("swirl", swirl);

// Left behind along its path: a wall of pale fire puffs and red flame arcs.
const fireWall = kit.spray([333, 1], kit.tex(321, 5), [0, -0.9, 0], { radius: 0.5, speed: 0.03, count: 1, bursts: LAUNCH, gap: 1, life: 11, scale: 1.2 });
spin(fireWall, -0.08, 0.08, 0, true);
setCurves(fireWall, grow(0.6, 0.3, 1.4), fadeInOut(1, 0.1, 0.55));
kit.prism(fireWall, [PALE, YELLOW, ORANGE]);
kit.add("fireWall", fireWall);

const flameArcs = kit.spray([333, 1], kit.tex(606, 4), [0, 0.4, 0], { radius: 0.5, speed: 0.04, count: 1, bursts: Math.ceil(LAUNCH / 2), gap: 2, life: 10, scale: 1.6 });
spin(flameArcs, -0.3, 0.3, 0, true);
setCurves(flameArcs, grow(0.6, 0.3, 1.3), fadeOut(1, 0.45));
kit.prism(flameArcs, [RED, ORANGE, RED]);
kit.add("flameArcs", flameArcs);

// --- 4. impact ---
const flash = kit.parked(kit.tex(228, 1), FOE, 2.2, 14);
spin(flash, 0.05);
setCurves(flash, grow(0.4, 0.2, 2.3), fadeOut(1, 0.35));
paint(flash, PALE, WHITE, YELLOW);
kit.add("flash", flash);

const blast = kit.spray([333, 1], kit.tex(321, 5), FOE, { radius: 0.8, speed: 0.16, count: 7, life: 16, scale: 1.3, shape: "ball" });
spin(blast, -0.08, 0.08, 0, true);
setCurves(blast, grow(0.5, 0.25, 1.5), fadeOut(1, 0.4));
kit.prism(blast, [YELLOW, PALE, ORANGE]);
kit.add("blast", blast);

const whiteStreaks = kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.4, speed: 0.9, count: 6, life: 8, scale: 2.2, directional: true });
setCurves(whiteStreaks, undefined, fadeOut());
paint(whiteStreaks, WHITE, WHITE, PALE);
kit.add("whiteStreaks", whiteStreaks);

const tongues = kit.spray([228, 3], kit.tex(321, 6), FOE, { radius: 0.4, speed: 0.6, count: 10, life: 11, scale: 0.8, directional: true });
setCurves(tongues, grow(1.2, 0.3, 0.6), fadeOut());
kit.prism(tongues, [ORANGE, RED, YELLOW]);
kit.add("tongues", tongues);

const afterEmbers = kit.spray([333, 1], kit.tex(333, 0), FOE, { radius: 0.6, speed: 0.3, count: 6, life: 14, scale: 0.13 });
afterEmbers.startDelayFrames = HIT_STOP;
afterEmbers.behaviors = [{ type: "gravity", magnitude: [0, -0.012, 0] }];
setCurves(afterEmbers, undefined, twinkle());
kit.prism(afterEmbers, [ORANGE, YELLOW, WHITE]);
kit.add("afterEmbers", afterEmbers);

// --- script ---
const emits = (names: string[], who: "ATTACKER" | "DEFENDER") => names.map((n) => kit.emit(n, who)).join("\n");
const ride = (name: string) => `EmitProjectile ${SPA}, ${kit.idx(name)}, STRAIGHT, ATTACKER, DEFENDER, 2px, ${LAUNCH}f, 0, 1x, 1x, 0`;
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -600, 115, 0, 0, 0
PlaySound 1467, SE2, 14, 4, 300, 90, 0, 0, 0
PlaySound 1425, SE2, 14, ${ANGER}, 0, 115, 0, 0, 0
PlaySound 1425, SE1, 14, ${ANGER + 14}, 300, 120, 0, 0, 0
PlaySound 1426, SE2, 14, ${STAGE}, -200, 125, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, ${LAUNCH}, 0, 50, 0, 0
PlaySound 1475, SE1, 16, ${STAGE + LAUNCH}, -300, 127, 0, 0, 0
PlaySound 1426, SE2, 16, ${STAGE + LAUNCH}, 0, 125, 0, 0, 0
PlaySound 1864, SE1, 16, ${STAGE + LAUNCH + HIT_STOP + 2}, 200, 100, 0, 0, 0
AudioContainer SUSPEND
${emits(["markBig", "markSmall", "steam", "heat", "flames", "blaze", "embers"], "ATTACKER")}
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, ${ANGER / 2}
Wait ${ANGER}
ChangeBackgroundColor 4, 0, 11, 3, 20, 2, 0
ChangeSpriteColor ATTACKER, 0, 10, 3, 31, 8, 4
Wait ${IGNITE / 2}
ChangeSpriteColor ATTACKER, 10, 15, 3, 31, 20, 8
ShakeSprite ATTACKER, 2, 1229, 0, 1, 1, ${IGNITE / 4}
Wait ${IGNITE / 2}
ToggleSpriteVisibility ATTACKER, 3
${ride("fireball")}
${ride("swirl")}
${ride("fireWall")}
${ride("flameArcs")}
MoveCamera INTERPOLATION, DEFENDER, ${LAUNCH}, 0, 8
Wait ${LAUNCH}
${emits(["flash", "blast", "whiteStreaks", "tongues", "afterEmbers"], "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 24, 8
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 3
Wait ${HIT_STOP}
ChangeSpriteColor DEFENDER, 14, 0, 2, 31, 14, 4
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 8
Wait ${HOLD}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 15, 0, 0, 31, 20, 8
ToggleSpriteVisibility ATTACKER, 4
ChangeBackgroundColor 4, 11, 0, 2, 20, 2, 0
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [53, 172, 163, 427, 63, 400, 291, 605],
  references: ["reference/Temper_Flare_IX.png", "reference/Temper_Flare_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, `Emit ${SPA}, ${kit.idx("flames")}, ATTACKER`, "ToggleSpriteVisibility ATTACKER, 3", `EmitProjectile ${SPA}, ${kit.idx("swirl")}, STRAIGHT, ATTACKER, DEFENDER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("blast")}, DEFENDER`, "ToggleSpriteVisibility ATTACKER, 4", "MoveCamera INTERPOLATION, INIT"],
});
const launchAt = CAMERA_IN + STAGE;
console.log(`  anger f${CAMERA_IN}, fire f${CAMERA_IN + ANGER}-${launchAt}, launch f${launchAt}, impact f${launchAt + LAUNCH}`);
