MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 937
AudioContainer CONTINUE
PlaySound 1434, SE1, 14, 0, -600, 115, 0, 0, 0
PlaySound 1467, SE2, 14, 4, 300, 90, 0, 0, 0
PlaySound 1425, SE2, 14, 16, 0, 115, 0, 0, 0
PlaySound 1425, SE1, 14, 30, 300, 120, 0, 0, 0
PlaySound 1426, SE2, 14, 44, -200, 125, 0, 0, 0
SwitchAudioSide SE2, INTERPOLATION, 14, 9, 0, 50, 0, 0
PlaySound 1475, SE1, 16, 53, -300, 127, 0, 0, 0
PlaySound 1426, SE2, 16, 53, 0, 125, 0, 0, 0
PlaySound 1864, SE1, 16, 60, 200, 100, 0, 0, 0
AudioContainer SUSPEND
Emit 937, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 937, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 937, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 937, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 937, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 937, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 937, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 819, 0, 1, 1, 8
Wait 16
ChangeBackgroundColor 4, 0, 11, 3, 20, 2, 0
ChangeSpriteColor ATTACKER, 0, 10, 3, 31, 8, 4
Wait 14
ChangeSpriteColor ATTACKER, 10, 15, 3, 31, 20, 8
ShakeSprite ATTACKER, 2, 1229, 0, 1, 1, 7
Wait 14
ToggleSpriteVisibility ATTACKER, 3
EmitProjectile 937, 7, STRAIGHT, ATTACKER, DEFENDER, 2px, 9f, 0, 1x, 1x, 0
EmitProjectile 937, 8, STRAIGHT, ATTACKER, DEFENDER, 2px, 9f, 0, 1x, 1x, 0
EmitProjectile 937, 9, STRAIGHT, ATTACKER, DEFENDER, 2px, 9f, 0, 1x, 1x, 0
EmitProjectile 937, 10, STRAIGHT, ATTACKER, DEFENDER, 2px, 9f, 0, 1x, 1x, 0
MoveCamera INTERPOLATION, DEFENDER, 9, 0, 8
Wait 9
Emit 937, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 937, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 937, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 937, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 937, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 14, 0, 31, 24, 8
ShakeScreen VERTICAL, 0.5x, 0, 1, 0, 3
Wait 5
ChangeSpriteColor DEFENDER, 14, 0, 2, 31, 14, 4
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 12
ShakeScreen VERTICAL, 1x, 0, 2, 0, 8
Wait 26
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeSpriteColor ATTACKER, 15, 0, 0, 31, 20, 8
ToggleSpriteVisibility ATTACKER, 4
ChangeBackgroundColor 4, 11, 0, 2, 20, 2, 0
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
