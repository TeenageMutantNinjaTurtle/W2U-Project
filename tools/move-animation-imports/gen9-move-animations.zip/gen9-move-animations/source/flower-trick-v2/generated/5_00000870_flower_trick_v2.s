MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 924
AudioContainer CONTINUE
PlaySound 1509, SE1, 14, 0, 300, 100, 0, 0, 0
PlaySound 1509, SE2, 14, 10, 900, 115, 0, 0, 0
PlaySound 1509, SE2, 14, 15, 1300, 95, 0, 0, 0
PlaySound 1483, SE1, 14, 38, 0, 110, 0, 0, 0
PlaySound 1445, SE2, 16, 46, 1200, 90, 0, 0, 0
PlaySound 1420, SE1, 16, 56, 0, 120, 0, 0, 0
PlaySound 1497, SE2, 16, 58, 0, 110, 0, 0, 0
PlaySound 1509, SE1, 14, 64, 600, 100, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 9, 2, 31, 30, 20
Emit 924, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 10
Emit 924, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 924, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 924, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 18
ChangeSpriteColor ATTACKER, 9, 0, 2, 31, 30, 20
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 10
Emit 924, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 924, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 924, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 924, 7, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 924, 8, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 924, 9, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 924, 10, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 924, 11, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 924, 12, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 924, 13, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 924, 14, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 924, 15, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor DEFENDER, 0, 6, 3, 31, 28, 18
Wait 18
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 6, 13, 0, 31, 30, 18
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 10
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 4
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 3, 31, 30, 18
Wait 26
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
