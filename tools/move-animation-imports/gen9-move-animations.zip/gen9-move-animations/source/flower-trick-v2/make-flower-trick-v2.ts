import { createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Flower Trick (move 870), v2 - from Logan's keyframes (shown in chat, not
// saved):
//   1. The user glows, lit gold-white round its edges.
//   2. It flicks a thin glowing gold ring beside it, a four-point sparkle
//      flashing at its centre - the trick.
//   3. A spotlight shines down on the foe, a warm gold pool on the ground.
//   4. A green bouquet drops out of the sky into the spotlight, sparkles
//      trailing.
//   5. It bursts on the foe in a yellow-gold spiky flash.
//   6. Green mist billows and colourful petal confetti and sparkles shower
//      round the foe, a streamer arcing.
// v1 (../flower-trick, from the Bulbapedia stills) is kept; reinstall its
// manifest to revert.
//
// Drawn here (see generated/): the spotlight cone (as v1's), the bouquet
// (32x32 a3i5: a green ball with a dark underside and a row of pink flowers)
// and a petal (32x32 a5i3 white mask, so each confetti petal takes its own
// colour).

const SPA = 924;
const kit = await createKit({ workDir: import.meta.dirname, slug: "flower-trick-v2", moveId: 870, spaId: SPA, donors: [298, 407, 465, 579, 228, 321, 411] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const GLOW = 10;
const RING = 18;
const PAN = 10;
const SPOT = 8; // spotlight settles before the drop
const DROP = 10;
const AFTER = 30;

const BESIDE: Vec3 = [0.9, 0.6, -1.2];
const FOE: Vec3 = [0, 0.3, 0.8];
const FOE_FLOOR: Vec3 = [0, -1.5, 0.9];
const DROP_FROM = 4.6;

const GOLD: Rgb = [1.0, 0.85, 0.35];
const PALE_GOLD: Rgb = [1.0, 0.96, 0.72];
const AMBER: Rgb = [1.0, 0.7, 0.3];
const YELLOW: Rgb = [1.0, 0.9, 0.3];
const MINT: Rgb = [0.55, 0.95, 0.8];
const GREEN_MIST: Rgb = [0.5, 0.85, 0.65];
const PINK: Rgb = [1.0, 0.55, 0.8];
const MAGENTA: Rgb = [0.95, 0.35, 0.9];
const SKY: Rgb = [0.55, 0.8, 1.0];
const LAVENDER: Rgb = [0.8, 0.7, 1.0];
const SPOTLIGHT: Rgb = [1.0, 0.98, 0.9];
const WHITE: Rgb = [1, 1, 1];

// --- drawn textures ---
const spotTex = await kit.drawn("spotlight", 64, 64, "a5i3", (x, y) => {
  const t = y / 63; // 0 top, 1 bottom
  const half = 6 + 25 * t;
  const d = Math.abs(x - 31.5) / half;
  if (d > 1) return undefined;
  const edge = d > 0.7 ? (1 - d) / 0.3 : 1;
  const a = Math.round(255 * 0.7 * edge * (1 - 0.55 * t));
  return a < 8 ? undefined : [255, 255, 255, a];
});

const flowers = [9, 16, 23];
const bouquetTex = await kit.drawn("bouquet", 32, 32, "a3i5", (x, y) => {
  const px = x + 0.5;
  const py = y + 0.5;
  for (const fx of flowers) {
    const dx = px - fx;
    const dy = py - 24;
    const r = Math.hypot(dx, dy);
    if (r < 1.3) return [255, 236, 140]; // flower centre
    const petals = 2.6 + 1.0 * Math.cos(5 * Math.atan2(dy, dx));
    if (r < petals) return r > petals - 0.8 ? [196, 70, 120] : [250, 140, 180];
  }
  const dx = px - 16;
  const dy = py - 14;
  const r = Math.hypot(dx, dy);
  if (r > 11.5) return undefined;
  if (r > 10.6) return [24, 60, 32]; // outline
  if (py > 18) return py > 21 ? [20, 34, 26] : [36, 66, 44]; // dark underside
  const light = (-dx - dy) / 11.5;
  return light > 0.55 ? [196, 250, 170] : light > 0 ? [112, 214, 104] : light > -0.5 ? [74, 172, 78] : [50, 130, 60];
});

const petalTex = await kit.drawn("petal", 32, 32, "a5i3", (x, y) => {
  const px = x + 0.5 - 16;
  const py = y + 0.5 - 16;
  // A teardrop: wide at the bottom, pointed at the top.
  const t = (py + 12) / 24; // 0 top .. 1 bottom
  if (t < 0 || t > 1) return undefined;
  const half = 8 * Math.sin(Math.PI * Math.pow(t, 0.7));
  const d = Math.abs(px) / Math.max(half, 0.01);
  if (d > 1) return undefined;
  return [255, 255, 255, d > 0.8 ? 170 : 245];
});

// --- 1. the glow ---
const aura = kit.parked(kit.tex(465, 1), [0, 0.3, 0.2], 3.0, GLOW + RING);
setCurves(aura, grow(0.5, 0.3, 1.1), fadeInOut(0.55, 0.2, 0.75));
paint(aura, PALE_GOLD, WHITE, GOLD);
kit.add("aura", aura);

// --- 2. the trick: ring and sparkle ---
const ring = kit.parked(kit.tex(298, 2), BESIDE, 1.7, RING);
ring.startDelayFrames = GLOW;
setCurves(ring, grow(0.2, 0.25, 1.15), fadeInOut(1, 0.1, 0.75));
paint(ring, PALE_GOLD, WHITE, GOLD);
kit.add("ring", ring);

const sparkle = kit.parked(kit.tex(407, 1), BESIDE, 0.9, RING - 2);
sparkle.startDelayFrames = GLOW + 2;
spin(sparkle, 0.05, 0.05, deg(45));
setCurves(sparkle, { start: 0.2, mid: 1.3, end: 0.6, curveIn: 0.2, curveOut: 0.6 }, fadeInOut(1, 0.1, 0.7));
paint(sparkle, WHITE, WHITE, PALE_GOLD);
kit.add("sparkle", sparkle);

const specks = kit.spray([333, 1], kit.tex(333, 0), BESIDE, { radius: 1.2, speed: 0.02, count: 1, bursts: 6, gap: 3, life: 10, scale: 0.13, shape: "circle" });
specks.startDelayFrames = GLOW + 2;
setCurves(specks, undefined, twinkle());
kit.prism(specks, [WHITE, PALE_GOLD, GOLD]);
kit.add("specks", specks);

// --- 3. the spotlight on the foe ---
const SHOW = SPOT + DROP + AFTER;
const spotlight = kit.parked(spotTex, [0, 1.4, 0.5], 3.4, SHOW);
spotlight.aspectRatio = 0.75;
setCurves(spotlight, hold(1), fadeInOut(0.8, 0.1, 0.85));
paint(spotlight, SPOTLIGHT, WHITE, SPOTLIGHT);
kit.add("spotlight", spotlight);

const pool = kit.parked(kit.tex(298, 0), FOE_FLOOR, 2.0, SHOW);
pool.aspectRatio = 2.8;
setCurves(pool, grow(0.4, 0.2, 1.05), fadeInOut(0.75, 0.1, 0.85));
paint(pool, AMBER, GOLD, AMBER);
kit.add("pool", pool);

// --- 4. the bouquet drops in ---
const bouquet = kit.parked(bouquetTex, [0, FOE[1] + DROP_FROM, FOE[2]], 1.0, DROP);
bouquet.startDelayFrames = SPOT;
bouquet.axis = [0, -1, 0];
bouquet.initVelAxisAmplifier = DROP_FROM / DROP;
spin(bouquet, 0.06, 0.06, deg(-15));
setCurves(bouquet, hold(1), hold(1));
paint(bouquet, WHITE);
kit.add("bouquet", bouquet);

const trail = kit.spray([333, 1], kit.tex(333, 0), [0, FOE[1] + DROP_FROM * 0.6, FOE[2]], { radius: 0.5, speed: 0, count: 1, bursts: DROP, gap: 1, life: 10, scale: 0.13, shape: "ball" });
trail.startDelayFrames = SPOT;
trail.axis = [0, -1, 0];
trail.initVelAxisAmplifier = 0.2;
setCurves(trail, undefined, twinkle());
kit.prism(trail, [WHITE, MINT, PINK]);
kit.add("trail", trail);

// --- 5. the burst ---
const BURST_AT = SPOT + DROP;
const at = <T extends { startDelayFrames: number }>(r: T, extra = 0): T => { r.startDelayFrames = BURST_AT + extra; return r; };

const flash = at(kit.parked(kit.tex(228, 1), FOE, 1.8, 12));
spin(flash, 0.06);
setCurves(flash, grow(0.4, 0.2, 2.0), fadeOut(1, 0.35));
paint(flash, WHITE, WHITE, PALE_GOLD);
kit.add("flash", flash);

const spiky = at(kit.parked(kit.tex(579, 2), FOE, 2.0, 12));
spin(spiky, 0.1);
setCurves(spiky, grow(0.4, 0.25, 1.5), fadeOut(1, 0.4));
paint(spiky, YELLOW, WHITE, GOLD);
kit.add("spiky", spiky);

const rays = at(kit.spray([228, 3], kit.tex(321, 6), FOE, { radius: 0.3, speed: 0.55, count: 9, life: 9, scale: 0.6, directional: true }));
setCurves(rays, grow(1.2, 0.3, 0.6), fadeOut());
kit.prism(rays, [YELLOW, GOLD, WHITE]);
kit.add("rays", rays);

// --- 6. mist, confetti and sparkles ---
const mist = at(kit.spray([333, 1], kit.tex(321, 5), FOE, { radius: 1.0, speed: 0.08, count: 5, life: 24, scale: 1.2, shape: "ball" }), 2);
spin(mist, -0.04, 0.04, 0, true);
setCurves(mist, grow(0.5, 0.3, 1.5), fadeInOut(0.55, 0.15, 0.6));
paint(mist, GREEN_MIST, MINT, GREEN_MIST);
kit.add("mist", mist);

const confetti = at(kit.spray([333, 1], petalTex, FOE, { radius: 0.6, speed: 0.3, count: 7, bursts: 2, gap: 4, life: 24, scale: 0.3 }), 1);
confetti.axis = [0, 1, 0];
confetti.initVelAxisAmplifier = 0.1;
confetti.airResistance = 0.94;
confetti.behaviors = [{ type: "gravity", magnitude: [0, -0.008, 0] }];
spin(confetti, -0.2, 0.2, 0, true);
setCurves(confetti, hold(1), fadeOut(1, 0.65));
kit.prism(confetti, [PINK, YELLOW, SKY]);
kit.add("confetti", confetti);

const confetti2 = at(kit.spray([333, 1], petalTex, FOE, { radius: 0.6, speed: 0.26, count: 4, life: 22, scale: 0.28 }), 3);
confetti2.axis = [0, 1, 0];
confetti2.initVelAxisAmplifier = 0.12;
confetti2.airResistance = 0.94;
confetti2.behaviors = [{ type: "gravity", magnitude: [0, -0.008, 0] }];
spin(confetti2, -0.2, 0.2, 0, true);
setCurves(confetti2, hold(1), fadeOut(1, 0.65));
kit.prism(confetti2, [WHITE, LAVENDER, MINT]);
kit.add("confetti2", confetti2);

const stars = at(kit.spray([333, 1], kit.tex(407, 1), FOE, { radius: 1.8, speed: 0.01, count: 1, bursts: 8, gap: 3, life: 10, scale: 0.5, shape: "ball" }), 3);
setCurves(stars, twinkle(1.1), twinkle(1));
kit.prism(stars, [MAGENTA, WHITE, YELLOW]);
kit.add("stars", stars);

const streamer = at(kit.spray([228, 3], kit.tex(411, 0), FOE, { radius: 0.2, speed: 0, count: 1, life: 12, scale: 2.6, directional: true }), 4);
streamer.axis = [0.6, 1, 0];
streamer.initVelAxisAmplifier = 0.3;
streamer.behaviors = [{ type: "gravity", magnitude: [0, -0.03, 0] }];
setCurves(streamer, undefined, fadeInOut(1, 0.15, 0.6));
paint(streamer, WHITE, WHITE, PALE_GOLD);
kit.add("streamer", streamer);

// --- script ---
const emits = (names: string[], who: "ATTACKER" | "DEFENDER") => names.map((n) => kit.emit(n, who)).join("\n");
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1509, SE1, 14, 0, 300, 100, 0, 0, 0
PlaySound 1509, SE2, 14, ${GLOW}, 900, 115, 0, 0, 0
PlaySound 1509, SE2, 14, ${GLOW + 5}, 1300, 95, 0, 0, 0
PlaySound 1483, SE1, 14, ${GLOW + RING + PAN}, 0, 110, 0, 0, 0
PlaySound 1445, SE2, 16, ${GLOW + RING + PAN + SPOT}, 1200, 90, 0, 0, 0
PlaySound 1420, SE1, 16, ${GLOW + RING + PAN + BURST_AT}, 0, 120, 0, 0, 0
PlaySound 1497, SE2, 16, ${GLOW + RING + PAN + BURST_AT + 2}, 0, 110, 0, 0, 0
PlaySound 1509, SE1, 14, ${GLOW + RING + PAN + BURST_AT + 8}, 600, 100, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 9, 2, 31, 30, 20
${kit.emit("aura", "ATTACKER")}
Wait ${GLOW}
${emits(["ring", "sparkle", "specks"], "ATTACKER")}
Wait ${RING}
ChangeSpriteColor ATTACKER, 9, 0, 2, 31, 30, 20
MoveCamera INTERPOLATION, DEFENDER, ${PAN}, 0, 8
Wait ${PAN}
${emits(["spotlight", "pool", "bouquet", "trail", "flash", "spiky", "rays", "mist", "confetti", "confetti2", "stars", "streamer"], "DEFENDER")}
ChangeSpriteColor DEFENDER, 0, 6, 3, 31, 28, 18
Wait ${BURST_AT}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 6, 13, 0, 31, 30, 18
ScaleSprite DEFENDER, ROUNDTRIP, 1229, -1229, 3, 1, 1
ShakeSprite DEFENDER, 2, 1229, 0, 2, 1, 10
ShakeScreen VERTICAL, 0.5x, 0, 2, 0, 4
Wait 4
ChangeSpriteColor DEFENDER, 13, 0, 3, 31, 30, 18
Wait ${AFTER - 4}
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [129, 236, 400, 63, 153, 240],
  references: ["reference/Flower_Trick_IX.png","reference/Flower_Trick_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, `Emit ${SPA}, 1, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, ${kit.idx("bouquet")}, DEFENDER`, `Emit ${SPA}, ${kit.idx("spiky")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
const foeAt = CAMERA_IN + GLOW + RING + PAN;
console.log(`  glow f${CAMERA_IN}, ring f${CAMERA_IN + GLOW}, spotlight f${foeAt}, drop f${foeAt + SPOT}, burst f${foeAt + BURST_AT}`);
