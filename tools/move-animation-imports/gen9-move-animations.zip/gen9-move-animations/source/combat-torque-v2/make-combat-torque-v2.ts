import { buildTorque } from "../tools/torque-v2";

// Combat Torque (move 899), v2 - from Bulbapedia's stills (reference/).
//   1. Yellow-white fighting spirit blazes up round the Starmobile.
//   2. A yellow swirl on the ground round the foe, yellow and white spikes
//      and streaks bursting up and out.
// Shared structure in ../tools/torque-v2.ts. v1 is in ../combat-torque.
const YELLOW: [number, number, number] = [1.0, 0.9, 0.25];
const PALE: [number, number, number] = [1.0, 0.98, 0.75];
const GOLD: [number, number, number] = [1.0, 0.72, 0.15];
const ORANGE: [number, number, number] = [1.0, 0.55, 0.15];
const WHITE: [number, number, number] = [1, 1, 1];

await buildTorque({
  workDir: import.meta.dirname, slug: "combat-torque-v2", moveId: 899, spaId: 892,
  references: ["reference/Combat_Torque_IX.png", "reference/Combat_Torque_IX_2.png"],
  aura: [YELLOW, WHITE, GOLD], rising: "flame",
  vortex: [YELLOW, PALE, GOLD],
  fan: [YELLOW, WHITE, ORANGE],
  core: [WHITE, WHITE, YELLOW],
  extra: "streaks", extraColours: [WHITE, YELLOW, ORANGE],
  userTint: [31, 28, 12], foeTint: [31, 28, 10],
  revSounds: ["PlaySound 1421, SE2, 14, 6, -200, 110, 0, 0, 0"],
  hitSounds: ["PlaySound 1424, SE2, 16, 0, 0, 125, 0, 0, 0", "PlaySound 1475, SE1, 16, 4, -400, 110, 0, 0, 0"],
});
