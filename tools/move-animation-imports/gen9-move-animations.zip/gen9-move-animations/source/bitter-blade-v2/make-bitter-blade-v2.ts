import { aimed, createKit, deg, fadeInOut, fadeOut, grow, hold, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Bitter Blade (move 891), v2 - from Bulbapedia's stills (reference/).
//   1. The user is wreathed in blue-violet ghostly flames with pink
//      highlights, its blade glinting pink.
//   2. A diagonal blue slash and an icy blue spiky fire burst on the foe,
//      with a gold spark trail.
// It drains HP: blue flame wisps flow back to the user afterward (as in v1).
// v1 (../bitter-blade) is kept; reinstall its manifest to revert.

const SPA = 884;
const kit = await createKit({ workDir: import.meta.dirname, slug: "bitter-blade-v2", moveId: 891, spaId: SPA, donors: [321, 333, 579, 407, 465] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const IGNITE = 22;
const DASH = 8;
const SLASH_HOLD = 18;
const DRAIN = 12;
const HEAL = 16;

const USER_FEET: Vec3 = [0, -1.6, 0.2];
const BLADE: Vec3 = [0.8, 1.0, 0.2];
const FOE: Vec3 = [0, 0.3, 0.8];
const USER: Vec3 = [0, 0.2, 0.3];

const BLUE: Rgb = [0.35, 0.5, 1.0];
const VIOLET: Rgb = [0.6, 0.35, 1.0];
const PINK: Rgb = [1.0, 0.5, 0.85];
const CYAN: Rgb = [0.5, 0.9, 1.0];
const PALE_CYAN: Rgb = [0.85, 0.97, 1.0];
const GOLD: Rgb = [1.0, 0.85, 0.4];
const WHITE: Rgb = [1, 1, 1];

// --- ignite ---
const flames = kit.spray([228, 3], kit.tex(321, 6), USER_FEET, { radius: 1.0, speed: 0.02, count: 2, bursts: 10, gap: 2, life: 12, scale: 0.7, shape: "circle", directional: true });
flames.emissionAxis = 1;
flames.axis = [0, 1, 0];
flames.initVelAxisAmplifier = 0.22;
setCurves(flames, grow(0.6, 0.3, 1.3), fadeInOut(1, 0.2, 0.5));
kit.prism(flames, [BLUE, VIOLET, PINK]);
kit.add("flames", flames);

const wreath = kit.spray([333, 1], kit.tex(321, 5), [0, -0.6, 0.2], { radius: 0.9, speed: 0.02, count: 1, bursts: 8, gap: 3, life: 14, scale: 0.7, shape: "circle" });
wreath.emissionAxis = 1;
wreath.axis = [0, 1, 0];
wreath.initVelAxisAmplifier = 0.1;
spin(wreath, -0.06, 0.06, 0, true);
setCurves(wreath, grow(0.5, 0.3, 1.2), fadeInOut(0.7, 0.2, 0.5));
kit.prism(wreath, [BLUE, VIOLET, BLUE]);
kit.add("wreath", wreath);

const gleam = kit.parked(kit.tex(407, 1), BLADE, 0.7, 12);
gleam.startDelayFrames = IGNITE - 10;
spin(gleam, 0.08, 0.08, deg(45));
setCurves(gleam, twinkle(1.3), twinkle(1));
paint(gleam, WHITE, WHITE, PINK);
kit.add("gleam", gleam);

// --- the slash ---
const slash = kit.parked(kit.tex(333, 2), FOE, 2.4, 12);
slash.aspectRatio = 0.45;
slash.initAngle = deg(-40);
setCurves(slash, grow(0.2, 0.25, 1.05), fadeOut(1, 0.5));
paint(slash, CYAN, WHITE, BLUE);
kit.add("slash", slash);

const burst = kit.parked(kit.tex(579, 2), FOE, 1.4, 12);
spin(burst, 0.1);
setCurves(burst, grow(0.4, 0.25, 1.5), fadeOut(1, 0.35));
paint(burst, PALE_CYAN, WHITE, BLUE);
kit.add("burst", burst);

const shards = kit.spray([228, 3], kit.tex(321, 6), FOE, { radius: 0.3, speed: 0.55, count: 10, life: 10, scale: 0.55, directional: true });
setCurves(shards, grow(1.2, 0.3, 0.6), fadeOut());
kit.prism(shards, [CYAN, BLUE, WHITE]);
kit.add("shards", shards);

const goldTrail = kit.spray([333, 1], kit.tex(333, 0), [-0.6, 1.2, 0.8], { radius: 0.4, speed: 0.06, count: 2, bursts: 5, gap: 2, life: 14, scale: 0.12 });
goldTrail.behaviors = [{ type: "gravity", magnitude: [0, -0.008, 0] }];
setCurves(goldTrail, undefined, twinkle());
paint(goldTrail, GOLD, WHITE, GOLD);
kit.add("goldTrail", goldTrail);

// --- drain ---
const wisps = kit.spray([333, 1], kit.tex(465, 1), FOE, { radius: 0.6, speed: 0.02, count: 1, bursts: 5, gap: 2, life: DRAIN + 2, scale: 0.45 });
aimed(wisps, 1.4, DRAIN + 2);
setCurves(wisps, hold(1), fadeInOut(1, 0.15, 0.85));
kit.prism(wisps, [BLUE, CYAN, VIOLET]);
kit.add("wisps", wisps);

const heal = kit.spray([333, 1], kit.tex(465, 1), USER, { radius: 1.2, speed: 0, count: 1, bursts: 6, gap: 2, life: 12, scale: 0.4, shape: "ball" });
heal.axis = [0, 1, 0];
heal.initVelAxisAmplifier = 0.06;
setCurves(heal, undefined, fadeInOut(0.9, 0.2, 0.6));
paint(heal, CYAN, PALE_CYAN, BLUE);
kit.add("heal", heal);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1425, SE1, 14, 0, -600, 110, 0, 0, 0
PlaySound 1467, SE2, 14, 4, 0, 90, 0, 0, 0
PlaySound 1509, SE2, 14, ${IGNITE - 8}, 800, 80, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 2, 12, 14, 31
${kit.emit("flames", "ATTACKER")}
${kit.emit("wreath", "ATTACKER")}
${kit.emit("gleam", "ATTACKER")}
Wait ${IGNITE}
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 8, 0, 1, 12, 14, 31
MoveCamera INTERPOLATION, DEFENDER, ${DASH}, 0, 8
Wait ${DASH}
AudioContainer CONTINUE
PlaySound 1514, SE1, 16, 0, 0, 125, 0, 0, 0
PlaySound 1426, SE2, 16, 2, 0, 110, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("slash", "DEFENDER")}
${kit.emit("burst", "DEFENDER")}
${kit.emit("shards", "DEFENDER")}
${kit.emit("goldTrail", "DEFENDER")}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 14, 20, 31
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
Wait 6
ChangeSpriteColor DEFENDER, 12, 0, 1, 14, 20, 31
Wait ${SLASH_HOLD - 6}
ToggleFreezeSprite DEFENDER, STOP
AudioContainer CONTINUE
PlaySound 1474, SE1, 14, 0, 0, 90, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 16, ${DRAIN}, 0, -50, 0, 0
AudioContainer SUSPEND
${kit.emit("wisps", "DEFENDER", "ATTACKER")}
MoveCamera INTERPOLATION, ATTACKER, ${DRAIN}, 0, 8
Wait ${DRAIN}
AudioContainer CONTINUE
PlaySound 1784, SE2, 14, 0, 0, 100, 0, 0, 0
AudioContainer SUSPEND
${kit.emit("heal", "ATTACKER")}
ChangeSpriteColor ATTACKER, 0, 10, 2, 16, 26, 31
Wait 8
ChangeSpriteColor ATTACKER, 10, 0, 2, 16, 26, 31
Wait ${HEAL - 8}
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

await kit.finish({
  script,
  donorMoveIds: [153, 163, 400, 236, 605, 53, 261, 381],
  references: ["reference/Bitter_Blade_IX.png", "reference/Bitter_Blade_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, `Emit ${SPA}, 0, ATTACKER`, "MoveCamera INTERPOLATION, DEFENDER", `Emit ${SPA}, 3, DEFENDER`, `Emit ${SPA}, 7, DEFENDER, ATTACKER`, `Emit ${SPA}, 8, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
console.log(`  ignite f${CAMERA_IN}-${CAMERA_IN + IGNITE}, slash f${CAMERA_IN + IGNITE + DASH}, heal f${CAMERA_IN + IGNITE + DASH + SLASH_HOLD + DRAIN}`);
