MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 884
AudioContainer CONTINUE
PlaySound 1425, SE1, 14, 0, -600, 110, 0, 0, 0
PlaySound 1467, SE2, 14, 4, 0, 90, 0, 0, 0
PlaySound 1509, SE2, 14, 14, 800, 80, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 8, 2, 12, 14, 31
Emit 884, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 884, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 884, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 22
MoveSprite ATTACKER, ROUNDTRIP, 0, 0, 3px, 49152, 0, 4096, 0
ChangeSpriteColor ATTACKER, 8, 0, 1, 12, 14, 31
MoveCamera INTERPOLATION, DEFENDER, 8, 0, 8
Wait 8
AudioContainer CONTINUE
PlaySound 1514, SE1, 16, 0, 0, 125, 0, 0, 0
PlaySound 1426, SE2, 16, 2, 0, 110, 0, 0, 0
AudioContainer SUSPEND
Emit 884, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 884, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 884, 5, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 884, 6, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 0, 14, 20, 31
ShakeSprite DEFENDER, 2, 1638, 0, 2, 1, 10
Wait 6
ChangeSpriteColor DEFENDER, 12, 0, 1, 14, 20, 31
Wait 12
ToggleFreezeSprite DEFENDER, STOP
AudioContainer CONTINUE
PlaySound 1474, SE1, 14, 0, 0, 90, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 16, 12, 0, -50, 0, 0
AudioContainer SUSPEND
Emit 884, 7, DEFENDER, ATTACKER, 2px, 0, 0, 1x, 1x, 1x, 1x
MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
Wait 12
AudioContainer CONTINUE
PlaySound 1784, SE2, 14, 0, 0, 100, 0, 0, 0
AudioContainer SUSPEND
Emit 884, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ChangeSpriteColor ATTACKER, 0, 10, 2, 16, 26, 31
Wait 8
ChangeSpriteColor ATTACKER, 10, 0, 2, 16, 26, 31
Wait 8
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
