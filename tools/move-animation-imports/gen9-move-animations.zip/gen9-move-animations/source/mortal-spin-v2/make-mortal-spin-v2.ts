import { assert, createKit, fadeInOut, fadeOut, grow, paint, setCurves, spin, type Rgb, type Vec3 } from "../tools/anim-kit";

// Mortal Spin (move 866), v2 - third pass, to Logan's brief (2026-10-01):
// "Take Hurricane's tornadoes that it spawns on the target, and instead spawn
// them on top of the user. Make them look poisonous-ish, and only use one
// tornado, but make it much wider, then spawn the same thing on the target,
// dealing damage."
//
// Hurricane (SPA 711) builds each tornado from three resources on an
// EmitCircle emitter that orbits the target: two stacks of crescent wind
// swooshes (res 2 and 4) that follow the emitter, rise and grow, and a ring
// of cloud debris (res 1) circling it. Retail spawns four of them, 20 frames
// apart, orbiting 2px out. Here there is ONE, about twice as wide and packed
// denser, orbiting only 0.5px out so it sits on the Pokemon, tinted purple
// and magenta - first on the user, then the same on the target.
// The hazard clearing and poisoning are handled by the engine.
// v1 (../mortal-spin, from the Bulbapedia still) is kept; reinstall its
// manifest to revert.

const SPA = 923;
const kit = await createKit({ workDir: import.meta.dirname, slug: "mortal-spin-v2", moveId: 866, spaId: SPA, donors: [711, 465, 579] });

// --- timing (30 fps) ---
const CAMERA_IN = 12;
const USER_TORNADO = 30; // on the user before the camera leaves
const PAN = 10;
const TARGET_AT = 4; // into the pan, the target's tornado starts
const HITS_AT = 6; // after it starts, the foe is being hit
const TARGET_TORNADO = 40;

const WIDEN = 2.0;
const ORBIT = "0.5px"; // retail Hurricane: 2px

const LAVENDER: Rgb = [0.92, 0.8, 1.0];
const VIOLET: Rgb = [0.68, 0.3, 1.0];
const PURPLE: Rgb = [0.55, 0.14, 0.82];
const MAGENTA: Rgb = [0.95, 0.25, 0.9];
const PINK: Rgb = [1.0, 0.55, 0.88];
const WHITE: Rgb = [1, 1, 1];

// --- the tornado (used for both the user and the target) ---
function swooshes(index: number, opts: { delay: number; emitFor: number; every: number; life: number; colour: Rgb; start: Rgb; end: Rgb }): ReturnType<typeof kit.shell> {
  const r = kit.shell(711, index);
  assert.ok(r.followEmitter, `Hurricane res ${index} no longer follows its emitter`);
  r.textureIndex = kit.tex(711, r.textureIndex);
  Object.assign(r, { baseScale: r.baseScale * WIDEN, startDelayFrames: opts.delay, emitterLifeFrames: opts.emitFor, emissionIntervalFrames: opts.every, particleLifeFrames: opts.life });
  paint(r, opts.colour, opts.start, opts.end, 0.5);
  return r;
}
// Retail: res 2 emits every 5 frames for 40, life 38; res 4 every 6 for 40 (from frame 12), life 60.
const inner = swooshes(2, { delay: 0, emitFor: 20, every: 3, life: 26, colour: VIOLET, start: LAVENDER, end: PURPLE });
kit.add("inner", inner);
const outer = swooshes(4, { delay: 4, emitFor: 18, every: 4, life: 28, colour: MAGENTA, start: LAVENDER, end: VIOLET });
kit.add("outer", outer);

const debris = kit.shell(711, 1);
debris.textureIndex = kit.tex(711, debris.textureIndex);
debris.texAnim!.textures = debris.texAnim!.textures.map((t, i) => (i < debris.texAnim!.textureCount ? kit.tex(711, t) : 0));
Object.assign(debris, { radius: debris.radius * WIDEN, baseScale: debris.baseScale * 1.2, emitterLifeFrames: 24, particleLifeFrames: 28 });
debris.color = [...PURPLE];
kit.add("debris", debris);

// Poison bubbles whirled up inside it.
function bubbles(pos: Vec3): ReturnType<typeof kit.spray> {
  const r = kit.spray([333, 1], kit.tex(465, 1), pos, { radius: 1.5, speed: 0.03, count: 1, bursts: 8, gap: 3, life: 18, scale: 0.4, shape: "circle" });
  r.emissionAxis = 1;
  r.axis = [0, 1, 0];
  r.initVelAxisAmplifier = 0.18;
  r.behaviors = [{ type: "spin", axis: 1, angle: 0.45 }];
  setCurves(r, grow(0.5, 0.2, 1), fadeInOut(1, 0.15, 0.7));
  kit.prism(r, [PURPLE, VIOLET, MAGENTA]);
  return r;
}
kit.add("bubbles", bubbles([0, -1.3, 0]));

// --- the damage on the target ---
const pops = kit.spray([333, 1], kit.tex(579, 2), [0, 0.3, 0.8], { radius: 0.7, speed: 0, count: 1, bursts: 3, gap: 7, life: 9, scale: 1.1, shape: "ball" });
spin(pops, -0.1, 0.1, 0, true);
setCurves(pops, { start: 0.3, mid: 1.1, end: 1.3, curveIn: 0.25, curveOut: 0.5 }, fadeOut(1, 0.45));
kit.prism(pops, [MAGENTA, PINK, WHITE]);
kit.add("pops", pops);

// --- script ---
const tornado = (centre: "ATTACKER_LEFT" | "DEFENDER_LEFT") =>
  ["inner", "outer", "debris"].map((n) => `EmitCircle ${SPA}, ${kit.idx(n)}, ${centre}, ${ORBIT}, ${ORBIT}, -1px, 120, 0, 1, 0`).join("\n");
const targetAt = USER_TORNADO + TARGET_AT;
const hitsAt = targetAt + HITS_AT;
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1919, SE1, 16, 0, 0, 120, 70, 20, 0
PlaySound 1446, SE2, 14, 6, 0, 95, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, ${USER_TORNADO + PAN}, 0, 50, 0, 0
PlaySound 1420, SE2, 16, ${hitsAt}, -200, 115, 0, 0, 0
PlaySound 1420, SE2, 16, ${hitsAt + 7}, 0, 110, 0, 0, 0
PlaySound 1420, SE2, 16, ${hitsAt + 14}, 200, 115, 0, 0, 0
PlaySound 1376, SE1, 16, ${targetAt + TARGET_TORNADO + 10}, 0, 0, 100, 20, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 1, 6, 0, 8
ChangeSpriteColor ATTACKER, 0, 8, 3, 22, 8, 28
${tornado("ATTACKER_LEFT")}
${kit.emit("bubbles", "ATTACKER")}
ShakeSprite ATTACKER, 2, 1229, 0, 2, 0, 12
Wait ${USER_TORNADO}
ChangeSpriteColor ATTACKER, 8, 0, 3, 22, 8, 28
MoveCamera INTERPOLATION, DEFENDER, ${PAN}, 0, 8
Wait ${TARGET_AT}
${tornado("DEFENDER_LEFT")}
${kit.emit("bubbles", "DEFENDER")}
Wait ${HITS_AT}
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 2, 24, 6, 28
ShakeSprite DEFENDER, 2, 2px, 0, 6, 0, 5
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 4, 2, 3
${kit.emit("pops", "DEFENDER")}
Wait ${TARGET_TORNADO - HITS_AT - 8}
ChangeSpriteColor DEFENDER, 12, 0, 3, 24, 6, 28
Wait 8
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 8, 0, 1, 6, 0, 8
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

const { built } = await kit.finish({
  script,
  donorMoveIds: [542, 63, 400],
  references: ["reference/Mortal_Spin_IX.png"],
  expectText: [`LoadSPA ${SPA}`, `EmitCircle ${SPA}, 0, ATTACKER_LEFT`, `EmitCircle ${SPA}, 1, ATTACKER_LEFT`, "MoveCamera INTERPOLATION, DEFENDER", `EmitCircle ${SPA}, 0, DEFENDER_LEFT`, `Emit ${SPA}, ${kit.idx("pops")}, DEFENDER`, "MoveCamera INTERPOLATION, INIT"],
});
const retail = kit.spa(711).resources;
assert.ok(built("inner").baseScale > retail[2]!.baseScale * 1.8 && built("outer").baseScale > retail[4]!.baseScale * 1.8, "Tornado is not much wider than Hurricane's");
assert.equal((script.match(/EmitCircle/g) ?? []).length, 6, "More than one tornado per side");
console.log(`  user tornado f${CAMERA_IN}, target tornado f${CAMERA_IN + targetAt}, hits f${CAMERA_IN + hitsAt}/${CAMERA_IN + hitsAt + 7}/${CAMERA_IN + hitsAt + 14}`);
