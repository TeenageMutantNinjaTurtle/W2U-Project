MoveCamera INTERPOLATION, ATTACKER, 12, 0, 8
LetCMDsFinish CAMERA
LoadSPA 923
AudioContainer CONTINUE
PlaySound 1919, SE1, 16, 0, 0, 120, 70, 20, 0
PlaySound 1446, SE2, 14, 6, 0, 95, 0, 0, 0
SwitchAudioSide SE1, INTERPOLATION, 14, 40, 0, 50, 0, 0
PlaySound 1420, SE2, 16, 40, -200, 115, 0, 0, 0
PlaySound 1420, SE2, 16, 47, 0, 110, 0, 0, 0
PlaySound 1420, SE2, 16, 54, 200, 115, 0, 0, 0
PlaySound 1376, SE1, 16, 84, 0, 0, 100, 20, 0
AudioContainer SUSPEND
ChangeBackgroundColor 4, 0, 8, 1, 6, 0, 8
ChangeSpriteColor ATTACKER, 0, 8, 3, 22, 8, 28
EmitCircle 923, 0, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 923, 1, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 923, 2, ATTACKER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
Emit 923, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
ShakeSprite ATTACKER, 2, 1229, 0, 2, 0, 12
Wait 30
ChangeSpriteColor ATTACKER, 8, 0, 3, 22, 8, 28
MoveCamera INTERPOLATION, DEFENDER, 10, 0, 8
Wait 4
EmitCircle 923, 0, DEFENDER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 923, 1, DEFENDER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
EmitCircle 923, 2, DEFENDER_LEFT, 0.5px, 0.5px, -1px, 120, 0, 1, 0
Emit 923, 3, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 6
ToggleFreezeSprite DEFENDER, START
ChangeSpriteColor DEFENDER, 0, 12, 2, 24, 6, 28
ShakeSprite DEFENDER, 2, 2px, 0, 6, 0, 5
ScaleSprite DEFENDER, ROUNDTRIP, -1229, 1229, 4, 2, 3
Emit 923, 4, DEFENDER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 26
ChangeSpriteColor DEFENDER, 12, 0, 3, 24, 6, 28
Wait 8
LetCMDsFinish PARTICLE
ToggleFreezeSprite DEFENDER, STOP
ChangeBackgroundColor 4, 8, 0, 1, 6, 0, 8
MoveCamera INTERPOLATION, INIT, 12, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
