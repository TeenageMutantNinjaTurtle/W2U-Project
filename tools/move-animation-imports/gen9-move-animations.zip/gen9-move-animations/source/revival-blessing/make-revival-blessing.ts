import { assert, createKit, fadeInOut, fadeOut, grow, paint, setCurves, spin, twinkle, type Rgb, type Vec3 } from "../tools/anim-kit";

// Revival Blessing (move 863) - from Bulbapedia's stills (reference/).
//   1. The user is bathed in white-cream light: fine mint and white glitter,
//      white light streaks crossing over it, four-point sparkles, mint orbs.
//   2. A big glowing mint-cyan ring spreads across the ground round the
//      user, pale light swirling round it, sparkles rising, a warm glow inside.
// Status move: everything plays on the user.
//
// Textures: Lucky Chant's hoop (ground ring), Swift's soft disc and sparkle,
// Psycho Cut's crescent (swirling light), Rain Dance's hair streak (light
// streaks), Dazzling Gleam's fuzzy glow (orbs), Slash's glow dot (glitter).

const SPA = 857;
const kit = await createKit({ workDir: import.meta.dirname, slug: "revival-blessing", moveId: 863, spaId: SPA, donors: [560, 298, 606, 411, 465] });

// --- timing (30 fps) ---
const CAMERA_IN = 14;
const GLOW = 60; // whole blessing on screen
const RING_AT = 16; // ground ring spreads once the light has gathered

const BODY: Vec3 = [0, 0.2, 0.3]; // on the user, camera side
const GROUND: Vec3 = [0, -2.1, 0];

const MINT: Rgb = [0.55, 1.0, 0.85];
const CYAN: Rgb = [0.5, 0.95, 1.0];
const PALE_MINT: Rgb = [0.88, 1.0, 0.95];
const CREAM: Rgb = [1.0, 0.98, 0.82];
const PALE_YELLOW: Rgb = [1.0, 0.95, 0.6];
const WHITE: Rgb = [1, 1, 1];

const hoopTex = kit.tex(560, 1);
const discTex = kit.tex(298, 0);
const sparkleTex = kit.tex(298, 1);

// --- light on the user ---
const warm = kit.parked(discTex, BODY, 1.6, GLOW);
setCurves(warm, grow(0.4, 0.3, 1.1), fadeInOut(0.5, 0.25, 0.8));
paint(warm, CREAM, WHITE, PALE_YELLOW);
kit.add("warm", warm);

const glitter = kit.spray([333, 1], kit.tex(333, 0), BODY, { radius: 1.6, speed: 0.02, count: 2, bursts: 20, gap: 2, life: 12, scale: 0.12, shape: "ball" });
setCurves(glitter, undefined, twinkle());
kit.prism(glitter, [WHITE, MINT, PALE_MINT]);
kit.add("glitter", glitter);

// White light streaks crossing over the user.
const streaks = kit.spray([228, 3], kit.tex(411, 0), BODY, { radius: 0.6, speed: 0.22, count: 1, bursts: 8, gap: 4, life: 10, scale: 1.6, directional: true });
streaks.startDelayFrames = 4;
setCurves(streaks, undefined, fadeInOut(0.95, 0.25, 0.5));
paint(streaks, WHITE, WHITE, PALE_MINT);
kit.add("streaks", streaks);

const sparkles = kit.spray([333, 1], sparkleTex, BODY, { radius: 1.5, speed: 0.01, count: 1, bursts: 12, gap: 4, life: 14, scale: 0.4, shape: "ball" });
spin(sparkles, 0.05, 0.05, 0, true);
setCurves(sparkles, twinkle(1), twinkle(1));
paint(sparkles, WHITE, WHITE, PALE_MINT);
kit.add("sparkles", sparkles);

// --- the ground ring ---
function ring(scale: number, delay: number, colour: Rgb, level: number): ReturnType<typeof kit.parked> {
  const r = kit.parked(hoopTex, GROUND, scale, GLOW - delay);
  r.aspectRatio = 3.4;
  r.startDelayFrames = delay;
  setCurves(r, grow(0.2, 0.3, 1.05), fadeInOut(level, 0.15, 0.8));
  paint(r, colour, WHITE, colour);
  return r;
}
kit.add("ring", ring(2.4, RING_AT, CYAN, 0.95));
kit.add("ringInner", ring(1.2, RING_AT + 6, MINT, 0.8));

const pool = kit.parked(discTex, GROUND, 2.2, GLOW - RING_AT);
pool.aspectRatio = 3.4;
pool.startDelayFrames = RING_AT;
setCurves(pool, grow(0.2, 0.3, 1.05), fadeInOut(0.45, 0.2, 0.8));
paint(pool, PALE_YELLOW, CREAM, MINT);
kit.add("pool", pool);

// Pale light swirling round the user above the ring.
const swirl = kit.parked(kit.tex(606, 3), [0, -0.6, 0.2], 2.0, GLOW - RING_AT);
swirl.emissionCount = 3;
swirl.startDelayFrames = RING_AT + 4;
swirl.aspectRatio = 1.8;
spin(swirl, -0.12, -0.07, 0, true);
setCurves(swirl, grow(0.6, 0.3, 1.1), fadeInOut(0.7, 0.25, 0.7));
paint(swirl, PALE_MINT, WHITE, CYAN);
kit.add("swirl", swirl);

// Sparkles and mint orbs rising off the ring.
const rising = kit.spray([333, 1], sparkleTex, GROUND, { radius: 2.0, speed: 0, count: 1, bursts: 12, gap: 3, life: 18, scale: 0.3, shape: "circle" });
rising.emissionAxis = 1;
rising.axis = [0, 1, 0];
rising.initVelAxisAmplifier = 0.16;
rising.startDelayFrames = RING_AT + 2;
setCurves(rising, twinkle(1), twinkle(1));
paint(rising, WHITE, WHITE, PALE_MINT);
kit.add("rising", rising);

const orbs = kit.spray([333, 1], kit.tex(465, 1), GROUND, { radius: 1.6, speed: 0, count: 1, bursts: 6, gap: 5, life: 22, scale: 0.4, shape: "circle" });
orbs.emissionAxis = 1;
orbs.axis = [0, 1, 0];
orbs.initVelAxisAmplifier = 0.12;
orbs.startDelayFrames = RING_AT + 4;
setCurves(orbs, grow(0.5, 0.3, 0.8), fadeInOut(0.9, 0.2, 0.6));
paint(orbs, MINT, PALE_MINT, CYAN);
kit.add("orbs", orbs);

// --- script ---
const script = `MoveCamera INTERPOLATION, ATTACKER, ${CAMERA_IN}, 0, 8
LetCMDsFinish CAMERA
LoadSPA ${SPA}
AudioContainer CONTINUE
PlaySound 1474, SE1, 14, 0, 0, 90, 0, 0, 0
PlaySound 1784, SE2, 14, ${RING_AT}, 0, 110, 0, 0, 0
PlaySound 1509, SE1, 14, ${RING_AT + 20}, 400, 90, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 2, 31, 31, 28
${kit.emit("warm", "ATTACKER")}
${kit.emit("glitter", "ATTACKER")}
${kit.emit("streaks", "ATTACKER")}
${kit.emit("sparkles", "ATTACKER")}
${kit.emit("ring", "ATTACKER")}
${kit.emit("ringInner", "ATTACKER")}
${kit.emit("pool", "ATTACKER")}
${kit.emit("swirl", "ATTACKER")}
${kit.emit("rising", "ATTACKER")}
${kit.emit("orbs", "ATTACKER")}
Wait ${GLOW - 14}
ChangeSpriteColor ATTACKER, 10, 0, 1, 31, 31, 28
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
`;

const { built } = await kit.finish({
  script,
  donorMoveIds: [381, 129, 427, 240, 605, 163],
  references: ["reference/Revival_Blessing_IX.png", "reference/Revival_Blessing_IX_2.png"],
  expectText: [`LoadSPA ${SPA}`, "ChangeSpriteColor ATTACKER, 0, 10, 2, 31, 31, 28", `Emit ${SPA}, 4, ATTACKER`, "MoveCamera INTERPOLATION, INIT"],
});
assert.ok(built("ring").aspectRatio > 3 && built("ring").emitterBasePos[1] < -1.8, "Ring is not flat on the ground");
assert.equal(built("ring").startDelayFrames, RING_AT, "Ring timing drifted");
console.log(`  blessing f${CAMERA_IN}-${CAMERA_IN + GLOW}, ring spreads f${CAMERA_IN + RING_AT}`);
