MoveCamera INTERPOLATION, ATTACKER, 14, 0, 8
LetCMDsFinish CAMERA
LoadSPA 857
AudioContainer CONTINUE
PlaySound 1474, SE1, 14, 0, 0, 90, 0, 0, 0
PlaySound 1784, SE2, 14, 16, 0, 110, 0, 0, 0
PlaySound 1509, SE1, 14, 36, 400, 90, 0, 0, 0
AudioContainer SUSPEND
ChangeSpriteColor ATTACKER, 0, 10, 2, 31, 31, 28
Emit 857, 0, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 857, 1, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 857, 2, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 857, 3, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 857, 4, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 857, 5, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 857, 6, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 857, 7, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 857, 8, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Emit 857, 9, ATTACKER, NONE, 2px, 0, 0, 1x, 1x, 1x, 1x
Wait 46
ChangeSpriteColor ATTACKER, 10, 0, 1, 31, 31, 28
LetCMDsFinish PARTICLE
MoveCamera INTERPOLATION, INIT, 14, 0, 8
LetCMDsFinish ALL
TerminateMoveScript
